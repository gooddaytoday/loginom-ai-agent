#![warn(unused_must_use)]

// Shared by Linux/Darwin/FreeBSD: libc syscall wrappers signal failure with the
// same-width all-ones sentinel (`-1` signed / `MAX` unsigned) and stash the
// real errno in a thread-local. Only the
// per-OS INVOCATION lists differ: notably Linux keeps a bespoke `usize` impl
// that decodes raw-syscall `-errno`-in-retval and MUST NOT route through this.
// Declared before the `mod` lines so textual-order macro visibility reaches them.
#[cfg(not(windows))]
macro_rules! impl_get_errno_libc {
    ($($t:ty),+ $(,)?) => {$(
        impl $crate::GetErrno for $t {
            #[inline]
            fn get_errno(self) -> $crate::E {
                // `as i64` would zero-extend u32, never matching -1. Compare
                // against the type's own all-ones value instead (== -1 for
                // signed, == MAX for unsigned — both are libc's failure rc).
                if self == !(0 as $t) {
                    $crate::last_error()
                } else {
                    $crate::E::SUCCESS
                }
            }
        }
    )+};
}

// ──────────────────────────────────────────────────────────────────────────
// __decl_uv_e! — single source of truth for the per-OS `uv_e` table.
//
// Each per-OS errno module invokes this once with `(IDENT = value => "DISPLAY")`
// rows. The macro emits BOTH directions:
//   • forward  : `pub const IDENT: i32 = value;`
//   • reverse  : `pub fn name(neg_uv_err) -> Option<&'static str>`
//
// The reverse map additionally hard-codes the libuv-synthetic codes that are
// target-INDEPENDENT and have no `uv_e::*` const today (`EOF`, `UNKNOWN`,
// `EAI_*`). Node's `util.getSystemErrorName()` requires them; without this the
// JS-visible result for `-4095` would regress to `"Unknown system error -4095"`.
// ──────────────────────────────────────────────────────────────────────────
#[macro_export]
#[doc(hidden)]
macro_rules! __decl_uv_e {
    ( $( $ident:ident = $value:expr => $display:literal ),+ $(,)? ) => {
        $( pub const $ident: i32 = $value; )+

        /// Full (negated code, name) table: libuv-synthetic codes (vendor/libuv/include/uv/errno.h)
        /// first, then per-OS rows. Consumed by `name()` and node:util `getSystemErrorMap()`.
        pub static ENTRIES: &[(i32, &'static str)] = &[
            (-4095, "EOF"),
            (-4094, "UNKNOWN"),
            (-3000, "EAI_ADDRFAMILY"),
            (-3001, "EAI_AGAIN"),
            (-3002, "EAI_BADFLAGS"),
            (-3003, "EAI_CANCELED"),
            (-3004, "EAI_FAIL"),
            (-3005, "EAI_FAMILY"),
            (-3006, "EAI_MEMORY"),
            (-3007, "EAI_NODATA"),
            (-3008, "EAI_NONAME"),
            (-3009, "EAI_OVERFLOW"),
            (-3010, "EAI_SERVICE"),
            (-3011, "EAI_SOCKTYPE"),
            (-3013, "EAI_BADHINTS"),
            (-3014, "EAI_PROTOCOL"),
            $( (-($ident), $display) ),+
        ];

        /// Negated libuv error code (`-UV_E*`) → user-visible name. `None` for unmapped values.
        /// First match wins, mirroring the old `if`-chain's duplicate tolerance (EAGAIN aliases).
        pub fn name(neg_uv_err: i32) -> Option<&'static str> {
            for &(code, name) in ENTRIES {
                if code == neg_uv_err {
                    return Some(name);
                }
            }
            None
        }
    };
}

// ──────────────────────────────────────────────────────────────────────────
// __uv_e_rows! — single source of truth for the 69 `(IDENT, E*, UV_E*)` rows
// that every per-OS `uv_e` module declares.
//
// The (IDENT, "E…") column pair is byte-for-byte identical across
// linux/darwin/freebsd/windows; only the middle `i32` value differs by design
// (native `SystemErrno::$e as i32` on POSIX vs libuv-synthetic
// `-bun_libuv_sys::UV_E*` on Windows / for codes the host OS lacks). Rather
// than re-list the rows 4×, the caller supplies a tiny *value-producer* macro
// `$cb!($id, $e, $uv) -> i32-expr` and this forwards each row to the existing
// `__decl_uv_e!` expander (consts + reverse `name()` fn).
//
// `$id`/`$e`/`$uv` are passed as **literal** tokens (never captured as
// `:ident`), so the per-OS `$cb` can override individual rows by literal-token
// match — e.g. `(CHARSET, $e:tt, $uv:tt) => { -::bun_libuv_sys::$uv }` — while
// a final `($i:tt, $e:tt, $uv:tt)` arm handles the native default.
// ──────────────────────────────────────────────────────────────────────────
#[macro_export]
#[doc(hidden)]
macro_rules! __uv_e_rows {
    ($cb:ident) => {
        $crate::__decl_uv_e! {
            // Rust idents can't start with a digit → `_2BIG`.
            _2BIG          = $cb!(_2BIG,          E2BIG,           UV_E2BIG)           => "E2BIG",
            ACCES          = $cb!(ACCES,          EACCES,          UV_EACCES)          => "EACCES",
            ADDRINUSE      = $cb!(ADDRINUSE,      EADDRINUSE,      UV_EADDRINUSE)      => "EADDRINUSE",
            ADDRNOTAVAIL   = $cb!(ADDRNOTAVAIL,   EADDRNOTAVAIL,   UV_EADDRNOTAVAIL)   => "EADDRNOTAVAIL",
            AFNOSUPPORT    = $cb!(AFNOSUPPORT,    EAFNOSUPPORT,    UV_EAFNOSUPPORT)    => "EAFNOSUPPORT",
            AGAIN          = $cb!(AGAIN,          EAGAIN,          UV_EAGAIN)          => "EAGAIN",
            ALREADY        = $cb!(ALREADY,        EALREADY,        UV_EALREADY)        => "EALREADY",
            BADF           = $cb!(BADF,           EBADF,           UV_EBADF)           => "EBADF",
            BUSY           = $cb!(BUSY,           EBUSY,           UV_EBUSY)           => "EBUSY",
            CANCELED       = $cb!(CANCELED,       ECANCELED,       UV_ECANCELED)       => "ECANCELED",
            CHARSET        = $cb!(CHARSET,        ECHARSET,        UV_ECHARSET)        => "ECHARSET",
            CONNABORTED    = $cb!(CONNABORTED,    ECONNABORTED,    UV_ECONNABORTED)    => "ECONNABORTED",
            CONNREFUSED    = $cb!(CONNREFUSED,    ECONNREFUSED,    UV_ECONNREFUSED)    => "ECONNREFUSED",
            CONNRESET      = $cb!(CONNRESET,      ECONNRESET,      UV_ECONNRESET)      => "ECONNRESET",
            DESTADDRREQ    = $cb!(DESTADDRREQ,    EDESTADDRREQ,    UV_EDESTADDRREQ)    => "EDESTADDRREQ",
            EXIST          = $cb!(EXIST,          EEXIST,          UV_EEXIST)          => "EEXIST",
            FAULT          = $cb!(FAULT,          EFAULT,          UV_EFAULT)          => "EFAULT",
            HOSTUNREACH    = $cb!(HOSTUNREACH,    EHOSTUNREACH,    UV_EHOSTUNREACH)    => "EHOSTUNREACH",
            INTR           = $cb!(INTR,           EINTR,           UV_EINTR)           => "EINTR",
            INVAL          = $cb!(INVAL,          EINVAL,          UV_EINVAL)          => "EINVAL",
            IO             = $cb!(IO,             EIO,             UV_EIO)             => "EIO",
            ISCONN         = $cb!(ISCONN,         EISCONN,         UV_EISCONN)         => "EISCONN",
            ISDIR          = $cb!(ISDIR,          EISDIR,          UV_EISDIR)          => "EISDIR",
            LOOP           = $cb!(LOOP,           ELOOP,           UV_ELOOP)           => "ELOOP",
            MFILE          = $cb!(MFILE,          EMFILE,          UV_EMFILE)          => "EMFILE",
            MSGSIZE        = $cb!(MSGSIZE,        EMSGSIZE,        UV_EMSGSIZE)        => "EMSGSIZE",
            NAMETOOLONG    = $cb!(NAMETOOLONG,    ENAMETOOLONG,    UV_ENAMETOOLONG)    => "ENAMETOOLONG",
            NETDOWN        = $cb!(NETDOWN,        ENETDOWN,        UV_ENETDOWN)        => "ENETDOWN",
            NETUNREACH     = $cb!(NETUNREACH,     ENETUNREACH,     UV_ENETUNREACH)     => "ENETUNREACH",
            NFILE          = $cb!(NFILE,          ENFILE,          UV_ENFILE)          => "ENFILE",
            NOBUFS         = $cb!(NOBUFS,         ENOBUFS,         UV_ENOBUFS)         => "ENOBUFS",
            NODEV          = $cb!(NODEV,          ENODEV,          UV_ENODEV)          => "ENODEV",
            NOENT          = $cb!(NOENT,          ENOENT,          UV_ENOENT)          => "ENOENT",
            NOMEM          = $cb!(NOMEM,          ENOMEM,          UV_ENOMEM)          => "ENOMEM",
            NONET          = $cb!(NONET,          ENONET,          UV_ENONET)          => "ENONET",
            NOSPC          = $cb!(NOSPC,          ENOSPC,          UV_ENOSPC)          => "ENOSPC",
            NOSYS          = $cb!(NOSYS,          ENOSYS,          UV_ENOSYS)          => "ENOSYS",
            NOTCONN        = $cb!(NOTCONN,        ENOTCONN,        UV_ENOTCONN)        => "ENOTCONN",
            NOTDIR         = $cb!(NOTDIR,         ENOTDIR,         UV_ENOTDIR)         => "ENOTDIR",
            NOTEMPTY       = $cb!(NOTEMPTY,       ENOTEMPTY,       UV_ENOTEMPTY)       => "ENOTEMPTY",
            NOTSOCK        = $cb!(NOTSOCK,        ENOTSOCK,        UV_ENOTSOCK)        => "ENOTSOCK",
            NOTSUP         = $cb!(NOTSUP,         ENOTSUP,         UV_ENOTSUP)         => "ENOTSUP",
            PERM           = $cb!(PERM,           EPERM,           UV_EPERM)           => "EPERM",
            PIPE           = $cb!(PIPE,           EPIPE,           UV_EPIPE)           => "EPIPE",
            PROTO          = $cb!(PROTO,          EPROTO,          UV_EPROTO)          => "EPROTO",
            PROTONOSUPPORT = $cb!(PROTONOSUPPORT, EPROTONOSUPPORT, UV_EPROTONOSUPPORT) => "EPROTONOSUPPORT",
            PROTOTYPE      = $cb!(PROTOTYPE,      EPROTOTYPE,      UV_EPROTOTYPE)      => "EPROTOTYPE",
            ROFS           = $cb!(ROFS,           EROFS,           UV_EROFS)           => "EROFS",
            SHUTDOWN       = $cb!(SHUTDOWN,       ESHUTDOWN,       UV_ESHUTDOWN)       => "ESHUTDOWN",
            SPIPE          = $cb!(SPIPE,          ESPIPE,          UV_ESPIPE)          => "ESPIPE",
            SRCH           = $cb!(SRCH,           ESRCH,           UV_ESRCH)           => "ESRCH",
            TIMEDOUT       = $cb!(TIMEDOUT,       ETIMEDOUT,       UV_ETIMEDOUT)       => "ETIMEDOUT",
            TXTBSY         = $cb!(TXTBSY,         ETXTBSY,         UV_ETXTBSY)         => "ETXTBSY",
            XDEV           = $cb!(XDEV,           EXDEV,           UV_EXDEV)           => "EXDEV",
            FBIG           = $cb!(FBIG,           EFBIG,           UV_EFBIG)           => "EFBIG",
            NOPROTOOPT     = $cb!(NOPROTOOPT,     ENOPROTOOPT,     UV_ENOPROTOOPT)     => "ENOPROTOOPT",
            RANGE          = $cb!(RANGE,          ERANGE,          UV_ERANGE)          => "ERANGE",
            NXIO           = $cb!(NXIO,           ENXIO,           UV_ENXIO)           => "ENXIO",
            MLINK          = $cb!(MLINK,          EMLINK,          UV_EMLINK)          => "EMLINK",
            HOSTDOWN       = $cb!(HOSTDOWN,       EHOSTDOWN,       UV_EHOSTDOWN)       => "EHOSTDOWN",
            REMOTEIO       = $cb!(REMOTEIO,       EREMOTEIO,       UV_EREMOTEIO)       => "EREMOTEIO",
            NOTTY          = $cb!(NOTTY,          ENOTTY,          UV_ENOTTY)          => "ENOTTY",
            FTYPE          = $cb!(FTYPE,          EFTYPE,          UV_EFTYPE)          => "EFTYPE",
            ILSEQ          = $cb!(ILSEQ,          EILSEQ,          UV_EILSEQ)          => "EILSEQ",
            OVERFLOW       = $cb!(OVERFLOW,       EOVERFLOW,       UV_EOVERFLOW)       => "EOVERFLOW",
            SOCKTNOSUPPORT = $cb!(SOCKTNOSUPPORT, ESOCKTNOSUPPORT, UV_ESOCKTNOSUPPORT) => "ESOCKTNOSUPPORT",
            NODATA         = $cb!(NODATA,         ENODATA,         UV_ENODATA)         => "ENODATA",
            UNATCH         = $cb!(UNATCH,         EUNATCH,         UV_EUNATCH)         => "EUNATCH",
            NOEXEC         = $cb!(NOEXEC,         ENOEXEC,         UV_ENOEXEC)         => "ENOEXEC",
        }
    };
}

#[cfg(target_os = "macos")]
pub mod darwin_errno;
#[cfg(target_os = "macos")]
pub use darwin_errno::*;
#[cfg(target_os = "freebsd")]
pub mod freebsd_errno;
#[cfg(target_os = "freebsd")]
pub use freebsd_errno::*;
// Android shares the Linux kernel errno space (bionic copies <asm/errno.h>),
// so it uses the same per-errno enum. Rust splits `target_os` into
// `linux`/`android`, so list both.
#[cfg(any(target_os = "linux", target_os = "android"))]
pub mod linux_errno;
#[cfg(any(target_os = "linux", target_os = "android"))]
pub use linux_errno::*;
#[cfg(windows)]
pub mod windows_errno;
#[cfg(windows)]
pub use windows_errno::{posix, *};

// ──────────────────────────────────────────────────────────────────────────
// posix — mode_t, the errno enum, S_* mode bits, and the C errno accessor
//
// Landed here so the errno
// crate stays leaf (T0) and bun_sys (T≥1) imports forward. Windows keeps its
// own divergent `mod posix` in windows_errno.rs (no `errno()` fn, unprefixed
// `E`); this block is the shared POSIX-target definition.
// ──────────────────────────────────────────────────────────────────────────
#[cfg(not(windows))]
#[allow(non_camel_case_types)]
pub mod posix {
    /// glibc/musl/bionic `mode_t` == `unsigned int`.
    #[cfg(any(target_os = "linux", target_os = "android"))]
    pub type mode_t = u32;
    /// Darwin/FreeBSD `mode_t` == `__uint16_t` in `<sys/types.h>`.
    #[cfg(any(target_os = "macos", target_os = "freebsd"))]
    pub type mode_t = u16;

    /// Kernel errno enum. `E` and `SystemErrno` share the exact same
    /// discriminant space on each POSIX target; alias rather than duplicate.
    /// Resolves to the per-OS `SystemErrno` via the glob re-export above.
    /// Variant names are prefixed (`EPERM`, `ENOENT`) — callers spell `E::EPERM`.
    pub type E = crate::SystemErrno;

    /// `stat` mode-flag constants and predicates.
    /// Values are POSIX-standard octal; identical across linux/darwin/freebsd.
    /// Constants are typed `u32` (== `bun_core::Mode`); on Darwin/FreeBSD the
    /// kernel `mode_t` is u16 so the upper 16 bits are always zero — every call
    /// site already casts (`as i32`/`as u32`/`as _`) so the wider type is
    /// harmless, and on Linux `mode_t` == `u32` so it's a drop-in re-export.
    pub use bun_core::S;

    /// Read the thread-local libc errno.
    /// Canonical impl lives in `bun_core::ffi` (single target_os→symbol ladder).
    pub use bun_core::ffi::errno;
}

/// Decode a POSIX syscall return value: `rc.get_errno()` / `get_errno(rc)` is
/// `SUCCESS` unless `rc` is the failure sentinel, in which case it is the errno
/// (Linux raw syscalls decode `-errno` from `usize`; libc wrappers read the
/// thread-local errno on `-1`).
#[cfg(not(windows))]
pub trait GetErrno: Copy {
    fn get_errno(self) -> E;
}

#[cfg(not(windows))]
#[inline]
pub fn get_errno<T: GetErrno>(rc: T) -> E {
    rc.get_errno()
}

/// The thread-local errno as `E` (`SUCCESS` when it is 0).
#[cfg(not(windows))]
#[inline]
pub fn last_error() -> E {
    u16::try_from(posix::errno()).map_or(E::EUNKNOWN, E::from_raw)
}

/// Decode a Node-style **negated** errno (`c_int`, as written by
/// `Error::to_system_error`) back into an `E`. The input crosses FFI
/// (BunObject.cpp `SystemError__*`) and is NOT trusted to be a declared
/// discriminant. `0` is `SUCCESS`; an unmapped value is `EUNKNOWN`.
#[inline]
pub fn e_from_negated(errno: core::ffi::c_int) -> E {
    let n = errno.wrapping_neg();
    #[cfg(windows)]
    {
        u16::try_from(n)
            .ok()
            .and_then(E::try_from_raw)
            .unwrap_or(E::EUNKNOWN)
    }
    #[cfg(not(windows))]
    {
        SystemErrno::init(i64::from(n)).unwrap_or(SystemErrno::EUNKNOWN)
    }
}

impl SystemErrno {
    /// The kernel is not bound to this table (FUSE, `ENOTSUPP` 524): an undeclared code is `EUNKNOWN`.
    #[inline]
    pub const fn from_raw(n: u16) -> SystemErrno {
        match Self::from_repr(n) {
            Some(e) => e,
            None => Self::EUNKNOWN,
        }
    }
}

/// Map a raw OS errno to `SystemErrno`. Unknown / out-of-range codes collapse
/// to `EIO`. This is the migration target for the deleted
/// `bun_core::errno_to_zig_err`; every caller's `Error` enum wraps the result
/// via `Sys(#[from] SystemErrno)`.
#[inline]
pub fn from_errno(errno: i32) -> SystemErrno {
    SystemErrno::init(errno as i64).unwrap_or(SystemErrno::EIO)
}

impl SystemErrno {
    /// `None` if `err` is not an OS error or its code has no `SystemErrno`.
    pub fn from_io_error(err: &std::io::Error) -> Option<SystemErrno> {
        // A Win32 code there, which the `u32` entry point maps (`i64` would take it for an errno).
        #[cfg(windows)]
        return SystemErrno::init(err.raw_os_error()? as u32);
        #[cfg(not(windows))]
        return SystemErrno::init(i64::from(err.raw_os_error()?));
    }
}

#[cfg(not(windows))]
impl SystemErrno {
    // `i64` covers every concrete call site (errno-range values).
    //
    // Windows defines its own `init<C: SystemErrnoInit>` (typed dispatch over
    // i64/DWORD/c_int) in windows_errno.rs, so this impl is POSIX-only.
    pub fn init(code: i64) -> Option<SystemErrno> {
        u16::try_from(code.unsigned_abs())
            .ok()
            .and_then(Self::from_repr)
    }
}

impl core::fmt::Display for SystemErrno {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str(<&'static str>::from(self))
    }
}
impl core::error::Error for SystemErrno {}

impl bun_core::output::ErrName for SystemErrno {
    fn name(&self) -> &[u8] {
        <&'static str>::from(*self).as_bytes()
    }
}

// ──────────────────────────────────────────────────────────────────────────
// system_errno_name — single source of truth for errno → variant name string
//
// The strum::IntoStaticStr
// derive on each per-OS `SystemErrno` IS the table; no hand-written `&[&str]`
// duplicate exists anywhere. bun_core (T0) consumes this through the
// `ErrnoNames` link-interface below — bun_errno already depends on bun_core,
// so a direct Cargo edge would cycle.
// ──────────────────────────────────────────────────────────────────────────

/// Platform errno integer → its `SystemErrno` tag name.
/// `None` for `0` (SUCCESS), out-of-range, or (POSIX) non-positive input —
/// the contract bun_core's `coreutils_error_map` relies on.
#[inline]
fn system_errno_name(errno: i32) -> Option<&'static str> {
    #[cfg(not(windows))]
    {
        if errno <= 0 {
            return None;
        }
        SystemErrno::init(i64::from(errno)).map(<&'static str>::from)
    }
    #[cfg(windows)]
    {
        // Windows libuv errnos arrive negated; abs-normalise before the
        // lookup. `from_repr` (strum::FromRepr)
        // covers BOTH the dense 0..=137 range and the sparse UV_* tags.
        let n = errno.unsigned_abs();
        if n == 0 {
            return None;
        }
        u16::try_from(n)
            .ok()
            .and_then(SystemErrno::from_repr)
            .map(<&'static str>::from)
    }
}

/// Length of the dense `0..MAX` prefix of `SystemErrno` (on Windows, the
/// dense head before the sparse UV_* range). Exposed so bun_core can pre-seed its
/// interned `ERRNO_MAP` without a second hand-written per-OS length table.
#[inline]
const fn system_errno_max_dense() -> u32 {
    SystemErrno::MAX as u32
}

/// Raw Win32 `GetLastError()` code → `SystemErrno` tag name, via the
/// `Win32Error` mapping table. Restores `error.code` fidelity (ENOENT,
/// EACCES, ...) for `?`-propagated `std::io::Error`s on Windows. Exists on all
/// platforms because the `ErrnoNames` link-interface is platform-independent;
/// always `None` off Windows.
#[inline]
fn win32_errno_name(code: u32) -> Option<&'static str> {
    #[cfg(windows)]
    {
        let code = u16::try_from(code).ok()?;
        SystemErrno::init_win32_error(windows_errno::Win32Error::from_raw(code))
            .map(<&'static str>::from)
    }
    #[cfg(not(windows))]
    {
        let _ = code;
        None
    }
}

// Wire the above into bun_core's `ErrnoNames` hook. `()` owner — pure
// stateless functions; the handle is the const `ErrnoNames::SYS`.
bun_core::link_impl_ErrnoNames! {
    Sys for extern () => |_this| {
        name(errno) => system_errno_name(errno),
        max_dense() => system_errno_max_dense(),
        win32_name(code) => win32_errno_name(code),
    }
}

#[cfg(test)]
mod errno_name_tests {
    use super::*;
    use bun_core::coreutils_error_map;

    #[test]
    fn errno_mapping() {
        assert_eq!(system_errno_name(2), Some("ENOENT"));
        assert_eq!(SystemErrno::init(2), Some(SystemErrno::ENOENT));
        assert_eq!(SystemErrno::init(12), Some(SystemErrno::ENOMEM));
        assert_eq!(system_errno_name(0), None);
        assert_eq!(system_errno_name(9999), None);
        // errno 11 is platform-specific: EAGAIN on linux/windows, EDEADLK on darwin/bsd.
        #[cfg(any(
            target_os = "linux",
            target_os = "android",
            windows,
            target_family = "wasm"
        ))]
        {
            assert_eq!(SystemErrno::init(11), Some(SystemErrno::EAGAIN));
            assert_eq!(SystemErrno::init(104), Some(SystemErrno::ECONNRESET));
        }
        #[cfg(any(target_os = "macos", target_os = "freebsd"))]
        {
            assert_eq!(SystemErrno::init(11), Some(SystemErrno::EDEADLK));
            assert_eq!(SystemErrno::init(35), Some(SystemErrno::EAGAIN));
            assert_eq!(SystemErrno::init(54), Some(SystemErrno::ECONNRESET));
        }
    }

    /// Exhaustive: every dense slot in the per-platform enum round-trips through
    /// `system_errno_name` and matches the strum table.
    #[test]
    fn errno_table_full_range() {
        // Slot 0 is the SUCCESS hole.
        assert_eq!(system_errno_name(0), None);
        let max = system_errno_max_dense();
        for i in 1..max {
            let name = system_errno_name(i as i32).expect("dense slot");
            assert_eq!(
                <&'static str>::from(SystemErrno::from_raw(i as u16)),
                name,
                "slot {i}"
            );
        }
        // One past the dense end → None.
        #[cfg(not(windows))]
        assert_eq!(system_errno_name(max as i32), None);

        // Spot-check the last entry on each platform.
        #[cfg(any(target_os = "linux", target_os = "android", target_family = "wasm"))]
        {
            assert_eq!(system_errno_name(133), Some("EHWPOISON"));
            assert_eq!(system_errno_name(134), Some("EUNKNOWN"));
        }
        #[cfg(windows)]
        {
            assert_eq!(system_errno_name(137), Some("EFTYPE"));
            // Sparse UV_* range round-trips.
            assert_eq!(system_errno_name(-4058), Some("UV_ENOENT"));
            assert_eq!(system_errno_name(-4092), Some("UV_EACCES"));
            assert_eq!(system_errno_name(-4095), Some("UV_EOF"));
            assert_eq!(system_errno_name(-3008), Some("UV_EAI_NONAME"));
            assert_eq!(system_errno_name(-5000), None);
        }
        #[cfg(target_os = "macos")]
        {
            assert_eq!(system_errno_name(106), Some("EQFULL"));
            assert_eq!(system_errno_name(107), Some("EUNKNOWN"));
        }
        #[cfg(target_os = "freebsd")]
        {
            assert_eq!(system_errno_name(97), Some("EINTEGRITY"));
            assert_eq!(system_errno_name(98), Some("EUNKNOWN"));
        }
    }

    #[test]
    fn unknown_errno_is_defined() {
        // Linux `ENOTSUPP`, `ERESTARTSYS`, and the largest possible code.
        for raw in [524u16, 512, u16::MAX] {
            assert_eq!(SystemErrno::from_raw(raw), SystemErrno::EUNKNOWN);
            #[cfg(not(windows))]
            {
                assert_eq!(SystemErrno::init(i64::from(raw)), None);
                assert_eq!(SystemErrno::init(-i64::from(raw)), None);
            }
            assert_eq!(system_errno_name(i32::from(raw)), None);
        }
        assert_eq!(SystemErrno::from_raw(0), SystemErrno::SUCCESS);
        assert_eq!(SystemErrno::from_raw(2), SystemErrno::ENOENT);
        assert_eq!(
            SystemErrno::from_raw(SystemErrno::EUNKNOWN as u16),
            SystemErrno::EUNKNOWN
        );

        // Round trip: a stored `EUNKNOWN` decodes as itself, not as `SUCCESS`.
        #[cfg(not(windows))]
        assert_eq!(
            SystemErrno::init(i64::from(SystemErrno::EUNKNOWN as u16)),
            Some(SystemErrno::EUNKNOWN)
        );
        assert_eq!(e_from_negated(0), E::SUCCESS);
        assert_eq!(e_from_negated(-524), E::EUNKNOWN);
        assert_eq!(e_from_negated(-(E::EUNKNOWN as i32)), E::EUNKNOWN);

        // Linux raw syscalls hand back `-errno` in the return register.
        #[cfg(any(target_os = "linux", target_os = "android"))]
        {
            assert_eq!((-524isize as usize).get_errno(), E::EUNKNOWN);
            assert_eq!((-2isize as usize).get_errno(), E::ENOENT);
            assert_eq!(7usize.get_errno(), E::SUCCESS);
        }
    }

    /// `win32_errno_name` translation contract: known `GetLastError()` codes
    /// map to POSIX names on Windows, unmapped/out-of-range codes are `None`,
    /// and the helper is a constant `None` off Windows.
    #[test]
    fn win32_errno_names() {
        #[cfg(windows)]
        {
            // ERROR_FILE_NOT_FOUND / ERROR_ACCESS_DENIED.
            assert_eq!(win32_errno_name(2), Some("ENOENT"));
            assert_eq!(win32_errno_name(5), Some("EPERM"));
            // Unmapped Win32 code and the `u16::try_from` overflow fallback.
            assert_eq!(win32_errno_name(0), None);
            assert_eq!(win32_errno_name(u32::MAX), None);
        }
        #[cfg(not(windows))]
        {
            assert_eq!(win32_errno_name(2), None);
            assert_eq!(win32_errno_name(u32::MAX), None);
        }
    }

    /// Matters on Windows, where `E` is a separate enum with unprefixed variant names.
    #[test]
    fn e_spells_like_system_errno() {
        assert_eq!(<&'static str>::from(E::ENOENT), "ENOENT");
        assert_eq!(<&'static str>::from(E::E2BIG), "E2BIG");
        assert_eq!(<&'static str>::from(E::SUCCESS), "SUCCESS");
        #[cfg(windows)]
        assert_eq!(<&'static str>::from(E::UV_ENOENT), "UV_ENOENT");
    }

    #[test]
    fn io_error_to_errno() {
        let of = |code| SystemErrno::from_io_error(&std::io::Error::from_raw_os_error(code));
        #[cfg(not(windows))]
        assert_eq!(of(SystemErrno::ENOMEM as i32), Some(SystemErrno::ENOMEM));
        // Win32 ERROR_NOT_ENOUGH_MEMORY / ERROR_ACCESS_DENIED; as errno values 8 and 5 are ENOEXEC and EIO.
        #[cfg(windows)]
        assert_eq!(
            (of(8), of(5)),
            (Some(SystemErrno::ENOMEM), Some(SystemErrno::EPERM))
        );
        let not_os = std::io::Error::other("not from the OS");
        assert_eq!(SystemErrno::from_io_error(&not_os), None);
    }

    #[test]
    fn coreutils_map() {
        assert_eq!(
            coreutils_error_map::get(2),
            Some("No such file or directory")
        );
        #[cfg(any(
            target_os = "linux",
            target_os = "android",
            windows,
            target_family = "wasm"
        ))]
        assert_eq!(
            coreutils_error_map::get(11),
            Some("Resource temporarily unavailable")
        );
        #[cfg(any(target_os = "macos", target_os = "freebsd"))]
        assert_eq!(
            coreutils_error_map::get(11),
            Some("Resource deadlock avoided")
        );
        assert_eq!(coreutils_error_map::get(0), None);
    }
}
