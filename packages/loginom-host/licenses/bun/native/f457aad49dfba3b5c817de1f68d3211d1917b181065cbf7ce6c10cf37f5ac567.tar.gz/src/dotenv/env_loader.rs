use core::cell::Cell;
use core::ffi::c_char;
use std::sync::OnceLock;
use std::sync::atomic::{AtomicBool, AtomicPtr, Ordering};

use bun_alloc::AllocError;
use bun_collections::{ArrayHashMapExt, GetOrPutResult, StringSet};
use bun_core::{self, Output};
use bun_core::{ZStr, strings};
use bun_paths::{self, MAX_PATH_BYTES, PathBuffer};
use bun_sys;
use bun_url::URL;
use bun_which::which;
use enumset::EnumSet;

use bun_core::analytics;

#[derive(Copy, Clone, PartialEq, Eq)]
pub enum DotEnvFileSuffix {
    Development,
    Production,
    Test,
}

/// Declaration order is the order `print_loaded` lists the files in.
#[derive(enumset::EnumSetType)]
pub(crate) enum DefaultEnvFile {
    DevelopmentLocal,
    ProductionLocal,
    TestLocal,
    Local,
    Development,
    Production,
    Test,
    Env,
}

impl DefaultEnvFile {
    fn name(self) -> &'static [u8] {
        match self {
            Self::DevelopmentLocal => b".env.development.local",
            Self::ProductionLocal => b".env.production.local",
            Self::TestLocal => b".env.test.local",
            Self::Local => b".env.local",
            Self::Development => b".env.development",
            Self::Production => b".env.production",
            Self::Test => b".env.test",
            Self::Env => b".env",
        }
    }
}

/// Directory-entry probe used by `Loader::load`. `bun_dotenv` sits below
/// `bun_resolver` in the crate graph, so the directory listing is taken
/// generically; the only operation `load_default_files` performs is a lookup
/// of a known-at-compile-time filename. Callers snapshot the resolver's
/// listing into a [`DirEntryKeys`] (the live `DirEntry` map may be rewritten
/// in place by a concurrent resolver, so `load` must not probe it directly).
pub trait DirEntryProbe {
    /// The argument MUST already be ASCII-lowercase.
    fn has_comptime_query(&self, query_lower: &'static [u8]) -> bool;
}

/// Directory-listing basenames copied out under the resolver's
/// `entries_mutex`, probed between the `.env` file reads in `Loader::load`.
pub struct DirEntryKeys(pub Vec<Box<[u8]>>);

impl DirEntryProbe for DirEntryKeys {
    fn has_comptime_query(&self, query_lower: &'static [u8]) -> bool {
        self.0.iter().any(|k| **k == *query_lower)
    }
}

/// Canonical definition; re-exported as
/// `bun_options_types::schema::api::DotEnvBehavior` for higher tiers.
#[repr(u32)]
#[derive(Copy, Clone, Eq, PartialEq, Debug, Default)]
#[allow(non_camel_case_types)]
pub enum DotEnvBehavior {
    #[default]
    _none = 0,
    disable = 1,
    prefix = 2,
    load_all = 3,
    load_all_without_inlining = 4,
}

#[allow(non_upper_case_globals)]
impl DotEnvBehavior {
    // PascalCase aliases — downstream callers (bundler/options.rs, bundler/defines.rs,
    // runtime/api/JSBundler.rs) name the variants both ways.
    pub const None: Self = Self::_none;
    pub const Disable: Self = Self::disable;
    pub const Prefix: Self = Self::prefix;
    pub const LoadAll: Self = Self::load_all;
    pub const LoadAllWithoutInlining: Self = Self::load_all_without_inlining;

    /// String-branch classifier shared by bunfig (serve.env) and
    /// JSBundler (Bun.build env). Only the *string* arm is common to
    /// both specs — the surrounding null/bool/number dispatch and the error
    /// reporting intentionally diverge per call site, so they stay inline there.
    ///
    /// Returns `Ok((behavior, prefix))` where `prefix` is `Some(&s[..idx])` only for
    /// `DotEnvBehavior::prefix`; `Err(())` means the string is none of
    /// `"inline"` / `"disable"` / contains-`*`, and the caller emits its own
    /// site-specific diagnostic.
    pub fn parse_str(s: &[u8]) -> Result<(Self, Option<&[u8]>), ()> {
        if s == b"inline" {
            Ok((Self::load_all, None))
        } else if s == b"disable" {
            Ok((Self::disable, None))
        } else if let Some(asterisk) = strings::index_of_char_usize(s, b'*') {
            if asterisk > 0 {
                Ok((Self::prefix, Some(&s[..asterisk])))
            } else {
                Ok((Self::load_all, None))
            }
        } else {
            Err(())
        }
    }
}

/// Mirrors the value fields of `bun_s3_signing::S3Credentials` (T5). Defined locally so
/// this T2 crate names no `bun_s3_signing` types — see PORTING.md §Dispatch (cold-path,
/// upward dep). The high-tier caller constructs the real refcounted `S3Credentials` from
/// this POD at the call site.
#[derive(Clone, Default)]
pub struct S3Credentials {
    pub access_key_id: Box<[u8]>,
    pub secret_access_key: Box<[u8]>,
    pub region: Box<[u8]>,
    pub endpoint: Box<[u8]>,
    pub bucket: Box<[u8]>,
    pub session_token: Box<[u8]>,
    /// Important for MinIO support.
    pub insecure_http: bool,
}

pub struct Loader {
    pub map: Map,
    // allocator dropped — global mimalloc (see PORTING.md §Allocators)
    pub(crate) default_files_loaded: EnumSet<DefaultEnvFile>,

    /// only populated with files specified explicitly (e.g. --env-file arg)
    pub(crate) custom_files_loaded: StringSet,

    pub quiet: bool,

    pub(crate) did_load_process: bool,
    pub(crate) reject_unauthorized: Cell<Option<bool>>,

    // Local POD mirror of `bun_s3_signing::S3Credentials` — see type doc above.
    aws_credentials: Option<S3Credentials>,
}

static DID_LOAD_CCACHE_PATH: AtomicBool = AtomicBool::new(false);
// Overwritten on every `load_node_js_config` call. NOT set-once despite the
// name, so RwLock<Option> (not OnceLock) — a 2nd call with an override must update the cache.
static NODE_PATH_TO_USE_SET_ONCE: bun_core::RwLock<Option<Box<[u8]>>> = bun_core::RwLock::new(None);

// PORTING.md §Concurrency: OnceLock — set once from CLI flag, read many.
pub static HAS_NO_CLEAR_SCREEN_CLI_FLAG: OnceLock<bool> = OnceLock::new();

/// Compares like [`HashTable`] keys, which are ASCII case-insensitive on Windows.
fn is_ipc_channel_key(key: &[u8]) -> bool {
    const KEYS: [&[u8]; 2] = [b"NODE_CHANNEL_FD", b"NODE_CHANNEL_SERIALIZATION_MODE"];
    KEYS.iter().any(|&k| {
        if cfg!(windows) {
            strings::eql_case_insensitive_ascii(key, k, true)
        } else {
            strings::eql(key, k)
        }
    })
}

impl Loader {
    /// Shared "empty-ish" predicate for proxy env vars: an unset/empty value,
    /// or a literal empty-quote pair left over from shell `export FOO=""` /
    /// `export FOO=''`.
    #[inline]
    fn is_emptyish(v: &[u8]) -> bool {
        v.is_empty() || v == b"\"\"" || v == b"''"
    }

    /// Lookup `lower` first; if present-but-empty, fall through to `upper`.
    /// CI environments often set `http_proxy=""` as a default; a runtime
    /// `process.env.HTTP_PROXY = "..."` must still be observed.
    #[inline]
    fn get_lower_then_upper(&self, lower: &[u8], upper: &[u8]) -> Option<&[u8]> {
        if let Some(p) = self.get(lower) {
            if !p.is_empty() {
                return Some(p);
            }
        }
        self.get(upper)
    }

    pub fn iterator(&mut self) -> <HashTable as ArrayHashMapExt>::Iterator<'_> {
        self.map.iterator()
    }

    pub fn has(&self, input: &[u8]) -> bool {
        let Some(value) = self.get(input) else {
            return false;
        };
        // NOTE: intentionally stricter than `is_emptyish` — also rejects
        // "0"/"false"; do not collapse the extra terms.
        !Self::is_emptyish(value) && value != b"0" && value != b"false"
    }

    /// `BUN_ENV` with fallback to `NODE_ENV` — Bun's env precedence for
    /// production/test detection.
    pub fn get_node_env(&self) -> Option<&[u8]> {
        self.get(b"BUN_ENV").or_else(|| self.get(b"NODE_ENV"))
    }

    pub fn is_production(&self) -> bool {
        self.get_node_env() == Some(b"production")
    }

    pub fn is_test(&self) -> bool {
        self.get_node_env() == Some(b"test")
    }

    pub fn get_node_path<'b>(
        &mut self,
        fs: &bun_paths::fs::FileSystem,
        buf: &'b mut PathBuffer,
    ) -> Option<&'b ZStr> {
        // Check NODE or npm_node_execpath env var, but only use it if the file actually exists.
        // NLL workaround: compute the length in an inner scope so the borrow of `buf` for the
        // executable check ends before we either return a fresh borrow or fall through to `which`.
        let env_len = self
            .get(b"NODE")
            .or_else(|| self.get(b"npm_node_execpath"))
            .filter(|n| !n.is_empty() && n.len() < MAX_PATH_BYTES)
            .map(|node| {
                buf[..node.len()].copy_from_slice(node);
                buf[node.len()] = 0;
                node.len()
            });
        if let Some(len) = env_len {
            if bun_sys::is_executable_file_path(ZStr::from_buf(&buf[..], len)) {
                return Some(ZStr::from_buf(&buf[..], len));
            }
        }

        let path = self.get(b"PATH")?;
        if let Some(node) = which(buf, path, fs.top_level_dir(), b"node") {
            return Some(node);
        }

        None
    }

    pub fn is_ci(&self) -> bool {
        self.get(b"CI")
            .or_else(|| self.get(b"TDDIUM"))
            .or_else(|| self.get(b"GITHUB_ACTIONS"))
            .or_else(|| self.get(b"JENKINS_URL"))
            .or_else(|| self.get(b"bamboo.buildKey"))
            .is_some()
    }

    pub fn get_s3_credentials(&mut self) -> &S3Credentials {
        if self.aws_credentials.is_none() {
            // Copy to `Box<[u8]>` so the cached struct owns its bytes and we
            // can release the `&self` borrow before writing `&mut self.aws_credentials`.
            // One-shot and cached — copies are negligible.
            let access_key_id: Box<[u8]> = self
                .get(b"S3_ACCESS_KEY_ID")
                .or_else(|| self.get(b"AWS_ACCESS_KEY_ID"))
                .map(Box::from)
                .unwrap_or_default();
            let secret_access_key: Box<[u8]> = self
                .get(b"S3_SECRET_ACCESS_KEY")
                .or_else(|| self.get(b"AWS_SECRET_ACCESS_KEY"))
                .map(Box::from)
                .unwrap_or_default();
            let region: Box<[u8]> = self
                .get(b"S3_REGION")
                .or_else(|| self.get(b"AWS_REGION"))
                .map(Box::from)
                .unwrap_or_default();

            let mut endpoint: Box<[u8]> = Box::default();
            let mut insecure_http = false;
            if let Some(parsed) = self
                .get(b"S3_ENDPOINT")
                .or_else(|| self.get(b"AWS_ENDPOINT"))
                .and_then(URL::parse_s3_endpoint)
            {
                endpoint = parsed.host_with_path;
                insecure_http = parsed.is_http;
            }

            let bucket: Box<[u8]> = self
                .get(b"S3_BUCKET")
                .or_else(|| self.get(b"AWS_BUCKET"))
                .map(Box::from)
                .unwrap_or_default();
            let session_token: Box<[u8]> = self
                .get(b"S3_SESSION_TOKEN")
                .or_else(|| self.get(b"AWS_SESSION_TOKEN"))
                .map(Box::from)
                .unwrap_or_default();

            self.aws_credentials = Some(S3Credentials {
                access_key_id,
                secret_access_key,
                region,
                endpoint,
                bucket,
                session_token,
                insecure_http,
            });
        }

        self.aws_credentials.as_ref().unwrap()
    }

    /// Checks whether `NODE_TLS_REJECT_UNAUTHORIZED` is set to `0` (matching
    /// Node's `=== '0'` check exactly).
    ///
    /// **Prefer VirtualMachine.getTLSRejectUnauthorized()** for JavaScript, as individual workers could have different settings.
    pub fn get_tls_reject_unauthorized(&self) -> bool {
        if let Some(reject_unauthorized) = self.reject_unauthorized.get() {
            return reject_unauthorized;
        }
        // default: true
        let result = self.get(b"NODE_TLS_REJECT_UNAUTHORIZED") != Some(b"0");
        self.reject_unauthorized.set(Some(result));
        result
    }

    pub fn get_http_proxy_for(&self, url: &URL<'_>) -> Option<URL<'_>> {
        // `http://DOMAIN\user:pass@proxy:8080` is a domain login, as curl reads it.
        let proxy = URL::parse_single_reader(self.proxy_env_for_scheme(url.is_http())?);
        if self.is_no_proxy(url.hostname, url.get_port_auto()) {
            return None;
        }
        Some(proxy)
    }

    pub fn has_http_proxy(&self) -> bool {
        self.has(b"http_proxy")
            || self.has(b"HTTP_PROXY")
            || self.has(b"https_proxy")
            || self.has(b"HTTPS_PROXY")
            || self.all_proxy().is_some()
    }

    /// `http_proxy` / `HTTP_PROXY` (or the `https` pair), falling back to
    /// `all_proxy` / `ALL_PROXY`.
    pub fn proxy_env_for_scheme(&self, is_http: bool) -> Option<&[u8]> {
        self.scheme_proxy(is_http).or_else(|| self.all_proxy())
    }

    /// `[proxy_env_for_scheme(true), proxy_env_for_scheme(false)]`.
    pub fn proxy_env_for_both_schemes(&self) -> [Option<&[u8]>; 2] {
        let (http, https) = (self.scheme_proxy(true), self.scheme_proxy(false));
        if http.is_some() && https.is_some() {
            return [http, https];
        }
        let all = self.all_proxy();
        [http.or(all), https.or(all)]
    }

    fn scheme_proxy(&self, is_http: bool) -> Option<&[u8]> {
        let specific = if is_http {
            self.get_lower_then_upper(b"http_proxy", b"HTTP_PROXY")
        } else {
            self.get_lower_then_upper(b"https_proxy", b"HTTPS_PROXY")
        };
        specific.filter(|p| !Self::is_emptyish(p))
    }

    /// The proxy for every target scheme. It commonly names a SOCKS proxy,
    /// which the HTTP client cannot speak, so a value with some other scheme
    /// than `http:` / `https:` is left alone. A value with no scheme is an
    /// HTTP proxy, as for curl and for `HTTP_PROXY`: going direct instead would
    /// silently bypass the proxy, where a wrong guess fails loudly.
    fn all_proxy(&self) -> Option<&[u8]> {
        let value = self
            .get_lower_then_upper(b"all_proxy", b"ALL_PROXY")
            .filter(|p| !Self::is_emptyish(p))?;
        let url = URL::parse_single_reader(value);
        (url.protocol.is_empty() || url.has_http_like_protocol()).then_some(value)
    }

    /// `no_proxy`, else `NO_PROXY`: one list, the lowercase name first, as curl,
    /// node and undici read it.
    pub fn no_proxy_list(&self) -> &[u8] {
        let read = |name: &[u8]| self.get(name).filter(|v| !Self::is_emptyish(v));
        read(b"no_proxy")
            .or_else(|| read(b"NO_PROXY"))
            .unwrap_or(b"")
    }

    /// Returns true if `hostname` on `port` should bypass the proxy according
    /// to the no_proxy / NO_PROXY environment variable.
    pub fn is_no_proxy(&self, hostname: &[u8], port: u16) -> bool {
        crate::no_proxy::matches(self.no_proxy_list(), hostname, port)
    }

    pub fn load_ccache_path(&mut self, fs: &bun_paths::fs::FileSystem) {
        if DID_LOAD_CCACHE_PATH.load(Ordering::Relaxed) {
            return;
        }
        DID_LOAD_CCACHE_PATH.store(true, Ordering::Relaxed);
        let _ = self.load_ccache_path_impl(fs);
    }

    fn load_ccache_path_impl(&mut self, fs: &bun_paths::fs::FileSystem) -> Result<(), AllocError> {
        // if they have ccache installed, put it in env variable `CMAKE_CXX_COMPILER_LAUNCHER` so
        // cmake can use it to hopefully speed things up
        let mut buf = bun_paths::path_buffer_pool::get();
        let path = match self.get(b"PATH") {
            Some(p) => p,
            None => return Ok(()),
        };
        // borrowck — `path` borrows `self.map`; `which` writes into `buf` and
        // returns a borrow of `buf`. Copy the result before mutating `self.map`.
        let ccache_path: Box<[u8]> = which(&mut buf, path, fs.top_level_dir(), b"ccache")
            .map(|z| Box::<[u8]>::from(z.as_bytes()))
            .unwrap_or_default();

        if !ccache_path.is_empty() {
            let cxx_gop = self
                .map
                .get_or_put_without_value(b"CMAKE_CXX_COMPILER_LAUNCHER")?;
            if !cxx_gop.found_existing {
                *cxx_gop.key_ptr = Box::<[u8]>::from(&**cxx_gop.key_ptr);
                *cxx_gop.value_ptr = HashTableValue {
                    value: ccache_path.clone(),
                };
            }
            let c_gop = self
                .map
                .get_or_put_without_value(b"CMAKE_C_COMPILER_LAUNCHER")?;
            if !c_gop.found_existing {
                *c_gop.key_ptr = Box::<[u8]>::from(&**c_gop.key_ptr);
                *c_gop.value_ptr = HashTableValue { value: ccache_path };
            }
        }
        Ok(())
    }

    /// Populates `NODE` /
    /// `npm_node_execpath` with the resolved node binary path. Returns `false`
    /// only when no node could be discovered and no override was supplied.
    pub fn load_node_js_config(
        &mut self,
        fs: &bun_paths::fs::FileSystem,
        override_node: &[u8],
    ) -> crate::Result<bool> {
        let mut buf = bun_paths::path_buffer_pool::get();

        let node_path_to_use: Box<[u8]> = if !override_node.is_empty() {
            Box::from(override_node)
        } else {
            let cached: Option<Box<[u8]>> = NODE_PATH_TO_USE_SET_ONCE
                .read()
                .as_ref()
                .filter(|b| !b.is_empty())
                .cloned();
            if let Some(c) = cached {
                c
            } else {
                let Some(node) = self.get_node_path(fs, &mut buf) else {
                    return Ok(false);
                };
                Box::from(node.as_bytes())
            }
        };
        // Cache to `NODE_PATH_TO_USE_SET_ONCE` first, then `map.put` (which
        // dupes the bytes).
        *NODE_PATH_TO_USE_SET_ONCE.write() = Some(node_path_to_use.clone());
        self.map.put(b"NODE", &node_path_to_use)?;
        self.map.put(b"npm_node_execpath", &node_path_to_use)?;
        Ok(true)
    }

    pub(crate) fn get_as_bool(&self, key: &[u8]) -> Option<bool> {
        let value = self.get(key)?;
        if value == b"" {
            return Some(false);
        }
        if value == b"0" {
            return Some(false);
        }
        if value == b"NO" {
            return Some(false);
        }
        if value == b"OFF" {
            return Some(false);
        }
        if value == b"false" {
            return Some(false);
        }

        Some(true)
    }

    /// Returns whether the `BUN_CONFIG_NO_CLEAR_TERMINAL_ON_RELOAD` env var is set to something truthy
    pub fn has_set_no_clear_terminal_on_reload(&self, default_value: bool) -> bool {
        HAS_NO_CLEAR_SCREEN_CLI_FLAG
            .get()
            .copied()
            .or_else(|| self.get_as_bool(b"BUN_CONFIG_NO_CLEAR_TERMINAL_ON_RELOAD"))
            .unwrap_or(default_value)
    }

    pub fn get(&self, key: &[u8]) -> Option<&[u8]> {
        let mut _key = key;
        if !_key.is_empty() && _key[0] == b'$' {
            _key = &key[1..];
        }

        if _key.is_empty() {
            return None;
        }

        self.map.get(_key)
    }

    pub fn get_auto<'b>(&'b self, key: &'b [u8]) -> &'b [u8] {
        // If it's "" or "$", it's not a variable
        if key.len() < 2 || key[0] != b'$' {
            return key;
        }

        self.get(&key[1..]).unwrap_or(key)
    }

    // `copyForDefine` moved up into `bun_bundler::defines::copy_env_for_define`
    // — it constructs `E::String` + `DefineData`, both higher-tier types, and
    // only reads `self.map.map.{keys,values}()` from this crate.

    pub fn init() -> Loader {
        Self::init_with_map(Map::init())
    }

    pub fn init_with_map(map: Map) -> Loader {
        Loader {
            map,
            default_files_loaded: EnumSet::empty(),
            custom_files_loaded: StringSet::new(),
            quiet: false,
            did_load_process: false,
            reject_unauthorized: Cell::new(None),
            aws_credentials: None,
        }
    }

    /// A `Worker`'s loader: the map, with the explicit entries marked loaded so a pipe is not read twice.
    pub fn clone_for_worker(&self) -> Result<Loader, AllocError> {
        Ok(Loader {
            map: self.map.clone_with_allocator()?,
            default_files_loaded: EnumSet::empty(),
            custom_files_loaded: self.custom_files_loaded.clone()?,
            quiet: false,
            did_load_process: false,
            reject_unauthorized: Cell::new(None),
            aws_credentials: None,
        })
    }

    /// Clones the loader for a macro VM. The clone remembers which files `self` loaded, so it only
    /// reads the ones `self` skipped.
    pub fn clone_loaded(&self) -> Result<Loader, AllocError> {
        Ok(Loader {
            map: self.map.clone_with_allocator()?,
            default_files_loaded: self.default_files_loaded,
            custom_files_loaded: self.custom_files_loaded.clone()?,
            quiet: self.quiet,
            did_load_process: self.did_load_process,
            reject_unauthorized: Cell::new(None),
            aws_credentials: None,
        })
    }

    pub fn load_process(&mut self) -> Result<(), AllocError> {
        if self.did_load_process {
            return Ok(());
        }

        let environ: &[*const c_char] = bun_sys::environ();
        self.map.map.ensure_total_capacity(environ.len())?;
        for &_env in environ {
            // SAFETY: environ entries are NUL-terminated C strings from the OS
            let env = unsafe { bun_core::ffi::cstr(_env) }.to_bytes();
            if let Some(i) = strings::index_of_char(env, b'=') {
                let key = &env[..i as usize];
                let value = &env[i as usize + 1..];
                if !key.is_empty() {
                    // Child processes don't inherit the IPC fd. `bun run` passes the fd on and
                    // adds these variables back.
                    if is_ipc_channel_key(key) {
                        continue;
                    }
                    self.map.put(key, value)?;
                }
            } else {
                if !env.is_empty() {
                    self.map.put(env, b"")?;
                }
            }
        }
        self.did_load_process = true;
        Ok(())
    }

    // mostly for tests
    pub fn load_from_string<const OVERWRITE: bool, const EXPAND: bool>(
        &mut self,
        str: &[u8],
    ) -> Result<(), AllocError> {
        let mut value_buffer: Vec<u8> = Vec::new();
        Parser::parse_bytes::<OVERWRITE, false, EXPAND>(str, &mut self.map, &mut value_buffer)
    }

    pub fn load<D: DirEntryProbe + ?Sized>(
        &mut self,
        dir: &D,
        env_files: &[&[u8]],
        suffix: DotEnvFileSuffix,
        skip_default_env: bool,
    ) -> crate::Result<()> {
        // `suffix` is a runtime arg (avoids unstable adt_const_params; cold path).
        let start = bun_core::time::nano_timestamp();
        let loaded_before = self.loaded_count();

        // Create a reusable buffer for parsing multiple files.
        let mut value_buffer: Vec<u8> = Vec::new();

        if !env_files.is_empty() {
            self.load_explicit_files(env_files, &mut value_buffer)?;
        } else {
            // Do not automatically load .env files in `bun run <script>`
            // Instead, it is the responsibility of the script's instance of `bun` to load .env,
            // so that if the script runner is NODE_ENV=development, but the script is
            // "NODE_ENV=production bun ...", there should be no development env loaded.
            //
            // See https://github.com/oven-sh/bun/issues/9635#issuecomment-2021350123
            // for more details on how this edge case works.
            if !skip_default_env {
                self.load_default_files(suffix, dir, &mut value_buffer)?;
            }
        }

        if !self.quiet && self.loaded_count() > loaded_before {
            self.print_loaded(start);
        }
        Ok(())
    }

    fn loaded_count(&self) -> usize {
        self.default_files_loaded.len() + self.custom_files_loaded.count()
    }

    fn load_explicit_files(
        &mut self,
        env_files: &[&[u8]],
        value_buffer: &mut Vec<u8>,
    ) -> crate::Result<()> {
        // iterate backwards, so the latest entry in the latest arg instance assumes the highest priority
        let mut i: usize = env_files.len();
        while i > 0 {
            let arg_value = strings::trim(env_files[i - 1], b" ");
            if !arg_value.is_empty() {
                // ignore blank args
                for file_path in strings::rsplit(arg_value, b",") {
                    if !file_path.is_empty() {
                        self.load_env_file_dynamic::<false>(file_path, value_buffer)?;
                        analytics::Features::dotenv_inc();
                    }
                }
            }
            i -= 1;
        }
        Ok(())
    }

    // .env.local goes first
    // Load .env.development if development
    // Load .env.production if !development
    // .env goes last
    fn load_default_files<D: DirEntryProbe + ?Sized>(
        &mut self,
        suffix: DotEnvFileSuffix,
        dir: &D,
        value_buffer: &mut Vec<u8>,
    ) -> crate::Result<()> {
        let dir_handle = bun_sys::Fd::cwd();

        match suffix {
            DotEnvFileSuffix::Development => self.try_load_default(
                dir,
                dir_handle,
                DefaultEnvFile::DevelopmentLocal,
                value_buffer,
            )?,
            DotEnvFileSuffix::Production => self.try_load_default(
                dir,
                dir_handle,
                DefaultEnvFile::ProductionLocal,
                value_buffer,
            )?,
            DotEnvFileSuffix::Test => {
                self.try_load_default(dir, dir_handle, DefaultEnvFile::TestLocal, value_buffer)?
            }
        }

        if suffix != DotEnvFileSuffix::Test {
            self.try_load_default(dir, dir_handle, DefaultEnvFile::Local, value_buffer)?;
        }

        match suffix {
            DotEnvFileSuffix::Development => {
                self.try_load_default(dir, dir_handle, DefaultEnvFile::Development, value_buffer)?
            }
            DotEnvFileSuffix::Production => {
                self.try_load_default(dir, dir_handle, DefaultEnvFile::Production, value_buffer)?
            }
            DotEnvFileSuffix::Test => {
                self.try_load_default(dir, dir_handle, DefaultEnvFile::Test, value_buffer)?
            }
        }

        self.try_load_default(dir, dir_handle, DefaultEnvFile::Env, value_buffer)
    }

    #[inline]
    fn try_load_default<D: DirEntryProbe + ?Sized>(
        &mut self,
        dir: &D,
        dir_handle: bun_sys::Fd,
        env_file: DefaultEnvFile,
        value_buffer: &mut Vec<u8>,
    ) -> crate::Result<()> {
        if dir.has_comptime_query(env_file.name()) {
            self.load_env_file::<false>(dir_handle, env_file, value_buffer)?;
            analytics::Features::dotenv_inc();
        }
        Ok(())
    }

    pub(crate) fn print_loaded(&self, start: i128) {
        let count = self.loaded_count();

        if count == 0 {
            return;
        }
        let elapsed = (bun_core::time::nano_timestamp() - start) as f64 / 1_000_000.0;

        let mut loaded_i: usize = 0;
        Output::print_elapsed(elapsed);
        bun_core::pretty_error!(" <d>");

        for env_file in self.default_files_loaded.iter() {
            loaded_i += 1;
            if count == 1 || (loaded_i >= count && count > 1) {
                bun_core::pretty_error!("\"{}\"", bstr::BStr::new(env_file.name()));
            } else {
                bun_core::pretty_error!("\"{}\", ", bstr::BStr::new(env_file.name()));
            }
        }

        for k in self.custom_files_loaded.keys() {
            loaded_i += 1;
            if count == 1 || (loaded_i >= count && count > 1) {
                bun_core::pretty_error!("\"{}\"", bstr::BStr::new(k));
            } else {
                bun_core::pretty_error!("\"{}\", ", bstr::BStr::new(k));
            }
        }

        bun_core::pretty_errorln!("<r>");
        Output::flush();
    }

    pub(crate) fn load_env_file<const OVERRIDE: bool>(
        &mut self,
        dir: bun_sys::Fd,
        env_file: DefaultEnvFile,
        value_buffer: &mut Vec<u8>,
    ) -> crate::Result<()> {
        if self.default_files_loaded.contains(env_file) {
            return Ok(());
        }
        let base = env_file.name();

        // `bun_sys` is errno-based; the match arms below group the recoverable
        // errnos. Any errno not listed propagates.
        let file = match bun_sys::File::openat(dir, base, DEFAULT_ENV_FILE_OPEN_FLAGS, 0) {
            Ok(file) => file,
            Err(err) => {
                use bun_sys::E;
                match err.get_errno() {
                    // A unix socket: ENXIO on Linux, EOPNOTSUPP on macOS and FreeBSD.
                    E::EISDIR | E::ENOENT | E::ENXIO | E::EOPNOTSUPP => {
                        // prevent retrying
                        self.default_files_loaded.insert(env_file);
                        return Ok(());
                    }
                    E::EBUSY | E::EACCES => {
                        if !self.quiet {
                            bun_core::pretty_errorln!(
                                "<r><red>{}<r> error loading {} file",
                                bstr::BStr::new(err.name()),
                                bstr::BStr::new(base)
                            );
                        }
                        // prevent retrying
                        self.default_files_loaded.insert(env_file);
                        return Ok(());
                    }
                    _ => return Err(err.into()),
                }
            }
        };

        match read_env_file_contents(&file, EnvFileSource::Default)? {
            ReadEnvFile::Empty => {}
            ReadEnvFile::ReadErr(err) => {
                if !self.quiet {
                    bun_core::pretty_errorln!(
                        "<r><red>{}<r> error loading {} file",
                        bstr::BStr::new(err.name()),
                        bstr::BStr::new(base)
                    );
                }
            }
            ReadEnvFile::Bytes(buf) => {
                Parser::parse_bytes::<OVERRIDE, false, true>(&buf, &mut self.map, value_buffer)?;
            }
        }

        self.default_files_loaded.insert(env_file);
        Ok(())
    }

    pub(crate) fn load_env_file_dynamic<const OVERRIDE: bool>(
        &mut self,
        file_path: &[u8],
        value_buffer: &mut Vec<u8>,
    ) -> crate::Result<()> {
        if self.custom_files_loaded.contains(file_path) {
            return Ok(());
        }

        // No `O_NONBLOCK`: an explicit FIFO waits for its writer, as in Node.
        let file = match bun_sys::File::openat(
            bun_sys::Fd::cwd(),
            file_path,
            bun_sys::O::RDONLY | bun_sys::O::CLOEXEC,
            0,
        ) {
            Ok(f) => f,
            Err(_) => {
                // prevent retrying
                self.custom_files_loaded.insert(file_path)?;
                return Ok(());
            }
        };

        match read_env_file_contents(&file, EnvFileSource::Explicit)? {
            ReadEnvFile::Empty => {}
            ReadEnvFile::ReadErr(err) => {
                if !self.quiet {
                    bun_core::pretty_errorln!(
                        "<r><red>{}<r> error loading {} file",
                        bstr::BStr::new(err.name()),
                        bstr::BStr::new(file_path)
                    );
                }
            }
            ReadEnvFile::Bytes(buf) => {
                Parser::parse_bytes::<OVERRIDE, false, true>(&buf, &mut self.map, value_buffer)?;
            }
        }

        self.custom_files_loaded.insert(file_path)?;
        Ok(())
    }
}

/// `O_NONBLOCK`: a blocking `open` of a FIFO named `.env` waits for a writer.
#[cfg(unix)]
const DEFAULT_ENV_FILE_OPEN_FLAGS: i32 =
    bun_sys::O::RDONLY | bun_sys::O::CLOEXEC | bun_sys::O::NONBLOCK;
/// No `O_NONBLOCK`: an overlapped Windows handle cannot be read synchronously.
#[cfg(not(unix))]
const DEFAULT_ENV_FILE_OPEN_FLAGS: i32 = bun_sys::O::RDONLY | bun_sys::O::CLOEXEC;

/// Decides what happens to an env file that is not a regular file.
#[derive(Clone, Copy, PartialEq, Eq)]
enum EnvFileSource {
    /// A `.env*` name from the cwd listing: skipped.
    Default,
    /// An `--env-file` argument: read whatever its kind, as in Node.
    Explicit,
}

/// Shared post-open tail of `load_env_file` / `load_env_file_dynamic`.
enum ReadEnvFile {
    /// Zero-length, or a default entry that is not a regular file. The caller marks the slot.
    Empty,
    /// Recoverable read errno (ENOMEM/EPIPE/EACCES/EISDIR) — caller prints
    /// (unless `quiet`), marks the slot, and returns.
    ReadErr(bun_sys::Error),
    /// File contents; `buf.len()` is the amount read.
    Bytes(Vec<u8>),
}

fn read_env_file_contents(
    file: &bun_sys::File,
    source: EnvFileSource,
) -> crate::Result<ReadEnvFile> {
    let stat = file.stat()?;
    let result = if bun_sys::is_regular_file(stat.st_mode as _) {
        if stat.st_size == 0 {
            return Ok(ReadEnvFile::Empty);
        }
        file.read_to_end()
    } else if source == EnvFileSource::Explicit {
        // A pipe or device is not seekable, so `read(2)` until EOF, not `pread`.
        let mut buf = Vec::new();
        file.read_to_end_into(&mut buf).map(|_| buf)
    } else {
        return Ok(ReadEnvFile::Empty);
    };
    match result {
        Ok(buf) if buf.is_empty() => Ok(ReadEnvFile::Empty),
        Ok(buf) => Ok(ReadEnvFile::Bytes(buf)),
        Err(err) => {
            use bun_sys::E;
            match err.get_errno() {
                E::ENOMEM | E::EPIPE | E::EACCES | E::EISDIR => Ok(ReadEnvFile::ReadErr(err)),
                _ => Err(err.into()),
            }
        }
    }
}

struct Parser<'a> {
    pos: usize,
    src: &'a [u8],
    value_buffer: &'a mut Vec<u8>,
}

// Input is UTF-8, so this set must be ASCII-only: 0xA0 is a continuation byte
// there (NBSP is C2 A0), and trimming it byte-wise corrupts multi-byte sequences.
const WHITESPACE_CHARS: &[u8] = b"\t\x0B\x0C \n\r";

impl<'a> Parser<'a> {
    fn skip_line(&mut self) {
        if let Some(i) = strings::index_of_any(&self.src[self.pos..], b"\n\r") {
            self.pos += i + 1;
        } else {
            self.pos = self.src.len();
        }
    }

    fn skip_whitespaces(&mut self) {
        let mut i = self.pos;
        while i < self.src.len() {
            if strings::index_of_char(WHITESPACE_CHARS, self.src[i]).is_none() {
                break;
            }
            i += 1;
        }
        self.pos = i;
    }

    fn parse_key<const CHECK_EXPORT: bool>(&mut self) -> Option<&'a [u8]> {
        if CHECK_EXPORT {
            self.skip_whitespaces();
        }
        let start = self.pos;
        let mut end = start;
        while end < self.src.len() {
            match self.src[end] {
                b'a'..=b'z' | b'A'..=b'Z' | b'0'..=b'9' | b'_' | b'-' | b'.' => {
                    end += 1;
                    continue;
                }
                _ => break,
            }
        }
        if end < self.src.len() && start < end {
            self.pos = end;
            self.skip_whitespaces();
            if self.pos < self.src.len() {
                if CHECK_EXPORT {
                    if end < self.pos && &self.src[start..end] == b"export" {
                        if let Some(key) = self.parse_key::<false>() {
                            return Some(key);
                        }
                    }
                }
                match self.src[self.pos] {
                    b'=' => {
                        self.pos += 1;
                        return Some(&self.src[start..end]);
                    }
                    b':' => {
                        let next = self.pos + 1;
                        if next < self.src.len()
                            && strings::index_of_char(WHITESPACE_CHARS, self.src[next]).is_some()
                        {
                            self.pos += 2;
                            return Some(&self.src[start..end]);
                        }
                    }
                    _ => {}
                }
            }
        }
        self.pos = start;
        None
    }

    fn parse_quoted<const QUOTE: u8>(&mut self) -> Result<Option<&[u8]>, AllocError> {
        debug_assert!(self.src[self.pos] == QUOTE);
        let start = self.pos;
        self.value_buffer.clear(); // Reset the buffer
        let mut end = start + 1;
        while end < self.src.len() {
            match self.src[end] {
                b'\\' => end += 1,
                q if q == QUOTE => {
                    end += 1;
                    // The first unescaped closing quote always terminates the value.
                    // Any trailing content on the same line is discarded (node/dotenv).
                    self.pos = end;
                    self.skip_line();
                    let mut i = start;
                    while i < end {
                        match self.src[i] {
                            b'\\' => {
                                if QUOTE == b'"' {
                                    debug_assert!(i + 1 < end);
                                    match self.src[i + 1] {
                                        b'n' => {
                                            self.value_buffer.push(b'\n');
                                            i += 2;
                                        }
                                        b'r' => {
                                            self.value_buffer.push(b'\r');
                                            i += 2;
                                        }
                                        _ => {
                                            self.value_buffer
                                                .extend_from_slice(&self.src[i..i + 2]);
                                            i += 2;
                                        }
                                    }
                                } else {
                                    self.value_buffer.push(b'\\');
                                    i += 1;
                                }
                            }
                            b'\r' => {
                                i += 1;
                                if i >= end || self.src[i] != b'\n' {
                                    self.value_buffer.push(b'\n');
                                }
                            }
                            c => {
                                self.value_buffer.push(c);
                                i += 1;
                            }
                        }
                    }
                    return Ok(Some(self.value_buffer.as_slice()));
                }
                _ => {}
            }
            end += 1;
        }
        Ok(None)
    }

    fn parse_value<const IS_PROCESS: bool>(&mut self) -> Result<&[u8], AllocError> {
        let start = self.pos;
        self.skip_whitespaces();
        let mut end = self.pos;
        if end >= self.src.len() {
            return Ok(&self.src[self.src.len()..]);
        }
        // reshaped for borrowck — `parse_quoted` returns a borrow of
        // `self.value_buffer`; capture only its length, then re-borrow the buffer
        // after the match so the unquoted fallthrough can re-borrow `self`.
        let quoted_len: Option<usize> = match self.src[end] {
            b'`' => self.parse_quoted::<b'`'>()?.map(|v| v.len()),
            b'"' => self.parse_quoted::<b'"'>()?.map(|v| v.len()),
            b'\'' => self.parse_quoted::<b'\''>()?.map(|v| v.len()),
            _ => None,
        };
        if let Some(len) = quoted_len {
            let value = &self.value_buffer[..len];
            return Ok(if IS_PROCESS {
                value
            } else {
                &value[1..value.len() - 1]
            });
        }
        end = start;
        while end < self.src.len() {
            match self.src[end] {
                b'#' | b'\r' | b'\n' => break,
                _ => {}
            }
            end += 1;
        }
        self.pos = end;
        Ok(strings::trim(&self.src[start..end], WHITESPACE_CHARS))
    }

    fn expand_value(&mut self, map: &Map, value: &[u8]) -> Result<Option<&[u8]>, AllocError> {
        if value.len() < 2 {
            return Ok(None);
        }
        self.value_buffer.clear();
        if !Self::expand_into(map, value, self.value_buffer, 0) {
            return Ok(None);
        }
        Ok(Some(self.value_buffer.as_slice()))
    }

    /// Left-to-right expansion of `$NAME` / `${NAME}` / `${NAME:-default}`.
    /// `${...}` locates its matching `}` by depth (`${` opens, `}` closes,
    /// `\x` skipped); malformed forms fall through as literal text. The `:-`
    /// default clause is expanded recursively.
    fn expand_into(map: &Map, value: &[u8], out: &mut Vec<u8>, depth: u8) -> bool {
        #[inline]
        fn is_ident(b: u8) -> bool {
            matches!(b, b'a'..=b'z' | b'A'..=b'Z' | b'0'..=b'9' | b'_')
        }

        let mut pos = 0;
        let mut changed = false;
        while pos < value.len() {
            let b = value[pos];
            if b == b'\\' && value.get(pos + 1) == Some(&b'$') {
                out.push(b'$');
                pos += 2;
                changed = true;
                continue;
            }
            if b != b'$' || pos + 1 >= value.len() {
                out.push(b);
                pos += 1;
                continue;
            }
            let next = value[pos + 1];
            if next == b'{' {
                let inner_start = pos + 2;
                let close = {
                    let mut i = inner_start;
                    let mut nest = 1usize;
                    loop {
                        if i >= value.len() {
                            break None;
                        }
                        match value[i] {
                            b'\\' if i + 1 < value.len() => i += 2,
                            b'$' if value.get(i + 1) == Some(&b'{') => {
                                nest += 1;
                                i += 2;
                            }
                            b'}' => {
                                nest -= 1;
                                if nest == 0 {
                                    break Some(i);
                                }
                                i += 1;
                            }
                            _ => i += 1,
                        }
                    }
                };
                let Some(close) = close else {
                    out.extend_from_slice(&value[pos..]);
                    pos = value.len();
                    continue;
                };
                changed = true;
                let inner = &value[inner_start..close];
                let key_end = inner
                    .iter()
                    .position(|&c| !is_ident(c))
                    .unwrap_or(inner.len());
                let key = &inner[..key_end];
                let rest = &inner[key_end..];
                if rest.is_empty() {
                    if let Some(v) = map.get(key) {
                        out.extend_from_slice(v);
                    }
                } else if let Some(default) = rest.strip_prefix(b":-") {
                    if let Some(v) = map.get(key) {
                        out.extend_from_slice(v);
                    } else if depth < 200 {
                        Self::expand_into(map, default, out, depth + 1);
                    } else {
                        out.extend_from_slice(default);
                    }
                } else {
                    out.extend_from_slice(&value[pos..=close]);
                }
                pos = close + 1;
                continue;
            }
            if is_ident(next) {
                changed = true;
                let key_start = pos + 1;
                let mut k = key_start;
                while k < value.len() && is_ident(value[k]) {
                    k += 1;
                }
                if let Some(v) = map.get(&value[key_start..k]) {
                    out.extend_from_slice(v);
                }
                pos = k;
                continue;
            }
            out.push(b'$');
            pos += 1;
        }
        changed
    }

    fn parse<const OVERRIDE: bool, const IS_PROCESS: bool, const EXPAND: bool>(
        &mut self,
        map: &mut Map,
    ) -> Result<(), AllocError> {
        let mut count = map.map.count();
        while self.pos < self.src.len() {
            let Some(key) = self.parse_key::<true>() else {
                self.skip_line();
                continue;
            };
            let value = self.parse_value::<IS_PROCESS>()?;
            // reshaped for borrowck — value borrows self.value_buffer; copy before map mut.
            let value_owned: Box<[u8]> = Box::from(value);
            let entry = map.map.get_or_put(key)?;
            if entry.found_existing {
                if entry.index < count {
                    // Allow keys defined later in the same file to override keys defined earlier
                    // https://github.com/oven-sh/bun/issues/1262
                    if !OVERRIDE {
                        continue;
                    }
                }
                // else: previous value freed by Drop on assignment below
            }
            *entry.value_ptr = HashTableValue { value: value_owned };
        }
        if !IS_PROCESS && EXPAND {
            // borrowck — index-based iteration: clone the value bytes, run
            // expansion against an immutable `&Map`, then write back via
            // `values_mut()`. Values are dupe'd by `parse` above, so length
            // is bounded by file size.
            let total = map.map.count();
            let mut idx = count;
            while idx < total {
                let current: Box<[u8]> = Box::from(&*map.map.values()[idx].value);
                if let Some(expanded) = self.expand_value(map, &current)? {
                    map.map.values_mut()[idx] = HashTableValue {
                        value: Box::from(expanded),
                    };
                }
                idx += 1;
            }
            count = 0;
        }
        let _ = count;
        Ok(())
    }

    /// Builds a [`Parser`] over `src` (minus any UTF-8 BOM) and runs [`Parser::parse`] into `map`.
    fn parse_bytes<const OVERRIDE: bool, const IS_PROCESS: bool, const EXPAND: bool>(
        src: &[u8],
        map: &mut Map,
        value_buffer: &mut Vec<u8>,
    ) -> Result<(), AllocError> {
        // Clear the buffer before each parse to ensure no leftover data
        value_buffer.clear();
        let mut parser = Parser {
            pos: 0,
            // Notepad and PowerShell redirects emit a UTF-8 BOM; without this the
            // first key fails `parse_key` and `skip_line` silently drops line 1.
            src: strings::without_utf8_bom(src),
            value_buffer,
        };
        parser.parse::<OVERRIDE, IS_PROCESS, EXPAND>(map)
    }
}

#[derive(Default, Clone)]
pub struct HashTableValue {
    // `Box<[u8]>` is owned-by-default, trading some copies for uniform
    // ownership.
    pub value: Box<[u8]>,
}

// On Windows, environment variables are case-insensitive. So we use a case-insensitive hash map.
// An issue with this exact implementation is unicode characters can technically appear in these
// keys, and we use a simple toLowercase function that only applies to ascii, so this will make
// some strings collide.
#[cfg(not(windows))]
pub type HashTable = bun_collections::StringArrayHashMap<HashTableValue>;
#[cfg(windows)]
pub type HashTable = bun_collections::CaseInsensitiveAsciiStringArrayHashMap<HashTableValue>;

pub struct Map {
    pub map: HashTable,
}

impl Map {
    /// Builds a NULL-terminated `K=V\0` envp array. Returns an owning struct so
    /// dropping it frees the joined buffers (PORTING.md §Forbidden: no Box::leak).
    pub fn create_null_delimited_env_map(&mut self) -> Result<NullDelimitedEnvMap, AllocError> {
        let envp_count = self.map.count();
        let mut storage: Vec<Box<[u8]>> = Vec::with_capacity(envp_count);
        let mut envp_buf: Vec<*const c_char> = Vec::with_capacity(envp_count + 1);
        {
            let mut it = self.map.iterator();
            while let Some(pair) = it.next() {
                let klen = pair.key_ptr.len();
                let vlen = pair.value_ptr.value.len();
                let mut env_buf = vec![0u8; klen + vlen + 2].into_boxed_slice();
                env_buf[..klen].copy_from_slice(pair.key_ptr);
                env_buf[klen] = b'=';
                env_buf[klen + 1..klen + 1 + vlen].copy_from_slice(&pair.value_ptr.value);
                // env_buf[klen + 1 + vlen] = 0; (already zero-initialized)
                envp_buf.push(env_buf.as_ptr().cast::<c_char>());
                storage.push(env_buf);
            }
            debug_assert!(envp_buf.len() == envp_count);
        }
        envp_buf.push(core::ptr::null()); // sentinel
        Ok(NullDelimitedEnvMap {
            _storage: storage,
            envp: envp_buf.into_boxed_slice(),
        })
    }

    /// Build a heap-allocated Windows environment block suitable for
    /// `CreateProcessW`'s `lpEnvironment` with `CREATE_UNICODE_ENVIRONMENT`.
    ///
    /// The 32,767-character limit applies to `CreateProcessA` (ANSI) only; the
    /// Unicode block has no documented size limit, so this sizes the buffer to
    /// the actual contents instead of failing when the environment is large.
    pub fn write_windows_env_block(&mut self) -> Vec<u16> {
        // UTF-16 output is at most one code unit per UTF-8 input byte (ASCII
        // is 1:1; multi-byte sequences shrink; surrogate pairs are 2 units
        // from 4 bytes), so the UTF-8 byte length is a safe upper bound.
        let mut capacity: usize = 4;
        {
            let mut it = self.map.iterator();
            while let Some(pair) = it.next() {
                capacity += pair.key_ptr.len() + 1 + pair.value_ptr.value.len() + 1;
            }
        }

        let mut result = vec![0u16; capacity];
        let mut i: usize = 0;
        {
            let mut it = self.map.iterator();
            while let Some(pair) = it.next() {
                i += strings::convert_utf8_to_utf16_in_buffer(&mut result[i..], pair.key_ptr).len();
                result[i] = b'=' as u16;
                i += 1;
                i += strings::convert_utf8_to_utf16_in_buffer(
                    &mut result[i..],
                    &pair.value_ptr.value,
                )
                .len();
                result[i] = 0;
                i += 1;
            }
        }
        // Terminator: four trailing NUL u16s (already zero-initialized above).
        result.truncate(i + 4);
        result
    }

    pub fn iterator(&mut self) -> <HashTable as ArrayHashMapExt>::Iterator<'_> {
        self.map.iterator()
    }

    #[inline]
    pub(crate) fn init() -> Map {
        Map {
            map: HashTable::default(),
        }
    }

    #[inline]
    pub fn put(&mut self, key: &[u8], value: &[u8]) -> Result<(), AllocError> {
        #[cfg(all(windows, debug_assertions))]
        {
            debug_assert!(strings::index_of_char(key, b'\x00').is_none());
        }
        self.map.put(
            key,
            HashTableValue {
                value: Box::from(value),
            },
        )
    }

    pub fn ensure_unused_capacity(&mut self, additional_count: usize) -> Result<(), AllocError> {
        self.map.ensure_unused_capacity(additional_count)
    }

    pub fn put_assume_capacity(&mut self, key: &[u8], value: &[u8]) {
        #[cfg(all(windows, debug_assertions))]
        {
            debug_assert!(strings::index_of_char(key, b'\x00').is_none());
        }
        self.map.put_assume_capacity(
            key,
            HashTableValue {
                value: Box::from(value),
            },
        );
    }

    #[inline]
    pub fn put_alloc_key_and_value(&mut self, key: &[u8], value: &[u8]) -> Result<(), AllocError> {
        let gop = self.map.get_or_put(key)?;
        *gop.value_ptr = HashTableValue {
            value: Box::from(value),
        };
        if !gop.found_existing {
            *gop.key_ptr = Box::from(key);
        }
        Ok(())
    }

    #[inline]
    pub fn put_alloc_value(&mut self, key: &[u8], value: &[u8]) -> Result<(), AllocError> {
        // `HashTableValue { value: Box<[u8]> }` storage forces a copy, so this is
        // equivalent to `put`. Kept as a thin wrapper to preserve call-site alloc intent
        // should storage ever change to `Cow`/borrowed.
        self.put(key, value)
    }

    #[inline]
    pub fn get_or_put_without_value(
        &mut self,
        key: &[u8],
    ) -> Result<GetOrPutResult<'_, Box<[u8]>, HashTableValue>, AllocError> {
        self.map.get_or_put(key)
    }

    #[inline]
    pub fn get(&self, key: &[u8]) -> Option<&[u8]> {
        self.map.get(key).map(|entry| entry.value.as_ref())
    }

    #[inline]
    pub fn put_default(&mut self, key: &[u8], value: &[u8]) -> Result<(), AllocError> {
        let _ = self.map.get_or_put_value(
            key,
            HashTableValue {
                value: Box::from(value),
            },
        )?;
        Ok(())
    }

    pub fn remove(&mut self, key: &[u8]) {
        let _ = self.map.swap_remove(key);
    }

    pub fn clone_with_allocator(&self) -> Result<Map, AllocError> {
        // allocator param dropped — global mimalloc
        Ok(Map {
            map: self.map.clone()?,
        })
    }

    /// The process's own (no `.env`), minus `git rev-parse --local-env-vars` except `GIT_CONFIG*`.
    pub fn for_git_child() -> Result<Map, AllocError> {
        const REPOSITORY_VARS: &[&[u8]] = &[
            b"GIT_DIR",
            b"GIT_WORK_TREE",
            b"GIT_IMPLICIT_WORK_TREE",
            b"GIT_INDEX_FILE",
            b"GIT_NAMESPACE",
            b"GIT_OBJECT_DIRECTORY",
            b"GIT_ALTERNATE_OBJECT_DIRECTORIES",
            b"GIT_COMMON_DIR",
            b"GIT_PREFIX",
            b"GIT_GRAFT_FILE",
            b"GIT_SHALLOW_FILE",
            b"GIT_NO_REPLACE_OBJECTS",
            b"GIT_REPLACE_REF_BASE",
        ];
        let mut loader = Loader::init();
        loader.load_process()?;
        for key in REPOSITORY_VARS {
            loader.map.remove(key);
        }
        Ok(loader.map)
    }
}

/// Owns the `K=V\0` strings backing a NULL-terminated envp array.
/// Dropping this frees every entry (PORTING.md §Forbidden: no Box::leak).
///
/// LAYOUT NOTE: `envp` stores raw `*const c_char` (with a trailing
/// `ptr::null()` sentinel), **not** `Option<*const c_char>`. Raw pointers are
/// already nullable, so `Option<*const T>` is *not* niche-optimized — it is a
/// 2-word `(tag, ptr)` pair. Casting `*const Option<*const c_char>` to
/// `*const *const c_char` for `execve()` interleaves `Some`-discriminant
/// `0x1` words between the real pointers and the kernel faults with `EFAULT`.
/// The correct FFI representation is `*const c_char`, not
/// `Option<*const c_char>`.
pub struct NullDelimitedEnvMap {
    _storage: Vec<Box<[u8]>>,
    envp: Box<[*const c_char]>,
}

impl NullDelimitedEnvMap {
    /// `[:null]?[*:0]const u8` — last element is `ptr::null()`.
    #[inline]
    pub fn as_slice(&self) -> &[*const c_char] {
        &self.envp
    }
    /// Raw `*const ?[*:0]const u8` for FFI (`envp`-style).
    #[inline]
    pub fn as_ptr(&self) -> *const *const c_char {
        self.envp.as_ptr()
    }
    /// The `KEY=VALUE` entries as C strings.
    pub fn iter(&self) -> impl Iterator<Item = &core::ffi::CStr> {
        self._storage.iter().map(|s| {
            core::ffi::CStr::from_bytes_until_nul(s).expect("entries are built NUL-terminated")
        })
    }
}

// Drop replaces deinit (only frees hash_map storage; Rust does this automatically)

// Global singleton. Installed and used under a single-thread (CLI-init)
// invariant. We store a raw `*mut` in an AtomicPtr (overwritable) and hand the
// raw pointer back to callers so the no-alias `&mut` proof obligation lives at
// the *call site*, not here — manufacturing `&'static mut` inside an accessor
// is aliased-&mut UB the moment two callers hold results simultaneously
// (PORTING.md §Forbidden: lifetime-extension via `unsafe { &*(p as *const _) }`).
pub static INSTANCE: AtomicPtr<Loader> = AtomicPtr::new(core::ptr::null_mut());

/// Read the global singleton as a raw pointer — `Some(ptr)` once `set_instance` has been called.
/// Callers must `unsafe { &mut *ptr }` at point of use under the single-thread
/// CLI-init invariant: the loader is only installed and dereferenced on the
/// main thread, so no two `&mut` borrows can be live at once.
#[inline]
pub fn instance() -> Option<*mut Loader> {
    let ptr = INSTANCE.load(Ordering::Acquire);
    if ptr.is_null() { None } else { Some(ptr) }
}

/// Install the global singleton. Overwrites any previous value (test harnesses
/// / worker re-init may call this more than once).
#[inline]
pub fn set_instance(loader: *mut Loader) {
    INSTANCE.store(loader, Ordering::Release);
}
