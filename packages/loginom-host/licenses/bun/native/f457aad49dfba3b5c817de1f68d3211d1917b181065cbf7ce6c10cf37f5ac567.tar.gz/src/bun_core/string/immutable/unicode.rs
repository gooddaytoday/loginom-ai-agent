use crate::string::WStr;
use crate::string::immutable::{
    U3Fast, UNICODE_REPLACEMENT as unicode_replacement, eql_comptime_ignore_len as eql_ignore_len,
    first_non_ascii, first_non_ascii16,
};
use bun_alloc::AllocError;

use crate::string::immutable::CodePoint; // i32
/// Borrow `wbuf[..len]` as `&WStr` (NUL at `wbuf[len]`). Local copy of the
/// helper that moved to `bun_paths::string_paths` with the rest of the
/// Windows path-shape transcoders.
#[inline(always)]
fn wstr_in_buf(wbuf: &[u16], len: usize) -> &WStr {
    WStr::from_buf(wbuf, len)
}
use bun_simdutf_sys::simdutf;

crate::declare_scope!(strings, hidden);

/// Widen-append `src` ASCII bytes onto `dst` as `u16` code units. Reserves,
/// commits the new length, then scalar-widens via `copy_u8_into_u16`. Folds
/// the `reserve + set_len + copy_u8_into_u16` triple repeated across the
/// UTF-8→UTF-16 paths into one audited block.
#[inline]
fn append_u8_as_u16(dst: &mut Vec<u16>, src: &[u8]) {
    if src.is_empty() {
        return;
    }
    // SAFETY: copy_u8_into_u16 fills exactly src.len() slots.
    copy_u8_into_u16(unsafe { crate::vec::writable_slice(dst, src.len()) }, src);
}

/// Narrow-append `src` Latin-1/ASCII `u16` code units onto `dst` as bytes.
/// Mirrors [`append_u8_as_u16`] for the UTF-16→UTF-8 fast path.
#[inline]
fn append_u16_as_u8(dst: &mut Vec<u8>, src: &[u16]) {
    if src.is_empty() {
        return;
    }
    // SAFETY: copy_u16_into_u8 fills exactly src.len() bytes.
    copy_u16_into_u8(unsafe { crate::vec::writable_slice(dst, src.len()) }, src);
}

// ───── canonical WTF-8 single-rune decode ─────
// Lives in `bun_core::string::immutable::unicode_draft` (this file), re-exported
// through the inline `pub mod unicode` in immutable.rs and onward as
// `bun_core::strings::{decode_wtf8_rune_t, decode_wtf8_rune_t_multibyte}`.
//
// Visibility promoted pub(super) → pub so the inline shim mod can re-export
// instead of carrying a second body, and so md/glob/parsers can call directly.

/// Integer types usable as the codepoint result of [`decode_wtf8_rune_t`].
/// Sealed to two instantiations (`i32` aka `CodePoint`, and `u32`);
/// every caller in-tree is one of these.
///
/// Bounds widened from `From<u8>` to include the bit-ops needed by
/// `decode_wtf8_rune_t_multibyte` plus a `from_u32` constructor (folds in the
/// previously separate `FromU32`/`FromU32Const` helper traits).
pub trait CodePointZero:
    Copy
    + Eq
    + PartialOrd
    + From<u8>
    + core::ops::Shl<u32, Output = Self>
    + core::ops::BitOr<Output = Self>
    + core::ops::BitAnd<Output = Self>
{
    fn from_u32(v: u32) -> Self;
    /// Alias kept for `decode_wtf8_rune_t_multibyte` integer-literal compares.
    #[inline]
    fn from_u32_const(v: u32) -> Self {
        Self::from_u32(v)
    }
}

impl CodePointZero for CodePoint {
    #[inline]
    fn from_u32(v: u32) -> Self {
        v as i32
    }
}

impl CodePointZero for u32 {
    #[inline]
    fn from_u32(v: u32) -> Self {
        v
    }
}

// ───────────────────────────── helpers ─────────────────────────────

/// Convert potentially ill-formed UTF-8 or UTF-16 bytes to a Unicode Codepoint.
/// - Invalid codepoints are replaced with `zero` parameter
/// - Null bytes return 0
pub fn decode_wtf8_rune_t<T: CodePointZero>(p: [u8; 4], len: U3Fast, zero: T) -> T {
    if len == 0 {
        return zero;
    }
    if len == 1 {
        return T::from(p[0]);
    }

    decode_wtf8_rune_t_multibyte::<T>(p, len, zero)
}

// ───────────────────────────── UTF16 → UTF8 ─────────────────────────────
//
// The transcoding suite (`convert_utf16_to_utf8{,_append}`, `to_utf8_alloc{,_z}`,
// `to_utf8_alloc_with_type`, `to_utf8_list_with_type`, `to_utf8_append_to_list`,
// `to_utf8_from_latin1{,_z}`, `allocate_latin1_into_utf8_with_list`) lives
// canonically in `crate::strings_impl` (T0) and is re-exported by
// `crate::string::immutable`. The `pub(super)` copies that previously lived here were
// shadowed dead code (the parent module re-exports the bun_core versions, not
// these) and have been deleted in D056.
//
// Kept below: the two variants bun_core does NOT provide —
//   * `convert_utf16_to_utf8_without_invalid_surrogate_pairs` (hard-error on
//     unpaired surrogates instead of U+FFFD replacement), and
//   * `to_utf8_list_with_type_bun::<SKIP_TRAILING_REPLACEMENT>` (returns the
//     dangling lead surrogate instead of replacing it — streaming TextEncoder
//     contract).

/// Returns `Some(u16)` (the trailing lead surrogate) when `SKIP_TRAILING_REPLACEMENT` and a
/// dangling lead surrogate is at the end; otherwise `None`.
pub fn to_utf8_list_with_type_bun<const SKIP_TRAILING_REPLACEMENT: bool>(
    list: &mut Vec<u8>,
    utf16: &[u16],
) -> Result<Option<u16>, AllocError> {
    let mut utf16_remaining = utf16;

    while let Some(i) = first_non_ascii16(utf16_remaining) {
        let i = i as usize;
        let to_copy = &utf16_remaining[..i];
        utf16_remaining = &utf16_remaining[i..];
        let token = utf16_remaining[0];

        let replacement = utf16_codepoint_with_fffd_and_first_input_char(token, utf16_remaining);
        utf16_remaining = &utf16_remaining[replacement.len as usize..];

        let count: usize = replacement.utf8_width() as usize;
        #[cfg(not(target_family = "wasm"))]
        let extra = ((utf16_remaining.len() as u64 & ((1u64 << 52) - 1)) as f64 * 1.2) as usize;
        #[cfg(target_family = "wasm")]
        let extra = utf16_remaining.len() + 4;
        list.try_reserve_exact(i + count + extra)
            .map_err(|_| AllocError)?;
        append_u16_as_u8(list, to_copy);

        if SKIP_TRAILING_REPLACEMENT {
            if replacement.is_lead && utf16_remaining.is_empty() {
                return Ok(Some(token));
            }
        }

        // Encode into a stack scratch then append the `count` (≤ 4) bytes.
        // Capacity for `count` is reserved above, so `extend_from_slice` is a
        // bounds-check + memcpy with no realloc — same write traffic as the
        // previous in-place `*[4]u8` cast without the raw-pointer view.
        let mut four = [0u8; 4];
        let _ = crate::strings_impl::encode_wtf8_rune(&mut four, replacement.code_point);
        list.extend_from_slice(&four[..count]);
    }

    if !utf16_remaining.is_empty() {
        list.try_reserve_exact(utf16_remaining.len())
            .map_err(|_| AllocError)?;
        append_u16_as_u8(list, utf16_remaining);
    }

    crate::scoped_log!(strings, "UTF16 {} -> {} UTF8", utf16.len(), list.len());

    if SKIP_TRAILING_REPLACEMENT {
        return Ok(None);
    }
    Ok(None)
}

use crate::strings_impl::EncodeIntoResult;

/// Thin wrapper over the canonical T0 `crate::strings_impl::allocate_latin1_into_utf8_with_list`.
/// Kept `Result`-typed for source-compat with existing callers (TextEncoder /
/// encoding.rs / ConsoleObject) — the bun_core impl is infallible per
/// PORTING.md §Allocators (panic-on-OOM), so this is always `Ok`.
pub fn allocate_latin1_into_utf8(latin1_: &[u8]) -> Result<Vec<u8>, AllocError> {
    Ok(crate::strings_impl::allocate_latin1_into_utf8_with_list(
        Vec::with_capacity(latin1_.len()),
        0,
        latin1_,
    ))
}

// ─── CANONICAL: UTF-16 codepoint decode ─────────────────────────────────────
// Re-exported from
// immutable.rs as `strings::{utf16_codepoint, utf16_codepoint_with_fffd,
// UTF16Replacement}`; the parallel Utf16CodepointLen + duplicate struct/fns
// that lived in immutable.rs are deleted in favour of this single source of
// truth. All callers (visible.rs ×1; unicode.rs ×4; shell_parser/parse.rs ×1;
// TextEncoderStreamEncoder.rs ×1) resolve through the
// `pub use unicode_draft::{…}` re-export with no source change.

/// `strings.UTF16Replacement` — decoded UTF-16 codepoint
/// with surrogate metadata.
#[derive(Clone, Copy)]
pub struct UTF16Replacement {
    pub code_point: u32,
    pub len: U3Fast,

    /// Explicit fail boolean to distinguish between a Unicode Replacement Codepoint
    /// that was already in there
    /// and a genuine error.
    pub fail: bool,

    pub(crate) can_buffer: bool,
    pub(crate) is_lead: bool,
}

impl Default for UTF16Replacement {
    fn default() -> Self {
        Self {
            code_point: unicode_replacement,
            len: 0,
            fail: false,
            can_buffer: true,
            is_lead: false,
        }
    }
}

impl UTF16Replacement {
    #[inline]
    pub fn utf8_width(self) -> U3Fast {
        match self.code_point {
            0..=0x7F => 1,
            0x80..=0x7FF => 2,
            0x800..=0xFFFF => 3,
            _ => 4,
        }
    }
}

fn convert_utf8_bytes_into_utf16_with_length(
    sequence: [u8; 4],
    len: U3Fast,
    remaining_len: usize,
) -> UTF16Replacement {
    debug_assert!(sequence[0] > 127);
    match len {
        2 => {
            debug_assert!(sequence[0] >= 0xC0);
            debug_assert!(sequence[0] <= 0xDF);
            if sequence[1] < 0x80 || sequence[1] > 0xBF {
                return UTF16Replacement {
                    len: 1,
                    fail: true,
                    can_buffer: remaining_len < 2,
                    ..Default::default()
                };
            }
            UTF16Replacement {
                len,
                code_point: (u32::from(sequence[0]) << 6) + u32::from(sequence[1]) - 0x00003080,
                ..Default::default()
            }
        }
        3 => {
            debug_assert!(sequence[0] >= 0xE0);
            debug_assert!(sequence[0] <= 0xEF);
            match sequence[0] {
                0xE0 => {
                    if sequence[1] < 0xA0 || sequence[1] > 0xBF {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
                0xED => {
                    if sequence[1] < 0x80 || sequence[1] > 0x9F {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
                _ => {
                    if sequence[1] < 0x80 || sequence[1] > 0xBF {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
            }
            if sequence[2] < 0x80 || sequence[2] > 0xBF {
                return UTF16Replacement {
                    len: 2,
                    fail: true,
                    can_buffer: remaining_len < 3,
                    ..Default::default()
                };
            }
            UTF16Replacement {
                len,
                code_point: ((u32::from(sequence[0]) << 12)
                    + (u32::from(sequence[1]) << 6)
                    + u32::from(sequence[2]))
                    - 0x000E2080,
                ..Default::default()
            }
        }
        4 => {
            match sequence[0] {
                0xF0 => {
                    if sequence[1] < 0x90 || sequence[1] > 0xBF {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
                0xF4 => {
                    if sequence[1] < 0x80 || sequence[1] > 0x8F {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
                // invalid code point
                // this used to be an assertion
                0..=0xEF | 0xF5..=u8::MAX => {
                    return UTF16Replacement {
                        len: 1,
                        fail: true,
                        can_buffer: false,
                        ..Default::default()
                    };
                }
                _ => {
                    if sequence[1] < 0x80 || sequence[1] > 0xBF {
                        return UTF16Replacement {
                            len: 1,
                            fail: true,
                            can_buffer: remaining_len < 2,
                            ..Default::default()
                        };
                    }
                }
            }

            if sequence[2] < 0x80 || sequence[2] > 0xBF {
                return UTF16Replacement {
                    len: 2,
                    fail: true,
                    can_buffer: remaining_len < 3,
                    ..Default::default()
                };
            }
            if sequence[3] < 0x80 || sequence[3] > 0xBF {
                return UTF16Replacement {
                    len: 3,
                    fail: true,
                    can_buffer: remaining_len < 4,
                    ..Default::default()
                };
            }
            UTF16Replacement {
                len,
                code_point: ((u32::from(sequence[0]) << 18)
                    + (u32::from(sequence[1]) << 12)
                    + (u32::from(sequence[2]) << 6)
                    + u32::from(sequence[3]))
                    - 0x03C82080,
                ..Default::default()
            }
        }
        // invalid unicode sequence
        // 1 or 0 are both invalid here
        _ => UTF16Replacement {
            len: 1,
            fail: true,
            ..Default::default()
        },
    }
}

// This variation matches WebKit behavior.
// fn convertUTF8BytesIntoUTF16(sequence: *const [4]u8, remaining_len: usize) UTF16Replacement {
pub(super) fn convert_utf8_bytes_into_utf16(bytes: &[u8]) -> UTF16Replacement {
    let sequence: [u8; 4] = match bytes.len() {
        0 => unreachable!(),
        1 => [bytes[0], 0, 0, 0],
        2 => [bytes[0], bytes[1], 0, 0],
        3 => [bytes[0], bytes[1], bytes[2], 0],
        _ => bytes[..4].try_into().expect("infallible: size matches"),
    };
    debug_assert!(sequence[0] > 127);
    let sequence_length = non_ascii_sequence_length(sequence[0]);
    convert_utf8_bytes_into_utf16_with_length(sequence, sequence_length, bytes.len())
}

/// Codepoint at the front of non-empty `bytes`; ill-formed input is U+FFFD per maximal subpart.
pub fn utf8_codepoint_with_fffd(bytes: &[u8]) -> UTF16Replacement {
    let lead = bytes[0];
    if lead < 0x80 {
        return UTF16Replacement {
            code_point: u32::from(lead),
            len: 1,
            ..Default::default()
        };
    }
    let r = convert_utf8_bytes_into_utf16(bytes);
    UTF16Replacement {
        len: r.len.max(1),
        ..r
    }
}

// SWAR body moved down into `crate::strings_impl` (T0) so the canonical
// `copy_latin1_into_utf8` is the spec-faithful fast path. Re-export here so
// `pub use unicode_draft::copy_latin1_into_utf8_stop_on_non_ascii` in
// `immutable.rs` keeps resolving.
pub use crate::strings_impl::copy_latin1_into_utf8_stop_on_non_ascii;

pub fn copy_cp1252_into_utf16(buf_: &mut [u16], latin1_: &[u8]) -> EncodeIntoResult {
    let buf_total = buf_.len();
    let latin1_total = latin1_.len();
    let mut buf: &mut [u16] = buf_;
    let mut latin1: &[u8] = latin1_;
    while !buf.is_empty() && !latin1.is_empty() {
        let to_write = first_non_ascii(latin1)
            .map(|v| v as usize)
            .unwrap_or_else(|| latin1.len().min(buf.len()));
        copy_u8_into_u16(buf, &latin1[..to_write]);

        latin1 = &latin1[to_write..];
        buf = &mut buf[to_write..];
        if !latin1.is_empty() && buf.len() >= 1 {
            buf[0] = cp1252_to_codepoint_bytes_assume_not_ascii16(u32::from(latin1[0]));
            latin1 = &latin1[1..];
            buf = &mut buf[1..];
        }
    }

    EncodeIntoResult {
        read: buf_total - buf.len(),
        written: latin1_total - latin1.len(),
    }
}

pub fn copy_latin1_into_utf16(buf_: &mut [u16], latin1_: &[u8]) -> EncodeIntoResult {
    let len = buf_.len().min(latin1_.len());
    debug_assert_eq!(buf_[..len].len(), latin1_[..len].len());
    for (out, &inp) in buf_[..len].iter_mut().zip(latin1_[..len].iter()) {
        *out = u16::from(inp);
    }
    EncodeIntoResult {
        read: len,
        written: len,
    }
}

pub fn element_length_cp1252_into_utf16(cp1252_: &[u8]) -> usize {
    // cp1252 is always at most 1 UTF-16 code unit long
    cp1252_.len()
}

#[inline]
pub fn copy_u8_into_u16(output_: &mut [u16], input_: &[u8]) {
    let output = output_;
    let input = input_;
    debug_assert!(input.len() <= output.len());

    let n = input.len().min(output.len());
    for i in 0..n {
        output[i] = u16::from(input[i]);
    }
}

#[inline]
pub fn copy_u16_into_u8(output: &mut [u8], input: &[u16]) {
    debug_assert!(input.len() <= output.len());
    let count = input.len().min(output.len());

    bun_highway::copy_u16_to_u8(&input[..count], &mut output[..count]);
}

pub fn copy_latin1_into_ascii(dest: &mut [u8], src: &[u8]) {
    let mut remain = src;
    let mut to: &mut [u8] = dest;

    let non_ascii_offset = first_non_ascii(remain)
        .map(|v| v as usize)
        .unwrap_or(remain.len());
    if non_ascii_offset > 0 {
        to[..non_ascii_offset].copy_from_slice(&remain[..non_ascii_offset]);
        remain = &remain[non_ascii_offset..];
        to = &mut to[non_ascii_offset..];

        // ascii fast path
        if remain.is_empty() {
            return;
        }
    }

    if to.len() >= 16 {
        const VECTOR_SIZE: usize = 16;
        let remain_in_u64_len = remain.len() - (remain.len() % VECTOR_SIZE);
        let to_in_u64_len = to.len() - (to.len() % VECTOR_SIZE);
        // Reshaped for borrowck — operate on byte indices instead of bytesAsSlice(u64).
        let end_vector_len = (remain_in_u64_len / 8).min(to_in_u64_len / 8);
        let mut idx = 0usize;
        // using the pointer instead of the length is super important for the codegen
        while idx < end_vector_len {
            let buf = u64::from_ne_bytes(
                remain[idx * 8..idx * 8 + 8]
                    .try_into()
                    .expect("infallible: size matches"),
            );
            // this gets auto-vectorized
            const MASK: u64 = 0x7f7f7f7f7f7f7f7f;
            to[idx * 8..idx * 8 + 8].copy_from_slice(&(buf & MASK).to_ne_bytes());
            idx += 1;
        }
        remain = &remain[remain_in_u64_len..];
        to = &mut to[to_in_u64_len..];
    }

    for to_byte in to.iter_mut() {
        *to_byte = remain[0] & 0x7f;
        remain = &remain[1..];
    }
}

/// It is common on Windows to find files that are not encoded in UTF8. Most of these include
/// a 'byte-order mark' codepoint at the start of the file. The layout of this codepoint can
/// determine the encoding.
///
/// https://en.wikipedia.org/wiki/Byte_order_mark
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum BOM {
    Utf8,
    Utf16Le,
}

impl BOM {
    pub const UTF8_BYTES: [u8; 3] = [0xef, 0xbb, 0xbf];
    pub(crate) const UTF16_LE_BYTES: [u8; 2] = [0xff, 0xfe];

    pub fn detect(bytes: &[u8]) -> Option<BOM> {
        if bytes.len() < 3 {
            return None;
        }
        if eql_ignore_len(bytes, &Self::UTF8_BYTES) {
            return Some(BOM::Utf8);
        }
        if eql_ignore_len(bytes, &Self::UTF16_LE_BYTES) {
            return Some(BOM::Utf16Le);
        }
        None
    }

    pub fn detect_and_split(bytes: &[u8]) -> (Option<BOM>, &[u8]) {
        let bom = Self::detect(bytes);
        match bom {
            None => (None, bytes),
            Some(b) => (bom, &bytes[b.length()..]),
        }
    }

    pub(crate) fn get_header(self) -> &'static [u8] {
        match self {
            BOM::Utf8 => &Self::UTF8_BYTES,
            BOM::Utf16Le => &Self::UTF16_LE_BYTES,
        }
    }

    pub(crate) fn length(self) -> usize {
        self.get_header().len()
    }

    pub fn tag_name(self) -> &'static str {
        match self {
            BOM::Utf8 => "utf8",
            BOM::Utf16Le => "utf16_le",
        }
    }

    /// If an allocation is needed, free the input and the caller will
    /// replace it with the new return
    pub fn remove_and_convert_to_utf8_and_free(self, mut bytes: Vec<u8>) -> Vec<u8> {
        match self {
            BOM::Utf8 => {
                crate::vec::drain_front(&mut bytes, Self::UTF8_BYTES.len());
                bytes
            }
            BOM::Utf16Le => {
                // `trimmed_bytes` is `&[u8]` at offset 2 of a `Vec<u8>`; alignment is
                // not guaranteed ≥ 2, so casting to `&[u16]` is UB. Route through
                // the byte-level helper which copies into an aligned `Vec<u16>` first.
                let trimmed_bytes = &bytes[Self::UTF16_LE_BYTES.len()..];
                let out = crate::strings_impl::to_utf8_alloc_from_le_bytes(trimmed_bytes);
                drop(bytes);
                out
            }
        }
    }

    /// This is required for the fs `use_shared_buffer` flag. we cannot free that pointer.
    /// The returned slice will always point to the base of the input.
    ///
    /// Requires an arraylist in case it must be grown.
    pub fn remove_and_convert_to_utf8_without_dealloc<'a>(self, list: &'a mut Vec<u8>) -> &'a [u8] {
        match self {
            BOM::Utf8 => {
                let n = Self::UTF8_BYTES.len();
                let len = list.len();
                list.copy_within(n.., 0);
                &list[..len - n]
            }
            BOM::Utf16Le => {
                // See `remove_and_convert_to_utf8_and_free` — `&list[2..]` has no
                // u16-alignment guarantee, so use the byte-level transcode helper.
                let out = crate::strings_impl::to_utf8_alloc_from_le_bytes(
                    &list[Self::UTF16_LE_BYTES.len()..],
                );
                list.clear();
                list.extend_from_slice(&out);
                // Return the list slice (not `out`, the new alloc) to honor the
                // "always points to the base of the input" doc comment.
                &list[..]
            }
        }
    }
}

// https://github.com/WebKit/WebKit/blob/443e796d1538654c34f2690e39600c70c8052b63/Source/WebCore/PAL/pal/text/TextCodecUTF8.cpp#L69
fn non_ascii_sequence_length(first_byte: u8) -> U3Fast {
    match first_byte {
        0..=193 => 0,
        194..=223 => 2,
        224..=239 => 3,
        240..=244 => 4,
        245..=255 => 0,
    }
}

#[derive(thiserror::Error, Debug, strum::IntoStaticStr)]
pub enum ToUTF16Error {
    #[error("OutOfMemory")]
    OutOfMemory,
    #[error("InvalidByteSequence")]
    InvalidByteSequence,
}

crate::oom_from_alloc!(ToUTF16Error);

pub fn to_utf16_alloc_maybe_buffered<const FAIL_IF_INVALID: bool, const FLUSH: bool>(
    bytes: &[u8],
) -> Result<Option<(Vec<u16>, [u8; 3], u8)>, ToUTF16Error> {
    let Some(first_non_ascii_idx) = first_non_ascii(bytes) else {
        return Ok(None);
    };
    let first_non_ascii_idx = first_non_ascii_idx as usize;

    let mut output: Vec<u16> = if crate::FeatureFlags::USE_SIMDUTF {
        'output: {
            let out_length = simdutf::length::utf16::from::utf8(bytes);

            if out_length == 0 {
                break 'output Vec::new();
            }

            let mut out: Vec<u16> = Vec::new();
            out.try_reserve_exact(out_length)
                .map_err(|_| ToUTF16Error::OutOfMemory)?;
            // SAFETY: `out` has >= `out_length` u16 of capacity (just reserved).
            // simdutf never reads the output buffer and writes at most
            // `out_length` code units, so passing uninitialised storage is
            // sound; the length is only ever set to what simdutf has written.
            let res = unsafe {
                simdutf::simdutf__convert_utf8_to_utf16le_with_errors(
                    bytes.as_ptr(),
                    bytes.len(),
                    out.as_mut_ptr(),
                )
            };
            if res.is_successful() {
                // SAFETY: on success simdutf initialised exactly `out_length` units.
                unsafe { out.set_len(out_length) };
                crate::scoped_log!(
                    strings,
                    "toUTF16 {} UTF8 -> {} UTF16",
                    bytes.len(),
                    out_length
                );
                return Ok(Some((out, [0; 3], 0)));
            }

            // SAFETY: simdutf converts sequentially and the first error is at or
            // after the first non-ASCII byte, so the leading `first_non_ascii_idx`
            // code units (one per ASCII prefix byte, `<= out_length`) are
            // initialised; keep exactly those.
            unsafe { out.set_len(first_non_ascii_idx) };
            break 'output out;
        }
    } else {
        Vec::new()
    };
    // errdefer output.deinit(allocator) — Vec drops on `?`

    let start = if !output.is_empty() {
        first_non_ascii_idx
    } else {
        0
    };
    let mut remaining = &bytes[start..];
    // The replacement decode emits at most one code unit per consumed byte, so
    // `remaining.len()` bounds the tail's growth (the bound `to_utf16_alloc`'s
    // slow path reserves too); the appends below stay inside this reservation.
    output
        .try_reserve(remaining.len())
        .map_err(|_| ToUTF16Error::OutOfMemory)?;

    let mut non_ascii: Option<u32> = Some(0);
    while let Some(i) = non_ascii {
        let i = i as usize;
        {
            append_u8_as_u16(&mut output, &remaining[..i]);
            remaining = &remaining[i..];
        }

        let sequence: [u8; 4] = match remaining.len() {
            0 => unreachable!(),
            1 => [remaining[0], 0, 0, 0],
            2 => [remaining[0], remaining[1], 0, 0],
            3 => [remaining[0], remaining[1], remaining[2], 0],
            _ => remaining[..4].try_into().expect("infallible: size matches"),
        };

        let converted_length = non_ascii_sequence_length(sequence[0]);

        let converted =
            convert_utf8_bytes_into_utf16_with_length(sequence, converted_length, remaining.len());

        if !FLUSH {
            if converted.fail
                && converted.can_buffer
                && (converted_length as usize) > remaining.len()
            {
                let buffered: [u8; 3] = match remaining.len() {
                    1 => [remaining[0], 0, 0],
                    2 => [remaining[0], remaining[1], 0],
                    3 => [remaining[0], remaining[1], remaining[2]],
                    _ => unreachable!(),
                };
                return Ok(Some((
                    output,
                    buffered,
                    u8::try_from(remaining.len()).expect("int cast"),
                )));
            }
        }

        if FAIL_IF_INVALID {
            if converted.fail {
                debug_assert!(converted.code_point == unicode_replacement);
                return Err(ToUTF16Error::InvalidByteSequence);
            }
        }

        remaining = &remaining[(converted.len as usize).max(1)..];

        // #define U16_LENGTH(c) ((uint32_t)(c)<=0xffff ? 1 : 2)
        push_codepoint_utf16(&mut output, converted.code_point);

        non_ascii = first_non_ascii(remaining);
    }

    if !remaining.is_empty() {
        append_u8_as_u16(&mut output, remaining);
    }

    crate::scoped_log!(
        strings,
        "toUTF16 {} UTF8 -> {} UTF16",
        bytes.len(),
        output.len()
    );
    Ok(Some((output, [0; 3], 0)))
}

#[inline]
pub fn utf16_codepoint_with_fffd(input: &[u16]) -> UTF16Replacement {
    utf16_codepoint_with_fffd_and_first_input_char(input[0], input)
}

fn utf16_codepoint_with_fffd_and_first_input_char(char: u16, input: &[u16]) -> UTF16Replacement {
    if u16_is_lead(char) {
        // surrogate pair
        if input.len() == 1 {
            return UTF16Replacement {
                len: 1,
                is_lead: true,
                ..Default::default()
            };
        }
        // error.DanglingSurrogateHalf;
        let c1 = input[1];
        if !u16_is_trail(c1) {
            return UTF16Replacement {
                fail: true,
                len: 1,
                code_point: unicode_replacement,
                is_lead: true,
                ..Default::default()
            };
        }
        // return error.ExpectedSecondSurrogateHalf;
        UTF16Replacement {
            len: 2,
            code_point: u16_get_supplementary(char, c1),
            ..Default::default()
        }
    } else if u16_is_trail(char) {
        // return error.UnexpectedSecondSurrogateHalf;
        UTF16Replacement {
            fail: true,
            len: 1,
            code_point: unicode_replacement,
            ..Default::default()
        }
    } else {
        UTF16Replacement {
            code_point: char as u32,
            len: 1,
            ..Default::default()
        }
    }
}

#[inline]
pub fn utf16_codepoint(input: &[u16]) -> UTF16Replacement {
    let c0 = input[0];
    if u16_is_lead(c0) {
        // surrogate pair
        if input.len() == 1 {
            return UTF16Replacement {
                len: 1,
                ..Default::default()
            };
        }
        // Falls through with len=2 even when input[1] is not a trail
        // surrogate; callers depend on that iteration behaviour.
        UTF16Replacement {
            len: 2,
            code_point: u16_get_supplementary(c0, input[1]),
            ..Default::default()
        }
    } else if u16_is_trail(c0) {
        // return error.UnexpectedSecondSurrogateHalf;
        UTF16Replacement {
            len: 1,
            ..Default::default()
        }
    } else {
        UTF16Replacement {
            code_point: c0 as u32,
            len: 1,
            ..Default::default()
        }
    }
}

pub(super) use crate::strings_impl::push_codepoint_utf16;

// `unreachable_pub`: these are re-exported externally via the parent's
// `pub use unicode_draft::{… u16_is_lead, u16_is_trail …}`; the lint does not
// trace that multi-hop re-export, so the `pub` is required here.
use crate::strings_impl::u16_get_supplementary;
pub use crate::strings_impl::{u16_is_lead, u16_is_trail};

pub fn convert_utf8_to_utf16_in_buffer_z<'a>(buf: &'a mut [u16], input: &[u8]) -> &'a WStr {
    // Checked conversion (see `try_convert_utf8_to_utf16_in_buffer`): the
    // NUL reserves one slot, and over-long input fails safe to "" — which
    // the consuming syscall rejects — instead of letting simdutf (which
    // never bounds-checks its output) write past `buf`.
    let cap = buf.len().saturating_sub(1);
    let len = crate::string::immutable::try_convert_utf8_to_utf16_in_buffer(&mut buf[..cap], input)
        .map(|converted| converted.len())
        .unwrap_or(0);
    buf[len] = 0;
    wstr_in_buf(buf, len)
}

#[rustfmt::skip]
static CP1252_TO_UTF16_CONVERSION_TABLE: [u16; 256] = [
    0x0000, 0x0001, 0x0002, 0x0003, 0x0004, 0x0005, 0x0006, 0x0007, // 00-07
    0x0008, 0x0009, 0x000A, 0x000B, 0x000C, 0x000D, 0x000E, 0x000F, // 08-0F
    0x0010, 0x0011, 0x0012, 0x0013, 0x0014, 0x0015, 0x0016, 0x0017, // 10-17
    0x0018, 0x0019, 0x001A, 0x001B, 0x001C, 0x001D, 0x001E, 0x001F, // 18-1F
    0x0020, 0x0021, 0x0022, 0x0023, 0x0024, 0x0025, 0x0026, 0x0027, // 20-27
    0x0028, 0x0029, 0x002A, 0x002B, 0x002C, 0x002D, 0x002E, 0x002F, // 28-2F
    0x0030, 0x0031, 0x0032, 0x0033, 0x0034, 0x0035, 0x0036, 0x0037, // 30-37
    0x0038, 0x0039, 0x003A, 0x003B, 0x003C, 0x003D, 0x003E, 0x003F, // 38-3F
    0x0040, 0x0041, 0x0042, 0x0043, 0x0044, 0x0045, 0x0046, 0x0047, // 40-47
    0x0048, 0x0049, 0x004A, 0x004B, 0x004C, 0x004D, 0x004E, 0x004F, // 48-4F
    0x0050, 0x0051, 0x0052, 0x0053, 0x0054, 0x0055, 0x0056, 0x0057, // 50-57
    0x0058, 0x0059, 0x005A, 0x005B, 0x005C, 0x005D, 0x005E, 0x005F, // 58-5F
    0x0060, 0x0061, 0x0062, 0x0063, 0x0064, 0x0065, 0x0066, 0x0067, // 60-67
    0x0068, 0x0069, 0x006A, 0x006B, 0x006C, 0x006D, 0x006E, 0x006F, // 68-6F
    0x0070, 0x0071, 0x0072, 0x0073, 0x0074, 0x0075, 0x0076, 0x0077, // 70-77
    0x0078, 0x0079, 0x007A, 0x007B, 0x007C, 0x007D, 0x007E, 0x007F, // 78-7F
    0x20AC, 0x0081, 0x201A, 0x0192, 0x201E, 0x2026, 0x2020, 0x2021, // 80-87
    0x02C6, 0x2030, 0x0160, 0x2039, 0x0152, 0x008D, 0x017D, 0x008F, // 88-8F
    0x0090, 0x2018, 0x2019, 0x201C, 0x201D, 0x2022, 0x2013, 0x2014, // 90-97
    0x02DC, 0x2122, 0x0161, 0x203A, 0x0153, 0x009D, 0x017E, 0x0178, // 98-9F
    0x00A0, 0x00A1, 0x00A2, 0x00A3, 0x00A4, 0x00A5, 0x00A6, 0x00A7, // A0-A7
    0x00A8, 0x00A9, 0x00AA, 0x00AB, 0x00AC, 0x00AD, 0x00AE, 0x00AF, // A8-AF
    0x00B0, 0x00B1, 0x00B2, 0x00B3, 0x00B4, 0x00B5, 0x00B6, 0x00B7, // B0-B7
    0x00B8, 0x00B9, 0x00BA, 0x00BB, 0x00BC, 0x00BD, 0x00BE, 0x00BF, // B8-BF
    0x00C0, 0x00C1, 0x00C2, 0x00C3, 0x00C4, 0x00C5, 0x00C6, 0x00C7, // C0-C7
    0x00C8, 0x00C9, 0x00CA, 0x00CB, 0x00CC, 0x00CD, 0x00CE, 0x00CF, // C8-CF
    0x00D0, 0x00D1, 0x00D2, 0x00D3, 0x00D4, 0x00D5, 0x00D6, 0x00D7, // D0-D7
    0x00D8, 0x00D9, 0x00DA, 0x00DB, 0x00DC, 0x00DD, 0x00DE, 0x00DF, // D8-DF
    0x00E0, 0x00E1, 0x00E2, 0x00E3, 0x00E4, 0x00E5, 0x00E6, 0x00E7, // E0-E7
    0x00E8, 0x00E9, 0x00EA, 0x00EB, 0x00EC, 0x00ED, 0x00EE, 0x00EF, // E8-EF
    0x00F0, 0x00F1, 0x00F2, 0x00F3, 0x00F4, 0x00F5, 0x00F6, 0x00F7, // F0-F7
    0x00F8, 0x00F9, 0x00FA, 0x00FB, 0x00FC, 0x00FD, 0x00FE, 0x00FF, // F8-FF
];

fn cp1252_to_codepoint_bytes_assume_not_ascii16(char: u32) -> u16 {
    CP1252_TO_UTF16_CONVERSION_TABLE[(char as u8) as usize]
}

// `copy_utf16_into_utf8` (the non-generic wrapper) lives canonically in
// `crate::strings_impl`; re-exported at `crate::string::immutable`. The
// `_impl<const ALLOW_TRUNCATED>` variant below is what hot paths
// (encoding.rs, Sink.rs, websocket_client.rs) call directly.

/// See comment on `copy_utf16_into_utf8_with_buffer_impl` on what `allow_truncated_utf8_sequence` should do
pub fn copy_utf16_into_utf8_impl<const ALLOW_TRUNCATED_UTF8_SEQUENCE: bool>(
    buf: &mut [u8],
    utf16: &[u16],
) -> EncodeIntoResult {
    if crate::FeatureFlags::USE_SIMDUTF {
        if utf16.is_empty() {
            return EncodeIntoResult {
                read: 0,
                written: 0,
            };
        }
        let out_len = if buf.len() <= utf16.len().saturating_mul(3) {
            simdutf::length::utf8::from::utf16::le(utf16)
        } else {
            buf.len()
        };

        return copy_utf16_into_utf8_with_buffer_impl::<ALLOW_TRUNCATED_UTF8_SEQUENCE>(
            buf, utf16, out_len,
        );
    }

    copy_utf16_into_utf8_with_buffer_impl::<ALLOW_TRUNCATED_UTF8_SEQUENCE>(buf, utf16, utf16.len())
}

/// Q: What does the `allow_truncated_utf8_sequence` parameter do?
/// A: If the output buffer can't fit everything, this function will write
///    incomplete utf-8 byte sequences if `allow_truncated_utf8_sequence` is
///    enabled.
///
/// Q: Doesn't that mean this function would output invalid utf-8? Why would you
///    ever want to do that?
/// A: Yes. This is needed for writing a UTF-16 string to a node Buffer that
///    doesn't have enough space for all the bytes:
///
/// ```js
/// let buffer = Buffer.allocUnsafe(1);
/// buffer.fill("Ȣ");
/// expect(buffer[0]).toBe(0xc8);
/// ```
fn copy_utf16_into_utf8_with_buffer_impl<const ALLOW_TRUNCATED_UTF8_SEQUENCE: bool>(
    buf: &mut [u8],
    utf16: &[u16],
    out_len: usize,
) -> EncodeIntoResult {
    let buf_total = buf.len();
    let mut remaining: &mut [u8] = buf;
    let mut utf16_remaining = utf16;
    let mut ended_on_non_ascii = false;

    'brk: {
        if crate::FeatureFlags::USE_SIMDUTF {
            crate::scoped_log!(strings, "UTF16 {} -> UTF8 {}", utf16.len(), out_len);
            if remaining.len() >= out_len {
                let result = simdutf::convert::utf16::to::utf8::with_errors::le(utf16, remaining);
                if result.status == simdutf::Status::SURROGATE {
                    break 'brk;
                }

                return EncodeIntoResult {
                    read: utf16.len(),
                    written: result.count,
                };
            }
        }
    }

    while let Some(i) = first_non_ascii16(utf16_remaining) {
        let i = i as usize;
        let end = i.min(remaining.len());
        if end > 0 {
            copy_u16_into_u8(remaining, &utf16_remaining[..end]);
        }
        remaining = &mut remaining[end..];
        utf16_remaining = &utf16_remaining[end..];

        if utf16_remaining.len().min(remaining.len()) == 0 {
            break;
        }

        let replacement = utf16_codepoint_with_fffd(utf16_remaining);

        let width: usize = replacement.utf8_width() as usize;
        debug_assert!(width > 1);
        if width > remaining.len() {
            ended_on_non_ascii = width > 1;
            if ALLOW_TRUNCATED_UTF8_SEQUENCE {
                match width {
                    2 => {
                        if !remaining.is_empty() {
                            //only first will be written
                            remaining[0] = (0xC0 | (replacement.code_point >> 6)) as u8;
                            let rl = remaining.len();
                            remaining = &mut remaining[rl..];
                        }
                    }
                    3 => {
                        //only first to second written
                        match remaining.len() {
                            1 => {
                                remaining[0] = (0xE0 | (replacement.code_point >> 12)) as u8;
                                let rl = remaining.len();
                                remaining = &mut remaining[rl..];
                            }
                            2 => {
                                remaining[0] = (0xE0 | (replacement.code_point >> 12)) as u8;
                                remaining[1] = (0x80 | (replacement.code_point >> 6) & 0x3F) as u8;
                                let rl = remaining.len();
                                remaining = &mut remaining[rl..];
                            }
                            _ => {}
                        }
                    }
                    4 => {
                        //only 1 to 3 written
                        match remaining.len() {
                            1 => {
                                remaining[0] = (0xF0 | (replacement.code_point >> 18)) as u8;
                                let rl = remaining.len();
                                remaining = &mut remaining[rl..];
                            }
                            2 => {
                                remaining[0] = (0xF0 | (replacement.code_point >> 18)) as u8;
                                remaining[1] = (0x80 | (replacement.code_point >> 12) & 0x3F) as u8;
                                let rl = remaining.len();
                                remaining = &mut remaining[rl..];
                            }
                            3 => {
                                remaining[0] = (0xF0 | (replacement.code_point >> 18)) as u8;
                                remaining[1] = (0x80 | (replacement.code_point >> 12) & 0x3F) as u8;
                                remaining[2] = (0x80 | (replacement.code_point >> 6) & 0x3F) as u8;
                                let rl = remaining.len();
                                remaining = &mut remaining[rl..];
                            }
                            _ => {}
                        }
                    }
                    _ => {}
                }
            }
            break;
        }

        utf16_remaining = &utf16_remaining[replacement.len as usize..];
        // `encode_wtf8_rune` only writes `width` bytes, but materializing
        // `&mut [u8; 4]` would assert 4 valid bytes even when remaining.len() < 4,
        // so encode into a stack buffer and copy the `width` bytes that were written.
        let mut four = [0u8; 4];
        let _ = crate::strings_impl::encode_wtf8_rune(&mut four, replacement.code_point);
        remaining[..width].copy_from_slice(&four[..width]);
        remaining = &mut remaining[width..];
    }

    if !remaining.is_empty() && !ended_on_non_ascii && !utf16_remaining.is_empty() {
        let len = remaining.len().min(utf16_remaining.len());
        copy_u16_into_u8(&mut remaining[..len], &utf16_remaining[..len]);
        utf16_remaining = &utf16_remaining[len..];
        remaining = &mut remaining[len..];
    }

    EncodeIntoResult {
        read: utf16.len() - utf16_remaining.len(),
        written: buf_total - remaining.len(),
    }
}

pub fn element_length_utf8_into_utf16(utf8: &[u8]) -> usize {
    let mut utf8_remaining = utf8;
    let mut count: usize = 0;

    if crate::FeatureFlags::USE_SIMDUTF {
        return simdutf::length::utf16::from::utf8(utf8);
    }

    while let Some(i) = first_non_ascii(utf8_remaining) {
        let i = i as usize;
        count += i;

        utf8_remaining = &utf8_remaining[i..];

        // Deliberate quirk: `utf16_codepoint` (which takes u16 units) is applied to
        // raw u8 bytes here. This branch is dead when USE_SIMDUTF is true.
        let replacement = {
            let n = utf8_remaining.len() / 2;
            if n == 0 {
                // lone trailing non-ASCII byte; count it as one UTF-16 unit and stop
                count += 1;
                utf8_remaining = &utf8_remaining[1..];
                continue;
            }
            let mut pair = [0u16; 2];
            pair[0] = u16::from_ne_bytes([utf8_remaining[0], utf8_remaining[1]]);
            if n >= 2 {
                pair[1] = u16::from_ne_bytes([utf8_remaining[2], utf8_remaining[3]]);
            }
            utf16_codepoint(&pair[..n.min(2)])
        };

        count += replacement.len as usize;
        utf8_remaining =
            &utf8_remaining[(replacement.utf8_width() as usize).min(utf8_remaining.len())..];
    }

    count + utf8_remaining.len()
}

pub fn wtf8_sequence(code_point: u32) -> [u8; 4] {
    match code_point {
        0..=0x7f => [u8::try_from(code_point).expect("int cast"), 0, 0, 0],
        0x80..=0x7ff => [
            (0xc0 | (code_point >> 6)) as u8,
            (0x80 | (code_point & 0x3f)) as u8,
            0,
            0,
        ],
        0x800..=0xffff => [
            (0xe0 | (code_point >> 12)) as u8,
            (0x80 | ((code_point >> 6) & 0x3f)) as u8,
            (0x80 | (code_point & 0x3f)) as u8,
            0,
        ],
        _ => [
            (0xf0 | (code_point >> 18)) as u8,
            (0x80 | ((code_point >> 12) & 0x3f)) as u8,
            (0x80 | ((code_point >> 6) & 0x3f)) as u8,
            (0x80 | (code_point & 0x3f)) as u8,
        ],
    }
}

/// Append `cp` to `buf` as 1 to 4 bytes of WTF-8. Lone-surrogate code points pass through as the
/// three bytes that they would have in UTF-8.
#[inline]
pub fn push_codepoint_wtf8(buf: &mut Vec<u8>, cp: u32) {
    let mut bytes = [0u8; 4];
    let len = crate::strings_impl::encode_wtf8_rune(&mut bytes, cp);
    buf.extend_from_slice(&bytes[..len]);
}

/// Convert potentially ill-formed UTF-8 or UTF-16 bytes to a Unicode Codepoint.
/// Invalid codepoints are replaced with `zero` parameter
/// This is a clone of esbuild's decodeWTF8Rune
/// which was a clone of golang's "utf8.DecodeRune" that was modified to decode using WTF-8 instead.
/// Asserts a multi-byte codepoint
#[inline]
pub fn decode_wtf8_rune_t_multibyte<T: CodePointZero>(p: [u8; 4], len: U3Fast, zero: T) -> T {
    debug_assert!(len > 1);

    let s1 = p[1];
    if (s1 & 0xC0) != 0x80 {
        return zero;
    }

    if len == 2 {
        let cp = (T::from(p[0] & 0x1F) << 6) | T::from(s1 & 0x3F);
        if cp < T::from(0x80u8) {
            return zero;
        }
        return cp;
    }

    let s2 = p[2];

    if (s2 & 0xC0) != 0x80 {
        return zero;
    }

    if len == 3 {
        let cp = (T::from(p[0] & 0x0F) << 12) | (T::from(s1 & 0x3F) << 6) | T::from(s2 & 0x3F);
        // 0x800 doesn't fit in u8; compare via FromU32 helper.
        if cp < T::from_u32_const(0x800) {
            return zero;
        }
        return cp;
    }

    let s3 = p[3];

    if (s3 & 0xC0) != 0x80 {
        return zero;
    }

    {
        let cp = (T::from(p[0] & 0x07) << 18)
            | (T::from(s1 & 0x3F) << 12)
            | (T::from(s2 & 0x3F) << 6)
            | T::from(s3 & 0x3F);
        if cp < T::from_u32_const(0x10000) || cp > T::from_u32_const(0x10FFFF) {
            return zero;
        }
        return cp;
    }
}

// `from_u32_const` folded into `CodePointZero` trait above.
