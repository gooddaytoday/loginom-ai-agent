use crate::mal_prelude::*;
use std::io::Write as _;

use crate::Error;
use bun_alloc::MaxHeapAllocator;
use bun_ast::Loc;
use bun_core::fmt::quote;
use bun_core::{String as BunString, strings};
use bun_paths as paths;
use bun_wyhash::hash;

use crate::LinkerContext;
use crate::chunk::{Content, Flags as ChunkFlags, ReferencePathStyle, SourceMapShiftTracking};
use crate::linker_context::output_file_list_builder::OutputFileList;
use crate::linker_context_mod::debug;
use crate::options::{self, Loader, OutputFile, SourceMapOption};
use crate::output_file::{
    BakeExtra, Index as OutputFileIndex, IndexOptional, Options as OutputFileInit,
    OptionsData as OutputFileData, SavedFile, Value as OutputFileValue,
};
use crate::{BundleV2, Chunk, cheap_prefix_normalizer};

use bun_sys::{
    FdDirExt, PathOrFileDescriptor, WriteFileArgs, WriteFileData, WriteFileEncoding,
    write_file_with_path_buffer,
};

use crate::bytecode_sidecar::EXTENSION as BYTECODE_EXTENSION;

pub(crate) fn write_output_files_to_disk(
    c: &mut LinkerContext,
    root_path: &[u8],
    chunks: &mut [Chunk],
    output_files: &mut OutputFileList,
    standalone_chunk_contents: Option<&[Option<Box<[u8]>>]>,
    standalone_sourcemaps: &mut [Option<Box<[u8]>>],
) -> Result<(), Error> {
    let _trace = bun_core::perf::trace("Bundler.writeOutputFilesToDisk");

    let root_dir = match bun_sys::Dir::cwd().make_open_path(root_path, Default::default()) {
        Ok(dir) => dir,
        Err(e) => {
            if bun_errno::SystemErrno::from(e.clone()) == bun_errno::SystemErrno::ENOTDIR {
                c.log_mut()
                    .add_error_fmt(
                        None,
                        Loc::EMPTY,
                        format_args!(
                            "Failed to create output directory {} is a file. Please choose a different outdir or delete {}",
                            quote(root_path),
                            quote(root_path),
                        ),
                    );
            } else {
                c.log_mut().add_error_fmt(
                    None,
                    Loc::EMPTY,
                    format_args!(
                        "Failed to create output directory {} {}",
                        bstr::BStr::new(e.name()),
                        quote(root_path),
                    ),
                );
            }
            return Err(e.into());
        }
    };
    // Optimization: when writing to disk, we can re-use the memory
    // between iterations: MaxHeapAllocator retains the largest allocation.
    // DynAlloc is currently `()` so the arena
    // handles below are placeholders; allocation routes through global mimalloc.
    let mut max_heap_allocator = MaxHeapAllocator::init();
    let mut _max_heap_allocator_source_map = MaxHeapAllocator::init();
    let mut _max_heap_allocator_inline_source_map = MaxHeapAllocator::init();

    let mut pathbuf = bun_paths::path_buffer_pool::get();
    // SAFETY: c points to LinkerContext which is the `linker` field of BundleV2.
    let bv2: &mut BundleV2 =
        unsafe { &mut *LinkerContext::bundle_v2_ptr(std::ptr::from_mut::<LinkerContext>(c)) };

    // `code()`/`code_standalone()` take both `chunk` (an element of `chunks`)
    // and `chunks` as
    // `&Chunk` / `&[Chunk]` (read-only), so iterate by index and reborrow
    // shared; the only per-chunk mutation is the `intermediate_output`
    // take/restore done via `chunks[i]`.
    let chunks_len = chunks.len();

    for chunk_index_in_chunks_list in 0..chunks_len {
        let chunk: &Chunk = &chunks[chunk_index_in_chunks_list];
        // In standalone mode, only write HTML chunks to disk.
        // Insert placeholder output files for non-HTML chunks to keep indices aligned.
        if standalone_chunk_contents.is_some() && !matches!(chunk.content, Content::Html) {
            // The chunk itself is inlined into the HTML document, but its .map
            // file (linked/external sourcemaps) is still written to disk.
            let source_map_index: Option<u32> = if let Some(output_source_map) =
                standalone_sourcemaps
                    .get_mut(chunk_index_in_chunks_list)
                    .and_then(Option::take)
            {
                let source_map_final_rel_path = strings::concat(&[&chunk.final_rel_path, b".map"]);

                let rel_parent = paths::resolve_path::dirname::<paths::platform::Posix>(
                    &source_map_final_rel_path,
                );
                if !rel_parent.is_empty() {
                    if let Err(e) = root_dir.make_path(rel_parent) {
                        c.log_mut().add_error_fmt(
                            None,
                            Loc::EMPTY,
                            format_args!(
                                "{} creating outdir {} while saving sourcemap {}",
                                bstr::BStr::new(e.name()),
                                quote(rel_parent),
                                quote(&*source_map_final_rel_path),
                            ),
                        );
                        return Err(e.into());
                    }
                }

                if let Err(e) = bun_sys::File::write_file(
                    bun_sys::Fd::from_std_dir(&root_dir),
                    paths::resolve_path::z(&source_map_final_rel_path, &mut pathbuf),
                    &output_source_map,
                ) {
                    c.log_mut().add_sys_error(
                        &e,
                        format_args!(
                            "writing sourcemap for chunk {}",
                            quote(&chunk.final_rel_path)
                        ),
                    );
                    return Err(crate::Error::WriteFailed);
                }

                let input_path: &[u8] = if chunk.entry_point.is_entry_point() {
                    c.parse_graph().input_files.items_source()
                        [chunk.entry_point.source_index() as usize]
                        .path
                        .text
                } else {
                    &chunk.final_rel_path
                };

                Some(
                    output_files.insert_for_sourcemap_or_bytecode(OutputFile::init(
                        OutputFileInit {
                            output_path: source_map_final_rel_path,
                            input_path: strings::concat(&[input_path, b".map"]),
                            loader: Loader::Json,
                            input_loader: Loader::File,
                            output_kind: options::OutputKind::Sourcemap,
                            size: Some(output_source_map.len()),
                            data: OutputFileData::Saved(0),
                            side: Some(options::Side::Client),
                            entry_point_index: None,
                            is_executable: false,
                            hash: None,
                            source_map_index: None,
                            bytecode_index: None,
                            module_info_index: None,
                            display_size: 0,
                            referenced_css_chunks: Box::default(),
                            source_index: IndexOptional::NONE,
                            bake_extra: BakeExtra::default(),
                        },
                    ))?,
                )
            } else {
                None
            };

            let _ = output_files.insert_for_chunk(OutputFile::init(OutputFileInit {
                data: OutputFileData::Saved(0),
                hash: None,
                loader: chunk.content.loader(),
                input_path: Box::default(),
                display_size: 0,
                output_kind: options::OutputKind::Chunk,
                input_loader: Loader::Js,
                output_path: Box::default(),
                is_executable: false,
                source_map_index,
                bytecode_index: None,
                module_info_index: None,
                side: Some(options::Side::Client),
                entry_point_index: None,
                referenced_css_chunks: Box::default(),
                size: None,
                source_index: IndexOptional::NONE,
                bake_extra: BakeExtra::default(),
            }));
            continue;
        }

        let _trace2 = bun_core::perf::trace("Bundler.writeChunkToDisk");
        // Reset the reusable
        // buffer after each chunk. `MaxHeapAllocator::scope()` returns an RAII
        // guard that resets on drop and derefs to the arena, so when
        // `code_allocator` is wired up it can borrow through `_code_allocator`.
        let _code_allocator = max_heap_allocator.scope();

        let rel_parent =
            paths::resolve_path::dirname::<paths::platform::Posix>(&chunk.final_rel_path);
        if !rel_parent.is_empty() {
            if let Err(e) = root_dir.make_path(rel_parent) {
                c.log_mut().add_error_fmt(
                    None,
                    Loc::EMPTY,
                    format_args!(
                        "{} creating outdir {} while saving chunk {}",
                        bstr::BStr::new(e.name()),
                        quote(rel_parent),
                        quote(&chunk.final_rel_path),
                    ),
                );
                return Err(e.into());
            }
        }
        let mut display_size: usize = 0;
        let resolver_opts = &c.resolver().opts;
        let public_path: &[u8] = if chunk
            .flags
            .contains(ChunkFlags::IS_BROWSER_CHUNK_FROM_SERVER_BUILD)
        {
            &bv2.transpiler_for_target(options::Target::Browser)
                .options
                .public_path
        } else {
            &resolver_opts.public_path
        };

        // Take `intermediate_output` by value so its `&mut self` is
        // disjoint from the `&chunks[i]` / `&[Chunk]` reads below.
        let mut intermediate_output =
            core::mem::take(&mut chunks[chunk_index_in_chunks_list].intermediate_output);
        let chunk: &Chunk = &chunks[chunk_index_in_chunks_list];
        let parse_graph = c.parse_graph();

        let mut code_result = if let Some(scc) = standalone_chunk_contents {
            match intermediate_output.code_standalone(
                None,
                parse_graph,
                &c.graph,
                public_path,
                chunk,
                chunks,
                Some(&mut display_size),
                ReferencePathStyle::ImporterRelative,
                SourceMapShiftTracking::Disabled,
                scc,
            ) {
                Ok(r) => r,
                Err(_e) => bun_core::Output::panic(format_args!(
                    "Failed to create output chunk: OutOfMemory"
                )),
            }
        } else {
            match intermediate_output.code(
                None,
                parse_graph,
                &c.graph,
                public_path,
                chunk,
                chunks,
                Some(&mut display_size),
                ReferencePathStyle::for_chunk(chunk, resolver_opts.compile),
                SourceMapShiftTracking::for_source_map(
                    chunk.content.sourcemap(c.options.source_maps),
                ),
            ) {
                Ok(r) => r,
                Err(_e) => bun_core::Output::panic(format_args!(
                    "Failed to create output chunk: OutOfMemory"
                )),
            }
        };
        // Tail of the loop body needs `&mut chunk` (`output_source_map.finalize()`);
        // no `&[Chunk]` is needed past this point so an exclusive reborrow is fine.
        let chunk: &mut Chunk = &mut chunks[chunk_index_in_chunks_list];
        chunk.intermediate_output = intermediate_output;

        let mut source_map_output_file: Option<OutputFile> = None;

        let input_path: Box<[u8]> = Box::from(if chunk.entry_point.is_entry_point() {
            parse_graph.input_files.items_source()[chunk.entry_point.source_index() as usize]
                .path
                .text
        } else {
            &chunk.final_rel_path
        });

        match chunk.content.sourcemap(c.options.source_maps) {
            tag @ (SourceMapOption::External | SourceMapOption::Linked) => {
                let output_source_map = chunk
                    .output_source_map
                    .finalize(&code_result.shifts)
                    .unwrap_or_else(|_| {
                        panic!("Failed to allocate memory for external source map")
                    });
                let source_map_final_rel_path = strings::concat(&[&chunk.final_rel_path, b".map"]);

                if tag == SourceMapOption::Linked {
                    let [a, b] = if !public_path.is_empty() {
                        cheap_prefix_normalizer(public_path, &source_map_final_rel_path)
                    } else {
                        [b"" as &[u8], paths::basename(&source_map_final_rel_path)]
                    };

                    let source_map_start = b"//# sourceMappingURL=";
                    let total_len = code_result.buffer.len()
                        + source_map_start.len()
                        + a.len()
                        + b.len()
                        + b"\n".len();
                    let mut buf: Vec<u8> = Vec::with_capacity(total_len);
                    buf.extend_from_slice(&code_result.buffer);
                    buf.extend_from_slice(source_map_start);
                    buf.extend_from_slice(a);
                    buf.extend_from_slice(b);
                    buf.push(b'\n');
                    code_result.buffer = buf.into_boxed_slice();
                }

                match bun_sys::File::write_file(
                    bun_sys::Fd::from_std_dir(&root_dir),
                    paths::resolve_path::z(&source_map_final_rel_path, &mut pathbuf),
                    &output_source_map,
                ) {
                    Err(e) => {
                        c.log_mut().add_sys_error(
                            &e,
                            format_args!(
                                "writing sourcemap for chunk {}",
                                quote(&chunk.final_rel_path)
                            ),
                        );
                        return Err(crate::Error::WriteFailed);
                    }
                    Ok(_) => {}
                }

                source_map_output_file = Some(OutputFile::init(OutputFileInit {
                    output_path: source_map_final_rel_path,
                    input_path: strings::concat(&[&input_path, b".map"]),
                    loader: Loader::Json,
                    input_loader: Loader::File,
                    output_kind: options::OutputKind::Sourcemap,
                    size: Some(output_source_map.len()),
                    data: OutputFileData::Saved(0),
                    side: Some(options::Side::Client),
                    entry_point_index: None,
                    is_executable: false,
                    hash: None,
                    source_map_index: None,
                    bytecode_index: None,
                    module_info_index: None,
                    display_size: 0,
                    referenced_css_chunks: Box::default(),
                    source_index: IndexOptional::NONE,
                    bake_extra: BakeExtra::default(),
                }));
            }
            SourceMapOption::Inline => {
                let output_source_map = chunk
                    .output_source_map
                    .finalize(&code_result.shifts)
                    .unwrap_or_else(|_| {
                        panic!("Failed to allocate memory for external source map")
                    });
                let encode_len = bun_base64::encode_len(&output_source_map);

                let source_map_start = b"//# sourceMappingURL=data:application/json;base64,";
                let total_len = code_result.buffer.len() + source_map_start.len() + encode_len + 1;
                let mut buf: Vec<u8> = Vec::with_capacity(total_len);

                buf.extend_from_slice(&code_result.buffer);
                buf.extend_from_slice(source_map_start);
                bun_base64::encode_append(&mut buf, &output_source_map);
                buf.push(b'\n');
                code_result.buffer = buf.into_boxed_slice();
            }
            SourceMapOption::None => {}
        }

        let bytecode_output_file: Option<OutputFile> = 'brk: {
            if c.options.generate_bytecode_cache {
                if c.chunk_gets_bytecode(chunk) {
                    let mut fdpath = bun_paths::path_buffer_pool::get();
                    let source_provider_url = BunString::create_format(format_args!(
                        "{}{}",
                        bstr::BStr::new(&chunk.final_rel_path),
                        BYTECODE_EXTENSION,
                    ));

                    if let Some(bytecode) = crate::bundle_v2::dispatch::generate_cached_bytecode(
                        c.options.output_format,
                        &code_result.buffer,
                        &source_provider_url,
                        c.options.bytecode_depth,
                        c.options.optimize_bytecode,
                        None,
                    ) {
                        let bytecode = crate::bytecode_sidecar::frame(bytecode);
                        let source_provider_url_str = source_provider_url.to_utf8();
                        debug!(
                            "Bytecode cache generated {}: {}",
                            bstr::BStr::new(source_provider_url_str.slice()),
                            bun_core::fmt::size(
                                bytecode.len(),
                                bun_core::fmt::SizeFormatterOptions {
                                    space_between_number_and_unit: true,
                                }
                            ),
                        );
                        let frp: &[u8] = &chunk.final_rel_path;
                        fdpath[..frp.len()].copy_from_slice(frp);
                        fdpath[frp.len()..frp.len() + BYTECODE_EXTENSION.len()]
                            .copy_from_slice(BYTECODE_EXTENSION.as_bytes());
                        match write_file_with_path_buffer(
                            &mut pathbuf,
                            &WriteFileArgs {
                                data: WriteFileData::Buffer { buffer: &bytecode },
                                encoding: WriteFileEncoding::Buffer,
                                mode: if chunk.flags.contains(ChunkFlags::IS_EXECUTABLE) {
                                    0o755
                                } else {
                                    0o644
                                },
                                dirfd: bun_sys::Fd::from_std_dir(&root_dir),
                                file: PathOrFileDescriptor::Path(
                                    &fdpath[..frp.len() + BYTECODE_EXTENSION.len()],
                                ),
                            },
                        ) {
                            Ok(_) => {}
                            Err(e) => {
                                c.log_mut().add_error_fmt(
                                    None,
                                    Loc::EMPTY,
                                    format_args!(
                                        "{} writing bytecode for chunk {}",
                                        e,
                                        quote(&chunk.final_rel_path),
                                    ),
                                );
                                return Err(crate::Error::WriteFailed);
                            }
                        }

                        let mut input_path_buf: Vec<u8> = Vec::new();
                        write!(
                            &mut input_path_buf,
                            "{}{}",
                            bstr::BStr::new(&chunk.final_rel_path),
                            BYTECODE_EXTENSION
                        )
                        .expect("unreachable");

                        break 'brk Some(OutputFile::init(OutputFileInit {
                            output_path: Box::<[u8]>::from(source_provider_url_str.slice()),
                            input_path: input_path_buf.into_boxed_slice(),
                            input_loader: Loader::File,
                            hash: chunk
                                .template
                                .placeholder
                                .hash
                                .map(|_| chunk.template.content_hash(hash(&bytecode))),
                            output_kind: options::OutputKind::Bytecode,
                            loader: Loader::File,
                            size: Some(bytecode.len()),
                            display_size: bytecode.len() as u32,
                            data: OutputFileData::Saved(0),
                            side: None,
                            entry_point_index: None,
                            is_executable: false,
                            source_map_index: None,
                            bytecode_index: None,
                            module_info_index: None,
                            referenced_css_chunks: Box::default(),
                            source_index: IndexOptional::NONE,
                            bake_extra: BakeExtra::default(),
                        }));
                    }
                }
            }

            break 'brk None;
        };

        match write_file_with_path_buffer(
            &mut pathbuf,
            &WriteFileArgs {
                data: WriteFileData::Buffer {
                    buffer: &code_result.buffer,
                },
                encoding: WriteFileEncoding::Buffer,
                mode: if chunk.flags.contains(ChunkFlags::IS_EXECUTABLE) {
                    0o755
                } else {
                    0o644
                },
                dirfd: bun_sys::Fd::from_std_dir(&root_dir),
                file: PathOrFileDescriptor::Path(&chunk.final_rel_path),
            },
        ) {
            Err(e) => {
                c.log_mut().add_sys_error(
                    &e,
                    format_args!("writing chunk {}", quote(&chunk.final_rel_path)),
                );
                return Err(crate::Error::WriteFailed);
            }
            Ok(_) => {}
        }

        let source_map_index: Option<u32> = if let Some(f) = source_map_output_file {
            Some(output_files.insert_for_sourcemap_or_bytecode(f)?)
        } else {
            None
        };

        let bytecode_index: Option<u32> = if let Some(f) = bytecode_output_file {
            Some(output_files.insert_for_sourcemap_or_bytecode(f)?)
        } else {
            None
        };

        let output_kind = c.chunk_output_kind(chunk);

        chunk.final_output_size = code_result.buffer.len();
        let chunk_index = output_files.insert_for_chunk(OutputFile::init(OutputFileInit {
            output_path: chunk.final_rel_path.clone(),
            input_path,
            input_loader: if chunk.entry_point.is_entry_point() {
                parse_graph.input_files.items_loader()[chunk.entry_point.source_index() as usize]
            } else {
                Loader::Js
            },
            hash: chunk.template.placeholder.hash,
            output_kind,
            loader: chunk.content.loader(),
            source_map_index,
            bytecode_index,
            module_info_index: None,
            size: Some(code_result.buffer.len()),
            display_size: display_size as u32,
            is_executable: chunk.flags.contains(ChunkFlags::IS_EXECUTABLE),
            data: OutputFileData::Saved(0),
            side: Some(c.chunk_side(chunk)),
            entry_point_index: if output_kind == options::OutputKind::EntryPoint {
                // Server-components builds insert 2 extra synthetic sources
                // before user entry points, so the source-index offset is 3.
                let offset: u32 = if c.framework.is_some_and(|fw| fw.server_components.is_some()) {
                    3
                } else {
                    1
                };
                Some(chunk.entry_point.source_index() - offset)
            } else {
                None
            },
            referenced_css_chunks: match &chunk.content {
                Content::Javascript(js) => {
                    // `Index` is `#[repr(transparent)]` over u32.
                    js.css_chunks
                        .iter()
                        .map(|&i| OutputFileIndex::init(i))
                        .collect()
                }
                Content::Css(_) => Box::default(),
                Content::Html => Box::default(),
            },
            source_index: IndexOptional::NONE,
            bake_extra: BakeExtra::default(),
        }));

        // We want the chunk index to remain the same in `output_files` so the indices in `OutputFile.referenced_css_chunks` work.
        // In standalone mode, non-HTML chunks are skipped so this invariant doesn't apply.
        if standalone_chunk_contents.is_none() {
            debug_assert!(
                chunk_index as usize == chunk_index_in_chunks_list,
                "chunk_index ({}) != chunk_index_in_chunks_list ({})",
                chunk_index,
                chunk_index_in_chunks_list,
            );
        }
    }

    // In standalone mode, additional output files (assets) are inlined into the HTML.
    if standalone_chunk_contents.is_some() {
        return Ok(());
    }

    {
        // Reshaped for borrowck — compute len before mut borrow,
        // bump `total_insertions`, then take the slice.
        let additional_start = output_files.additional_output_files_start as usize;
        let additional_len = output_files.output_files.len() - additional_start;
        output_files.total_insertions += u32::try_from(additional_len).expect("int cast");
        let additional_output_files = &mut output_files.output_files[additional_start..];
        // SAFETY: parse_graph backref; raw deref because `parse_graph` is held
        // across `c.log_mut()` below (split borrow).
        let parse_graph = unsafe { &mut *c.parse_graph };
        debug_assert_eq!(
            parse_graph.additional_output_files.len(),
            additional_output_files.len()
        );
        for (src, dest) in parse_graph
            .additional_output_files
            .iter_mut()
            .zip(additional_output_files.iter_mut())
        {
            let bytes = if let OutputFileValue::Buffer { bytes } = &mut src.value {
                core::mem::take(bytes)
            } else {
                Box::default()
            };
            // `defer src.value.buffer.arena.free(bytes)` — `bytes` is now an
            // owned Box that drops at end of scope.

            let rel_parent = paths::resolve_path::dirname::<paths::platform::Auto>(&src.dest_path);
            if !rel_parent.is_empty() {
                if let Err(e) = root_dir.make_path(rel_parent) {
                    c.log_mut().add_error_fmt(
                        None,
                        Loc::EMPTY,
                        format_args!(
                            "{} creating outdir {} while saving file {}",
                            bstr::BStr::new(e.name()),
                            quote(rel_parent),
                            quote(&*src.dest_path),
                        ),
                    );
                    return Err(e.into());
                }
            }

            match bun_sys::File::write_file(
                bun_sys::Fd::from_std_dir(&root_dir),
                paths::resolve_path::z(&src.dest_path, &mut pathbuf),
                &bytes,
            ) {
                Err(e) => {
                    c.log_mut().add_sys_error(
                        &e,
                        format_args!("writing file {}", quote(src.src_path.text)),
                    );
                    return Err(crate::Error::WriteFailed);
                }
                Ok(_) => {}
            }

            let bytes_len = bytes.len();
            drop(bytes);
            *dest = core::mem::replace(src, OutputFile::zero_value());
            dest.value = OutputFileValue::Saved(SavedFile::default());
            dest.size = bytes_len;
        }
    }

    Ok(())
}
