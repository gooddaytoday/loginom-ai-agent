use crate::LinkerContext;
use crate::analyze_transpiled_module::ModuleInfo;
use crate::bundle_v2::bake_types::{HmrRuntimeSide, get_hmr_runtime};
use crate::linker_context_mod::{GenerateChunkCtx, LinkerOptionsMode};
use crate::mal_prelude::*;
use crate::options;
use crate::options_impl::TargetExt as _;
use crate::{
    Chunk, CompileResult, CompileResultForSourceMap, Index, RefImportData, ResolvedExports,
    ThreadPool,
};
use bun_alloc::Arena;
use bun_ast::{self as js_ast, B, Binding, E, Expr, G, Part, Ref, S, Scope, Stmt, StmtOrExpr};
use bun_ast::{ImportRecord, ImportRecordFlags, ImportRecordTag};
use bun_collections::MultiArrayList;
use bun_collections::VecExt;
use bun_core::perf;
use bun_core::{
    MutableString,
    string_joiner::{StringJoiner, Watcher},
    strings,
};
use bun_js_printer::{self as js_printer, PrintResult};
use bun_sourcemap as SourceMap;

use crate::IndexInt;

/// Move the printed code out of a `PrintResult` so the joiner takes ownership
/// of the slice — `PrintResultSuccess.code` is a `Box<[u8]>` that would
/// otherwise drop at end of `post_process_js_chunk` and leave the deferred
/// `IntermediateOutput::Joiner` path holding freed memory.
fn print_result_take_code(r: &mut PrintResult) -> Box<[u8]> {
    match r {
        PrintResult::Result(ok) => core::mem::take(&mut ok.code),
        PrintResult::Err(_) => Box::default(),
    }
}

/// `__chunks(import.meta.url, ids, nodes, 0)` for a browser entry chunk of a
/// split bundle: the chunk graph `__preload` walks (see runtime.js).
fn module_preload_registration(
    c: &mut LinkerContext,
    chunk: &mut Chunk,
    chunk_index: usize,
    chunks: &[Chunk],
) -> Result<Vec<u8>, crate::Error> {
    use std::io::Write as _;
    let mut code = Vec::new();
    if !c.module_preload()
        || !chunk.entry_point.is_entry_point()
        || !c
            .preload_entries
            .is_set(chunk.entry_point.source_index() as usize)
    {
        return Ok(code);
    }
    let chunks_ref = c.graph.symbols.follow(c.chunks_runtime_ref);

    // `reached[i]` gets local index `i`; sites and `seen` use the stable `id()`.
    let reached = Chunk::reachable_chunks(
        chunks,
        chunk_index as u32,
        &[bun_ast::ImportKind::Stmt, bun_ast::ImportKind::Dynamic],
    )?;
    let mut local = vec![u32::MAX; chunks.len()];
    for (i, &chunk_index) in reached.iter().enumerate() {
        local[chunk_index as usize] = i as u32;
    }

    let mut renamer = chunk.renamer.as_renamer();
    write!(
        &mut code,
        "{}(import.meta.url,[",
        bstr::BStr::new(renamer.name_for_symbol(chunks_ref))
    )
    .unwrap();
    for (i, &chunk_index) in reached.iter().enumerate() {
        let sep = if i == 0 { "" } else { "," };
        write!(
            &mut code,
            "{sep}\"{}\"",
            bstr::BStr::new(chunks[chunk_index as usize].id_key)
        )
        .unwrap();
    }
    code.extend_from_slice(b"],[");
    for (i, &chunk_index) in reached.iter().enumerate() {
        let other = &chunks[chunk_index as usize];
        let sep = if i == 0 { "" } else { "," };
        write!(&mut code, "{sep}[\"{}\"", bstr::BStr::new(other.unique_key)).unwrap();
        for import in other.cross_chunk_imports.iter() {
            if import.import_kind == bun_ast::ImportKind::Stmt {
                write!(&mut code, ",{}", local[import.chunk_index as usize]).unwrap();
            }
        }
        code.push(b']');
    }
    code.extend_from_slice(b"],0);\n");
    Ok(code)
}

/// This runs after we've already populated the compile results
pub(crate) fn post_process_js_chunk(
    ctx: GenerateChunkCtx,
    worker: &mut ThreadPool::Worker,
    chunk: &mut Chunk,
    chunk_index: usize,
) -> Result<(), crate::Error> {
    let _trace = perf::trace("Bundler.postProcessJSChunk");

    let c: &mut LinkerContext = ctx.c();
    debug_assert!(matches!(
        chunk.content,
        crate::chunk::Content::Javascript(_)
    ));

    bun_ast::expr::data::Store::create();
    bun_ast::stmt::data::Store::create();
    // Side arena for `AstAlloc` — linker thread builds wrapper/runtime AST
    // nodes here outside any `ASTMemoryAllocator` scope; without this their
    // embedded `Vec<Property>`/`Vec<Expr>` buffers leak from the global heap.
    let _ast_alloc_heap = js_ast::StoreAstAllocHeap::new();

    // The renamer is
    // not used after this function, so it is reset to `None` before returning
    // (success path below). `ChunkRenamer`'s variants free their owned storage
    // via Drop; the `symbols` view inside is `ManuallyDrop` (non-owning), so
    // graph storage is never freed.

    let arena = Arena::new();

    // Also generate the cross-chunk binding code
    let mut cross_chunk_prefix: PrintResult;
    let mut cross_chunk_suffix: PrintResult;

    let runtime_input_file =
        c.graph.files.items_input_file()[Index::RUNTIME.value() as usize].get() as usize;
    let runtime_scope: &mut Scope = &mut c.graph.ast.items_module_scope_mut()[runtime_input_file];
    let runtime_members = &mut runtime_scope.members;
    let to_common_js_ref = c
        .graph
        .symbols
        .follow(runtime_members.get(&b"__toCommonJS"[..]).unwrap().ref_);
    let to_esm_ref = c
        .graph
        .symbols
        .follow(runtime_members.get(&b"__toESM"[..]).unwrap().ref_);
    let runtime_require_ref = if c.options.output_format == options::OutputFormat::Cjs {
        None
    } else {
        Some(
            c.graph
                .symbols
                .follow(runtime_members.get(&b"__require"[..]).unwrap().ref_),
        )
    };

    // The chunk's module record, assembled in output order: the printer records
    // the cross-chunk prefix imports below, then the per-part-range results
    // (printed in parallel into their own ModuleInfo) are appended, then the
    // cross-chunk suffix and entry point tail exports are printed into it.
    // Stored on chunk.content.javascript.module_info — owned `Box<ModuleInfo>`.
    let mut module_info: Option<Box<ModuleInfo>> = c.options.generates_module_info().then(|| {
        let loader =
            c.parse_graph().input_files.items_loader()[chunk.entry_point.source_index() as usize];
        ModuleInfo::create(loader.is_type_script())
    });

    // SAFETY: worker.arena is set in Worker::init() before any task runs.
    let worker_arena: &Arena = worker.arena();

    // An ESM entry point already ends in an `export { }` clause
    // (`generate_entry_point_tail_js`); its cross-chunk exports join that
    // clause instead of adding a second one.
    let joined_cross_chunk_exports: Option<bun_ast::StoreSlice<bun_ast::ClauseItem>> = if chunk
        .is_entry_point()
        && c.options.output_format == options::OutputFormat::Esm
        && c.graph.meta.items_flags()[chunk.entry_point.source_index() as usize].wrap
            != crate::WrapKind::Cjs
    {
        match chunk.content.javascript().cross_chunk_suffix_stmts.slice() {
            [] => Some(bun_ast::StoreSlice::EMPTY),
            [stmt] => match &stmt.data {
                bun_ast::StmtData::SExportClause(clause) => Some(clause.items),
                _ => None,
            },
            _ => None,
        }
    } else {
        None
    };
    let exports_join_entry_tail = joined_cross_chunk_exports.is_some();

    {
        // `Options` is not `Copy` (holds `&mut ModuleInfo`), and a closure
        // taking `&mut ModuleInfo` can't express "output lifetime = input
        // lifetime" — so build a base with `module_info: None` and override it
        // via FRU at each call site.
        let make_print_options = || js_printer::Options {
            bundling: true,
            indent: Default::default(),
            has_run_symbol_renamer: true,

            require_ref: runtime_require_ref,
            minify_whitespace: c.options.minify_whitespace,
            minify_identifiers: c.options.minify_identifiers,
            minify_syntax: c.options.minify_syntax,
            target: c.options.target,
            print_dce_annotations: c.options.emit_dce_annotations,
            mangled_props: Some(&c.mangled_props),
            module_info: None,
            // .const_values = c.graph.const_values,
            ..Default::default()
        };

        let mut cross_chunk_import_records: Vec<ImportRecord> =
            Vec::with_capacity(chunk.cross_chunk_imports.len() as usize);
        for import_record in chunk.cross_chunk_imports.slice() {
            cross_chunk_import_records.push(ImportRecord {
                kind: import_record.import_kind,
                // `ctx.chunks` is a `BackRef<[Chunk]>` (safe `Deref`); chunk_index is
                // in-bounds (produced by the linker for this chunks slice).
                path: bun_paths::fs::Path::init(
                    ctx.chunks[import_record.chunk_index as usize].unique_key,
                ),
                range: bun_ast::Range::NONE,
                // Remaining fields (`ImportRecord` has no `Default` impl):
                tag: ImportRecordTag::None,
                loader: None,
                source_index: Index::INVALID,
                original_path: b"",
                flags: ImportRecordFlags::default(),
            });
        }

        // `MultiArrayList::get` returns `ManuallyDrop<BundledAst>` —
        // the storage retains ownership of every Drop field (`named_imports`,
        // `parts`, `top_level_symbols_to_parts`, …), so the gathered struct
        // must NOT run Drop. `to_ast` consumes by value, so unwrap, convert,
        // and re-wrap the result (which carries the same heap pointers).
        let ast_view = core::mem::ManuallyDrop::new(
            core::mem::ManuallyDrop::into_inner(
                c.graph.ast.get(chunk.entry_point.source_index() as usize),
            )
            .to_ast(),
        );
        let source = c.get_source(chunk.entry_point.source_index());
        let target = c.resolver().opts.target;

        // Hoist the StoreSlice extraction so the two `&mut chunk` borrows below
        // (content vs renamer) don't overlap inside a single expression.
        let prefix_stmts = bun_ast::StoreSlice::new_mut(
            chunk
                .content
                .javascript_mut()
                .cross_chunk_prefix_stmts
                .slice_mut(),
        );
        let suffix_stmts = bun_ast::StoreSlice::new_mut(if exports_join_entry_tail {
            &mut []
        } else {
            chunk
                .content
                .javascript_mut()
                .cross_chunk_suffix_stmts
                .slice_mut()
        });

        cross_chunk_prefix = js_printer::print::<false>(
            worker_arena,
            target,
            &ast_view,
            source,
            js_printer::Options {
                module_info: module_info.as_deref_mut(),
                ..make_print_options()
            },
            cross_chunk_import_records.as_slice(),
            &[Part {
                stmts: prefix_stmts,
                ..Default::default()
            }],
            chunk.renamer.as_renamer(),
        );
        if let Some(mi) = module_info.as_deref_mut() {
            // One result per entry of `parts_in_chunk_in_order`, in that order.
            for compile_result in chunk.compile_results_for_chunk.iter() {
                if let CompileResult::Javascript {
                    module_info: Some(part_module_info),
                    ..
                } = compile_result
                {
                    mi.append(part_module_info);
                }
            }
        }
        cross_chunk_suffix = js_printer::print::<false>(
            worker_arena,
            target,
            &ast_view,
            source,
            js_printer::Options {
                module_info: module_info.as_deref_mut(),
                ..make_print_options()
            },
            &[],
            &[Part {
                stmts: suffix_stmts,
                ..Default::default()
            }],
            chunk.renamer.as_renamer(),
        );
    }

    // The printer does not know about top-level await, so derive that flag from
    // the AST. The JSC module loader decides sync vs async evaluation from
    // JSModuleRecord::hasTLA(), which is set from this bit when the record is
    // constructed from module_info (BunAnalyzeTranspiledModule). Without it, a
    // bytecode-compiled module that contains TLA gets evaluated on the sync path
    // and the suspended generator is dropped — the entry promise resolves
    // immediately and the process exits before the awaited value lands.
    if let Some(mi) = module_info.as_deref_mut() {
        let tla_keywords = c.parse_graph().ast.items_top_level_await_keyword();
        let wraps = c.graph.meta.items_flags();
        for part_range in chunk.content.javascript().parts_in_chunk_in_order.iter() {
            let idx = part_range.source_index.get() as usize;
            if idx >= tla_keywords.len() {
                continue;
            }
            if wraps[idx].wrap != crate::WrapKind::None {
                continue;
            }
            if !tla_keywords[idx].is_empty() {
                mi.flags.has_tla = true;
                break;
            }
        }
    }

    // Generate the exports for the entry point, if there are any.
    // This must happen before module_info serialization so the printer
    // can populate export entries in module_info.
    let entry_point_tail = 'brk: {
        if chunk.is_entry_point() {
            let cross_chunk_exports: &[bun_ast::ClauseItem] = match &joined_cross_chunk_exports {
                Some(items) => items.slice(),
                None => &[],
            };
            break 'brk generate_entry_point_tail_js(
                c,
                to_common_js_ref,
                to_esm_ref,
                chunk.entry_point.source_index(),
                worker_arena,
                &arena,
                chunk.renamer.as_renamer(),
                module_info.as_deref_mut(),
                cross_chunk_exports,
            );
        }

        break 'brk CompileResult::Javascript {
            source_index: Index::INVALID.value(),
            result: PrintResult::Result(js_printer::PrintResultSuccess {
                code: Box::default(),
                source_map: None,
            }),
            module_info: None,
        };
    };

    // Store unserialized ModuleInfo on the chunk. Serialization is deferred to
    // generateChunksInParallel after final chunk paths are computed, so that
    // cross-chunk import specifiers (which use unique_key placeholders during
    // printing) can be resolved to actual paths.
    if let Some(mi) = module_info {
        chunk.content.javascript_mut().module_info = Some(mi);
    }

    let mut j = StringJoiner::default();
    j.watcher = Watcher {
        input: chunk.unique_key,
        ..Default::default()
    };
    // errdefer j.deinit() — deleted; StringJoiner has Drop
    let output_format = c.options.output_format;

    let mut line_offset: SourceMap::LineColumnOffsetOptional =
        if c.options.source_maps != options::SourceMapOption::None {
            SourceMap::LineColumnOffsetOptional::Value(Default::default())
        } else {
            SourceMap::LineColumnOffsetOptional::Null
        };

    // Concatenate the generated JavaScript chunks together

    let mut newline_before_comment = false;
    let mut is_executable = false;

    // Extract hashbang and banner for entry points
    let (hashbang, banner): (&[u8], &[u8]) = if chunk.is_entry_point() {
        'brk: {
            let source_hashbang =
                c.graph.ast.items_hashbang()[chunk.entry_point.source_index() as usize];

            // If source file has a hashbang, use it
            if !source_hashbang.is_empty() {
                break 'brk (source_hashbang.slice(), c.options.banner);
            }

            // Otherwise check if banner starts with hashbang
            if !c.options.banner.is_empty() && c.options.banner.starts_with(b"#!") {
                let newline_pos = strings::index_of_char(c.options.banner, b'\n')
                    .map(|n| n as usize)
                    .unwrap_or(c.options.banner.len());
                let banner_hashbang = &c.options.banner[..newline_pos];

                break 'brk (
                    banner_hashbang,
                    strings::trim_left(&c.options.banner[newline_pos..], b"\r\n"),
                );
            }

            // No hashbang anywhere
            break 'brk (b"", c.options.banner);
        }
    } else {
        (b"", c.options.banner)
    };

    // Start with the hashbang if there is one. This must be done before the
    // banner because it only works if it's literally the first character.
    if !hashbang.is_empty() {
        j.push_static(hashbang);
        j.push_static(b"\n");
        line_offset.advance(hashbang);
        line_offset.advance(b"\n");
        newline_before_comment = true;
        is_executable = true;
    }

    // Add @bun comments and CJS wrapper start for each chunk when targeting Bun.
    let is_bun = c.graph.ast.items_target()[chunk.entry_point.source_index() as usize].is_bun();
    if is_bun {
        if c.options.generate_bytecode_cache && output_format == options::OutputFormat::Cjs {
            const INPUT: &[u8] =
                b"// @bun @bytecode @bun-cjs\n(function(exports, require, module, __filename, __dirname) {";
            j.push_static(INPUT);
            line_offset.advance(INPUT);
        } else if c.options.generate_bytecode_cache {
            j.push_static(b"// @bun @bytecode\n");
            line_offset.advance(b"// @bun @bytecode\n");
        } else if output_format == options::OutputFormat::Cjs {
            const INPUT: &[u8] =
                b"// @bun @bun-cjs\n(function(exports, require, module, __filename, __dirname) {";
            j.push_static(INPUT);
            line_offset.advance(INPUT);
        } else {
            j.push_static(b"// @bun\n");
            line_offset.advance(b"// @bun\n");
        }
    }

    // Add the banner (excluding any hashbang part) for all chunks
    if !banner.is_empty() {
        j.push_static(banner);
        line_offset.advance(banner);
        if !strings::ends_with_char(banner, b'\n') {
            j.push_static(b"\n");
            line_offset.advance(b"\n");
        }
        newline_before_comment = true;
    }

    // Add the top-level directive if present (but omit "use strict" in ES
    // modules because all ES modules are automatically in strict mode)
    if chunk.is_entry_point() && !output_format.is_always_strict_mode() {
        let flags = c.graph.ast.items_flags()[chunk.entry_point.source_index() as usize];

        if flags.contains(crate::bundled_ast::Flags::HAS_EXPLICIT_USE_STRICT_DIRECTIVE) {
            j.push_static(b"\"use strict\";\n");
            line_offset.advance(b"\"use strict\";\n");
            newline_before_comment = true;
        }
    }

    let mut preload_registration = module_preload_registration(c, chunk, chunk_index, &ctx.chunks)?;

    // For Kit, hoist runtime.js outside of the IIFE
    let compile_results = &chunk.compile_results_for_chunk;
    // Right after the runtime (which declares `__chunks`) if it is in this chunk, else first.
    let preload_registration_index = compile_results
        .iter()
        .take_while(|r| r.source_index() == Index::RUNTIME.value())
        .count();
    if c.options.output_format == options::OutputFormat::InternalBakeDev {
        for compile_result in compile_results.iter() {
            let source_index = compile_result.source_index();
            if source_index != Index::RUNTIME.value() {
                break;
            }
            line_offset.advance(compile_result.code());
            j.push(compile_result.code());
        }
    }

    match c.options.output_format {
        options::OutputFormat::InternalBakeDev => {
            let start = get_hmr_runtime(if c.options.target.is_server_side() {
                HmrRuntimeSide::Server
            } else {
                HmrRuntimeSide::Client
            });
            j.push_static(start.code);
            line_offset.advance(start.code);
        }
        options::OutputFormat::Iife => {
            // Bun does not do arrow function lowering. So the wrapper can be an arrow.
            let start: &[u8] = if c.options.minify_whitespace {
                b"(()=>{"
            } else {
                b"(() => {\n"
            };
            j.push_static(start);
            line_offset.advance(start);
        }
        _ => {} // no wrapper
    }

    {
        // `cross_chunk_prefix` is a local that drops at fn exit, but the joiner
        // may be stashed on `chunk.intermediate_output` and consumed later
        // (`IntermediateOutput::Joiner` path). Move the Box into the joiner.
        let code = print_result_take_code(&mut cross_chunk_prefix);
        if !code.is_empty() {
            newline_before_comment = true;
            line_offset.advance(&code);
            j.push_owned(code);
        }
    }

    // Concatenate the generated JavaScript chunks together
    let mut prev_filename_comment: IndexInt = 0;

    let mut compile_results_for_source_map: MultiArrayList<CompileResultForSourceMap> =
        MultiArrayList::default();
    bun_core::handle_oom(compile_results_for_source_map.set_capacity(compile_results.len()));

    let show_comments = c.options.mode == LinkerOptionsMode::Bundle && !c.options.minify_whitespace;

    let emit_targets_in_commands =
        show_comments && c.framework.is_some_and(|fw| fw.server_components.is_some());

    let sources: &[bun_ast::Source] = c.parse_graph().input_files.items_source();
    let targets: &[options::Target] = c.parse_graph().ast.items_target();
    for (compile_result_index, compile_result) in compile_results.iter().enumerate() {
        let source_index = compile_result.source_index();
        let is_runtime = source_index == Index::RUNTIME.value();

        if compile_result_index == preload_registration_index && !preload_registration.is_empty() {
            newline_before_comment = true;
            line_offset.advance(&preload_registration);
            j.push_owned(core::mem::take(&mut preload_registration).into_boxed_slice());
        }

        // TODO: extracated legal comments

        // Add a comment with the file path before the file contents
        if show_comments
            && source_index != prev_filename_comment
            && !compile_result.code().is_empty()
        {
            prev_filename_comment = source_index;

            if newline_before_comment {
                j.push_static(b"\n");
                line_offset.advance(b"\n");
            }

            // Make sure newlines in the path can't cause a syntax error.
            enum CommentType {
                Multiline,
                Single,
            }

            let pretty = sources[source_index as usize].path.pretty;

            // TODO: quote this. This is really janky.
            let comment_type = if strings::index_of_newline_or_non_ascii(pretty, 0).is_some() {
                CommentType::Multiline
            } else {
                CommentType::Single
            };

            if !c.options.minify_whitespace
                && (output_format == options::OutputFormat::Iife
                    || output_format == options::OutputFormat::InternalBakeDev)
            {
                j.push_static(b"  ");
                line_offset.advance(b"  ");
            }

            match comment_type {
                CommentType::Multiline => {
                    j.push_static(b"/* ");
                    line_offset.advance(b"/* ");
                }
                CommentType::Single => {
                    j.push_static(b"// ");
                    line_offset.advance(b"// ");
                }
            }

            // A `*/` in the path would terminate the block comment early and
            // turn the rest of the path into generated JavaScript.
            if matches!(comment_type, CommentType::Multiline) && strings::contains(pretty, b"*/") {
                let mut sanitized = pretty.to_vec();
                while let Some(i) = strings::index_of(&sanitized, b"*/") {
                    sanitized[i + 1] = b'_';
                }
                line_offset.advance(&sanitized);
                j.push_owned(sanitized.into_boxed_slice());
            } else {
                j.push_static(pretty);
                line_offset.advance(pretty);
            }

            if emit_targets_in_commands {
                j.push_static(b" (");
                line_offset.advance(b" (");
                let target: &'static str =
                    <&'static str>::from(targets[source_index as usize].bake_graph());
                j.push_static(target.as_bytes());
                line_offset.advance(target.as_bytes());
                j.push_static(b")");
                line_offset.advance(b")");
            }

            match comment_type {
                CommentType::Multiline => {
                    j.push_static(b" */\n");
                    line_offset.advance(b" */\n");
                }
                CommentType::Single => {
                    j.push_static(b"\n");
                    line_offset.advance(b"\n");
                }
            }
        }

        if is_runtime {
            if c.options.output_format != options::OutputFormat::InternalBakeDev {
                line_offset.advance(compile_result.code());
                j.push(compile_result.code());
            }
        } else {
            j.push(compile_result.code());

            if let Some(source_map_chunk) = compile_result.source_map_chunk() {
                if c.options.source_maps != options::SourceMapOption::None {
                    bun_core::handle_oom(compile_results_for_source_map.append(
                        CompileResultForSourceMap {
                            // SAFETY: bitwise alias of `chunk.compile_results_for_chunk`
                            // (read-only and outlives this fn); slab-only MAL drop means
                            // the alias is never freed — original keeps the single owner.
                            source_map_chunk: unsafe { source_map_chunk.alias() },
                            generated_offset: match line_offset {
                                SourceMap::LineColumnOffsetOptional::Value(v) => v,
                                SourceMap::LineColumnOffsetOptional::Null => Default::default(),
                            },
                            source_index: compile_result.source_index(),
                        },
                    ));
                }

                line_offset.reset();
            } else {
                line_offset.advance(compile_result.code());
            }
        }

        // TODO: metafile
        newline_before_comment = !compile_result.code().is_empty();
    }
    // An entry chunk whose code all lives in shared chunks has no compile results of its own.
    if !preload_registration.is_empty() {
        line_offset.advance(&preload_registration);
        j.push_owned(preload_registration.into_boxed_slice());
        newline_before_comment = true;
    }

    {
        // `entry_point_tail` is a local `CompileResult` whose `code`
        // is a `Box<[u8]>`. Move it into the joiner so the deferred-joiner
        // path doesn't read freed memory after this fn returns.
        let tail_code = entry_point_tail.into_code();
        if !tail_code.is_empty() {
            // Stick the entry point tail at the end of the file. Deliberately don't
            // include any source mapping information for this because it's automatically
            // generated and doesn't correspond to a location in the input file.
            j.push_owned(tail_code);
        }
    }

    // Put the cross-chunk suffix inside the IIFE
    {
        // See cross_chunk_prefix above — move ownership into joiner.
        let code = print_result_take_code(&mut cross_chunk_suffix);
        if !code.is_empty() {
            if newline_before_comment {
                j.push_static(b"\n");
            }
            j.push_owned(code);
        }
    }

    match output_format {
        options::OutputFormat::Iife => {
            const WITHOUT_NEWLINE: &[u8] = b"})();";

            let with_newline: &[u8] = if newline_before_comment {
                b"})();\n"
            } else {
                WITHOUT_NEWLINE
            };

            j.push_static(with_newline);
        }
        options::OutputFormat::InternalBakeDev => {
            {
                let str = b"}, {\n  main: ";
                j.push_static(str);
                line_offset.advance(str);
            }
            {
                let input = &c.parse_graph().input_files.items_source()
                    [chunk.entry_point.source_index() as usize]
                    .path;
                let mut buf = MutableString::init_empty();
                let _ = js_printer::quote_for_json(input.pretty, &mut buf, true); // fmt::Result into Vec<u8> is infallible
                let quoted = buf.take_slice();
                line_offset.advance(&quoted);
                j.push_owned(quoted.into_boxed_slice());
            }
            {
                let str = b"\n});";
                j.push_static(str);
                line_offset.advance(str);
            }
        }
        options::OutputFormat::Cjs => {
            if is_bun {
                j.push_static(b"})\n");
                line_offset.advance(b"})\n");
            }
        }
        _ => {}
    }

    j.ensure_newline_at_end();
    // TODO: maybeAppendLegalComments

    if !c.options.footer.is_empty() {
        if newline_before_comment {
            j.push_static(b"\n");
            line_offset.advance(b"\n");
        }
        j.push_static(c.options.footer);
        line_offset.advance(c.options.footer);
        j.push_static(b"\n");
        line_offset.advance(b"\n");
    }

    // SAFETY: every borrowed node in `j` points into `chunk.compile_results_for_chunk`
    // (slots pre-sized in generateChunksInParallel, filled in place by the print
    // workers before post-processing, never reassigned afterwards), `c.options`
    // banner/footer (`&'static`), graph/parse-graph data (hashbangs, source paths,
    // HMR runtime), or `'static` literals; `watcher.input` is `chunk.unique_key`
    // (`&'static`). All of these outlive the joiner stored in
    // `chunk.intermediate_output`, which is only read while the chunk and the
    // linker graph are alive.
    let mut j = unsafe { j.detach_lifetime() };
    chunk.intermediate_output = c
        .break_output_into_pieces(worker_arena, &mut j, ctx.chunks.len() as u32)
        .unwrap_or_else(|_| panic!("Unhandled out of memory error in breakOutputIntoPieces()"));

    // TODO: meta contents

    chunk.isolated_hash = c.generate_isolated_hash(chunk, worker_arena);
    chunk
        .flags
        .set(crate::chunk::Flags::IS_EXECUTABLE, is_executable);

    if c.options.source_maps != options::SourceMapOption::None {
        let can_have_shifts = matches!(
            chunk.intermediate_output,
            crate::chunk::IntermediateOutput::Pieces(_)
        );
        // Copy the `ParentRef` out (not `c.resolver()`) so the arg borrows the
        // local, not `c`, avoiding the split-borrow with
        // `c.generate_source_map_for_chunk(&mut self, …)`.
        let resolver = c.resolver.expect("resolver set in load()");
        chunk.output_source_map = c.generate_source_map_for_chunk(
            chunk.isolated_hash,
            worker,
            &compile_results_for_source_map,
            &resolver.opts.output_dir,
            can_have_shifts,
        )?;
    }

    // Free the renamer now that printing is done; nothing reads it after
    // post-processing.
    chunk.renamer = Default::default();

    Ok(())
}

// `js_printer::print` ties bump/Options/import_records/renamer to a
// single `'a`, and `Renamer<'r, 'src>` is invariant in `'src` — so the caller's
// renamer lifetime fixes `'a`. All by-ref params that flow into `print` must
// share that lifetime.
pub(crate) fn generate_entry_point_tail_js<'a>(
    c: &'a mut LinkerContext,
    to_common_js_ref: Ref,
    to_esm_ref: Ref,
    source_index: IndexInt,
    arena: &'a Arena,
    temp_arena: &Arena,
    r: js_printer::renamer::Renamer<'a, 'a>,
    module_info: Option<&'a mut ModuleInfo>,
    cross_chunk_exports: &[bun_ast::ClauseItem],
) -> CompileResult {
    let flags: crate::js_meta::Flags = c.graph.meta.items_flags()[source_index as usize];
    let mut stmts: Vec<Stmt> = Vec::new();
    // `MultiArrayList::get` returns `ManuallyDrop<BundledAst>`; the
    // storage retains ownership of every Drop field, so neither this
    // `BundledAst` nor the `ast_view: Ast` derived from it below may run Drop.
    let ast = c.graph.ast.get(source_index as usize);

    match c.options.output_format {
        options::OutputFormat::Esm => {
            match flags.wrap {
                crate::WrapKind::Cjs => {
                    stmts.push(Stmt::alloc(
                        // "export default require_foo();"
                        S::ExportDefault {
                            default_name: bun_ast::LocRef {
                                loc: bun_ast::Loc::EMPTY,
                                ref_: ast.wrapper_ref,
                            },
                            value: StmtOrExpr::Expr(Expr::init(
                                E::Call {
                                    target: Expr::init_identifier(
                                        ast.wrapper_ref,
                                        bun_ast::Loc::EMPTY,
                                    ),
                                    ..Default::default()
                                },
                                bun_ast::Loc::EMPTY,
                            )),
                        },
                        bun_ast::Loc::EMPTY,
                    ));
                }
                _ => {
                    if flags.wrap == crate::WrapKind::Esm && ast.wrapper_ref.is_valid() {
                        if flags.is_async_or_has_async_dependency {
                            // "await init_foo();"
                            stmts.push(Stmt::alloc(
                                S::SExpr {
                                    value: Expr::init(
                                        E::Await {
                                            value: Expr::init(
                                                E::Call {
                                                    target: Expr::init_identifier(
                                                        ast.wrapper_ref,
                                                        bun_ast::Loc::EMPTY,
                                                    ),
                                                    ..Default::default()
                                                },
                                                bun_ast::Loc::EMPTY,
                                            ),
                                        },
                                        bun_ast::Loc::EMPTY,
                                    ),
                                    ..Default::default()
                                },
                                bun_ast::Loc::EMPTY,
                            ));
                        } else {
                            // "init_foo();"
                            stmts.push(Stmt::alloc(
                                S::SExpr {
                                    value: Expr::init(
                                        E::Call {
                                            target: Expr::init_identifier(
                                                ast.wrapper_ref,
                                                bun_ast::Loc::EMPTY,
                                            ),
                                            ..Default::default()
                                        },
                                        bun_ast::Loc::EMPTY,
                                    ),
                                    ..Default::default()
                                },
                                bun_ast::Loc::EMPTY,
                            ));
                        }
                    }

                    let sorted_and_filtered_export_aliases =
                        &c.graph.meta.items_sorted_and_filtered_export_aliases()
                            [source_index as usize];

                    let default_is_namespace =
                        LinkerContext::chunk_default_export_is_namespace(flags, ast.flags);

                    if !sorted_and_filtered_export_aliases.is_empty()
                        || !cross_chunk_exports.is_empty()
                    {
                        let resolved_exports: &ResolvedExports =
                            &c.graph.meta.items_resolved_exports()[source_index as usize];
                        let imports_to_bind: &RefImportData =
                            &c.graph.meta.items_imports_to_bind()[source_index as usize];

                        // If the output format is ES6 modules and we're an entry point, generate an
                        // ES6 export statement containing all exports. Except don't do that if this
                        // entry point is a CommonJS-style module, since that would generate an ES6
                        // export statement that's not top-level. Instead, we will export the CommonJS
                        // exports as a default export later on.
                        let mut items: Vec<bun_ast::ClauseItem> = Vec::new();
                        let cjs_export_copies =
                            &c.graph.meta.items_cjs_export_copies()[source_index as usize];

                        let mut had_default_export = false;

                        for (i, alias) in sorted_and_filtered_export_aliases.iter().enumerate() {
                            if default_is_namespace && **alias == *b"default" {
                                continue;
                            }

                            // Only `.data` (an `ImportTracker`, `Copy`) is
                            // read/mutated below, so copy that field instead of
                            // the whole `ExportData`.
                            let mut resolved_export_data =
                                resolved_exports.get(alias).unwrap().data;

                            had_default_export = had_default_export || **alias == *b"default";

                            // If this is an export of an import, reference the symbol that the import
                            // was eventually resolved to. We need to do this because imports have
                            // already been resolved by this point, so we can't generate a new import
                            // and have that be resolved later.
                            if let Some(import_data) =
                                imports_to_bind.get(&resolved_export_data.import_ref)
                            {
                                resolved_export_data.import_ref = import_data.data.import_ref;
                                resolved_export_data.source_index = import_data.data.source_index;
                            }

                            // Exports of imports need EImportIdentifier in case they need to be re-
                            // written to a property access later on
                            // SAFETY: symbol::Map::get returns a non-null `*mut Symbol` for a valid ref.
                            if unsafe {
                                (*c.graph
                                    .symbols
                                    .get(resolved_export_data.import_ref)
                                    .unwrap())
                                .namespace_alias
                                .is_some()
                            } {
                                let temp_ref = cjs_export_copies[i];

                                // Create both a local variable and an export clause for that variable.
                                // The local variable is initialized with the initial value of the
                                // export. This isn't fully correct because it's a "dead" binding and
                                // doesn't update with the "live" value as it changes. But ES6 modules
                                // don't have any syntax for bare named getter functions so this is the
                                // best we can do.
                                //
                                // These input files:
                                //
                                //   // entry_point.js
                                //   export {foo} from './cjs-format.js'
                                //
                                //   // cjs-format.js
                                //   Object.defineProperty(exports, 'foo', {
                                //     enumerable: true,
                                //     get: () => Math.random(),
                                //   })
                                //
                                // Become this output file:
                                //
                                //   // cjs-format.js
                                //   var require_cjs_format = __commonJS((exports) => {
                                //     Object.defineProperty(exports, "foo", {
                                //       enumerable: true,
                                //       get: () => Math.random()
                                //     });
                                //   });
                                //
                                //   // entry_point.js
                                //   var cjs_format = __toESM(require_cjs_format());
                                //   var export_foo = cjs_format.foo;
                                //   export {
                                //     export_foo as foo
                                //   };
                                //
                                stmts.push(Stmt::alloc(
                                    S::Local {
                                        decls: G::DeclList::from_slice(&[G::Decl {
                                            binding: Binding::alloc(
                                                temp_arena,
                                                B::Identifier { r#ref: temp_ref },
                                                bun_ast::Loc::EMPTY,
                                            ),
                                            value: Some(Expr::init(
                                                E::ImportIdentifier {
                                                    ref_: resolved_export_data.import_ref,
                                                    ..Default::default()
                                                },
                                                bun_ast::Loc::EMPTY,
                                            )),
                                        }]),
                                        ..Default::default()
                                    },
                                    bun_ast::Loc::EMPTY,
                                ));

                                items.push(bun_ast::ClauseItem {
                                    name: bun_ast::LocRef {
                                        ref_: temp_ref,
                                        loc: bun_ast::Loc::EMPTY,
                                    },
                                    alias: bun_ast::StoreStr::new(alias),
                                    alias_loc: bun_ast::Loc::EMPTY,
                                    ..Default::default()
                                });
                            } else {
                                // Local identifiers can be exported using an export clause. This is done
                                // this way instead of leaving the "export" keyword on the local declaration
                                // itself both because it lets the local identifier be minified and because
                                // it works transparently for re-exports across files.
                                //
                                // These input files:
                                //
                                //   // entry_point.js
                                //   export * from './esm-format.js'
                                //
                                //   // esm-format.js
                                //   export let foo = 123
                                //
                                // Become this output file:
                                //
                                //   // esm-format.js
                                //   let foo = 123;
                                //
                                //   // entry_point.js
                                //   export {
                                //     foo
                                //   };
                                //
                                items.push(bun_ast::ClauseItem {
                                    name: bun_ast::LocRef {
                                        ref_: resolved_export_data.import_ref,
                                        loc: resolved_export_data.name_loc,
                                    },
                                    alias: bun_ast::StoreStr::new(alias),
                                    alias_loc: resolved_export_data.name_loc,
                                    ..Default::default()
                                });
                            }
                        }

                        let own_len = items.len();
                        items.extend(cross_chunk_exports.iter().map(|item| bun_ast::ClauseItem {
                            alias: item.alias,
                            alias_loc: item.alias_loc,
                            name: item.name,
                            original_name: item.original_name,
                        }));
                        // arena-owned `*mut [ClauseItem]` — move the
                        // collected Vec into the linker arena. The arena slice is also iterated
                        // below for the synthetic-default-export path.
                        let items: &mut [bun_ast::ClauseItem] = arena.alloc_slice_fill_iter(items);
                        if !items.is_empty() {
                            stmts.push(Stmt::alloc(
                                S::ExportClause {
                                    items: bun_ast::StoreSlice::new_mut(items),
                                    is_single_line: false,
                                },
                                bun_ast::Loc::EMPTY,
                            ));
                        }
                        let items = &items[..own_len];

                        if flags.needs_synthetic_default_export
                            && !default_is_namespace
                            && !had_default_export
                            && !items.is_empty()
                        {
                            let mut properties = G::PropertyList::init_capacity(items.len());
                            let getter_fn_body: &mut [Stmt] =
                                arena.alloc_slice_fill_default(items.len());
                            let mut remain_getter_fn_body = &mut getter_fn_body[..];
                            for export_item in items.iter() {
                                let (fn_body, rest) = remain_getter_fn_body.split_at_mut(1);
                                remain_getter_fn_body = rest;
                                fn_body[0] = Stmt::alloc(
                                    S::Return {
                                        value: Some(Expr::init(
                                            E::Identifier {
                                                ref_: export_item.name.ref_,
                                                ..Default::default()
                                            },
                                            export_item.name.loc,
                                        )),
                                    },
                                    bun_ast::Loc::EMPTY,
                                );
                                VecExt::append(
                                    &mut properties,
                                    G::Property {
                                        key: Some(Expr::init(
                                            E::String {
                                                // SAFETY: alias is an arena `*const [u8]`; never null.
                                                data: export_item.alias.slice().into(),
                                                is_utf16: false,
                                                ..Default::default()
                                            },
                                            export_item.alias_loc,
                                        )),
                                        value: Some(Expr::init(
                                            E::Function {
                                                func: G::Fn {
                                                    body: G::FnBody {
                                                        loc: bun_ast::Loc::EMPTY,
                                                        stmts: bun_ast::StoreSlice::new_mut(
                                                            fn_body,
                                                        ),
                                                    },
                                                    ..Default::default()
                                                },
                                            },
                                            export_item.alias_loc,
                                        )),
                                        kind: G::PropertyKind::Get,
                                        flags: bun_ast::Flags::Property::IsMethod.into(),
                                        ..Default::default()
                                    },
                                );
                            }
                            stmts.push(Stmt::alloc(
                                S::ExportDefault {
                                    default_name: bun_ast::LocRef {
                                        ref_: Ref::NONE,
                                        loc: bun_ast::Loc::EMPTY,
                                    },
                                    value: StmtOrExpr::Expr(Expr::init(
                                        E::Object {
                                            properties,
                                            ..Default::default()
                                        },
                                        bun_ast::Loc::EMPTY,
                                    )),
                                },
                                bun_ast::Loc::EMPTY,
                            ));
                        }
                    }

                    if default_is_namespace {
                        // "export default exports_foo;"
                        stmts.push(Stmt::alloc(
                            S::ExportDefault {
                                default_name: bun_ast::LocRef {
                                    ref_: Ref::NONE,
                                    loc: bun_ast::Loc::EMPTY,
                                },
                                value: StmtOrExpr::Expr(Expr::init_identifier(
                                    ast.exports_ref,
                                    bun_ast::Loc::EMPTY,
                                )),
                            },
                            bun_ast::Loc::EMPTY,
                        ));
                    }
                }
            }
        }

        // TODO: iife
        options::OutputFormat::Iife => {}

        options::OutputFormat::InternalBakeDev => {
            // nothing needs to be done here, as the exports are already
            // forwarded in the module closure.
        }

        options::OutputFormat::Cjs => {
            match flags.wrap {
                crate::WrapKind::Cjs => {
                    // "module.exports = require_foo();"
                    stmts.push(Stmt::assign(
                        Expr::init(
                            E::Dot {
                                target: Expr::init_identifier(
                                    c.unbound_module_ref,
                                    bun_ast::Loc::EMPTY,
                                ),
                                name: b"exports".into(),
                                name_loc: bun_ast::Loc::EMPTY,
                                ..Default::default()
                            },
                            bun_ast::Loc::EMPTY,
                        ),
                        Expr::init(
                            E::Call {
                                target: Expr::init_identifier(ast.wrapper_ref, bun_ast::Loc::EMPTY),
                                ..Default::default()
                            },
                            bun_ast::Loc::EMPTY,
                        ),
                    ));
                }
                // A file without a wrapper symbol prints unwrapped (`needs_wrapper_ref`
                // in the parser), so there is no `init_foo` to call.
                crate::WrapKind::Esm if ast.wrapper_ref.is_valid() => {
                    // "init_foo();"
                    stmts.push(Stmt::alloc(
                        S::SExpr {
                            value: Expr::init(
                                E::Call {
                                    target: Expr::init_identifier(
                                        ast.wrapper_ref,
                                        bun_ast::Loc::EMPTY,
                                    ),
                                    ..Default::default()
                                },
                                bun_ast::Loc::EMPTY,
                            ),
                            ..Default::default()
                        },
                        bun_ast::Loc::EMPTY,
                    ));
                }
                _ => {}
            }

            // TODO:
            // If we are generating CommonJS for node, encode the known export names in
            // a form that node can understand them. This relies on the specific behavior
            // of this parser, which the node project uses to detect named exports in
            // CommonJS files: https://github.com/guybedford/cjs-module-lexer. Think of
            // this code as an annotation for that parser.
        }
    }

    if stmts.is_empty() {
        return CompileResult::Javascript {
            source_index,
            result: PrintResult::Result(js_printer::PrintResultSuccess {
                code: Box::default(),
                source_map: None,
            }),
            module_info: None,
        };
    }

    let print_options = js_printer::Options {
        // TODO: IIFE indent
        indent: Default::default(),
        has_run_symbol_renamer: true,

        to_esm_ref,
        to_commonjs_ref: to_common_js_ref,
        require_or_import_meta_for_source_callback: js_printer::RequireOrImportMetaCallback::init::<
            LinkerContext,
        >(c),

        minify_whitespace: c.options.minify_whitespace,
        print_dce_annotations: c.options.emit_dce_annotations,
        minify_syntax: c.options.minify_syntax,
        mangled_props: Some(&c.mangled_props),
        module_info,
        // .const_values = c.graph.const_values,
        ..Default::default()
    };

    let ast_view = core::mem::ManuallyDrop::new(core::mem::ManuallyDrop::into_inner(ast).to_ast());
    // SAFETY: `import_records` is a `Vec` pointing into the bundler arena,
    // which outlives `'a` (the chunk-processing scope). Detach the borrow from
    // the local `ast_view` so it can satisfy `print`'s `&'a [ImportRecord]`.
    let import_records: &'a [ImportRecord] =
        unsafe { bun_ptr::detach_lifetime(ast_view.import_records.as_slice()) };

    CompileResult::Javascript {
        result: js_printer::print::<false>(
            arena,
            c.resolver().opts.target,
            &ast_view,
            c.get_source(source_index),
            print_options,
            import_records,
            &[Part {
                stmts: bun_ast::StoreSlice::new_mut(stmts.as_mut_slice()),
                ..Default::default()
            }],
            r,
        ),
        source_index,
        // The exports were recorded straight into the chunk's ModuleInfo above.
        module_info: None,
    }
}
