use core::ptr::NonNull;

use bun_alloc::Arena; // MimallocArena → bumpalo::Bump (ThreadLocalArena)
use bun_core::{self, Output, zstr};
use bun_io as Async;
use bun_threading::unbounded_queue::{Node, UnboundedQueue};

use crate::bundle_v2::{FileMap, JSBundlerPlugin, dispatch};
use crate::{BundleV2, Transpiler};

/// Used to keep the bundle thread from spinning on Windows
#[cfg(windows)]
extern "C" fn timer_callback(_: *mut bun_sys::windows::libuv::Timer) {}

/// Port of `std.Thread.ResetEvent` — single-shot manual-reset event used to
/// block `spawn()` until the bundle thread has initialized its `Waker`.
// Re-exports `bun_threading::ResetEvent` (futex-backed); the futex impl
// preserves the "set-before-wait does not deadlock" property `spawn()` relies on.
pub use bun_threading::ResetEvent;

/// Result of a `Bun.build` invocation handed back to the JS thread.
/// Consumed by `bundler_jsc` via the `CompletionStruct` trait.
pub struct BuildResult {
    pub output_files: Vec<crate::options::OutputFile>,
    pub metafile: Option<Box<[u8]>>,
    pub metafile_markdown: Option<Box<[u8]>>,
}

pub enum BundleV2Result {
    Pending,
    Err(crate::Error),
    Value(BuildResult),
}

/// Originally, bake.DevServer required a separate bundling thread, but that was
/// later removed. The bundling thread's scheduling logic is generalized over
/// the completion structure.
///
/// CompletionStruct's interface:
///
/// - `configureBundler` is used to configure `Bundler`.
/// - `completeOnBundleThread` is used to tell the task that it is done.
// The trait bound lives on the `impl` (not the struct) so the
// `singleton` static can name `BundleThread<JSBundleCompletionTask>` before T6
// provides the `CompletionStruct` impl for the forward-decl.
pub(crate) struct BundleThread<C: Node> {
    pub(crate) waker: Async::Waker,
    /// Set by the bundle thread before it signals `ready_event` if creating `waker` fails.
    pub(crate) waker_error: Option<Async::Error>,
    pub(crate) ready_event: ResetEvent,
    // `bun.UnboundedQueue(CompletionStruct, .next)` — intrusive over `C.next`;
    // the field offset is encoded via the `Node` supertrait on `CompletionStruct`.
    pub(crate) queue: UnboundedQueue<C>,
    pub(crate) generation: bun_core::Generation,
}

/// Trait capturing the interface a completion task must satisfy.
///
/// The trait accessors keep the generic `BundleThread<C>`
/// layout-agnostic. The concrete impl lives in T6 (`bun_bundler_jsc`).
pub trait CompletionStruct: Node + Send + 'static {
    /// `bump` is the per-build mimalloc heap that backs `transpiler`, so the
    /// two share lifetime `'a` (option fields like `optimize_imports: &'a
    /// StringSet` borrow from `bump`).
    fn configure_bundler<'a>(
        &mut self,
        transpiler: &mut Transpiler<'a>,
        bump: &'a Arena,
    ) -> Result<(), crate::Error>;
    /// Bundle thread, on dequeue: `false` if the owner released this build
    /// while it was still queued ([`free_released_unstarted`] then frees it).
    fn try_start(&mut self) -> bool;
    fn free_released_unstarted(this: *mut Self);
    fn complete_on_bundle_thread(&mut self);
    fn set_result(&mut self, result: BundleV2Result);
    fn set_log(&mut self, log: bun_ast::Log);
    fn set_transpiler(&mut self, this: *mut BundleV2<'_>);
    fn plugins(&self) -> Option<NonNull<JSBundlerPlugin>>;
    /// Returns the file map if non-empty; a single accessor so the opaque
    /// `FileMap` layout stays in T6.
    fn file_map(&mut self) -> Option<NonNull<FileMap>>;
    /// Returns a §Dispatch handle (erased owner + `&'static` vtable) the impl
    /// provides, so the bundler can read `result == .err` / `is_cancelled`,
    /// and post plugin hops to the owning VM, without naming the concrete
    /// struct.
    fn as_js_bundle_completion_task(&mut self) -> dispatch::CompletionHandle;

    /// `Transpiler<'a>` has borrow-carrying fields (`arena: &'a Arena`,
    /// `resolver: Resolver<'a>`) that cannot be zero-init'd, so the allocate +
    /// configure pair is folded into one trait call returning the
    /// arena-allocated, fully-configured transpiler.
    // The returned `&'a mut Transpiler<'a>` is arena-allocated via `bump.alloc(...)`
    // (bumpalo `Bump`), which hands out `&mut` from `&self` through interior
    // mutability — the standard arena pattern `mut_from_ref` cannot see through.
    #[allow(clippy::mut_from_ref)]
    fn create_and_configure_transpiler<'a>(
        &mut self,
        bump: &'a Arena,
    ) -> Result<&'a mut Transpiler<'a>, crate::Error>;

    /// Constructs the `BundleV2`, wires `plugins`/`completion`/`file_map`,
    /// and runs the bundle.
    ///
    /// This body is `JSBundleCompletionTask`-specific, so the
    /// construction + run is delegated to the trait impl in T6, which has
    /// access to the concrete event-loop / work-pool wiring. The shared
    /// scaffolding (arena, AST arena push/pop, log copy,
    /// `completeOnBundleThread`) stays in `generate_in_new_thread` below.
    fn init_and_run<'a>(
        &mut self,
        transpiler: &'a mut Transpiler<'a>,
        bump: &'a Arena,
        // Raw `*mut` (not `&'static`) because `BundleV2::init` ultimately
        // stores it as `worker_pool: *mut ThreadPool` and `WorkPool::get()`
        // hands out `&'static`; materializing `&mut` from that would be UB.
        thread_pool: *mut bun_threading::ThreadPool,
    ) -> Result<(), crate::Error>;
}

impl<C: CompletionStruct> BundleThread<C> {
    /// To initialize, put this somewhere in memory, and then call `spawn()`
    // We can't use
    // `mem::zeroed()` here — the platform `Waker`s hold NonNull-validity
    // fields (a `Box<[u8]>` on macOS, a niche-optimised `Option<BackRef>` on
    // Windows), so zeroing them is *language-level* UB even if never read.
    // `placeholder()` yields a fully-initialized inert value instead.
    // `ready_event.wait()` in `spawn()` blocks until `thread_main` overwrites
    // it via `ptr::write`, so the placeholder is never observed live.
    pub(crate) fn uninitialized() -> Self {
        Self {
            waker: Async::Waker::placeholder(),
            waker_error: None,
            queue: UnboundedQueue::new(),
            generation: 0,
            ready_event: ResetEvent::default(),
        }
    }

    /// # Safety
    /// `instance` must be valid for `'static` (the spawned thread runs forever and
    /// accesses it). On `Ok`, the bundle thread concurrently accesses
    /// `*instance`; callers must only touch it via the raw-pointer methods on this
    /// impl (e.g. `enqueue`) and never materialize a `&mut Self`. On `Err`, no
    /// thread references `*instance` and the caller owns it again.
    pub(crate) unsafe fn spawn(instance: *mut Self) -> std::io::Result<()> {
        // `std::thread::Builder` (not `std::thread::spawn`) so the spawn error
        // is surfaced to the caller.
        struct SendPtr<T>(*mut T);
        // SAFETY: the pointer is only dereferenced on the bundle thread via raw
        // projections; `BundleThread<C>` itself is never moved across threads.
        unsafe impl<T> Send for SendPtr<T> {}
        let ptr = SendPtr(instance);
        let thread = std::thread::Builder::new()
            .name("Bundler".into())
            .spawn(move || {
                let ptr = ptr;
                // SAFETY: caller guarantees `instance` is valid for 'static; `thread_main`
                // accesses fields only via raw-ptr projection (never `&Self`/`&mut Self`)
                // and is the sole writer of `waker`/`generation`, so concurrent `enqueue()`
                // from other threads is sound.
                unsafe { Self::thread_main(ptr.0) }
            })?;
        // SAFETY: field projection via raw ptr — the spawned thread is concurrently
        // writing `waker`, so we must not hold `&Self`/`&mut Self` here. `ready_event`
        // itself is a sync primitive safe to wait on from this thread, and it
        // publishes `waker_error`.
        let waker_error = unsafe {
            (*instance).ready_event.wait();
            (*instance).waker_error
        };
        if let Some(err) = waker_error {
            // The caller frees `*instance`, so join the thread first.
            let _ = thread.join();
            return Err(std::io::Error::other(err));
        }
        // `std.Thread.detach()` — drop the JoinHandle without joining.
        drop(thread);
        Ok(())
    }

    /// # Safety
    /// `instance` must point to a live `BundleThread` whose bundle thread has been
    /// spawned (so `waker` is initialized). Called concurrently with `thread_main`.
    pub(crate) unsafe fn enqueue(instance: *mut Self, completion: *mut C) {
        // SAFETY: `completion` is a live, caller-owned task node (non-null).
        let completion = unsafe { core::ptr::NonNull::new_unchecked(completion) };
        // SAFETY: field projections via raw ptr — `thread_main` on the bundle thread
        // accesses the same struct concurrently, so we never materialize `&mut Self`.
        // `UnboundedQueue::push` takes `&self` (lock-free MPSC). `Waker::wake` takes
        // `&self` on all platforms and only reads a Copy field (eventfd, mach port,
        // `WindowsLoop` pointer) to pass to a wake call that is safe from any thread
        // (eventfd write, mach_msg send, uv_async_send), so the `&Waker` autoref is
        // sound alongside `wait(&self)` in `thread_main` and other `enqueue` callers.
        unsafe {
            (*instance).queue.push(completion);
            (*instance).waker.wake();
        }
    }

    unsafe fn thread_main(instance: *mut Self) {
        Output::Source::configure_named_thread(zstr!("Bundler"));

        // On Windows the waker is this thread's libuv loop, so create it here, not in `spawn()`.
        let waker = match Async::Waker::init() {
            Ok(waker) => waker,
            Err(err) => {
                // SAFETY: `spawn()` is blocked in `ready_event.wait()` and joins this
                // thread before `*instance` is freed.
                unsafe {
                    core::ptr::addr_of_mut!((*instance).waker_error).write(Some(err));
                    (*instance).ready_event.set();
                }
                return;
            }
        };

        // SAFETY: `waker` is written exactly once here, before `ready_event.set()`
        // releases any thread that could call `enqueue` (which reads `waker`).
        unsafe { core::ptr::addr_of_mut!((*instance).waker).write(waker) };

        // Unblock the calling thread so it can continue.
        // SAFETY: raw-ptr field projection; spawning thread is blocked in `ready_event.wait()`.
        unsafe { (*instance).ready_event.set() };

        // The libuv Timer lives on stack for the lifetime of this never-returning fn.
        // It MUST be declared at function scope (not inside the `#[cfg(windows)] { ... }`
        // block below) because `timer.init()`/`timer.start()` register `&timer`'s address
        // into the uv loop's intrusive handle queue / timer min-heap, and `waker.wait()`
        // (→ `uv_run`) in the `loop {}` below dereferences that address.
        #[cfg(windows)]
        let mut timer: bun_sys::windows::libuv::Timer = bun_core::ffi::zeroed();
        #[cfg(windows)]
        {
            // SAFETY: raw place read of `waker.loop_.uv_loop` (Copy ptr); field is
            // write-once in `Waker::init()` above and never mutated by `wake()`, so a
            // concurrent `enqueue()` (possible now that `ready_event.set()` has fired)
            // does not conflict. No `&Waker`/`&mut Waker` is materialized here.
            timer.init(unsafe { (*instance).waker.uv_loop() });
            timer.start(u64::MAX, u64::MAX, Some(timer_callback));
        }

        let mut has_bundled = false;
        loop {
            loop {
                // SAFETY: `UnboundedQueue::pop` takes `&self`; concurrent `push` from
                // `enqueue` is the lock-free queue's intended use.
                let completion = unsafe { (*instance).queue.pop() };
                if completion.is_null() {
                    break;
                }
                // SAFETY: queue stores non-null *mut C pushed via enqueue(); owner keeps it alive
                // until complete_on_bundle_thread() signals completion — unless it
                // released the build while it sat here (its VM went away).
                if !unsafe { (*completion).try_start() } {
                    C::free_released_unstarted(completion);
                    continue;
                }
                // SAFETY: as above; started ⇒ the owner waits for us.
                let completion = unsafe { &mut *completion };
                // SAFETY: `generation` is only read/written on this (bundle) thread.
                let generation = unsafe { (*instance).generation };
                // `panic = "abort"` → a Rust panic on this thread enters the
                // crash-handler hook and aborts the whole process.
                // No `catch_unwind` — there is nothing to catch.
                match Self::generate_in_new_thread(completion, generation) {
                    Ok(()) => {}
                    Err(err) => {
                        completion.set_result(BundleV2Result::Err(err));
                        completion.complete_on_bundle_thread();
                    }
                }
                has_bundled = true;
            }
            // SAFETY: `generation` is only read/written on this (bundle) thread.
            unsafe {
                let g = core::ptr::addr_of_mut!((*instance).generation);
                *g = (*g).saturating_add(1);
            }

            if has_bundled {
                crate::bundle_v2::dispatch::__bun_jsc_destroy_bytecode_cache_vm();
                bun_alloc::mimalloc::mi_collect(false);
                has_bundled = false;
            }

            // SAFETY: `Waker::wait` takes `&self`; concurrent `wake()` from `enqueue` is by design.
            unsafe { (*instance).waker.wait() };
        }
    }

    /// This is called from `Bun.build` in JavaScript.
    fn generate_in_new_thread(
        completion: &mut C,
        generation: bun_core::Generation,
    ) -> Result<(), crate::Error> {
        let heap = Arena::new();

        let bump = &heap;
        let ast_memory_store: &mut bun_ast::ASTMemoryAllocator =
            bump.alloc(bun_ast::ASTMemoryAllocator::new(bump));
        ast_memory_store.reset();
        ast_memory_store.push();

        // Allocate + configure folded — see `create_and_configure_transpiler` doc.
        let transpiler = completion.create_and_configure_transpiler(bump)?;

        transpiler.resolver.generation = generation;

        // Construction + run delegated — see
        // `init_and_run` doc. Reborrow `transpiler` through a raw ptr so
        // `completion` can be borrowed again below.
        let transpiler_ptr: *mut Transpiler<'_> = transpiler;
        let run = completion.init_and_run(
            // SAFETY: `transpiler` lives in `bump` for the duration of `heap`.
            unsafe { &mut *transpiler_ptr },
            bump,
            // `WorkPool::get()` returns `&'static ThreadPool`; pass as raw so
            // the impl can hand it to `BundleV2::init` (which stores `*mut`).
            std::ptr::from_ref(bun_threading::work_pool::WorkPool::get()).cast_mut(),
        );

        // Straight-line teardown: log copy
        // runs on both paths; `completeOnBundleThread` only on success (the error
        // path's `set_result(Err)` + complete happens in `thread_main`). The
        // `deinit_without_freeing_arena` call lives inside `init_and_run`
        // (it owns `this`).
        let mut out_log = bun_ast::Log::init();
        // SAFETY: `transpiler.log` is the arena-allocated `*mut Log` set up by
        // `configure_bundler`; valid for the lifetime of `heap`. Raw deref so the
        // `&'a mut Transpiler` consumed by `init_and_run` above is not reborrowed.
        let _ = unsafe { (*(*transpiler_ptr).log).append_to_with_recycled(&mut out_log, true) }; // logger OOM-only
        completion.set_log(out_log);

        if run.is_ok() {
            completion.complete_on_bundle_thread();
        }

        ast_memory_store.pop();

        // `transpiler` / `ast_memory_store` are arena-allocated, but their
        // containers (`Resolver` caches, `BundleOptions` strings, the AST
        // allocator's own `mi_heap` handle, …) live on the global heap as
        // `Vec`/`Box`/`HashMap`, so dropping `heap` (`mi_heap_destroy`) reclaims
        // the struct bytes but never runs `Transpiler::drop` /
        // `ASTMemoryAllocator::drop` — leaking the resolver's directory/file
        // caches and an entire `mi_heap` per `Bun.build()` call. LSan does not
        // flag the latter (mimalloc bypasses the ASAN `malloc` interceptor), so
        // the symptom is RSS-only: ~32 MB/build linear growth in the
        // bun-build-api "does not leak sourcemap JSON" test.
        //
        // SAFETY: both pointers are the unique `&'a mut` slots returned by
        // `bump.alloc(...)` above; nothing else holds a reference to either
        // past `init_and_run` (`set_transpiler` was cleared by
        // `deinit_without_freeing_arena`, `pop()` restored the AST-allocator
        // thread-local). The arena bytes themselves are bulk-freed afterwards
        // by `heap`'s `Drop` — `drop_in_place` only releases the *embedded
        // global-heap* state, so there is no double free.
        unsafe {
            core::ptr::drop_in_place(transpiler_ptr);
            core::ptr::drop_in_place(std::ptr::from_mut::<bun_ast::ASTMemoryAllocator>(
                ast_memory_store,
            ));
        }

        run
    }
}

/// Lazily-initialized singleton. This is used for `Bun.build` since the
/// bundle thread may not be needed.
// Rust forbids generic statics, so the storage is
// type-erased (`*mut ()`) and the accessor functions are generic over `C`.
// In practice exactly one `C` (`JSBundleCompletionTask`) is ever used — see
// `get`'s safety contract — so the
// erased static is sound. T6 (`bun_bundler_jsc`) calls these with its concrete
// completion-task type.
pub mod singleton {
    use super::*;

    /// `Send` newtype around the leaked `BundleThread` allocation so it can be
    /// stored in a `Guarded`. Type-erased because Rust forbids generic
    /// statics; see module comment. Stored as a raw pointer (not `&'static`)
    /// because the bundle thread mutates `*self` concurrently — callers must
    /// only ever project fields via raw-pointer access.
    struct Instance(NonNull<()>);
    // SAFETY: the allocation is a leaked `Box<BundleThread<C>>` valid for
    // `'static`; cross-thread access is mediated entirely through
    // `UnboundedQueue` / `ResetEvent` atomics inside `BundleThread::enqueue`.
    unsafe impl Send for Instance {}

    static INSTANCE: bun_threading::Guarded<Option<Instance>> = bun_threading::Guarded::new(None);

    /// Returns the raw singleton pointer and starts the bundle thread on first
    /// use. If the thread fails to start, the next build tries again.
    /// The bundle thread runs `thread_main` against this allocation for the
    /// process lifetime, so callers MUST NOT materialize `&mut BundleThread` from it.
    /// Use `BundleThread::enqueue(get(), ...)` instead.
    ///
    /// # Safety
    /// All calls (across the process) must use the same `C`; the static is
    /// type-erased.
    pub(crate) fn get<C: CompletionStruct>() -> std::io::Result<*mut BundleThread<C>> {
        // The lock also blocks other callers until the thread is created.
        let mut instance = INSTANCE.lock();
        if let Some(instance) = &*instance {
            return Ok(instance.0.as_ptr().cast::<BundleThread<C>>());
        }

        let bundle_thread =
            bun_core::heap::into_raw_nn(Box::new(BundleThread::<C>::uninitialized()));
        // SAFETY: bundle_thread is a leaked Box, valid for 'static; `spawn` takes the
        // raw pointer directly so no `&mut` is materialized that would alias the
        // bundle thread's own access.
        if let Err(err) = unsafe { BundleThread::spawn(bundle_thread.as_ptr()) } {
            // SAFETY: no thread refers to the allocation after `Err`.
            unsafe { bun_core::heap::destroy(bundle_thread.as_ptr()) };
            return Err(err);
        }
        *instance = Some(Instance(bundle_thread.cast::<()>()));
        Ok(bundle_thread.as_ptr())
    }

    pub fn enqueue<C: CompletionStruct>(completion: *mut C) {
        // Validate the caller's pointer at the public boundary so the unsafe
        // path below never receives null.
        let completion = NonNull::new(completion).unwrap_or_else(|| {
            Output::panic(format_args!("BundleThread enqueue: null completion"))
        });
        let err = match get::<C>() {
            Ok(instance) => {
                // SAFETY: `get()` returns the leaked 'static singleton whose bundle thread is
                // running; `BundleThread::enqueue` only performs raw-ptr field projections.
                unsafe { BundleThread::enqueue(instance, completion.as_ptr()) };
                return;
            }
            Err(err) => err,
        };

        // SAFETY: the task is live and never reached the queue, so nothing else uses it.
        let completion = unsafe { &mut *completion.as_ptr() };
        // Mark the build as started so VM teardown lets the posted completion free it.
        let started = completion.try_start();
        debug_assert!(started);
        let mut log = bun_ast::Log::init();
        log.add_error_fmt(
            None,
            bun_ast::Loc::EMPTY,
            format_args!("Failed to start the bundler thread: {err}"),
        );
        completion.set_log(log);
        completion.set_result(BundleV2Result::Err(crate::Error::BuildFailed));
        completion.complete_on_bundle_thread();
    }
}
