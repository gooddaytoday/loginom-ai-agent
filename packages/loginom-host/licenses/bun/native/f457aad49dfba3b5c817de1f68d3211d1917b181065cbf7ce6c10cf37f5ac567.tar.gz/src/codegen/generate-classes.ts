// @ts-nocheck
import { existsSync, readFileSync } from "fs";
import { createRequire } from "module";
import path from "path";
import { inspect } from "util";
import jsclasses from "./../jsc/bindings/js_classes.ts";
import { type ClassDefinition, type Field } from "./class-definitions.ts";
import { writeIfNotChanged } from "./helpers.ts";

const require = createRequire(import.meta.url);
const files = process.argv.slice(2);
const typesDir = files.pop();
const outBase = files.pop();
let externs = "";
const CommonIdentifiers = {
  "name": true,
};
function toIdentifier(propertyName) {
  if (CommonIdentifiers[propertyName]) {
    return `vm.propertyNames->${propertyName}`;
  }

  return `Identifier::fromString(vm, ${JSON.stringify(propertyName)}_s)`;
}

function symbolName(typeName, name) {
  return `${typeName}__${name.replaceAll("@@", "")}`;
}

function protoSymbolName(typeName, name) {
  return `${typeName}Prototype__${name.replaceAll("@@", "")}`;
}

function classSymbolName(typeName, name) {
  return `${typeName}Class__${name.replaceAll("@@", "")}`;
}

function subspaceFor(typeName) {
  return `m_subspaceFor${typeName}`;
}

function clientSubspaceFor(typeName) {
  return `m_clientSubspaceFor${typeName}`;
}

function prototypeName(typeName) {
  return `JS${typeName}Prototype`;
}

function className(typeName) {
  return `JS${typeName}`;
}

function constructorName(typeName) {
  return `JS${typeName}Constructor`;
}

function zigExportName(to: Map<string, string>, symbolName: (name: string) => string, prop) {
  var { getter, setter, fn } = prop;
  const exportNames = {
    getter: "",
    setter: "",
    fn: "",
  };

  if (getter && !to.get(getter)) {
    to.set(getter, (exportNames.getter = symbolName(getter)));
  }

  if (setter && !to.get(setter)) {
    to.set(setter, (exportNames.setter = symbolName(setter)));
  }

  if (fn && !to.get(fn)) {
    to.set(fn, (exportNames.fn = symbolName(fn)));
  }

  return exportNames;
}
function propRow(
  symbolName: (a: string, b: string) => string,
  typeName: string,
  name: string,
  prop: Field,
  isWrapped = true,
  defaultPropertyAttributes,
  disableDom,
) {
  var {
    getter,
    setter,
    fn,
    length = 0,
    enumerable = true,
    configurable = false,
    builtin,
    writable = false,
  } = (defaultPropertyAttributes ? Object.assign({}, defaultPropertyAttributes, prop) : prop) as any;

  var extraPropertyAttributes = "";
  if (!enumerable) {
    extraPropertyAttributes += " | PropertyAttribute::DontEnum";
  }

  if (!configurable) {
    extraPropertyAttributes += " | PropertyAttribute::DontDelete";
  }

  var symbol = symbolName(typeName, name);

  if (isWrapped) {
    if (getter) {
      getter = symbol + "GetterWrap";
    }
    if (setter || writable) {
      setter = symbol + "SetterWrap";
    }
    if (fn) {
      fn = symbol + "Callback";
    }
  } else {
    if (getter) {
      getter = symbolName(typeName, getter);
    }
    if (setter || writable) {
      setter = symbolName(typeName, setter);
    }
    if (fn) {
      fn = symbolName(typeName, fn);
    }
  }

  if (builtin !== undefined) {
    if (typeof builtin !== "string") throw new Error('"builtin" should be string');
    return `
{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::Builtin), NoIntrinsic, { HashTableValue::BuiltinGeneratorType, ${builtin}, ${
      length || 0
    } } }
`.trim();
  } else if (fn !== undefined) {
    return `
{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::Function${extraPropertyAttributes}), NoIntrinsic, { HashTableValue::NativeFunctionType, ${fn}, ${
      length || 0
    } } }
`.trim();
  } else if (getter && setter) {
    return `

{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::CustomAccessor${disableDom ? "" : "| JSC::PropertyAttribute::DOMAttribute"}${extraPropertyAttributes}), NoIntrinsic, { HashTableValue::GetterSetterType, ${getter}, ${setter} } }
`.trim();
  } else if (getter && !writable) {
    return `{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::ReadOnly | JSC::PropertyAttribute::CustomAccessor${disableDom ? "" : "| JSC::PropertyAttribute::DOMAttribute"}${extraPropertyAttributes}), NoIntrinsic, { HashTableValue::GetterSetterType, ${getter}, 0 } }
`.trim();
  } else if (getter && writable) {
    return `{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::CustomAccessor${disableDom ? "" : "| JSC::PropertyAttribute::DOMAttribute"}${extraPropertyAttributes}), NoIntrinsic, { HashTableValue::GetterSetterType, ${getter}, ${setter} } }
`.trim();
  } else if (setter) {
    return `{ "${name}"_s, static_cast<unsigned>(JSC::PropertyAttribute::CustomAccessor${disableDom ? "" : "| JSC::PropertyAttribute::DOMAttribute"}${extraPropertyAttributes}), NoIntrinsic, { HashTableValue::GetterSetterType, 0, ${setter} } }
  `.trim();
  }

  throw "Unsupported property";
}

export function generateHashTable(nameToUse, symbolName, typeName, obj, props = {}, wrapped) {
  const rows = [];
  let defaultPropertyAttributes = undefined;

  if ("enumerable" in obj) {
    defaultPropertyAttributes ||= {};
    defaultPropertyAttributes.enumerable = obj.enumerable;
  }

  if ("configurable" in obj) {
    defaultPropertyAttributes ||= {};
    defaultPropertyAttributes.configurable = obj.configurable;
  }

  for (const name in props) {
    if ("privateSymbol" in props[name] || "internal" in props[name] || "value" in props[name]) continue;
    if (name.startsWith("@@")) continue;

    rows.push(propRow(symbolName, typeName, name, props[name], wrapped, defaultPropertyAttributes, !!obj.forBind));
  }

  if (rows.length === 0) {
    return "";
  }
  return `
  static const HashTableValue ${nameToUse}TableValues[${rows.length}] = {${"\n" + rows.join("  ,\n") + "\n"}};
`;
}

function generatePrototype(typeName, obj) {
  const proto = prototypeName(typeName);
  const { proto: protoFields } = obj;
  var specialSymbols = "";

  var staticPrototypeValues = "";

  if (obj.construct) {
    if (obj.constructNeedsThis) {
      externs += `
extern JSC_CALLCONV void* JSC_HOST_CALL_ATTRIBUTES ${classSymbolName(typeName, "construct")}(JSC::JSGlobalObject*, JSC::CallFrame*, JSC::EncodedJSValue);
JSC_DECLARE_CUSTOM_GETTER(js${typeName}Constructor);
`;
    } else {
      externs += `
extern JSC_CALLCONV void* JSC_HOST_CALL_ATTRIBUTES ${classSymbolName(typeName, "construct")}(JSC::JSGlobalObject*, JSC::CallFrame*);
JSC_DECLARE_CUSTOM_GETTER(js${typeName}Constructor);
`;
    }
  }

  if (obj.structuredClone) {
    externs +=
      `extern JSC_CALLCONV void JSC_HOST_CALL_ATTRIBUTES ${symbolName(
        typeName,
        "onStructuredCloneSerialize",
      )}(void*, JSC::JSGlobalObject*, WebCore::CloneSerializer*, SYSV_ABI void (*) (WebCore::CloneSerializer*, const uint8_t*, uint32_t));` +
      "\n";

    externs +=
      `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${symbolName(
        typeName,
        "onStructuredCloneDeserialize",
      )}(JSC::JSGlobalObject*, uint8_t**, const uint8_t*);` + "\n";
  }
  if (obj.finalize) {
    externs +=
      `extern JSC_CALLCONV void JSC_HOST_CALL_ATTRIBUTES ${classSymbolName(typeName, "finalize")}(void*);` + "\n";
  }

  if (obj.call) {
    externs += `extern JSC_CALLCONV JSC_DECLARE_HOST_FUNCTION(${classSymbolName(typeName, "call")}) SYSV_ABI;` + "\n";
  }

  for (const name in protoFields) {
    if ("value" in protoFields[name]) {
      const { value } = protoFields[name];
      staticPrototypeValues += `
      this->putDirect(vm, ${toIdentifier(name)}, jsString(vm, String(${JSON.stringify(
        value,
      )}_s)), PropertyAttribute::ReadOnly | 0);`;
    }

    if (protoFields[name].privateSymbol !== undefined) {
      const privateSymbol = protoFields[name].privateSymbol;
      const fn = protoFields[name].fn;
      if (!fn) throw Error(`(field: ${name}) private field needs 'fn' key `);
      const observable_name = protoFields[name].name ?? fn;

      specialSymbols += `
    this->putDirect(vm, WebCore::clientData(vm)->builtinNames().${privateSymbol}PrivateName(), JSFunction::create(vm, globalObject, ${
      protoFields[name].length || 0
    }, String("${observable_name}"_s), ${protoSymbolName(
      typeName,
      fn,
    )}Callback, ImplementationVisibility::Private), PropertyAttribute::ReadOnly | PropertyAttribute::DontEnum | 0);`;
      continue;
    }

    if (protoFields[name].publicSymbol !== undefined) {
      const publicSymbol = protoFields[name].publicSymbol;
      const fn = protoFields[name].fn;
      if (!fn) throw Error(`(field: ${name}) public field needs 'fn' key `);
      const observable_name = protoFields[name].name ?? fn;

      specialSymbols += `
    this->putDirect(vm, WebCore::clientData(vm)->builtinNames().${publicSymbol}PublicName(), JSFunction::create(vm, globalObject, ${
      protoFields[name].length || 0
    }, String("${observable_name}"_s), ${protoSymbolName(
      typeName,
      fn,
    )}Callback, ImplementationVisibility::Public), PropertyAttribute::Function | 0);`;
      continue;
    }

    if (!name.startsWith("@@")) {
      continue;
    }

    const symbol = name.slice(2);

    specialSymbols += `
    this->putDirect(vm, vm.propertyNames->${symbol}Symbol, JSFunction::create(vm, globalObject, 1, String("${symbol}"_s), ${protoSymbolName(
      typeName,
      symbol,
    )}Callback, ImplementationVisibility::Public), PropertyAttribute::ReadOnly | PropertyAttribute::DontEnum | 0);`;
  }

  return `
${renderDecls(protoSymbolName, typeName, protoFields)}
STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${proto}, ${proto}::Base);

${generateHashTable(
  prototypeName(typeName),
  protoSymbolName,
  typeName,
  obj,

  protoFields,
  true,
)}

const ClassInfo ${proto}::s_info = { "${typeName}"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${proto}) };

${renderFieldsImpl(protoSymbolName, typeName, obj, protoFields, obj.values || [])}

void ${proto}::finishCreation(JSC::VM& vm, JSC::JSGlobalObject* globalObject)
{
    Base::finishCreation(vm);
    ${
      Object.keys(protoFields).length > 0
        ? `Bun::reifyStaticPropertyTable(vm, ${className(typeName)}::info(), ${proto}TableValues, *this);`
        : ""
    }${specialSymbols}${staticPrototypeValues}
    Bun::putToStringTagWithoutTransition(vm, this, info());
}

`;
}

function generatePrototypeHeader(typename, final = true) {
  const proto = prototypeName(typename);

  return `
class ${proto} ${final ? "final" : ""} : public JSC::JSNonFinalObject {
  public:
      using Base = JSC::JSNonFinalObject;

      static ${proto}* create(JSC::VM& vm, JSGlobalObject* globalObject, JSC::Structure* structure)
      {
          ${proto}* ptr = new (NotNull, Bun::allocatePlainObjectCell(vm, sizeof(${proto}))) ${proto}(vm, globalObject, structure);
          ptr->finishCreation(vm, globalObject);
          return ptr;
      }

      DECLARE_INFO;
      template<typename CellType, JSC::SubspaceAccess>
      static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
      {
          STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${proto}, Base);
          return &vm.plainObjectSpace();
      }
      static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
      {
          return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::ObjectType, StructureFlags), info());
      }

  protected:
      ${proto}(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure)
          : Base(vm, structure)
      {
      }

      void finishCreation(JSC::VM&, JSC::JSGlobalObject*);
};
`;
}

function generateConstructorHeader(typeName) {
  const name = constructorName(typeName);

  // we use a single shared isosubspace for constructors since they will rarely
  // ever be created multiple times per VM and have no fields themselves
  return (
    `
class ${name} final : public JSC::InternalFunction {
  public:
      using Base = JSC::InternalFunction;
      static ${name}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, ${prototypeName(
        typeName,
      )}* prototype);

      static constexpr unsigned StructureFlags = Base::StructureFlags;
      static constexpr JSC::DestructionMode needsDestruction = DoesNotNeedDestruction;

      static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
      {
          return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::InternalFunctionType, StructureFlags), info());
      }

      template<typename, JSC::SubspaceAccess mode> static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
      {
        if constexpr (mode == JSC::SubspaceAccess::Concurrently)
          return nullptr;

        return WebCore::subspaceForImpl<${name}, WebCore::UseCustomHeapCellType::No>(
            vm, BUN_SUBSPACE_SLOTS(${clientSubspaceFor("BunClass")}Constructor, ${subspaceFor("BunClass")}Constructor));
      }

      // Must be defined for each specialization class.
      static JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES construct(JSC::JSGlobalObject*, JSC::CallFrame*);
      static JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES call(JSC::JSGlobalObject*, JSC::CallFrame*);

      DECLARE_EXPORT_INFO;
  protected:
      ${name}(JSC::VM& vm, JSC::Structure* structure);
      void finishCreation(JSC::VM&, JSC::JSGlobalObject* globalObject, ${prototypeName(typeName)}* prototype);
};

    `.trim() + "\n"
  );
}

function generateConstructorImpl(typeName, obj: ClassDefinition) {
  const name = constructorName(typeName);
  const { klass: fields } = obj;
  const hashTable =
    Object.keys(fields).length > 0 ? generateHashTable(name, classSymbolName, typeName, obj, fields, false) : "";

  const hashTableIdentifier = hashTable.length ? `${name}TableValues` : "";

  return (
    `
${renderStaticDecls(classSymbolName, typeName, fields)}
${hashTable}

void ${name}::finishCreation(VM& vm, JSC::JSGlobalObject* globalObject, ${prototypeName(typeName)}* prototype)
{
    Base::finishCreation(vm, 0, "${typeName}"_s, PropertyAdditionMode::WithoutStructureTransition);
    ${hashTableIdentifier.length ? `Bun::reifyStaticPropertyTable(vm, &${name}::s_info, ${hashTableIdentifier}, *this);` : ""}
    putDirectWithoutTransition(vm, vm.propertyNames->prototype, prototype, PropertyAttribute::DontEnum | PropertyAttribute::DontDelete | PropertyAttribute::ReadOnly);
    ASSERT(inherits(info()));
}

${name}::${name}(JSC::VM& vm, JSC::Structure* structure) : Base(vm, structure, ${
      obj.call ? classSymbolName(typeName, "call") : "call"
    }, construct) {

  }

${name}* ${name}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, ${prototypeName(
      typeName,
    )}* prototype) {
    ${name}* ptr = new (NotNull, JSC::allocateCell<${name}>(vm)) ${name}(vm, structure);
    ptr->finishCreation(vm, globalObject, prototype);
    return ptr;
}

JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${name}::call(JSC::JSGlobalObject* lexicalGlobalObject, JSC::CallFrame* callFrame)
{
    Zig::GlobalObject *globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    JSC::VM &vm = globalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);

${
  obj.call
    ? !obj.constructNeedsThis
      ? `
    void* ptr = ${classSymbolName(typeName, "construct")}(globalObject, callFrame);

    if (!ptr || scope.exception()) [[unlikely]] {
      return JSValue::encode(JSC::jsUndefined());
    }

    Structure* structure = globalObject->${className(typeName)}Structure();
    ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr);
`
      : `
    Structure* structure = globalObject->${className(typeName)}Structure();
    ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, nullptr);

    void* ptr = ${classSymbolName(typeName, "construct")}(globalObject, callFrame, JSValue::encode(instance));
    if (scope.exception()) [[unlikely]] {
      ASSERT_WITH_MESSAGE(!ptr, "Memory leak detected: new ${typeName}() allocated memory without checking for exceptions.");
      return JSValue::encode(JSC::jsUndefined());
    }

    instance->m_ctx = ptr;
`
    : `
    Bun::throwError(lexicalGlobalObject, scope, Bun::ErrorCode::ERR_ILLEGAL_CONSTRUCTOR, "${typeName} constructor cannot be invoked without 'new'"_s);
    return JSValue::encode(JSC::jsUndefined());
`
}

${
  obj.call
    ? `    RETURN_IF_EXCEPTION(scope, {});
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }

    RELEASE_AND_RETURN(scope, JSValue::encode(instance));`
    : ""
}
}

JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${name}::construct(JSC::JSGlobalObject* lexicalGlobalObject, JSC::CallFrame* callFrame)
{
    Zig::GlobalObject *globalObject = defaultGlobalObject(lexicalGlobalObject);
    JSC::VM &vm = globalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    JSObject* newTarget = asObject(callFrame->newTarget());
    auto* constructor = globalObject->${className(typeName)}Constructor();
    Structure* structure = globalObject->${className(typeName)}Structure();
    if (constructor != newTarget) [[unlikely]] {
      structure = structureForNewTarget(globalObject, newTarget, Zig::GlobalObject::GeneratedLazyClass${className(typeName)});
      RETURN_IF_EXCEPTION(scope, {});
    }

` +
    (!obj.constructNeedsThis
      ? `
    void* ptr = ${classSymbolName(typeName, "construct")}(globalObject, callFrame);

    if (scope.exception()) [[unlikely]] {
      ASSERT_WITH_MESSAGE(!ptr, "Memory leak detected: new ${typeName}() allocated memory without checking for exceptions.");
      return JSValue::encode(JSC::jsUndefined());
    }

    ASSERT_WITH_MESSAGE(ptr, "Incorrect exception handling: new ${typeName} returned a null pointer, indicating an exception - but did not throw an exception.");
    ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr);
`
      : `
    ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, nullptr);

    void* ptr = ${classSymbolName(typeName, "construct")}(globalObject, callFrame, JSValue::encode(instance));
    if (scope.exception()) [[unlikely]] {
      ASSERT_WITH_MESSAGE(!ptr, "Memory leak detected: new ${typeName}() allocated memory without checking for exceptions.");
      return JSValue::encode(JSC::jsUndefined());
    }

    instance->m_ctx = ptr;
    `) +
    `
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }

    auto value = JSValue::encode(instance);
    RELEASE_AND_RETURN(scope, value);
}

const ClassInfo ${name}::s_info = { "Function"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${name}) };

${
  !obj.noConstructor
    ? `
  extern JSC_CALLCONV JSC::EncodedJSValue ${typeName}__getConstructor(Zig::GlobalObject* globalObject) {
    return generatedClassConstructor(globalObject, Zig::GlobalObject::GeneratedLazyClass${className(typeName)});
  }`
    : ""
}

      `
  );
}

function renderCachedFieldsHeader(typeName, klass, proto, values) {
  const rows: string[] = [];
  for (const name in proto) {
    if (proto[name]?.cache === true || klass[name]?.internal) {
      rows.push(`mutable JSC::WriteBarrier<JSC::Unknown> m_${name};`);
    }
  }

  for (const name of values) {
    rows.push(`mutable JSC::WriteBarrier<JSC::Unknown> m_${name};`);
  }

  return rows.join("\n");
}

function renderDecls(symbolName, typeName, proto) {
  const rows = [];

  for (const name in proto) {
    if ("getter" in proto[name]) {
      externs +=
        `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${symbolName(
          typeName,
          proto[name].getter,
        )}(void* ptr,${
          !!proto[name].this ? " JSC::EncodedJSValue thisValue, " : ""
        } JSC::JSGlobalObject* lexicalGlobalObject);` + "\n";

      rows.push(
        `
    JSC_DECLARE_CUSTOM_GETTER(${symbolName(typeName, name)}GetterWrap);
    ${proto[name].writable ? `JSC_DECLARE_CUSTOM_SETTER(${symbolName(typeName, name)}SetterWrap);` : ""}
    `.trim(),
        "\n",
      );
    }

    if ("setter" in proto[name]) {
      externs +=
        `extern JSC_CALLCONV bool JSC_HOST_CALL_ATTRIBUTES ${symbolName(typeName, proto[name].setter)}(void* ptr,${
          !!proto[name].this ? " JSC::EncodedJSValue thisValue, " : ""
        } JSC::JSGlobalObject* lexicalGlobalObject, JSC::EncodedJSValue value);` + "\n";
      rows.push(
        `
      static JSC_DECLARE_CUSTOM_SETTER(${symbolName(typeName, name)}SetterWrap);
      `.trim(),
        "\n",
      );
    }

    if ("fn" in proto[name]) {
      externs +=
        `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${symbolName(
          typeName,
          proto[name].fn,
        )}(void* ptr, JSC::JSGlobalObject* lexicalGlobalObject, JSC::CallFrame* callFrame${proto[name].passThis ? ", JSC::EncodedJSValue thisValue" : ""});` +
        "\n";
      rows.push(
        `
        JSC_DECLARE_HOST_FUNCTION(${symbolName(typeName, name)}Callback);
        `.trim(),
        "\n",
      );
    }
  }

  return rows.map(a => a.trim()).join("\n");
}

function renderStaticDecls(symbolName, typeName, fields) {
  const rows = [];

  for (const name in fields) {
    if ("getter" in fields[name]) {
      externs += `extern JSC_CALLCONV JSC_DECLARE_CUSTOM_GETTER(${symbolName(typeName, fields[name].getter)});` + "\n";
    }

    if ("setter" in fields[name]) {
      externs += `extern JSC_CALLCONV JSC_DECLARE_CUSTOM_SETTER(${symbolName(typeName, fields[name].setter)});` + "\n";
    }

    if ("fn" in fields[name]) {
      externs +=
        `extern JSC_CALLCONV JSC_DECLARE_HOST_FUNCTION(${symbolName(typeName, fields[name].fn)}) SYSV_ABI;` + "\n";
    }
  }

  return rows.join("\n");
}

function writeBarrier(symbolName, typeName, name, cacheName) {
  return `

extern JSC_CALLCONV void ${symbolName(typeName, name)}SetCachedValue(JSC::EncodedJSValue thisValue, JSC::JSGlobalObject *globalObject, JSC::EncodedJSValue value)
{
    auto& vm = JSC::getVM(globalObject);
    auto* thisObject = uncheckedDowncast<${className(typeName)}>(JSValue::decode(thisValue));
    thisObject->${cacheName}.set(vm, thisObject, JSValue::decode(value));
}

extern JSC_CALLCONV JSC::EncodedJSValue ${symbolName(typeName, name)}GetCachedValue(JSC::EncodedJSValue thisValue)
{
  auto* thisObject = uncheckedDowncast<${className(typeName)}>(JSValue::decode(thisValue));
  return JSValue::encode(thisObject->${cacheName}.get());
}

  `.trim();
}

function renderFieldsImpl(
  symbolName: (typeName: string, name: string) => string,
  typeName: string,
  obj: ClassDefinition,
  proto: ClassDefinition["proto"],
  cachedValues: string[],
) {
  const rows: string[] = [];

  if (obj.construct) {
    rows.push(
      `

JSC_DEFINE_CUSTOM_GETTER(js${typeName}Constructor, (JSGlobalObject * lexicalGlobalObject, EncodedJSValue thisValue, PropertyName))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    auto throwScope = DECLARE_THROW_SCOPE(vm);
    auto* globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    auto* prototype = dynamicDowncast<${prototypeName(typeName)}>(JSValue::decode(thisValue));

    if (!prototype) [[unlikely]] {
        return throwVMTypeError(lexicalGlobalObject, throwScope, "Cannot get constructor for ${typeName}"_s);
    }
    return JSValue::encode(globalObject->${className(typeName)}Constructor());
}

`.trim(),
    );
  }

  for (const name in proto) {
    if ("cache" in proto[name] || proto[name]?.internal) {
      const cacheName = typeof proto[name].cache === "string" ? `m_${proto[name].cache}` : `m_${name}`;
      if ("cache" in proto[name]) {
        rows.push(
          `
JSC_DEFINE_CUSTOM_GETTER(${symbolName(typeName, name)}GetterWrap, (JSGlobalObject * lexicalGlobalObject, EncodedJSValue encodedThisValue, PropertyName attributeName))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    Zig::GlobalObject *globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    auto throwScope = DECLARE_THROW_SCOPE(vm);
    ${
      obj.forBind
        ? `
      JSC::JSBoundFunction* thisBoundFunction = dynamicDowncast<JSC::JSBoundFunction>(JSValue::decode(encodedThisValue));
      if (!thisBoundFunction) [[unlikely]] {
        return throwVMTypeError(lexicalGlobalObject, throwScope, "The ${typeName}.${name} getter can only be used on instances of ${typeName}"_s);
      }
      JSC::JSValue thisBoundFunctionThisValue = thisBoundFunction->boundThis();
      ${className(typeName)}* thisObject = dynamicDowncast<${className(typeName)}>(thisBoundFunctionThisValue);
      if (!thisObject) [[unlikely]] {
        return throwVMTypeError(lexicalGlobalObject, throwScope, "The ${typeName}.${name} getter can only be used on instances of ${typeName}"_s);
      }
    `
        : `${className(typeName)}* thisObject = uncheckedDowncast<${className(typeName)}>(JSValue::decode(encodedThisValue));`
    }
      JSC::EnsureStillAliveScope thisArg = JSC::EnsureStillAliveScope(thisObject);

    if (JSValue cachedValue = thisObject->${cacheName}.get())
        return JSValue::encode(cachedValue);

    JSC::JSValue result = JSC::JSValue::decode(
        ${symbolName(typeName, proto[name].getter)}(thisObject->wrapped(),${
          proto[name].this!! ? " encodedThisValue, " : ""
        } globalObject)
    );
    RETURN_IF_EXCEPTION(throwScope, {});
    thisObject->${cacheName}.set(vm, thisObject, result);
#if ASSERT_ENABLED
    if (!result.isEmpty() && result.isCell()) {
      JSC::Integrity::auditCellFully(vm, result.asCell());
    }
#endif
    RELEASE_AND_RETURN(throwScope, JSValue::encode(result));
}`.trim(),
        );
        if (proto[name].writable) {
          rows.push(
            `
JSC_DEFINE_CUSTOM_SETTER(${symbolName(typeName, name)}SetterWrap, (JSGlobalObject * lexicalGlobalObject, EncodedJSValue encodedThisValue, EncodedJSValue encodedValue, PropertyName attributeName))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    auto throwScope = DECLARE_THROW_SCOPE(vm);
    ${className(typeName)}* thisObject = dynamicDowncast<${className(typeName)}>(JSValue::decode(encodedThisValue));
    if (!thisObject) [[unlikely]] {
        throwDOMAttributeSetterTypeError(lexicalGlobalObject, throwScope, ${className(typeName)}::info(), attributeName);
        return false;
    }
    JSC::EnsureStillAliveScope thisArg = JSC::EnsureStillAliveScope(thisObject);
    thisObject->${cacheName}.set(vm, thisObject, JSValue::decode(encodedValue));
    RELEASE_AND_RETURN(throwScope, true);
}`.trim(),
          );
        }
      }
      rows.push(writeBarrier(symbolName, typeName, name, cacheName));
    } else if ("getter" in proto[name]) {
      rows.push(`
JSC_DEFINE_CUSTOM_GETTER(${symbolName(typeName, name)}GetterWrap, (JSGlobalObject * lexicalGlobalObject, EncodedJSValue encodedThisValue, PropertyName attributeName))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    Zig::GlobalObject *globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    auto throwScope = DECLARE_THROW_SCOPE(vm);
    ${className(typeName)}* thisObject = uncheckedDowncast<${className(typeName)}>(JSValue::decode(encodedThisValue));
    JSC::EnsureStillAliveScope thisArg = JSC::EnsureStillAliveScope(thisObject);
    JSC::EncodedJSValue result = ${symbolName(typeName, proto[name].getter)}(thisObject->wrapped(),${
      !!proto[name].this ? " encodedThisValue, " : ""
    } globalObject);
    RETURN_IF_EXCEPTION(throwScope, {});
#if ASSERT_ENABLED
    JSValue decodedValue = JSValue::decode(result);
    if (!decodedValue.isEmpty() && decodedValue.isCell()) {
      JSC::Integrity::auditCellFully(vm, decodedValue.asCell());
    }
#endif
    RELEASE_AND_RETURN(throwScope, result);
}
        `);
    }

    if ("setter" in proto[name]) {
      rows.push(
        `
JSC_DEFINE_CUSTOM_SETTER(${symbolName(typeName, name)}SetterWrap, (JSGlobalObject * lexicalGlobalObject, EncodedJSValue encodedThisValue, EncodedJSValue encodedValue, PropertyName attributeName))
{
    auto& vm = JSC::getVM(lexicalGlobalObject);
    auto throwScope = DECLARE_THROW_SCOPE(vm);
    ${className(typeName)}* thisObject = dynamicDowncast<${className(typeName)}>(JSValue::decode(encodedThisValue));
    if (!thisObject) [[unlikely]] {
        throwDOMAttributeSetterTypeError(lexicalGlobalObject, throwScope, ${className(typeName)}::info(), attributeName);
        return false;
    }
    JSC::EnsureStillAliveScope thisArg = JSC::EnsureStillAliveScope(thisObject);
    bool result = ${symbolName(typeName, proto[name].setter)}(thisObject->wrapped(),${
      !!proto[name].this ? " encodedThisValue, " : ""
    } lexicalGlobalObject, encodedValue);
    RELEASE_AND_RETURN(throwScope, result);
}
`,
      );
    }

    if ("fn" in proto[name]) {
      const fn = proto[name].fn;
      rows.push(`
JSC_DEFINE_HOST_FUNCTION(${symbolName(typeName, name)}Callback, (JSGlobalObject * lexicalGlobalObject, CallFrame* callFrame))
{
  auto& vm = JSC::getVM(lexicalGlobalObject);
  auto scope = DECLARE_THROW_SCOPE(vm);

  ${
    obj.forBind
      ? `
        JSC::JSBoundFunction* thisBoundFunction = dynamicDowncast<JSC::JSBoundFunction>(callFrame->thisValue());
        if (!thisBoundFunction) [[unlikely]] {
          RELEASE_AND_RETURN(scope, Bun::throwInvalidThisCallError(lexicalGlobalObject, callFrame, "${typeName}"_s));
        }
        JSC::JSValue thisBoundFunctionThisValue = thisBoundFunction->boundThis();
        ${className(typeName)}* thisObject = dynamicDowncast<${className(typeName)}>(thisBoundFunctionThisValue);
    `
      : `${className(typeName)}* thisObject = dynamicDowncast<${className(typeName)}>(callFrame->thisValue());`
  }

  if (!thisObject) [[unlikely]] {
    RELEASE_AND_RETURN(scope, Bun::throwInvalidThisCallError(lexicalGlobalObject, callFrame, "${typeName}"_s));
  }

  JSC::EnsureStillAliveScope thisArg = JSC::EnsureStillAliveScope(thisObject);

#if BUN_DEBUG
    /** View the file name of the JS file that called this function
     * from a debugger */
    SourceOrigin sourceOrigin = callFrame->callerSourceOrigin(vm);
    auto fileNameUTF8 = sourceOrigin.string().utf8();
    const char* fileName = fileNameUTF8.legacyCStringPointer();
    static const char* lastFileName = nullptr;
    if (lastFileName != fileName) {
      lastFileName = fileName;
    }

    JSC::EncodedJSValue result = ${symbolName(typeName, fn)}(thisObject->wrapped(), lexicalGlobalObject, callFrame${proto[name].passThis ? ", JSValue::encode(thisObject)" : ""});

    ASSERT_WITH_MESSAGE(!JSValue::decode(result).isEmpty() or DECLARE_TOP_EXCEPTION_SCOPE(vm).exception() != 0, \"${typeName}.${proto[name].fn} returned an empty value without an exception\");

#if ASSERT_ENABLED
    JSValue decodedValue = JSValue::decode(result);
    if (!decodedValue.isEmpty() && decodedValue.isCell()) {
      JSC::Integrity::auditCellFully(vm, decodedValue.asCell());
    }
#endif

    return result;
#endif

  return ${symbolName(typeName, proto[name].fn)}(thisObject->wrapped(), lexicalGlobalObject, callFrame${proto[name].passThis ? ", JSValue::encode(thisObject)" : ""});
}

    `);
    }
  }

  if (cachedValues?.length) {
    for (const cacheName of cachedValues) {
      rows.push(writeBarrier(symbolName, typeName, cacheName, "m_" + cacheName));
    }
  }

  return rows.map(a => a.trim()).join("\n");
}

function allCachedValues(obj: ClassDefinition) {
  let values = (obj.values ?? []).slice().map(name => [name, `m_${name}`]);
  for (const name in obj.proto) {
    let cacheName = obj.proto[name].cache;
    if (cacheName === true) {
      cacheName = "m_" + name;
    } else if (cacheName) {
      cacheName = `m_${cacheName}`;
    }

    if (cacheName) {
      values.push([name, cacheName]);
    }
  }

  return values;
}

function generateClassHeader(typeName, obj: ClassDefinition) {
  var { klass, proto, JSType = "ObjectType", values = [] } = obj;

  const name = className(typeName);

  if (obj.estimatedSize) {
    externs += `extern JSC_CALLCONV size_t ${symbolName(typeName, "estimatedSize")}(void* ptr);` + "\n";
  }

  for (const a of [...Object.values(klass), ...Object.values(proto)]) {
    if (a.internal === true) {
      throw new Error(
        `${typeName}: 'internal: true' on a property is not implemented (no users today; the visitChildren plumbing for it was never wired up consistently). Use 'cache: true' or add it to 'values' instead.`,
      );
    }
  }
  const DECLARE_VISIT_CHILDREN =
    values.length || obj.estimatedSize || obj.valuesArray || Object.values(proto).find(a => a.cache === true)
      ? "DECLARE_VISIT_CHILDREN;\n"
      : "";

  var weakOwner = "";
  var weakInit = ``;
  if (obj.hasPendingActivity) {
    weakInit = `m_weakThis = JSC::Weak<${name}>(this, getOwner());`;
    weakOwner = `
    JSC::Weak<${name}> m_weakThis;

    static bool hasPendingActivity(void* ctx);

    class Owner final : public JSC::WeakHandleOwner {
      public:
          bool isReachableFromOpaqueRoots(JSC::Handle<JSC::Unknown> handle, void*, JSC::AbstractSlotVisitor&, ASCIILiteral* reason) final
          {
              auto* controller = uncheckedDowncast<${name}>(handle.slot()->asCell());
              // m_ctx is null between wrapper creation and constructor return
              // when constructNeedsThis is set; GC during that window must not
              // call into the Zig hasPendingActivity with nullptr.
              if (controller->wrapped() && ${name}::hasPendingActivity(controller->wrapped())) {
                  if (reason) [[unlikely]] {
                    *reason = "has pending activity"_s;
                  }
                  return true;
              }

              return false;
          }
          void finalize(JSC::Handle<JSC::Unknown>, void* context) final {}
      };

      static JSC::WeakHandleOwner* getOwner()
      {
          static NeverDestroyed<Owner> m_owner;
          return &m_owner.get();
      }
      `;
  }
  const final = obj.final ?? true;

  return `
  class ${name}${final ? " final" : ""} : public JSC::JSDestructibleObject {
    public:
        using Base = JSC::JSDestructibleObject;
        static constexpr unsigned StructureFlags = Base::StructureFlags;
        static ${name}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx);
        ${obj.valuesArray ? `static ${name}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx, WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray);` : ""}
        ${obj.valuesArray && obj.values && obj.values.length > 0 ? `static ${name}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx${obj.values.map(v => `, JSC::JSValue ${v}`).join("")});` : ""}
        ${obj.valuesArray && obj.values && obj.values.length > 0 ? `static ${name}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx, WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray${obj.values.map(v => `, JSC::JSValue ${v}`).join("")});` : ""}

        DECLARE_EXPORT_INFO;
        template<typename, JSC::SubspaceAccess mode> static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
        {
            if constexpr (mode == JSC::SubspaceAccess::Concurrently)
                return nullptr;
            return WebCore::subspaceForImpl<${name}, WebCore::UseCustomHeapCellType::No>(
                vm, BUN_SUBSPACE_SLOTS(${clientSubspaceFor(typeName)}, ${subspaceFor(typeName)}));
        }

        static void destroy(JSC::JSCell*);
        static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
        {
            return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(static_cast<JSC::JSType>(${JSType}), StructureFlags), info());
        }

        static JSObject* createPrototype(VM& vm, JSDOMGlobalObject* globalObject);
        ${
          obj.noConstructor
            ? ""
            : `static JSObject* createConstructor(VM& vm, JSGlobalObject* globalObject, JSValue prototype)`
        };

        ~${name}();

        void* wrapped() const { return m_ctx; }

        void detach()
        {
            m_ctx = nullptr;
        }

        ${
          obj.valuesArray
            ? `const WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>& values() const { return jsvalueArray; }
        `
            : ""
        }

        static void analyzeHeap(JSCell*, JSC::HeapAnalyzer&);
        // constexpr: the extern "C" <Type>__ptrOffset constants initialized from
        // this are then constant-initialized in every build mode (no static
        // initializer at -O0; the link-time initializer audit relies on it).
        static constexpr ptrdiff_t offsetOfWrapped() { return OBJECT_OFFSETOF(${name}, m_ctx); }

        /**
         * Estimated size of the object from Zig including the JS wrapper.
         */
        static size_t estimatedSize(JSC::JSCell* cell, JSC::VM& vm);

        /**
         * Memory cost of the object from Zig, without necessarily having a JS wrapper alive.
         */
        static size_t memoryCost(void* ptr);

        void* m_ctx { nullptr };

        ${name}(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr${obj.valuesArray ? ", WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray_" : ""})
            : Base(vm, structure)${obj.valuesArray ? ", jsvalueArray(WTF::move(jsvalueArray_))" : ""}
        {
            m_ctx = sinkPtr;
            ${weakInit.trim()}
        }

        ${
          obj.valuesArray && obj.values && obj.values.length > 0
            ? `${name}(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr${obj.values.map(v => `, JSC::JSValue ${v}`).join("")})
            : Base(vm, structure)${obj.values.map(v => `\n            , m_${v}(${v}, JSC::WriteBarrierEarlyInit)`).join("")}
        {
            m_ctx = sinkPtr;
            ${weakInit.trim()}
        }`
            : ""
        }

        ${
          obj.valuesArray && obj.values && obj.values.length > 0
            ? `${name}(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr, WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray_${obj.values.map(v => `, JSC::JSValue ${v}`).join("")})
            : Base(vm, structure), jsvalueArray(WTF::move(jsvalueArray_))${obj.values.map(v => `\n            , m_${v}(${v}, JSC::WriteBarrierEarlyInit)`).join("")}
        {
            m_ctx = sinkPtr;
            ${weakInit.trim()}
        }`
            : ""
        }

        void finishCreation(JSC::VM&);

        

        ${weakOwner}

        ${DECLARE_VISIT_CHILDREN}

        ${renderCachedFieldsHeader(typeName, klass, proto, values)}
        
        ${obj.valuesArray ? "WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>> jsvalueArray;" : ""}
    };
  `.trim();
}

/** The (heap-analyzer property name, backing member) rows analyzeHeap reports. */
function cachedFieldTable(obj: ClassDefinition): { member: string; name: string }[] {
  return allCachedValues(obj).map(([name, cacheName]) => ({ member: cacheName, name }));
}

function generateClassImpl(typeName, obj: ClassDefinition) {
  const { klass: fields, finalize, proto, construct, estimatedSize, hasPendingActivity = false } = obj;
  const name = className(typeName);
  const cachedFields = cachedFieldTable(obj);
  // Below this the per-field inline expansion is no bigger than the table.
  const useCachedFieldTable = cachedFields.length >= 2;
  const cachedFieldTableName = `${name}CachedFields`;
  const CACHED_FIELD_TABLE = useCachedFieldTable
    ? `static constexpr GeneratedCachedField ${cachedFieldTableName}[] = {
${cachedFields.map(({ member, name: n }) => `    { OBJECT_OFFSETOF(${name}, ${member}), ${JSON.stringify(n)} },`).join("\n")}
};
`
    : "";

  // analyzeHeap reports these as named property edges (see allCachedValues); appendHidden
  // marks for GC without emitting a duplicate anonymous internal edge.
  const DEFINE_VISIT_CHILDREN_LIST = Object.entries(proto)
    .filter(([name, { cache = false }]) => cache === true)
    .map(([name]) => `visitor.appendHidden(thisObject->m_${name});`)
    .join("\n");

  const values = (obj.values || [])
    .map(val => {
      return `visitor.appendHidden(thisObject->m_${val});`;
    })
    .join("\n");
  var DEFINE_VISIT_CHILDREN = "";
  // Generated classes intentionally do NOT override visitOutputConstraints (and therefore
  // do not get enrolled in BunGCOutputConstraint / m_outputConstraintSpaces).
  //
  // visitOutputConstraints exists so JSC's incremental GC can re-scan an already-black cell
  // after the mutator runs, to pick up new outgoing edges that were added without firing a
  // write barrier. WebCore needs this because edges like EventTarget's listener list or
  // AbortSignal's algorithm vector live inside the wrapped RefCounted C++ object, not in
  // WriteBarrier<> fields on the JSCell, so addEventListener() etc. can add an edge from a
  // black wrapper to a white callback with no barrier firing.
  //
  // Generated classes don't have that problem. Every GC-visible edge below is either:
  //   - a WriteBarrier<Unknown> field on the JSCell, mutated only via .set(vm, thisObject, v)
  //     (see *SetCachedValue / cached getter paths), which calls vm.writeBarrier(thisObject, v)
  //     and re-greys thisObject if it was already marked (Heap::addToRememberedSet pushes it
  //     back onto m_mutatorMarkStack so visitChildren runs again), or
  //   - jsvalueArray, a FixedVector<WriteBarrier<>> populated before allocateCell() and never
  //     resized.
  //
  // In all cases the write barrier (or immutability) guarantees correctness, so re-walking
  // every live instance of every generated type after each mutator yield is pure overhead.
  // Only visitChildren is needed.
  //
  // hasPendingActivity does not need visitChildren at all: liveness is decided by the
  // WeakHandleOwner calling hasPendingActivity(wrapped()) directly during weak processing.
  // The previous addOpaqueRoot(wrapped()) had no consumer (the Weak's context was nullptr,
  // so containsOpaqueRoot(context) always checked for nullptr, never m_ctx).
  if (DEFINE_VISIT_CHILDREN_LIST.length || estimatedSize || values.length || obj.valuesArray) {
    DEFINE_VISIT_CHILDREN = `
template<typename Visitor>
void ${name}::visitChildrenImpl(JSCell* cell, Visitor& visitor)
{
    ${name}* thisObject = uncheckedDowncast<${name}>(cell);
    ASSERT_GC_OBJECT_INHERITS(thisObject, info());
    Base::visitChildren(thisObject, visitor);
    ${
      estimatedSize
        ? `if (auto* ptr = thisObject->wrapped()) {
            auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
visitor.reportExtraMemoryVisited(size);
}`
        : ""
    }
    ${values}
    ${DEFINE_VISIT_CHILDREN_LIST}
    ${obj.valuesArray ? "for (auto& value : thisObject->jsvalueArray) { visitor.append(value); }" : ""}
}

DEFINE_VISIT_CHILDREN(${name});

        `.trim();
  }

  var output = CACHED_FIELD_TABLE;

  if (hasPendingActivity) {
    externs +=
      `extern JSC_CALLCONV bool JSC_HOST_CALL_ATTRIBUTES ${symbolName(typeName, "hasPendingActivity")}(void* ptr);` +
      "\n";
    output += `
    bool ${name}::hasPendingActivity(void* ctx) {
        return ${symbolName(typeName, "hasPendingActivity")}(ctx);
    }
`;
  }

  if (finalize) {
    output += `
${name}::~${name}()
{
    if (m_ctx) [[likely]] {
        ${classSymbolName(typeName, "finalize")}(m_ctx);
    }
}
`;
  } else {
    output += `
${name}::~${name}()
{
}
`;
  }

  if (!obj.estimatedSize && !obj.memoryCost) {
    externs += `extern "C" const size_t ${symbolName(typeName, "ZigStructSize")};`;
  } else if (obj.memoryCost) {
    externs += `extern JSC_CALLCONV size_t ${symbolName(typeName, "memoryCost")}(void* ptr);`;
  }

  if (obj.memoryCost) {
    output += `
size_t ${name}::memoryCost(void* ptr) {
  return ptr ? ${symbolName(typeName, "memoryCost")}(ptr) : 0;
}
`;
  } else if (obj.estimatedSize) {
    output += `
size_t ${name}::memoryCost(void* ptr) {
  return ptr ? ${symbolName(typeName, "estimatedSize")}(ptr) : 0;
}
  `;
  } else {
    output += `
size_t ${name}::memoryCost(void* ptr) {
  return ptr ? ${symbolName(typeName, "ZigStructSize")} : 0;
}
  `;
  }

  output += `

size_t ${name}::estimatedSize(JSC::JSCell* cell, JSC::VM& vm) {
  auto* thisObject = uncheckedDowncast<${name}>(cell);
  auto* wrapped = thisObject->wrapped();
  return Base::estimatedSize(cell, vm) + ${name}::memoryCost(wrapped);
}

void ${name}::destroy(JSCell* cell)
{
    static_cast<${name}*>(cell)->${name}::~${name}();
}

const ClassInfo ${name}::s_info = { "${typeName}"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${name}) };

void ${name}::finishCreation(VM& vm)
{
    Base::finishCreation(vm);
    ASSERT(inherits(info()));
}

${name}* ${name}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx) {
  ${name}* ptr = new (NotNull, JSC::allocateCell<${name}>(vm)) ${name}(vm, structure, ctx${obj.valuesArray ? ", WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>()" : ""});
  ptr->finishCreation(vm);
  return ptr;
}

${
  obj.valuesArray
    ? `${name}* ${name}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx, WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray) {
  ${name}* ptr = new (NotNull, JSC::allocateCell<${name}>(vm)) ${name}(vm, structure, ctx, WTF::move(jsvalueArray));
  ptr->finishCreation(vm);
  return ptr;
}`
    : ""
}

${
  obj.valuesArray && obj.values && obj.values.length > 0
    ? `${name}* ${name}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx${obj.values.map(v => `, JSC::JSValue ${v}`).join("")}) {
  ${name}* ptr = new (NotNull, JSC::allocateCell<${name}>(vm)) ${name}(vm, structure, ctx${obj.values.map(v => `, ${v}`).join("")});
  ptr->finishCreation(vm);
  return ptr;
}`
    : ""
}

${
  obj.valuesArray && obj.values && obj.values.length > 0
    ? `${name}* ${name}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* ctx, WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>>&& jsvalueArray${obj.values.map(v => `, JSC::JSValue ${v}`).join("")}) {
  ${name}* ptr = new (NotNull, JSC::allocateCell<${name}>(vm)) ${name}(vm, structure, ctx, WTF::move(jsvalueArray)${obj.values.map(v => `, ${v}`).join("")});
  ptr->finishCreation(vm);
  return ptr;
}`
    : ""
}

extern JSC_CALLCONV void* JSC_HOST_CALL_ATTRIBUTES ${typeName}__fromJS(JSC::EncodedJSValue value)  {
  JSC::JSValue decodedValue = JSC::JSValue::decode(value);
  if (decodedValue.isEmpty() || !decodedValue.isCell())
      return nullptr;

  JSC::JSCell* cell = decodedValue.asCell();
  ${className(typeName)}* object = dynamicDowncast<${className(typeName)}>(cell);

  if (!object)
      return nullptr;

  return object->wrapped();
}

extern JSC_CALLCONV void* JSC_HOST_CALL_ATTRIBUTES ${typeName}__fromJSDirect(JSC::EncodedJSValue value) {
  JSC::JSValue decodedValue = JSC::JSValue::decode(value);
  ASSERT(decodedValue.isCell());

  JSC::JSCell* cell = decodedValue.asCell();
  ${className(typeName)}* object = dynamicDowncast<${className(typeName)}>(cell);

  if (!object)
      return nullptr;

  Zig::GlobalObject* globalObject = dynamicDowncast<Zig::GlobalObject>(object->globalObject());

  if (globalObject == nullptr || cell->structureID() != globalObject->${className(typeName)}Structure()->id()) [[unlikely]] {
    return nullptr;
  }

  return object->wrapped();
}

extern JSC_CALLCONV bool JSC_HOST_CALL_ATTRIBUTES ${typeName}__dangerouslySetPtr(JSC::EncodedJSValue value, void* ptr) {
  ${className(typeName)}* object = dynamicDowncast<${className(typeName)}>(JSValue::decode(value));
  if (!object)
      return false;

  object->m_ctx = ptr;
  return true;
}

extern "C" const size_t ${typeName}__ptrOffset = ${className(typeName)}::offsetOfWrapped();

void ${name}::analyzeHeap(JSCell* cell, HeapAnalyzer& analyzer)
{
    auto* thisObject = uncheckedDowncast<${name}>(cell);
    if (void* wrapped = thisObject->wrapped()) {
        analyzer.setWrappedObjectForCell(cell, wrapped);
    }

    Base::analyzeHeap(cell, analyzer);
    ${
      useCachedFieldTable
        ? `analyzeGeneratedCachedFields(cell, analyzer, ${cachedFieldTableName});`
        : `${allCachedValues(obj).length > 0 ? `auto& vm = thisObject->vm();` : ""}

    ${allCachedValues(obj)
      .map(
        ([name, cacheName]) => `
if (JSValue ${cacheName}Value = thisObject->${cacheName}.get()) {
  if (${cacheName}Value.isCell()) {
    const Identifier& id = Identifier::fromString(vm, "${name}"_s);
    analyzer.analyzePropertyNameEdge(cell, ${cacheName}Value.asCell(), id.impl());
  }
}`,
      )
      .join("\n  ")}`
    }
}

${
  !obj.noConstructor
    ? `JSObject* ${name}::createConstructor(VM& vm, JSGlobalObject* globalObject, JSValue prototype)
{
  return WebCore::${constructorName(typeName)}::create(vm, globalObject, WebCore::${constructorName(
    typeName,
  )}::createStructure(vm, globalObject, globalObject->functionPrototype()), uncheckedDowncast<WebCore::${prototypeName(typeName)}>(prototype));
}`
    : ""
}

JSObject* ${name}::createPrototype(VM& vm, JSDOMGlobalObject* globalObject)
{
    auto *structure = ${prototypeName(typeName)}::createStructure(vm, globalObject, ${
      obj.forBind
        ? "globalObject->functionPrototype()"
        : obj.prototypeBase === "Error"
          ? "globalObject->errorPrototype()"
          : "globalObject->objectPrototype()"
    });
    structure->setMayBePrototype(true);
    return ${prototypeName(typeName)}::create(vm, globalObject, structure);
}

extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${typeName}__create(Zig::GlobalObject* globalObject, void* ptr) {
  auto &vm = globalObject->vm();
  JSC::Structure* structure = globalObject->${className(typeName)}Structure();
  ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr);
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }
  return JSValue::encode(instance);
}

${
  obj.valuesArray
    ? `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${typeName}__createWithValues(Zig::GlobalObject* globalObject, void* ptr, void* markedArgumentBuffer) {
  auto &vm = globalObject->vm();
  JSC::Structure* structure = globalObject->${className(typeName)}Structure();
  auto* args = static_cast<JSC::MarkedArgumentBuffer*>(markedArgumentBuffer);
  WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>> jsvalueArray(args->size());
  for (size_t i = 0; i < args->size(); ++i) {
    jsvalueArray[i].setWithoutWriteBarrier(args->at(i));
  }
  ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr, WTF::move(jsvalueArray));
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }
  return JSValue::encode(instance);
}`
    : ""
}

${
  obj.valuesArray && obj.values && obj.values.length > 0
    ? `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${typeName}__createWithInitialValues(Zig::GlobalObject* globalObject, void* ptr${obj.values.map(v => `, JSC::EncodedJSValue ${v}`).join("")}) {
  auto &vm = globalObject->vm();
  JSC::Structure* structure = globalObject->${className(typeName)}Structure();
  ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr${obj.values.map(v => `, JSC::JSValue::decode(${v})`).join("")});
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }
  return JSValue::encode(instance);
}`
    : ""
}

${
  obj.valuesArray && obj.values && obj.values.length > 0
    ? `extern JSC_CALLCONV JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${typeName}__createWithValuesAndInitialValues(Zig::GlobalObject* globalObject, void* ptr, void* markedArgumentBuffer${obj.values.map(v => `, JSC::EncodedJSValue ${v}`).join("")}) {
  auto &vm = globalObject->vm();
  JSC::Structure* structure = globalObject->${className(typeName)}Structure();
  auto* args = static_cast<JSC::MarkedArgumentBuffer*>(markedArgumentBuffer);
  WTF::FixedVector<JSC::WriteBarrier<JSC::Unknown>> jsvalueArray(args->size());
  for (size_t i = 0; i < args->size(); ++i) {
    jsvalueArray[i].setWithoutWriteBarrier(args->at(i));
  }
  ${className(typeName)}* instance = ${className(typeName)}::create(vm, globalObject, structure, ptr, WTF::move(jsvalueArray)${obj.values.map(v => `, JSC::JSValue::decode(${v})`).join("")});
  ${
    obj.estimatedSize
      ? `
      auto size = ${symbolName(typeName, "estimatedSize")}(ptr);
      vm.heap.reportExtraMemoryAllocated(instance, size);`
      : ""
  }
  return JSValue::encode(instance);
}`
    : ""
}

${DEFINE_VISIT_CHILDREN}

    `.trim();

  return output;
}

function generateHeader(typeName, obj) {
  const fields = [
    generateClassHeader(typeName, obj).trim() + "\n\n",
    !(obj.final ?? true) ? generatePrototypeHeader(typeName, false) : null,
  ].filter(Boolean);

  return "\n" + fields.join("\n").trim();
}

function generateImpl(typeName, obj: ClassDefinition) {
  const proto = obj.proto;
  return [
    (obj.final ?? true) ? generatePrototypeHeader(typeName, true) : null,
    !obj.noConstructor ? generateConstructorHeader(typeName).trim() + "\n" : null,
    generatePrototype(typeName, obj).trim(),
    !obj.noConstructor ? generateConstructorImpl(typeName, obj).trim() : null,
    generateClassImpl(typeName, obj).trim(),
  ]
    .filter(Boolean)
    .join("\n\n");
}

// ──────────────────────────────────────────────────────────────────────────
// Rust emitter.
//
// Emits, per class, a block of \`#[unsafe(no_mangle)]
// pub extern "C" fn\` thunks whose unmangled names and signatures are
// byte-identical to the externs the C++ side declares (renderDecls /
// renderStaticDecls / generateConstructorImpl). The C++ output is invariant;
// only the implementer of the symbols changes.
//
// Exception protocol: every JSValue-returning thunk routes through
// \`bun_jsc::host_fn::host_fn_result(global, || …)\` which maps
// \`JsResult<JSValue>\` → \`.zero\` on Err and asserts the
// \`(ret == 0) == hasException()\` biconditional in debug builds.
// ──────────────────────────────────────────────────────────────────────────

/** camelCase / PascalCase → snake_case, then escape Rust reserved words. */
function rustSnakeIdent(name: string): string {
  // getURLSchemeV2 → get_url_scheme_v2; HTTPServer → http_server; crc32 → crc32
  const snake = name
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/([A-Z]+)([A-Z][a-z])/g, "$1_$2")
    .replace(/[.\-]/g, "_")
    .toLowerCase();
  return rustIdent(snake);
}

// ── Rust module-path resolver ────────────────────────────────────────────────
// Walks the `pub mod` tree rooted at `src/runtime/lib.rs` (the `bun_runtime`
// crate), honouring `#[path = "…"]` attributes, to build a map of public type
// name → shortest `crate::…` path at which that name is visible. Indexes both
// `pub struct`/`pub type` definitions *and* `pub use …::Name` re-exports so a
// type defined in a private `_body` module but re-exported one level up is
// addressed by its public path (e.g. `crate::ffi::FFI`, not
// `crate::ffi::ffi_body::FFI`). A missing struct (or method) on the resolved
// path is a compile error in `cargo check` — that's the point: surface
// unported surface area at build time, not as a runtime `unimplemented!()`.
//
// Classes whose JS name doesn't match any Rust type name (e.g. `Immediate` →
// `ImmediateObject`, the `*InternalReadableStreamSource` family → three
// distinct `Source` structs) MUST set `rustPath` explicitly in their
// `.classes.ts` definition; this resolver is name-based and can't infer those.
const rustModuleResolver = (() => {
  const runtimeRoot = path.resolve(import.meta.dirname, "../runtime");
  const fileToMod = new Map<string, string>(); // abs .rs path → crate::a::b
  const structToPath = new Map<string, string>(); // StructName → crate::a::b::StructName (shortest)
  // `(?:#[path = "…"]\s*)? (?:#[...]\s*)* pub mod NAME ;` — pub-only: a private
  // `mod foo_body;` makes `crate::…::foo_body::T` unnameable from generated
  // code, so don't descend into it.
  const modRe = /(?:#\[path\s*=\s*"([^"]+)"\]\s*)?(?:#\[[^\]]*\]\s*)*pub(?:\([^)]*\))?\s+mod\s+(\w+)\s*;/g;
  // Index both `pub struct Name` and `pub type Name = …` — several JS classes
  // (HTTPServer/HTTPSServer/…) are generic instantiations exposed as
  // type aliases; the thunks call `Name::method` either way.
  const structRe = /\bpub(?:\([^)]*\))?\s+(?:struct|type)\s+([A-Z]\w*)\b/g;
  // `pub use a::b::{Name, Name as Alias};` — only the *exported* identifier is
  // indexed, at the current module path.
  const pubUseRe = /\bpub(?:\([^)]*\))?\s+use\s+((?:\w+::)*)\{?([^;{}]+?)\}?\s*;/g;

  const segs = (p: string) => p.split("::").length;
  function register(name: string, fullPath: string) {
    const cur = structToPath.get(name);
    if (!cur || segs(fullPath) < segs(cur)) structToPath.set(name, fullPath);
  }

  // Inline-module depth at byte index `i`. Only `mod foo { … }` bodies change
  // the addressable path of nested items; macro invocations like
  // `cfg_if! { pub mod foo; }` emit at the *parent* scope and must stay
  // transparent. So count only `{` braces immediately preceded by
  // `mod <ident>`, and their matching `}`. Items at modDepth 0 are addressable
  // at this file's `modPath`; deeper ones are not.
  function modDepthTable(src: string): Int32Array {
    const depth = new Int32Array(src.length + 1);
    const stack: boolean[] = []; // true = this `{` opened an inline `mod`
    let d = 0;
    for (let j = 0; j < src.length; j++) {
      depth[j] = d;
      const c = src.charCodeAt(j);
      if (c === 123 /* { */) {
        const isMod = /\bmod\s+\w+\s*$/.test(src.slice(Math.max(0, j - 64), j));
        stack.push(isMod);
        if (isMod) d++;
      } else if (c === 125 /* } */) {
        if (stack.pop()) d--;
      }
    }
    depth[src.length] = d;
    return depth;
  }

  function walk(file: string, modPath: string) {
    const abs = path.resolve(file);
    if (fileToMod.has(abs)) return;
    let src: string;
    try {
      src = readFileSync(abs, "utf8");
    } catch {
      return;
    }
    // Blank out `//` line comments so commented-out items and brace characters
    // in doc text don't pollute regex matches / depth tracking. Preserve
    // length so `m.index` ↔ depth lookup stays aligned.
    src = src.replace(/\/\/[^\n]*/g, m => " ".repeat(m.length));
    fileToMod.set(abs, modPath);
    const modDepth = modDepthTable(src);

    for (const m of src.matchAll(structRe)) {
      if (modDepth[m.index!] !== 0) continue;
      register(m[1], `${modPath}::${m[1]}`);
    }

    for (const m of src.matchAll(pubUseRe)) {
      if (modDepth[m.index!] !== 0) continue;
      for (let item of m[2].split(",")) {
        item = item.trim();
        if (!item || item === "*" || item === "self") continue;
        // `Name as Alias` → exported = Alias, source = Name
        // `Name`          → exported = source = Name
        const asMatch = item.match(/^(\S+)\s+as\s+(\w+)$/);
        const source = asMatch ? asMatch[1] : item;
        const exported = asMatch ? asMatch[2] : item;
        // A module re-export (lowercase source leaf) does not name a type.
        const sourceLeaf = source.split("::").pop()!;
        if (!/^[A-Z]/.test(sourceLeaf)) continue;
        if (!/^[A-Z]\w*$/.test(exported)) continue;
        register(exported, `${modPath}::${exported}`);
      }
    }

    const dir = path.dirname(abs);
    for (const m of src.matchAll(modRe)) {
      if (modDepth[m.index!] !== 0) continue;
      const [, pathAttr, modName] = m;
      let child: string | null = null;
      if (pathAttr) {
        child = path.resolve(dir, pathAttr);
      } else {
        const f1 = path.resolve(dir, `${modName}.rs`);
        const f2 = path.resolve(dir, modName, "mod.rs");
        child = existsSync(f1) ? f1 : existsSync(f2) ? f2 : null;
      }
      if (child) walk(child, `${modPath}::${modName}`);
    }
  }

  walk(path.join(runtimeRoot, "lib.rs"), "crate");

  return {
    /** Resolve a class name to its `crate::…::Name` path, or a derived guess. */
    resolveStruct(name: string, classesFile?: string): string {
      if (structToPath.has(name)) return structToPath.get(name)!;
      // Fallback: derive from the .classes.ts location → sibling .rs module.
      // src/runtime/webcore/response.classes.ts → crate::webcore::response::Name
      if (classesFile) {
        const rel = path.relative(runtimeRoot, classesFile).replace(/\.classes\.ts$/, "");
        if (!rel.startsWith("..")) {
          const mod = rel
            .split(path.sep)
            .map(seg => rustSnakeIdent(seg))
            .join("::");
          return `crate::${mod}::${name}`;
        }
      }
      // Out-of-crate (e.g. src/jsc/*.classes.ts → bun_jsc) — `api.rs` already
      // `pub use bun_jsc::{BuildMessage, ResolveMessage};` so route there.
      return `crate::api::${name}`;
    },
    /** Resolve an absolute `.rs` file path to its `crate::…` module path. */
    resolveFile(absRs: string): string | null {
      return fileToMod.get(path.resolve(absRs)) ?? null;
    },
    has(name: string): boolean {
      return structToPath.has(name);
    },
  };
})();

function rustIdent(name: string): string {
  // Rust reserved words that appear as JS property/method names in .classes.ts.
  const reserved = new Set([
    "as",
    "break",
    "const",
    "continue",
    "crate",
    "else",
    "enum",
    "extern",
    "false",
    "fn",
    "for",
    "if",
    "impl",
    "in",
    "let",
    "loop",
    "match",
    "mod",
    "move",
    "mut",
    "pub",
    "ref",
    "return",
    "self",
    "Self",
    "static",
    "struct",
    "super",
    "trait",
    "true",
    "type",
    "unsafe",
    "use",
    "where",
    "while",
    "async",
    "await",
    "dyn",
    "abstract",
    "become",
    "box",
    "do",
    "final",
    "macro",
    "override",
    "priv",
    "typeof",
    "unsized",
    "virtual",
    "yield",
    "try",
    "gen",
  ]);
  return reserved.has(name) ? `r#${name}` : name;
}

function generateRust(
  typeName,
  {
    klass = {},
    proto = {},
    construct,
    constructNeedsThis = false,
    finalize,
    refCounted = false,
    noConstructor = false,
    overridesToJS = false,
    estimatedSize,
    call = false,
    memoryCost,
    values = [],
    hasPendingActivity = false,
    structuredClone = false,
    rustPath,
    sharedThis = true,
  } = {} as ClassDefinition,
) {
  const gc_fields = Object.entries({
    ...proto,
    ...Object.fromEntries((values || []).map(a => [a, { internal: true }])),
  }).filter(([name, { cache, internal }]) => (cache && typeof cache !== "string") || internal);

  // ── exported #[no_mangle] thunks ─────────────────────────────────────────
  // Direct dispatch: each thunk calls an *inherent* method on the user's real
  // Rust struct (re-exported as `${typeName}` below). No trait, no opaque
  // placeholder, no `unimplemented!()` — a missing method is a compile error.
  const thunks: string[] = [];
  const symbols: string[] = [];
  function thunk(sym: string, sig: string, body: string) {
    symbols.push(sym);
    // Safe-body thunks: every pointer param is typed as `&`/`&mut` directly
    // (ABI-identical to `*const`/`*mut` for non-null inputs, which the C++
    // caller guarantees) and routed through a safe `host_fn::*` helper. The
    // body itself contains no unsafe operations; the `unsafe fn` qualifier is
    // mandated by `jsc_host_abi!` and is harmless (only C++ calls these).
    //
    // Calling convention: every C++-side decl for these symbols uses
    // `extern JSC_CALLCONV` which expands to `extern "C" SYSV_ABI` on Windows
    // (see `#define JSC_CALLCONV` below in the .cpp emitter), so every thunk
    // — including finalize/hasPendingActivity/memoryCost/estimatedSize — must
    // be `extern "sysv64"` on win-x64. `jsc_host_abi!` does the cfg-split.
    thunks.push(
      `bun_jsc::jsc_host_abi! {\n` +
        `    #[allow(dead_code, unreachable_pub, unused)]\n` +
        `    #[unsafe(no_mangle)]\n` +
        `    pub unsafe fn ${sym}${sig} {\n` +
        `    ${body}\n` +
        `    }\n` +
        `}`,
    );
  }
  const T = typeName;
  // R-2 Phase 3: default flipped to `sharedThis: true`. Every JS-exposed
  // host-fn now receives `&${T}` (no `noalias` on the LLVM arg, so re-entrant
  // JS that re-derives `&Self` from the wrapper's `m_ctx` cannot miscompile).
  // `sharedThis: false` remains an explicit opt-out for types that have not
  // yet migrated their fields to `Cell`/`JsCell`; only the `_getter`/`_setter`
  // (no `this`) `&mut` helpers survive in `src/jsc/host_fn.rs` for it.
  const recv = sharedThis ? `&${T}` : `&mut ${T}`;
  const helper = (base: string) => (sharedThis ? `host_fn::${base}_shared` : `host_fn::${base}`);

  // memoryCost / estimatedSize / ZigStructSize
  if (memoryCost) {
    thunk(symbolName(typeName, "memoryCost"), `(this: &${T}) -> usize`, `    ${T}::memory_cost(this)`);
  }
  if (estimatedSize) {
    thunk(symbolName(typeName, "estimatedSize"), `(this: &${T}) -> usize`, `    ${T}::estimated_size(this)`);
  }
  if (!memoryCost && !estimatedSize) {
    symbols.push(symbolName(typeName, "ZigStructSize"));
    thunks.push(
      `#[allow(dead_code, unreachable_pub, unused)]\n#[unsafe(no_mangle)]\npub static ${symbolName(typeName, "ZigStructSize")}: usize = core::mem::size_of::<${T}>();`,
    );
  }

  if (hasPendingActivity) {
    thunk(symbolName(typeName, "hasPendingActivity"), `(this: &${T}) -> bool`, `    ${T}::has_pending_activity(this)`);
  }

  if (refCounted) {
    // The wrapper holds one ref: run the `&self` hook, then drop that ref.
    thunk(
      classSymbolName(typeName, "finalize"),
      `(this: *mut ${T}) -> ()`,
      `    use bun_jsc::JsFinalizeRefCounted as _;\n` +
        `    // SAFETY: this is the live m_ctx pointer the wrapper holds a ref on.\n` +
        `    unsafe { host_fn::host_fn_finalize_ref_counted(this, |t| ${T}::finalize(t)) }`,
    );
  } else if (finalize) {
    // `host_fn_finalize` does the single `Box::from_raw(this)` and hands the
    // user impl an owned `Box<Self>` — genuinely safe (ownership transferred).
    thunk(
      classSymbolName(typeName, "finalize"),
      `(this: *mut ${T}) -> ()`,
      `    use bun_jsc::JsFinalize as _;\n` +
        `    // SAFETY: this is the unique GC-owned m_ctx pointer from Box::into_raw in the construct path.\n` +
        `    unsafe { host_fn::host_fn_finalize(this, |b| ${T}::finalize(b)) }`,
    );
  }

  if (construct && !noConstructor) {
    if (constructNeedsThis) {
      thunk(
        classSymbolName(typeName, "construct"),
        `(global: &JSGlobalObject, callframe: &CallFrame, this_value: JSValue) -> *mut c_void`,
        `    host_fn::host_fn_construct_this(global, callframe, this_value, ${T}::constructor).cast()`,
      );
    } else {
      thunk(
        classSymbolName(typeName, "construct"),
        `(global: &JSGlobalObject, callframe: &CallFrame) -> *mut c_void`,
        `    host_fn::host_fn_construct(global, callframe, ${T}::constructor).cast()`,
      );
    }
  }

  if (call) {
    thunk(
      classSymbolName(typeName, "call"),
      `(global: &JSGlobalObject, callframe: &CallFrame) -> JSValue`,
      `    host_fn::host_fn_static(global, callframe, ${T}::call)`,
    );
  }

  // ── proto getters / setters / fns ────────────────────────────────────────
  // Closure form (`|t, g, c| T::method(t, g, c)`) rather than bare `T::method`
  // so `&mut T → &T` autoref/coercion applies — many user impls take `&self`.
  {
    const seen = new Map<string, string>();
    const exportNames = name => zigExportName(seen, n => protoSymbolName(typeName, n), proto[name]);
    for (const name in proto) {
      const { getter, setter, fn, this: thisValue = false, passThis } = proto[name];
      const names = exportNames(name);

      if (thisValue && !sharedThis && (names.getter || names.setter)) {
        throw new Error(`${typeName}.${name}: \`this: true\` accessors require \`sharedThis: true\``);
      }

      if (names.getter) {
        const id = rustSnakeIdent(getter);
        thunk(
          names.getter,
          `(this: ${recv}, ${thisValue ? "this_value: JSValue, " : ""}global: &JSGlobalObject) -> JSValue`,
          thisValue
            ? `    host_fn::host_fn_getter_this_shared(this, this_value, global, |t, v, g| ${T}::${id}(t, v, g))`
            : `    ${helper("host_fn_getter")}(this, global, |t, g| ${T}::${id}(t, g))`,
        );
      }

      if (names.setter) {
        const id = rustSnakeIdent(setter);
        thunk(
          names.setter,
          `(this: ${recv}, ${thisValue ? "this_value: JSValue, " : ""}global: &JSGlobalObject, value: JSValue) -> bool`,
          thisValue
            ? `    host_fn::host_fn_setter_this_shared(this, this_value, global, value, |t, tv, g, v| ${T}::${id}(t, tv, g, v))`
            : `    ${helper("host_fn_setter")}(this, global, value, |t, g, v| ${T}::${id}(t, g, v))`,
        );
      }

      if (names.fn) {
        const id = rustSnakeIdent(fn);
        thunk(
          names.fn,
          `(this: ${recv}, global: &JSGlobalObject, callframe: &CallFrame${passThis ? ", js_this_value: JSValue" : ""}) -> JSValue`,
          passThis
            ? `    ${helper("host_fn_this_value")}(this, global, callframe, js_this_value, |t, g, c, v| ${T}::${id}(t, g, c, v))`
            : `    ${helper("host_fn_this")}(this, global, callframe, |t, g, c| ${T}::${id}(t, g, c))`,
        );
      }
    }
  }

  // ── klass (static) getters / setters / fns ───────────────────────────────
  {
    const seen = new Map<string, string>();
    const exportNames = name => zigExportName(seen, n => classSymbolName(typeName, n), klass[name]);
    for (const name in klass) {
      const { getter, setter, fn } = klass[name];
      const names = exportNames(name);

      if (names.getter) {
        const id = rustSnakeIdent(getter);
        thunk(
          names.getter,
          `(global: &JSGlobalObject, this_value: JSValue, prop: PropertyName) -> JSValue`,
          `    host_fn::host_fn_static_getter(global, this_value, prop, |g, t, p| ${T}::${id}(g, t, p))`,
        );
      }

      if (names.setter) {
        const id = rustSnakeIdent(setter);
        thunk(
          names.setter,
          `(global: &JSGlobalObject, this_value: JSValue, value: JSValue, prop: PropertyName) -> bool`,
          `    host_fn::host_fn_static_setter(global, this_value, value, prop, |g, t, v, p| ${T}::${id}(g, t, v, p))`,
        );
      }

      if (names.fn) {
        const id = rustSnakeIdent(fn);
        thunk(
          names.fn,
          `(global: &JSGlobalObject, callframe: &CallFrame) -> JSValue`,
          `    host_fn::host_fn_static(global, callframe, |g, c| ${T}::${id}(g, c))`,
        );
      }
    }
  }

  // ── structuredClone ──────────────────────────────────────────────────────
  if (structuredClone) {
    thunk(
      symbolName(typeName, "onStructuredCloneSerialize"),
      `(this: ${recv}, global: &JSGlobalObject, ctx: *mut c_void, write_bytes: WriteBytesFn) -> ()`,
      `    ${T}::on_structured_clone_serialize(this, global, ctx, write_bytes)`,
    );
    if (typeof structuredClone === "object" && structuredClone.transferable) {
      thunk(
        symbolName(typeName, "onStructuredCloneTransfer"),
        `(this: ${recv}, global: &JSGlobalObject, ctx: *mut c_void, write_bytes: WriteBytesFn) -> ()`,
        `    ${T}::on_structured_clone_transfer(this, global, ctx, write_bytes)`,
      );
    }
    thunk(
      symbolName(typeName, "onStructuredCloneDeserialize"),
      `(global: &JSGlobalObject, ptr: *mut *mut u8, end: *const u8) -> JSValue`,
      `    // Empty with nothing pending: the record was malformed (CloneDeserializer::readTerminal → fail()).
    match ${T}::on_structured_clone_deserialize(global, ptr, end) {
        Ok(Some(value)) => value,
        Ok(None) => JSValue::ZERO,
        Err(err) => host_fn::host_call_error_value(global, err),
    }`,
    );
  }

  // ── C++→Rust extern imports + safe wrappers ──────────────────────────────
  // Emitted as free functions in a per-class `js_${T}` sub-module so they
  // don't collide with inherent `from_js`/`to_js` already defined on the
  // real struct.
  const cachedExterns = gc_fields
    .map(
      ([name]) =>
        `        safe fn ${protoSymbolName(typeName, name)}SetCachedValue(this_value: JSValue, global: *mut JSGlobalObject, value: JSValue);\n` +
        `        safe fn ${protoSymbolName(typeName, name)}GetCachedValue(this_value: JSValue) -> JSValue;`,
    )
    .join("\n");

  const gcAccessors = gc_fields
    .map(
      ([name]) => `    /// \`${typeName}.${name}\` cached-value setter (GC-visited via WriteBarrier).
    #[inline] pub fn ${rustSnakeIdent(name)}_set_cached(this_value: JSValue, global: &JSGlobalObject, value: JSValue) {
        ${protoSymbolName(typeName, name)}SetCachedValue(this_value, global.as_mut_ptr(), value)
    }
    /// \`${typeName}.${name}\` cached-value getter; \`None\` when never set.
    #[inline] pub fn ${rustSnakeIdent(name)}_get_cached(this_value: JSValue) -> Option<JSValue> {
        let v = ${protoSymbolName(typeName, name)}GetCachedValue(this_value);
        if v.is_empty() { None } else { Some(v) }
    }`,
    )
    .join("\n");

  // `safe fn` (Rust 2024) inside `jsc_abi_extern! {}`: the C++ side
  // (ZigGeneratedClasses.cpp) tolerates every well-typed input — \`fromJS\`
  // returns null on type mismatch, \`create\` allocates from a live global,
  // \`SetCachedValue\` is a WriteBarrier store. Declaring them \`safe\` moves
  // the audit obligation to this generator (one place) instead of an
  // \`unsafe {}\` per call site (~800 in the emitted file).
  //
  // Calling convention: every C++ definition uses `extern JSC_CALLCONV` =
  // `extern "C" SYSV_ABI` on Windows, so import them via `jsc_abi_extern!`
  // (sysv64 on win-x64, "C" elsewhere).
  const jsModule = `#[allow(dead_code, unreachable_pub, unused)]
pub mod js_${typeName} {
    use super::*;
    bun_jsc::jsc_abi_extern! {
        safe fn ${symbolName(typeName, "fromJS")}(value: JSValue) -> *mut ${typeName};
        safe fn ${symbolName(typeName, "fromJSDirect")}(value: JSValue) -> *mut ${typeName};${
          !noConstructor
            ? `
        safe fn ${symbolName(typeName, "getConstructor")}(global: *mut JSGlobalObject) -> JSValue;`
            : ""
        }
        safe fn ${symbolName(typeName, "create")}(global: *mut JSGlobalObject, ptr: *mut ${typeName}) -> JSValue;
        safe fn ${symbolName(typeName, "dangerouslySetPtr")}(value: JSValue, ptr: *mut ${typeName}) -> bool;
${cachedExterns}
    }
    #[inline] pub fn from_js(value: JSValue) -> Option<core::ptr::NonNull<${typeName}>> {
        core::ptr::NonNull::new(${symbolName(typeName, "fromJS")}(value))
    }
    #[inline] pub fn from_js_direct(value: JSValue) -> Option<core::ptr::NonNull<${typeName}>> {
        core::ptr::NonNull::new(${symbolName(typeName, "fromJSDirect")}(value))
    }
    ${
      !noConstructor
        ? `#[inline] pub fn get_constructor(global: &JSGlobalObject) -> JSValue {
        ${symbolName(typeName, "getConstructor")}(global.as_mut_ptr())
    }`
        : ""
    }
    ${
      !overridesToJS
        ? `/// Transfer ownership of \`this\` to a freshly-allocated JS wrapper.
    #[inline] pub fn to_js(this: *mut ${typeName}, global: &JSGlobalObject) -> JSValue {
        ${symbolName(typeName, "create")}(global.as_mut_ptr(), this)
    }`
        : ""
    }
    #[inline] pub fn detach_ptr(value: JSValue) {
        let ok = ${symbolName(typeName, "dangerouslySetPtr")}(value, core::ptr::null_mut());
        debug_assert!(ok);
    }
${gcAccessors}
}`;

  return {
    symbols,
    rustPath,
    src: `
// ════════════════════════════════════════════════════════════════════════════
// ${typeName}
// ════════════════════════════════════════════════════════════════════════════

/// Native backing type for \`JS${typeName}.m_ctx\`. Re-export of the real
/// struct so the thunks below call its inherent methods directly. A missing
/// method is a compile error — fix it in \`${rustPath}\`, not here.
#[allow(dead_code, unreachable_pub, unused)]
pub(crate) use ${rustPath} as ${typeName};

${thunks.join("\n\n")}

${jsModule}
`,
  };
}

const RUST_GENERATED_CLASSES_HEADER = `// Auto-generated by src/codegen/generate-classes.ts — DO NOT EDIT.
//
// Per-class \`#[unsafe(no_mangle)] extern "C"\` thunks satisfying the externs
// declared by ZigGeneratedClasses.cpp. Each thunk calls an inherent method on
// the user's real Rust struct (re-exported here as \`\${T}\`). No trait, no
// opaque placeholder, no runtime panic fallback — a missing struct or method
// is a hard compile error in \`cargo check -p bun_runtime\`.
//
// Calling convention: \`jsc.conv\` is plain \`extern "C"\` on every target except
// Windows-x64 (\`extern "sysv64"\`). Every exported thunk and import in this
// file maps to a C++ decl using \`extern JSC_CALLCONV\` (= \`"C" SYSV_ABI\` on
// Windows), so the file uses \`bun_jsc::jsc_host_abi!\` / \`jsc_abi_extern!\`
// for the cfg-split.

#[allow(dead_code, unreachable_pub, unused)]
use core::ffi::c_void;
#[allow(dead_code, unreachable_pub, unused)]
use bun_jsc::{self, host_fn, CallFrame, JSGlobalObject, JSValue, JsError, JsResult};

/// \`SYSV_ABI void (*)(CloneSerializer*, const uint8_t*, uint32_t)\`
#[allow(dead_code, unreachable_pub, unused)]
#[cfg(all(windows, target_arch = "x86_64"))]
pub type WriteBytesFn = unsafe extern "sysv64" fn(*mut c_void, *const u8, u32);
#[allow(dead_code, unreachable_pub, unused)]
#[cfg(not(all(windows, target_arch = "x86_64")))]
pub type WriteBytesFn = unsafe extern "C" fn(*mut c_void, *const u8, u32);

/// \`JSC::PropertyName\` — opaque pointer-sized handle (UniquedStringImpl*).
#[allow(dead_code, unreachable_pub, unused)]
#[repr(transparent)]
#[derive(Clone, Copy)]
pub struct PropertyName(pub *const c_void);
`;

function generateLazyClassStructureHeader(typeName, { klass = {}, proto = {} }) {
  const name = className(typeName);
  return `
  JSC::Structure* ${name}Structure() const { return m_generatedLazyClasses[GeneratedLazyClass${name}].getInitializedOnMainThread(this); }
  JSC::JSObject* ${name}Constructor() const { return m_generatedLazyClasses[GeneratedLazyClass${name}].constructorInitializedOnMainThread(this); }
  JSC::JSObject* ${name}Prototype() const { return m_generatedLazyClasses[GeneratedLazyClass${name}].prototypeInitializedOnMainThread(this); }
    `.trim();
}

// All generated classes share one `initLater` callback: it recovers the class's
// index from the `LazyClassStructure`'s position in `m_generatedLazyClasses` and
// calls through this table, instead of instantiating a callback per class.
function generateLazyClassStructureImpl(typeName, { klass = {}, proto = {}, noConstructor = false }) {
  const name = className(typeName);
  return `{ WebCore::${name}::createPrototype, WebCore::${name}::createStructure, ${
    noConstructor ? "nullptr" : `WebCore::${name}::createConstructor`
  } },`;
}

function generateLazyClassStructureHeaderTail(classes) {
  return `
  enum GeneratedLazyClass : unsigned {
    ${classes.map((a, i) => `GeneratedLazyClass${className(a.name)} = ${i},`).join("\n    ")}
  };
  // A plain array (not std::array) so OBJECT_OFFSETOF(GlobalObject, m_generatedLazyClasses[i])
  // works for the static property table in ZigGlobalObject.lut.txt.
  JSC::LazyClassStructure m_generatedLazyClasses[${classes.length}];
`;
}

const GENERATED_CLASSES_HEADER = [
  `
// GENERATED CODE - DO NOT MODIFY BY HAND
// Generated by "bun run build"
#pragma once

#include "root.h"

namespace Zig {

JSC_DECLARE_HOST_FUNCTION(jsFunctionInherits);

}

#include "JSDOMWrapper.h"
#include <wtf/NeverDestroyed.h>
#include "SerializedScriptValue.h"
`,

  `

namespace WebCore {
using namespace Zig;
using namespace JSC;

`,
];

const GENERATED_CLASSES_IMPL_HEADER_PRE = `
// GENERATED CODE - DO NOT MODIFY BY HAND
// Generated by make codegen
#include "root.h"
#include "headers.h"

#include "BunClientData.h"
#include "ZigGlobalObject.h"

#include <JavaScriptCore/JSFunction.h>
#include <JavaScriptCore/InternalFunction.h>
#include <JavaScriptCore/LazyClassStructure.h>
#include <JavaScriptCore/LazyClassStructureInlines.h>
#include <JavaScriptCore/FunctionPrototype.h>

#include "JSDOMConvertBufferSource.h"
#include "ZigGeneratedClasses.h"
#include "WebCoreJSBuiltins.h"
#include "ErrorCode+List.h"
#include "ErrorCode.h"
#include <JavaScriptCore/HeapAnalyzer.h>

#if !OS(WINDOWS)
#define JSC_CALLCONV "C"
#else
#define JSC_CALLCONV "C" SYSV_ABI
#endif

#if ASSERT_ENABLED
#include <JavaScriptCore/IntegrityInlines.h>
#endif

`;

const GENERATED_CLASSES_IMPL_HEADER_POST = `
namespace WebCore {

using namespace JSC;
using namespace Zig;

static NEVER_INLINE JSC::EncodedJSValue generatedClassConstructor(Zig::GlobalObject* globalObject, Zig::GlobalObject::GeneratedLazyClass which)
{
    return JSValue::encode(globalObject->m_generatedLazyClasses[which].constructorInitializedOnMainThread(globalObject));
}

// The \`new.target !== constructor\` (subclass / Reflect.construct) path shared by
// every generated constructor.
static NEVER_INLINE JSC::Structure* structureForNewTarget(Zig::GlobalObject* globalObject, JSC::JSObject* newTarget, Zig::GlobalObject::GeneratedLazyClass which)
{
    auto& vm = globalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    // ShadowRealm functions belong to a different global object.
    auto* functionGlobalObject = defaultGlobalObject(getFunctionRealm(globalObject, newTarget));
    RETURN_IF_EXCEPTION(scope, nullptr);
    auto* structure = InternalFunction::createSubclassStructure(globalObject, newTarget, functionGlobalObject->m_generatedLazyClasses[which].getInitializedOnMainThread(functionGlobalObject));
    RETURN_IF_EXCEPTION(scope, nullptr);
    return structure;
}

// Cached JSValue fields of a generated class, as byte offsets into the cell, so
// analyzeHeap can loop over one shared body instead of expanding an inlined
// edge per field per class. (visitChildren stays inline: it is GC-hot.)
struct GeneratedCachedField {
    unsigned offset;
    // Property name reported to the heap analyzer.
    const char* name;
};

static ALWAYS_INLINE const JSC::WriteBarrier<JSC::Unknown>& generatedCachedField(const JSCell* cell, const GeneratedCachedField& field)
{
    return *reinterpret_cast<const JSC::WriteBarrier<JSC::Unknown>*>(reinterpret_cast<const uint8_t*>(cell) + field.offset);
}

static NEVER_INLINE void analyzeGeneratedCachedFields(JSCell* cell, HeapAnalyzer& analyzer, std::span<const GeneratedCachedField> fields)
{
    auto& vm = cell->vm();
    for (auto& field : fields) {
        JSValue value = generatedCachedField(cell, field).get();
        if (value && value.isCell()) {
            const Identifier& id = Identifier::fromString(vm, ASCIILiteral::fromLiteralUnsafe(field.name));
            analyzer.analyzePropertyNameEdge(cell, value.asCell(), id.impl());
        }
    }
}

`;

const GENERATED_CLASSES_IMPL_FOOTER = `

} // namespace WebCore

`;

function jsInheritsCppImpl() {
  return `
${jsclasses
  .map(v => v[1])
  .filter(v => v?.length > 0)
  .map((v, i) => `#include "${v}"`)
  .join("\n")}

JSC_DEFINE_HOST_FUNCTION(Zig::jsFunctionInherits, (JSC::JSGlobalObject * globalObject, JSC::CallFrame* callFrame))
{
    auto id = callFrame->argument(0).toInt32(globalObject);
    auto value = callFrame->argument(1);
    if (!value.isCell()) return JSValue::encode(jsBoolean(false));
    auto cell = value.asCell();
    switch (id) {
${jsclasses
  .map(v => v[0])
  .map((v, i) => `    case ${i}: return JSValue::encode(jsBoolean(dynamicDowncast<WebCore::JS${v}>(cell) != nullptr));`)
  .join("\n")}
    }
    return JSValue::encode(jsBoolean(false));
}`;
}

function isTransferableCppImpl() {
  return `
bool WebCore::SerializedScriptValue::isTransferable(JSC::JSGlobalObject* globalObject, JSC::JSValue value)
{
  if (!value.isCell()) return true;
  auto cell = value.asCell();
${classes
  .map(c => {
    if (c.structuredClone == null) return "";
    if (typeof c.structuredClone === "boolean") return "";
    if (c.structuredClone.transferable) return "";
    return `  if (dynamicDowncast<WebCore::JS${c.name}>(cell)) return false;\n`;
  })
  .join("")}
  return true;
}
`;
}

function initLazyClasses(initTableRows) {
  return `
struct GeneratedLazyClassInit {
    JSC::JSObject* (*createPrototype)(JSC::VM&, WebCore::JSDOMGlobalObject*);
    JSC::Structure* (*createStructure)(JSC::VM&, JSC::JSGlobalObject*, JSC::JSValue);
    JSC::JSObject* (*createConstructor)(JSC::VM&, JSC::JSGlobalObject*, JSC::JSValue);
};

static constexpr GeneratedLazyClassInit generatedLazyClassInits[] = {
    ${initTableRows.map(a => a.trim()).join("\n    ")}
};

ALWAYS_INLINE void GlobalObject::initGeneratedLazyClasses() {
    static_assert(std::size(generatedLazyClassInits) == std::extent_v<decltype(m_generatedLazyClasses)>);
    for (auto& lazyClass : m_generatedLazyClasses) {
        lazyClass.initLater([](LazyClassStructure::Initializer& init) {
            // The owner passed to get() is normally the holder; some call sites pass
            // another realm's global and reach the holder via defaultGlobalObject().
            Zig::GlobalObject* globalObject = nullptr;
            size_t index = std::size(generatedLazyClassInits);
            for (JSGlobalObject* candidate : { init.global, static_cast<JSGlobalObject*>(defaultGlobalObject(init.global)) }) {
                if (auto* holder = dynamicDowncast<Zig::GlobalObject>(candidate)) {
                    size_t i = &init.classStructure - holder->m_generatedLazyClasses;
                    if (i < std::size(generatedLazyClassInits)) {
                        globalObject = holder;
                        index = i;
                        break;
                    }
                }
            }
            RELEASE_ASSERT(globalObject);
            const GeneratedLazyClassInit& fns = generatedLazyClassInits[index];
            init.setPrototype(fns.createPrototype(init.vm, globalObject));
            init.setStructure(fns.createStructure(init.vm, init.global, init.prototype));
            if (fns.createConstructor)
                init.setConstructor(fns.createConstructor(init.vm, init.global, init.prototype));
        });
    }
}

`.trim();
}

function visitLazyClasses(classes) {
  return `

template<typename Visitor>
void GlobalObject::visitGeneratedLazyClasses(GlobalObject *thisObject, Visitor& visitor)
{
    for (auto& lazyClass : thisObject->m_generatedLazyClasses)
        lazyClass.visit(visitor);
}

  `.trim();
}

const classes: ClassDefinition[] = [];
{
  let errors = [];
  for (const file of files) {
    const filepath = path.resolve(file);
    const result = require(filepath);
    if (!(result?.default?.length ?? 0)) {
      errors.push(
        new TypeError(
          `Missing classes in "${path.relative(process.cwd(), filepath)}". Expected \`export default [ define(...) ] satisfies Array<ClassDefinition>\` but got ${inspect(result).slice(0, 100) + "..."} `,
        ),
      );
      continue;
    }

    console.log("Found", result.default.length, "classes from", file);
    for (let { name, proto = {}, klass = {} } of result.default) {
      let protoProps = Object.keys(proto).length ? `${Object.keys(proto).length} fields` : "";
      let klassProps = Object.keys(klass).length ? `${Object.keys(klass).length} class fields` : "";
      let props = [protoProps, klassProps].filter(Boolean).join(", ");
      if (props.length) props = ` (${props})`;
      console.log(`  - ${name}` + props);
    }

    for (const def of result.default) def._classesFilePath = filepath;
    classes.push(...result.default);
  }

  if (errors.length) {
    throw new AggregateError(errors, "Failed to generate classes");
  }
}
classes.sort((a, b) => (a.name < b.name ? -1 : 1));

// sort all the prototype keys and klass keys
for (const obj of classes) {
  let { klass = {}, proto = {} } = obj;

  klass = Object.fromEntries(Object.entries(klass).sort(([a], [b]) => a.localeCompare(b)));
  proto = Object.fromEntries(Object.entries(proto).sort(([a], [b]) => a.localeCompare(b)));

  obj.klass = klass;
  obj.proto = proto;
}

const GENERATED_CLASSES_FOOTER = `

typedef SYSV_ABI void (*CppStructuredCloneableSerializeFunction)(CloneSerializer*, const uint8_t*, uint32_t);
typedef SYSV_ABI void (*ZigStructuredCloneableSerializeFunction)(void*, JSC::JSGlobalObject*, CloneSerializer*, CppStructuredCloneableSerializeFunction);

class StructuredCloneableSerialize {
  public:
    CppStructuredCloneableSerializeFunction cppWriteBytes;
    ZigStructuredCloneableSerializeFunction zigFunction;

    uint8_t tag = 0;

    // the type from zig
    void* impl = nullptr;

    bool isForTransfer = false;
    bool isForStorage = false;

    static std::optional<StructuredCloneableSerialize> fromJS(JSC::JSValue);
    void write(CloneSerializer* serializer, JSC::JSGlobalObject* globalObject)
    {
      zigFunction(impl, globalObject, serializer, cppWriteBytes);
    }
};

class StructuredCloneableDeserialize {
  public:
    static std::optional<JSC::EncodedJSValue> fromTagDeserialize(uint8_t tag, JSC::JSGlobalObject*, const uint8_t*&, const uint8_t*);
};

}

`;

function writeCppSerializers() {
  var output = ``;

  var structuredClonable = classes
    .filter(a => a.structuredClone)
    .sort((a, b) => a.structuredClone.tag < b.structuredClone.tag);

  function fromJSForEachClass(klass) {
    return `
    if (auto* result = dynamicDowncast<${className(klass.name)}>(value)) {
      return StructuredCloneableSerialize { .cppWriteBytes = SerializedScriptValue::writeBytesForBun, .zigFunction = ${symbolName(
        klass.name,
        "onStructuredCloneSerialize",
      )}, .tag = ${klass.structuredClone.tag}, .impl = result->wrapped(), .isForTransfer = ${!!klass.structuredClone.transferable}, .isForStorage = ${!!klass.structuredClone.storable} };
    }
    `;
  }

  function fromTagDeserializeForEachClass(klass) {
    return `
    if (tag == ${klass.structuredClone.tag}) {
      return ${symbolName(klass.name, "onStructuredCloneDeserialize")}(globalObject, (uint8_t**)&ptr, end);
    }
    `;
  }

  output += `
  std::optional<StructuredCloneableSerialize> StructuredCloneableSerialize::fromJS(JSC::JSValue value)
  {
    ${structuredClonable.map(fromJSForEachClass).join("\n").trim()}
    return std::nullopt;
  }
  `;

  output += `
  std::optional<JSC::EncodedJSValue> StructuredCloneableDeserialize::fromTagDeserialize(uint8_t tag, JSC::JSGlobalObject* globalObject, const uint8_t*& ptr, const uint8_t* end)
  {
    ${structuredClonable.map(fromTagDeserializeForEachClass).join("\n").trim()}
    return std::nullopt;
  }
  `;

  return output;
}

// ── Rust output: per-class thunks ──────────────────────────────────────────
{
  const rustClasses = classes;
  let totalSyms = 0;
  let resolved = 0;
  const blocks = rustClasses.map(a => {
    a.rustPath ??= rustModuleResolver.resolveStruct(a.name, a._classesFilePath);
    if (rustModuleResolver.has(a.name)) resolved++;
    const { symbols, src } = generateRust(a.name, a);
    totalSyms += symbols.length;
    return src;
  });
  await writeIfNotChanged(`${outBase}/generated_classes.rs`, [
    RUST_GENERATED_CLASSES_HEADER,
    ...blocks,
    `\n// classes: ${rustClasses.length} (${resolved} structs found, ${rustClasses.length - resolved} unresolved), exported symbols: ${totalSyms}\n`,
  ]);
  console.log(
    `generated_classes.rs: ${rustClasses.length} classes (${resolved} resolved), ${totalSyms} exported symbols`,
  );
}

// ── C++ output: ZigGeneratedClasses.{h,cpp,+*.h} and the .d.ts twin ────────
{
  const allHeaders = classes.map(a => generateHeader(a.name, a));
  await writeIfNotChanged(`${outBase}/ZigGeneratedClasses.h`, [
    ...GENERATED_CLASSES_HEADER,
    ...allHeaders,
    GENERATED_CLASSES_FOOTER,
  ]);

  const allImpls = classes.map(a => generateImpl(a.name, a));
  await writeIfNotChanged(`${outBase}/ZigGeneratedClasses.cpp`, [
    GENERATED_CLASSES_IMPL_HEADER_PRE,
    externs.trim(),
    GENERATED_CLASSES_IMPL_HEADER_POST,
    allImpls.join("\n"),
    writeCppSerializers(classes),
    GENERATED_CLASSES_IMPL_FOOTER,
    jsInheritsCppImpl(),
    isTransferableCppImpl(),
  ]);

  await writeIfNotChanged(
    `${outBase}/ZigGeneratedClasses+lazyStructureHeader.h`,
    classes.map(a => generateLazyClassStructureHeader(a.name, a)).join("\n") +
      generateLazyClassStructureHeaderTail(classes),
  );

  await writeIfNotChanged(
    `${outBase}/ZigGeneratedClasses+DOMClientIsoSubspaces.h`,
    classes.map(a => [`GCClient::IsoSubspace* ${clientSubspaceFor(a.name)} { nullptr };`].join("\n")),
  );

  await writeIfNotChanged(
    `${outBase}/ZigGeneratedClasses+DOMIsoSubspaces.h`,
    classes.map(a => [`IsoSubspace* ${subspaceFor(a.name)} { nullptr };`].join("\n")),
  );

  await writeIfNotChanged(
    `${outBase}/ZigGeneratedClasses+lazyStructureImpl.h`,
    initLazyClasses(classes.map(a => generateLazyClassStructureImpl(a.name, a))) + "\n" + visitLazyClasses(classes),
  );

  await writeIfNotChanged(`${typesDir}/ZigGeneratedClasses.d.ts`, [generateBuiltinTypes(classes)]);
}

/**
 * Generates a basic TypeScript type signature string for a given property
 * definition.
 * Returns null if the property should not be included in the types (e.g., private).
 */
function getPropertySignatureWithComment(
  propName: string,
  propDef: Field,
  classDef: ClassDefinition,
): { signature: string; comment: string | null } | null {
  let tsPropName = propName;
  // Handle well-known symbols
  if (tsPropName.startsWith("@@")) {
    tsPropName = `[Symbol.${tsPropName.slice(2)}]`;
  } else if (/[^a-zA-Z0-9_$]/.test(tsPropName)) {
    // Quote property names that are not valid JS identifiers (e.g., contain '-')
    tsPropName = `"${tsPropName}"`;
  }

  if ("privateSymbol" in propDef) {
    tsPropName = `$${propDef.privateSymbol}`;
  }

  // --- Skip internal/private properties ---
  if ("internal" in propDef) {
    return null;
  }

  // --- Determine Type and Readonly Status ---
  let signature = "";
  let isMethod = false;
  let isReadOnly = false;
  let commentLines: string[] = [];

  if ("fn" in propDef || "builtin" in propDef) {
    const length = propDef.length ?? 0;
    let args = Array(length)
      .fill(0)
      .map((_, i) => `arg${i}?: unknown`)
      .concat(...(length > 0 ? ["...args: unknown[]"] : []))
      .join(", ");
    let returnType = "unknown";
    if (propDef.async) {
      returnType = "Promise<unknown>";
    }

    signature = `${tsPropName}(${args}): ${returnType};`; // Basic method signature
    isMethod = true;
    if ("fn" in propDef) {
      commentLines.push(
        ` Look for a function like this:
      * \`\`\`zig
      * fn ${propDef.fn}(this: *${classDef.name}, globalThis: *jsc.JSGlobalObject, callframe: *jsc.CallFrame) bun.JSError!jsc.JSValue { ... }
      * \`\`\``,
      );
    } else if ("builtin" in propDef) {
      commentLines.push(`* C++ builtin name: \`${propDef.builtin}\``);
    }
  } else if ("getter" in propDef) {
    signature = `${tsPropName}: unknown;`; // Getter, possibly with setter
    isReadOnly = !propDef.writable && !("setter" in propDef); // Mark readonly if only getter or explicitly not writable
    commentLines.push(
      ` Look for a getter like this:
      * \`\`\`zig
      * fn ${propDef.getter}(this: *${classDef.name}, globalThis: *jsc.JSGlobalObject) bun.JSError!jsc.JSValue { ... }
      * \`\`\``,
    );
    if (propDef.writable) {
      commentLines.push(` Writable`); // Implicitly means a setter exists or is generated
    }
  } else if ("setter" in propDef) {
    // Can't represent pure write-only in interfaces easily, treat as read-write
    signature = `${tsPropName}: unknown;`;
    commentLines.push(
      ` Look for a setter like this:
      * \`\`\`zig
      * fn ${propDef.setter}(this: *${classDef.name}, globalThis: *jsc.JSGlobalObject, value: jsc.JSValue) bun.JSError!void { ... }
      * \`\`\``,
    );
  } else {
    // Unknown property type or skipped type (like internal)
    return null;
  }

  // --- Add Modifiers ---
  if (isReadOnly && !isMethod) {
    signature = `readonly ${signature}`;
  }
  // --- Format Comment ---
  const comment = commentLines.length > 0 ? `/**\n      *${commentLines.join("\n      *")}\n      */` : null;

  return { signature, comment };
}

/**
 * Generates TypeScript type definitions (interfaces) for all provided class definitions.
 * Creates content for a single ambient declaration file (ZigGeneratedClasses.d.ts).
 */
export function generateBuiltinTypes(classes: ClassDefinition[]): string {
  const typeDeclarations: string[] = [];

  for (const classDef of classes) {
    const instanceMembers: string[] = [];
    const staticMembers: string[] = [];
    const constructorInterfaceName = `${classDef.name}Constructor`;
    const staticsInterfaceName = `${classDef.name}Statics`;

    // --- Process Instance Members (proto, values) ---
    for (const [propName, propDef] of Object.entries(classDef.proto || {})) {
      const result = getPropertySignatureWithComment(propName, propDef, classDef);
      if (result) {
        if (result.comment) instanceMembers.push(`    ${result.comment}`);
        instanceMembers.push(`    ${result.signature}`);
      }
    }

    // --- Process Static Members (klass) ---
    for (const [propName, propDef] of Object.entries(classDef.klass || {})) {
      const result = getPropertySignatureWithComment(propName, propDef, classDef);
      if (result) {
        if (result.comment) staticMembers.push(`    ${result.comment}`);
        staticMembers.push(`    ${result.signature}`);
      }
    }

    // --- Generate Instance Interface ---
    typeDeclarations.push(`  interface ${classDef.name} {`);
    if (instanceMembers.length === 0) {
      typeDeclarations.push(`    /* Opaque interface */`);
    } else {
      typeDeclarations.push(...instanceMembers);
    }
    typeDeclarations.push(`  }`);
    typeDeclarations.push(""); // Blank line separator

    // --- Determine if Constructor/Static Interface is needed ---
    const hasStaticMembers = staticMembers.length > 0;
    const isConstructible = !!classDef.construct;
    const isCallable = !!classDef.call;
    const hasExplicitConstructor = !classDef.noConstructor;

    const needsConstructorInterface = isConstructible || isCallable || (hasStaticMembers && hasExplicitConstructor);
    const needsStaticInterface = hasStaticMembers && !hasExplicitConstructor && !isConstructible && !isCallable;
    const needsGlobalVar = hasExplicitConstructor || needsStaticInterface;

    // --- Generate Constructor Interface (if applicable) ---
    if (needsConstructorInterface) {
      typeDeclarations.push(`  interface ${constructorInterfaceName} {`);
      if (isConstructible) {
        typeDeclarations.push(`    new(...args: any[]): ${classDef.name};`);
        typeDeclarations.push(`    prototype: ${classDef.name};`);
      }
      if (isCallable) {
        // Add call signature if the constructor itself is callable
        typeDeclarations.push(`    (...args: any[]): any;`);
      }

      // Add static members
      if (staticMembers.length > 0) {
        typeDeclarations.push(`\n    // Static members`);
        typeDeclarations.push(...staticMembers);
      }
      typeDeclarations.push(`  }`);
      typeDeclarations.push(""); // Blank line separator
    }

    // --- Generate Statics Interface (if applicable, for noConstructor classes with statics) ---
    if (needsStaticInterface) {
      typeDeclarations.push(`  interface ${staticsInterfaceName} {`);
      if (staticMembers.length > 0) {
        typeDeclarations.push(`\n    // Static members`);
        typeDeclarations.push(...staticMembers);
      }
      typeDeclarations.push(`  }`);
      typeDeclarations.push(""); // Blank line separator
    }

    // --- Generate Global Variable Declaration ---
    if (needsGlobalVar) {
      const interfaceToUse = needsConstructorInterface ? constructorInterfaceName : staticsInterfaceName;
      // Declare the global variable holding the constructor or static methods/props
      typeDeclarations.push(`  var ${classDef.name}: ${interfaceToUse};`);
      typeDeclarations.push(""); // Blank line separator
    }
  } // End loop through classes

  // --- Assemble Final File Content ---
  return `// GENERATED CODE - DO NOT MODIFY BY HAND
// Generated by generate-classes.ts

/**
 * Type definitions for Bun's built-in classes implemented in Zig.
 * Do not edit this file directly.
 * @generated
 *
 * This namespace does not exist at runtime!
 */
declare namespace $ZigGeneratedClasses {
${typeDeclarations.map(line => (line ? "  " + line : "")).join("\n")}
}
`;
}
