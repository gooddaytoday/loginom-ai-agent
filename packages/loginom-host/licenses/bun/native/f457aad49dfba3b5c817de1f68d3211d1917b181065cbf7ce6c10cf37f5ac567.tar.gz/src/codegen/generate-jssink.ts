import { mkdirSync, writeFileSync } from "fs";
import { join, resolve } from "path";
import { createHashTable } from "./create-hash-table.ts";

const classes = [
  "ArrayBufferSink",
  "FileSink",
  "HTTPResponseSink",
  "HTTPSResponseSink",
  "NetworkSink",
  "FetchRequestBodySink",
  "HTMLRewriterSink",
];

function names(name) {
  return {
    constructor: `JS${name}Constructor`,
    className: `JS${name}`,
    controller: `JSReadable${name}Controller`,
    controllerName: `Readable${name}Controller`,
    prototypeName: `JS${name}Prototype`,
    controllerPrototypeName: `JSReadable${name}ControllerPrototype`,
  };
}

function header() {
  function classTemplate(name) {
    const { constructor, className, controller } = names(name);

    return `class ${constructor} final : public JSC::InternalFunction {                                                                                                     
        public:                                                                                                                                                                     
            using Base = JSC::InternalFunction;                                                                                                                                     
            static ${constructor}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, JSC::JSObject* prototype); 
            static constexpr SinkID Sink = SinkID::${name};
                                                                                                                                                                                    
            static constexpr unsigned StructureFlags = Base::StructureFlags;                                                                                                        
            static constexpr JSC::DestructionMode needsDestruction = DoesNotNeedDestruction;                                                                                                                         
                                                                                                                                                                                    
            DECLARE_EXPORT_INFO;                                                                                                                                                    
            template<typename, JSC::SubspaceAccess mode> static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)                                                                
            {                                                                                                                                                                       
                if constexpr (mode == JSC::SubspaceAccess::Concurrently)                                                                                                            
                    return nullptr;                                                                                                                                                 
                return WebCore::subspaceForImpl<${constructor}, WebCore::UseCustomHeapCellType::No>(vm, BUN_SUBSPACE_SLOTS(m_clientSubspaceForJSSinkConstructor, m_subspaceForJSSinkConstructor));                                                                    
            }                                                                                                                                                                       
                                                                                                                                                                                    
            static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)                                                          
            {                                                                                                                                                                       
                return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::InternalFunctionType, StructureFlags), info());                                                 
            }                                                                                                                                                                       
            void initializeProperties(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSObject* prototype);   
            
            
            // Must be defined for each specialization class.
            static JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES construct(JSC::JSGlobalObject*, JSC::CallFrame*);
                                                                                                                                                               
        private:                                                                                                                                                                    
            ${constructor}(JSC::VM& vm, JSC::Structure* structure, JSC::NativeFunction nativeFunction)                                                                  
                : Base(vm, structure, nativeFunction, nativeFunction)                                                                                                               
                                                                                                                                                                                    
            {                                                                                                                                                                       
            }                                                                                                                                                                       
                                                                                                                                                                                    
            void finishCreation(JSC::VM&, JSC::JSGlobalObject* globalObject, JSC::JSObject* prototype);                                                     
        };                                                                                                                                                                          
                                                                                                                                                                                    
        class ${className} final : public JSC::JSDestructibleObject {                                                                                                              
        public:                                                                                                                                                                     
            using Base = JSC::JSDestructibleObject;                                                                                                                                 
            static ${className}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* sinkPtr, uintptr_t destructor = 0);       
            static constexpr SinkID Sink = SinkID::${name};                                          
                                                                                                                                                                                    
            DECLARE_EXPORT_INFO;                                                                                                                                                    
            template<typename, JSC::SubspaceAccess mode> static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)                                                                
            {                                                                                                                                                                       
                if constexpr (mode == JSC::SubspaceAccess::Concurrently)                                                                                                            
                    return nullptr;                                                                                                                                                 
                return WebCore::subspaceForImpl<${className}, WebCore::UseCustomHeapCellType::No>(vm, BUN_SUBSPACE_SLOTS(m_clientSubspaceForJSSink, m_subspaceForJSSink));                                                                               
            }                                                                                                                                                                       
                                                                                                                                                                                    
            static void destroy(JSC::JSCell*);                                                                                                                                      
            static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)                                                          
            {                                                                                                                                                                       
                return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::ObjectType, StructureFlags), info());                                                 
            }                       
            
            static JSObject* createPrototype(VM& vm, JSDOMGlobalObject& globalObject);
                                                                                                                                                                                    
            ~${className}();                                                                                                                                                       
                                                                                                                                                                                    
            void* wrapped() const { return m_sinkPtr; }    
            DECLARE_VISIT_CHILDREN;                                                                                                                         

            void detach() {
                m_sinkPtr = nullptr;

            }

            static void analyzeHeap(JSCell*, JSC::HeapAnalyzer&);
            static size_t estimatedSize(JSCell* cell, JSC::VM& vm);
            static size_t memoryCost(void* sinkPtr);

            void ref();
            void unref();
                                                                                                                                                                                    
            void* m_sinkPtr;
            int m_refCount { 1 };

            uintptr_t m_onDestroy { 0 };
                                                                                                                                                                                    
            ${className}(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr, uintptr_t onDestroy)
                : Base(vm, structure)
            {
                m_sinkPtr = sinkPtr;
                m_onDestroy = onDestroy;
            }
                                                                                                                                                                                    
            void finishCreation(JSC::VM&);
        };

     

        class ${controller} final : public JSReadableSinkControllerBase {
            public:
                using Base = JSReadableSinkControllerBase;
                static ${controller}* create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* sinkPtr, uintptr_t onDestroy);
                static constexpr SinkID Sink = SinkID::${name};

                DECLARE_EXPORT_INFO;
                template<typename, JSC::SubspaceAccess mode> static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
                {
                    if constexpr (mode == JSC::SubspaceAccess::Concurrently)
                        return nullptr;
                    return WebCore::subspaceForImpl<${controller}, WebCore::UseCustomHeapCellType::No>(vm, BUN_SUBSPACE_SLOTS(m_clientSubspaceForJSSinkController, m_subspaceForJSSinkController));
                }

                static void destroy(JSC::JSCell*);
                static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
                {
                    return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::ObjectType, StructureFlags), info());
                }
                static JSObject* createPrototype(VM& vm, JSDOMGlobalObject& globalObject);

                ~${controller}();

                void detach(JSC::JSValue reason = {});

                DECLARE_VISIT_CHILDREN;

                static void analyzeHeap(JSCell*, JSC::HeapAnalyzer&);
                static size_t estimatedSize(JSCell* cell, JSC::VM& vm);
                static size_t memoryCost(void* sinkPtr);

                ${controller}(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr, uintptr_t onDestroy)
                    : Base(vm, structure, sinkPtr, SinkID::${name}, onDestroy)
                {
                }

                void finishCreation(JSC::VM&);
            };

JSC_DECLARE_CUSTOM_GETTER(function${name}__getter);

        `;
  }

  const outer = `
// AUTO-GENERATED FILE. DO NOT EDIT.
// Generated by generate-jssink.ts
//
#pragma once

#include "root.h"

#include "JSDOMWrapper.h"
#include <JavaScriptCore/JSPromise.h>
#include <JavaScriptCore/WeakInlines.h>
#include <wtf/NeverDestroyed.h>

#include "Sink.h"

extern "C" bool JSSink_isSink(JSC::JSGlobalObject*, JSC::EncodedJSValue);

namespace WebCore {
using namespace JSC;

class JSReadableSinkControllerBase;

// Who consumes the sink's close/ready signals. Both bodies live in BunStreamSource.cpp.
enum class SinkSource : uint8_t {
    None,
    DirectStream, // m_source is the JSDirectStreamSource; only onClose is used
    Pump,         // m_source is the JSReadStreamIntoSinkOperation
};

} // namespace WebCore

namespace Bun::WebStreams {
void sinkControllerOnClose(JSC::JSGlobalObject*, WebCore::JSReadableSinkControllerBase*, JSC::JSValue reason, bool sinkClosed);
void sinkControllerOnReady(JSC::JSGlobalObject*, WebCore::JSReadableSinkControllerBase*);
}

namespace WebCore {

// Shared non-virtual layout of every JSReadable*SinkController; the generic JSSinkController__* externs read it.
class JSReadableSinkControllerBase : public JSC::JSDestructibleObject {
public:
    using Base = JSC::JSDestructibleObject;

    DECLARE_INFO;

    void* wrapped() const { return m_sinkPtr; }
    SinkID sinkId() const { return m_sinkId; }

    void start(JSC::VM& vm, JSC::JSObject* readableStream, SinkSource kind, JSC::JSCell* source)
    {
        m_readableStream.set(vm, this, readableStream);
        m_sourceKind = kind;
        m_source.set(vm, this, source);
    }
    JSC::JSObject* readableStream() const { return m_readableStream.get(); }
    // Two users: this cell's close handler (until m_sourceKind is None) and a sink that set it through setPipe. The last one out drops it.
    void clearReadableStream()
    {
        if (!m_pipeHoldsStream && m_sourceKind == SinkSource::None)
            m_readableStream.clear();
    }
    JSC::EncodedJSValue end(JSC::JSGlobalObject*); // the JS-visible end(): finish the native sink, then detach()
    JSC::EncodedJSValue close(JSC::JSGlobalObject*, JSC::JSValue reason); // the JS-visible close(reason): a truthy reason fails the sink without flushing

    void* m_sinkPtr;
    SinkID m_sinkId;
    SinkSource m_sourceKind { SinkSource::None };
    mutable WriteBarrier<JSC::JSCell> m_source;
    mutable WriteBarrier<JSC::JSPromise> m_closePromise; // DirectStream: readDirectStream's result, taken by whatever closes the controller
    mutable WriteBarrier<JSC::Unknown> m_failReason; // close(error)'s error, so the owner's promise rejects with it even when detach() or readDirectStream only see it afterwards
    // Strong, and cleared as soon as the pipe is over, so a controller the user still holds does not keep the stream alive.
    mutable WriteBarrier<JSC::JSObject> m_readableStream;
    // While a native sink pipes a stream in, it roots only this cell; this and m_readableStream hold the rest (streams.rs PipeCell).
    mutable WriteBarrier<JSC::JSPromise> m_pipeDone;
    uintptr_t m_onDestroy { 0 };
    bool m_pipeHoldsStream { false };
    bool m_destinationClosed { false }; // the sink closed underneath the source (peer abort, write error): write()/flush() report 0 instead of throwing

protected:
    JSReadableSinkControllerBase(JSC::VM& vm, JSC::Structure* structure, void* sinkPtr, SinkID sinkId, uintptr_t onDestroy)
        : Base(vm, structure)
    {
        m_sinkPtr = sinkPtr;
        m_sinkId = sinkId;
        m_onDestroy = onDestroy;
    }
};

`;

  const bottom = `
JSObject* createJSSinkPrototype(JSC::VM& vm, JSC::JSGlobalObject* globalObject, WebCore::SinkID sinkID);
JSObject* createJSSinkControllerPrototype(JSC::VM& vm, JSC::JSGlobalObject* globalObject, WebCore::SinkID sinkID);
Structure* createJSSinkControllerStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, WebCore::SinkID sinkID);
// readStreamIntoSink's close for a failed source: \`error\` reaches the sink
// whatever its value. The controller's JS close(error) reads a falsy argument
// as a clean close instead.
void closeSinkControllerWithError(JSC::JSGlobalObject*, JSReadableSinkControllerBase*, JSC::JSValue error);
} // namespace WebCore
`;
  var templ = outer;
  for (let name of classes) {
    templ += classTemplate(name) + "\n";
  }
  templ += bottom;
  return templ;
}

async function implementation() {
  const head = `
// AUTO-GENERATED FILE. DO NOT EDIT.
// Generated by 'generate-jssink.ts'
//
#include "root.h"
#include "headers.h"
#include "BunClientData.h"

#include "JSSink.h"
#include "AsyncContextFrame.h"

#include "ExtendedDOMClientIsoSubspaces.h"
#include "ExtendedDOMIsoSubspaces.h"
#include "IDLTypes.h"
// #include "JSBlob.h"
#include "JSDOMAttribute.h"
#include "JSDOMBinding.h"
#include "JSDOMConstructor.h"
#include "JSDOMConvertBase.h"
#include "JSDOMConvertInterface.h"
#include "JSDOMConvertStrings.h"
#include "JSDOMExceptionHandling.h"
#include "JSDOMGlobalObject.h"
#include "JSDOMGlobalObjectInlines.h"
#include "JSDOMOperation.h"
#include "JSDOMWrapperCache.h"
#include "ScriptExecutionContext.h"
#include "WebCoreJSClientData.h"
#include <JavaScriptCore/FunctionPrototype.h>
#include <JavaScriptCore/HeapAnalyzer.h>

#include <JavaScriptCore/JSDestructibleObjectHeapCellType.h>
#include <JavaScriptCore/SlotVisitorMacros.h>
#include <JavaScriptCore/SubspaceInlines.h>
#include <wtf/GetPtr.h>
#include <wtf/PointerPreparations.h>
#include <wtf/URL.h>
#include <JavaScriptCore/BuiltinNames.h>

#include "JSBufferEncodingType.h"
#include <JavaScriptCore/JSBase.h>
#if ENABLE(MEDIA_SOURCE)
#include "BufferMediaSource.h"
#include "JSMediaSource.h"
#endif

// #include <JavaScriptCore/JSTypedArrayViewPrototype.h>
#include <JavaScriptCore/JSArrayBufferViewInlines.h>

#include "BunClientData.h"
#include <JavaScriptCore/Weak.h>
#include <JavaScriptCore/WeakInlines.h>

extern "C" void Bun__onSinkDestroyed(uintptr_t destructor, void* sinkPtr);
namespace WebCore {
using namespace JSC;

${classes.map(name => `extern "C" size_t ${name}__memoryCost(void* sinkPtr);`).join("\n")}
${classes.map(name => `extern "C" void ${name}__controllerDetached(void* sinkPtr, JSC::EncodedJSValue controllerValue);`).join("\n")}
${classes.map(name => `extern "C" void ${name}__controllerFinalize(void* sinkPtr);`).join("\n")}

const ClassInfo JSReadableSinkControllerBase::s_info = { "ReadableSinkController"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(JSReadableSinkControllerBase) };
`;
  var templ = head;

  for (let name of classes) {
    const { className, controller, prototypeName, controllerName, controllerPrototypeName, constructor } = names(name);
    templ += `

  void ${className}::ref() {
    if (!m_sinkPtr)
      return;

    m_refCount++;
    if (m_refCount == 1) {
      ${name}__updateRef(m_sinkPtr, true);
    }
  }

  void ${className}::unref() {
    if (!m_sinkPtr)
      return;

      m_refCount = std::max(0, m_refCount - 1);
      if (!m_refCount)
      {
        ${name}__updateRef(m_sinkPtr, false);
      }
  }

JSC_DEFINE_HOST_FUNCTION(${name}__ref, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    auto* sink = dynamicDowncast<WebCore::${className}>(callFrame->thisValue());
    if (sink) [[likely]] {
        sink->ref();
    }
    return JSC::JSValue::encode(JSC::jsUndefined());

}


JSC_DEFINE_HOST_FUNCTION(${name}__unref, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    auto* sink = dynamicDowncast<WebCore::${className}>(callFrame->thisValue());
    if (sink) [[likely]] {
        sink->unref();
    }
    return JSC::JSValue::encode(JSC::jsUndefined());

}

JSC_DEFINE_CUSTOM_GETTER(function${name}__getter, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::EncodedJSValue thisValue, JSC::PropertyName))
{
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);

    return JSC::JSValue::encode(globalObject->${name}());
}

size_t ${className}::estimatedSize(JSCell* cell, JSC::VM& vm) {
    return Base::estimatedSize(cell, vm) + ${className}::memoryCost(uncheckedDowncast<${className}>(cell)->wrapped());
}

size_t ${className}::memoryCost(void* sinkPtr) {
    if (!sinkPtr)
        return 0;

    return ${name}__memoryCost(sinkPtr);
}

size_t ${controller}::memoryCost(void* sinkPtr) {
    if (!sinkPtr)
        return 0;

    return ${name}__memoryCost(sinkPtr);
}

size_t ${controller}::estimatedSize(JSCell* cell, JSC::VM& vm) {
    return Base::estimatedSize(cell, vm) + ${controller}::memoryCost(uncheckedDowncast<${controller}>(cell)->wrapped());
}

// The body of the controller's close(). \`reason\` is the empty value for a
// clean close; any other value, undefined included, tells the sink its
// source failed with that reason.
static JSC::EncodedJSValue ${controller}__closeWithReason(JSC::JSGlobalObject* lexicalGlobalObject, WebCore::${controller}* controller, JSC::EncodedJSValue reason)
{
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);

    void *ptr = controller->wrapped();
    if (ptr == nullptr) {
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    // Null the native pointer before running any JS. detach() fires the
    // onClose callback, which can re-enter the event loop and free the
    // sink (e.g. handle_resolve_stream -> destroy_sink) while ptr is still
    // live on our stack. Do the native close first, then let detach() run
    // the JS callback once we no longer need ptr.
    ${name}__controllerDetached(ptr, JSC::JSValue::encode(controller));
    controller->m_sinkPtr = nullptr;

    ${name}__close(lexicalGlobalObject, ptr, reason);

    // detach() must still fire onClose (it transitions the direct
    // ReadableStream to closed and settles its close promise)
    // even if the native close threw, matching the pre-reorder behaviour.
    // Stash and rethrow around it; the sink's error wins over any onClose
    // error.
    if (JSC::Exception* pending = scope.exception()) [[unlikely]] {
        if (!scope.tryClearException()) {
            return {};
        }
        controller->detach(JSC::JSValue::decode(reason));
        (void)scope.tryClearException();
        scope.throwException(lexicalGlobalObject, pending);
        return {};
    }

    controller->detach(JSC::JSValue::decode(reason));
    RETURN_IF_EXCEPTION(scope, {});
    return JSC::JSValue::encode(JSC::jsUndefined());
}

JSC_DECLARE_HOST_FUNCTION(${controller}__close);
JSC_DEFINE_HOST_FUNCTION(${controller}__close, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    WebCore::${controller}* controller = dynamicDowncast<WebCore::${controller}>(callFrame->thisValue());
    if (!controller) {
        scope.throwException(globalObject, JSC::createTypeError(globalObject, "Expected ${controller}"_s));
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    // close(error?): a falsy argument is the same clean close as close(),
    // the truthiness rule directStreamOnClose uses for its reason. The
    // pump reports a failed source through closeSinkControllerWithError.
    JSC::JSValue error = callFrame->argument(0);
    JSC::EncodedJSValue reason = error.toBoolean(lexicalGlobalObject) ? JSC::JSValue::encode(error) : JSC::JSValue::encode(JSC::JSValue());
    RELEASE_AND_RETURN(scope, ${controller}__closeWithReason(lexicalGlobalObject, controller, reason));
}

static JSC::EncodedJSValue ${controller}__endImpl(JSC::JSGlobalObject* lexicalGlobalObject, WebCore::${controller}* controller)
{
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);

    void *ptr = controller->wrapped();
    if (ptr == nullptr) {
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    // Null the native pointer before running any JS. detach() fires the
    // onClose callback, which can re-enter the event loop and free the
    // sink (e.g. handle_resolve_stream -> destroy_sink) while ptr is still
    // live on our stack. Do the native end first, then let detach() run
    // the JS callback once we no longer need ptr.
    ${name}__controllerDetached(ptr, JSC::JSValue::encode(controller));
    controller->m_sinkPtr = nullptr;

    auto result = ${name}__endWithSink(ptr, lexicalGlobalObject);

    // detach() must still fire onClose (it transitions the direct
    // ReadableStream to closed and settles its close promise)
    // even if the native end threw, matching the pre-reorder behaviour.
    // Stash and rethrow around it; the sink's error wins over any onClose
    // error.
    if (JSC::Exception* pending = scope.exception()) [[unlikely]] {
        if (!scope.tryClearException()) {
            return {};
        }
        controller->detach();
        (void)scope.tryClearException();
        scope.throwException(lexicalGlobalObject, pending);
        return {};
    }

    controller->detach();
    RETURN_IF_EXCEPTION(scope, {});
    return result;
}

JSC_DECLARE_HOST_FUNCTION(${controller}__end);
JSC_DEFINE_HOST_FUNCTION(${controller}__end, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    WebCore::${controller}* controller = dynamicDowncast<WebCore::${controller}>(callFrame->thisValue());
    if (!controller) {
        scope.throwException(lexicalGlobalObject, JSC::createTypeError(lexicalGlobalObject, "Expected ${controller}"_s));
        return {};
    }
    RELEASE_AND_RETURN(scope, ${controller}__endImpl(lexicalGlobalObject, controller));
}

extern "C" JSC::EncodedJSValue ${name}__getInternalFd(void* sinkPtr);

// TODO: how to make this a property callback. then, we can expose this as a documented field
// It should not be shipped as a function call.
JSC_DEFINE_HOST_FUNCTION(${name}__getFd, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    WebCore::${className}* sink = dynamicDowncast<WebCore::${className}>(callFrame->thisValue());
    if (!sink) {
        scope.throwException(globalObject, JSC::createTypeError(globalObject, "Expected ${name}"_s));
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    void *ptr = sink->wrapped();
    if (ptr == nullptr) {
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    return ${name}__getInternalFd(ptr);
}

JSC_DECLARE_HOST_FUNCTION(${name}__doClose);
JSC_DEFINE_HOST_FUNCTION(${name}__doClose, (JSC::JSGlobalObject * lexicalGlobalObject, JSC::CallFrame *callFrame))
{
    
    auto& vm = lexicalGlobalObject->vm();
    auto scope = DECLARE_THROW_SCOPE(vm);
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(lexicalGlobalObject);
    WebCore::${className}* sink = dynamicDowncast<WebCore::${className}>(callFrame->thisValue());
    if (!sink) {
        scope.throwException(globalObject, JSC::createTypeError(globalObject, "Expected ${name}"_s));
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    void *ptr = sink->wrapped();
    if (ptr == nullptr) {
        return JSC::JSValue::encode(JSC::jsUndefined());
    }

    sink->detach();
    ${name}__close(lexicalGlobalObject, ptr, JSC::JSValue::encode(JSC::JSValue()));
    // detach() nulled m_sinkPtr so ~${className} won't finalize ptr; do the
    // destructor's teardown (onDestroy first so Subprocess clears its weak
    // back-pointer, then __finalize) here instead, even if __close threw.
    if (auto destroy = std::exchange(sink->m_onDestroy, 0)) {
        Bun__onSinkDestroyed(destroy, ptr);
    }
    ${name}__finalize(ptr);
    RETURN_IF_EXCEPTION(scope, {});
    return JSC::JSValue::encode(JSC::jsUndefined());
}


`;
  }

  templ += `
#include "JSSink.lut.h"
  `;

  for (let name of classes) {
    const { className, controller, prototypeName, controllerPrototypeName, constructor, controllerName } = names(name);
    templ += `
#pragma mark - ${name}

class ${prototypeName} final : public JSC::JSNonFinalObject {
public:
    using Base = JSC::JSNonFinalObject;
    static constexpr unsigned StructureFlags = Base::StructureFlags | HasStaticPropertyTable;

    static ${prototypeName}* create(JSC::VM& vm, JSGlobalObject* globalObject, JSC::Structure* structure)
    {
        ${prototypeName}* ptr = new (NotNull, Bun::allocatePlainObjectCell(vm, sizeof(${prototypeName}))) ${prototypeName}(vm, globalObject, structure);
        ptr->finishCreation(vm, globalObject);
        return ptr;
    }

    DECLARE_INFO;
    template<typename CellType, JSC::SubspaceAccess>
    static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
    {
        STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${prototypeName}, Base);
        return &vm.plainObjectSpace();
    }
    static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
    {
        return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::ObjectType, StructureFlags), info());
    }

private:
    ${prototypeName}(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure)
        : Base(vm, structure)
    {
    }

    void finishCreation(JSC::VM&, JSC::JSGlobalObject*);
};
STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${prototypeName}, ${prototypeName}::Base);

class ${controllerPrototypeName} final : public JSC::JSNonFinalObject {
    public:
        using Base = JSC::JSNonFinalObject;
        static constexpr unsigned StructureFlags = Base::StructureFlags | HasStaticPropertyTable;
    
        static ${controllerPrototypeName}* create(JSC::VM& vm, JSGlobalObject* globalObject, JSC::Structure* structure)
        {
            ${controllerPrototypeName}* ptr = new (NotNull, Bun::allocatePlainObjectCell(vm, sizeof(${controllerPrototypeName}))) ${controllerPrototypeName}(vm, globalObject, structure);
            ptr->finishCreation(vm, globalObject);
            return ptr;
        }
    
        DECLARE_INFO;
        template<typename CellType, JSC::SubspaceAccess>
        static JSC::GCClient::IsoSubspace* subspaceFor(JSC::VM& vm)
        {
            STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${controllerPrototypeName}, Base);
            return &vm.plainObjectSpace();
        }
        static JSC::Structure* createStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::JSValue prototype)
        {
            return Bun::createClassStructure(vm, globalObject, prototype, JSC::TypeInfo(JSC::ObjectType, StructureFlags), info());
        }
    
    private:
        ${controllerPrototypeName}(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure)
            : Base(vm, structure)
        {
        }
    
        void finishCreation(JSC::VM&, JSC::JSGlobalObject*);
    };
    STATIC_ASSERT_ISO_SUBSPACE_SHARABLE(${controllerPrototypeName}, ${controllerPrototypeName}::Base);

const ClassInfo ${prototypeName}::s_info = { "${name}"_s, &Base::s_info, &JS${name}PrototypeTable, nullptr, CREATE_METHOD_TABLE(${prototypeName}) };
const ClassInfo ${className}::s_info = { "${name}"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${className}) };
const ClassInfo ${constructor}::s_info = { "${name}"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${constructor}) };


const ClassInfo ${controllerPrototypeName}::s_info = { "${controllerName}"_s, &Base::s_info, &${controllerPrototypeName}Table, nullptr, CREATE_METHOD_TABLE(${controllerPrototypeName}) };
const ClassInfo ${controller}::s_info = { "${controllerName}"_s, &Base::s_info, nullptr, nullptr, CREATE_METHOD_TABLE(${controller}) };

${className}::~${className}()
{
    if (m_onDestroy) {
        Bun__onSinkDestroyed(m_onDestroy, m_sinkPtr);
    }

    if (m_sinkPtr) {
        ${name}__finalize(m_sinkPtr);
    }
}


${controller}::~${controller}()
{
    if (m_onDestroy) {
        Bun__onSinkDestroyed(m_onDestroy, m_sinkPtr);
    }

    if (m_sinkPtr) {
        ${name}__controllerDetached(m_sinkPtr, JSC::JSValue::encode(this));
        ${name}__controllerFinalize(m_sinkPtr);
    }
}

JSObject* ${className}::createPrototype(VM& vm, JSDOMGlobalObject& globalObject)
{
    return ${prototypeName}::create(vm, &globalObject, ${prototypeName}::createStructure(vm, &globalObject, globalObject.objectPrototype()));
}

JSObject* JS${controllerName}::createPrototype(VM& vm, JSDOMGlobalObject& globalObject)
{
    return ${controllerPrototypeName}::create(vm, &globalObject, ${controllerPrototypeName}::createStructure(vm, &globalObject, globalObject.objectPrototype()));
}

void JS${controllerName}::detach(JSC::JSValue reason) {
    if (reason && !m_failReason)
        m_failReason.set(this->vm(), this, reason);
    auto* sinkPtr = std::exchange(m_sinkPtr, nullptr);
    auto destroy = std::exchange(m_onDestroy, 0);

    if (destroy) {
        Bun__onSinkDestroyed(destroy, sinkPtr);
    }

    if (sinkPtr) {
        ${name}__controllerDetached(sinkPtr, JSC::JSValue::encode(this));
    }

    if (m_sourceKind == SinkSource::None) {
        clearReadableStream();
        return;
    }
    // A sink whose close re-enters here (FileSink's on_close runs inside close(error)) detaches before closeWithReason passes the reason; m_failReason already has it.
    if (!reason)
        reason = m_failReason.get();
    Bun::WebStreams::sinkControllerOnClose(this->globalObject(), this, reason ? reason : JSC::jsUndefined(), /* sinkClosed */ false);
}
`;

    templ += `

${constructor}* ${constructor}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, JSObject* prototype)
{
    ${constructor}* ptr = new (NotNull, JSC::allocateCell<${constructor}>(vm)) ${constructor}(vm, structure, ${name}__construct);
    ptr->finishCreation(vm, globalObject, prototype);
    return ptr;
}

${className}* ${className}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* sinkPtr, uintptr_t onDestroy)
{
    ${className}* ptr = new (NotNull, JSC::allocateCell<${className}>(vm)) ${className}(vm, structure, sinkPtr, onDestroy);
    ptr->finishCreation(vm);
    return ptr;
}

${controller}* ${controller}::create(JSC::VM& vm, JSC::JSGlobalObject* globalObject, JSC::Structure* structure, void* sinkPtr, uintptr_t onDestroy)
{
    ${controller}* ptr = new (NotNull, JSC::allocateCell<${controller}>(vm)) ${controller}(vm, structure, sinkPtr, onDestroy);
    ptr->finishCreation(vm);
    return ptr;
}

void ${constructor}::finishCreation(VM& vm, JSC::JSGlobalObject* globalObject, JSObject* prototype)
{
    Base::finishCreation(vm);
    ASSERT(inherits(info()));
    initializeProperties(vm, globalObject, prototype);
}

JSC::EncodedJSValue JSC_HOST_CALL_ATTRIBUTES ${constructor}::construct(JSC::JSGlobalObject* globalObject, JSC::CallFrame* callFrame) {
    return ${name}__construct(globalObject, callFrame);
}


void ${constructor}::initializeProperties(VM& vm, JSC::JSGlobalObject* globalObject, JSObject* prototype)
{
    putDirect(vm, vm.propertyNames->length, jsNumber(0), JSC::PropertyAttribute::ReadOnly | JSC::PropertyAttribute::DontEnum);
    JSString* nameString = jsNontrivialString(vm, "${name}"_s);
    m_originalName.set(vm, this, nameString);
    putDirect(vm, vm.propertyNames->name, nameString, JSC::PropertyAttribute::ReadOnly | JSC::PropertyAttribute::DontEnum);
}

void ${prototypeName}::finishCreation(JSC::VM& vm, JSC::JSGlobalObject* globalObject)
{
    Base::finishCreation(vm);
    Bun::reifyStaticPropertyTable(vm, ${className}::info(), ${className}PrototypeTableValues, *this);
    putDirect(vm, JSC::Identifier::fromString(vm, "sinkId"_s), JSC::jsNumber(${className}::Sink), JSC::PropertyAttribute::ReadOnly | JSC::PropertyAttribute::DontEnum);
    Bun::putToStringTagWithoutTransition(vm, this, info());
}

void ${controllerPrototypeName}::finishCreation(JSC::VM& vm, JSC::JSGlobalObject* globalObject)
{
    Base::finishCreation(vm);
    Bun::reifyStaticPropertyTable(vm, ${controller}::info(), ${controller}PrototypeTableValues, *this);
    putDirect(vm, JSC::Identifier::fromString(vm, "sinkId"_s), JSC::jsNumber(${className}::Sink), JSC::PropertyAttribute::ReadOnly | JSC::PropertyAttribute::DontEnum);
    Bun::putToStringTagWithoutTransition(vm, this, info());
}

void ${className}::finishCreation(VM& vm)
{
    Base::finishCreation(vm);
    ASSERT(inherits(info()));
}

void ${controller}::finishCreation(VM& vm)
{
    Base::finishCreation(vm);
    ASSERT(inherits(info()));
}

extern "C" void ${name}__setDestroyCallback(EncodedJSValue encodedValue, uintptr_t callback)
{
    JSValue value = JSValue::decode(encodedValue);
    if (auto* sink = dynamicDowncast<WebCore::${className}>(value)) {
        sink->m_onDestroy = callback;
    } else if (auto* controller = dynamicDowncast<WebCore::${controller}>(value)) {
        controller->m_onDestroy = callback;
    }
}

void ${className}::analyzeHeap(JSCell* cell, HeapAnalyzer& analyzer)
{
    Base::analyzeHeap(cell, analyzer);    
    auto* thisObject = uncheckedDowncast<${className}>(cell);
    if (void* wrapped = thisObject->wrapped()) {
        analyzer.setWrappedObjectForCell(cell, wrapped);
        // if (thisObject->scriptExecutionContext())
        //     analyzer.setLabelForCell(cell, makeString("url ", thisObject->scriptExecutionContext()->url().string()));
    }
    
}

void ${controller}::analyzeHeap(JSCell* cell, HeapAnalyzer& analyzer)
{
    Base::analyzeHeap(cell, analyzer);
    auto* thisObject = uncheckedDowncast<${controller}>(cell);
    if (void* wrapped = thisObject->wrapped()) {
        analyzer.setWrappedObjectForCell(cell, wrapped);
        // if (thisObject->scriptExecutionContext())
        //     analyzer.setLabelForCell(cell, makeString("url ", thisObject->scriptExecutionContext()->url().string()));
    }

    auto& vm = cell->vm();
    if (auto* source = thisObject->m_source.get())
        analyzer.analyzePropertyNameEdge(cell, source, Identifier::fromString(vm, "source"_s).impl());
    if (auto* closePromise = thisObject->m_closePromise.get())
        analyzer.analyzePropertyNameEdge(cell, closePromise, Identifier::fromString(vm, "closePromise"_s).impl());
}


template<typename Visitor>
void ${controller}::visitChildrenImpl(JSCell* cell, Visitor& visitor)
{
    ${controller}* thisObject = uncheckedDowncast<${controller}>(cell);
    ASSERT_GC_OBJECT_INHERITS(thisObject, info());
    Base::visitChildren(thisObject, visitor);
    
    visitor.append(thisObject->m_source);
    visitor.append(thisObject->m_closePromise);
    visitor.append(thisObject->m_failReason);
    visitor.append(thisObject->m_readableStream);
    visitor.append(thisObject->m_pipeDone);

    void* ptr = thisObject->m_sinkPtr;
    if (ptr)
      visitor.addOpaqueRoot(ptr);
}

DEFINE_VISIT_CHILDREN(${controller});

template<typename Visitor>
void ${className}::visitChildrenImpl(JSCell* cell, Visitor& visitor)
{
    ${className}* thisObject = uncheckedDowncast<${className}>(cell);
    ASSERT_GC_OBJECT_INHERITS(thisObject, info());
    Base::visitChildren(thisObject, visitor);
    void* ptr = thisObject->m_sinkPtr;
    if (ptr)
      visitor.addOpaqueRoot(ptr);
}

DEFINE_VISIT_CHILDREN(${className});


void ${className}::destroy(JSCell* cell)
{
    static_cast<${className}*>(cell)->${className}::~${className}();
}


void ${controller}::destroy(JSCell* cell)
{
    static_cast<${controller}*>(cell)->${controller}::~${controller}();
}


`;
  }

  templ += `
  JSObject* createJSSinkPrototype(JSC::VM& vm, JSC::JSGlobalObject* globalObject, SinkID sinkID)
  {
      switch (sinkID) {
    `;
  for (let name of classes) {
    templ += `
    case ${name}:
        return JS${name}Prototype::create(vm, globalObject, JS${name}Prototype::createStructure(vm, globalObject, globalObject->objectPrototype()));
`;
  }
  templ += `
default: 
    RELEASE_ASSERT_NOT_REACHED();
    }
}`;

  templ += `
JSObject* createJSSinkControllerPrototype(JSC::VM& vm, JSC::JSGlobalObject* globalObject, SinkID sinkID)
{
    switch (sinkID) {
  `;
  for (let name of classes) {
    const { controllerPrototypeName } = names(name);
    templ += `
  case ${name}:
      return ${controllerPrototypeName}::create(vm, globalObject, ${controllerPrototypeName}::createStructure(vm, globalObject, globalObject->objectPrototype()));
`;
  }
  templ += `
default: 
  RELEASE_ASSERT_NOT_REACHED();
  }
}`;

  templ += `
Structure* createJSSinkControllerStructure(JSC::VM& vm, JSC::JSGlobalObject* globalObject, SinkID sinkID)
{
    switch (sinkID) {
  `;
  for (let name of classes) {
    templ += `
  case ${name}: {
    auto* prototype = createJSSinkControllerPrototype(vm, globalObject, sinkID);
    return JSReadable${name}Controller::createStructure(vm, globalObject, prototype);
  }
`;
  }
  templ += `
default:
    RELEASE_ASSERT_NOT_REACHED();
  }
}`;

  const footer = `
} // namespace WebCore

`;
  templ += footer;

  for (let name of classes) {
    const { className, controller, prototypeName, controllerPrototypeName, constructor } = names(name);

    templ += `
extern "C" JSC::EncodedJSValue ${name}__createObject(JSC::JSGlobalObject* arg0, void* sinkPtr, uintptr_t destructor)
{
    auto& vm = arg0->vm();
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(arg0);
    JSC::Structure* structure = globalObject->${name}Structure();
    return JSC::JSValue::encode(WebCore::JS${name}::create(vm, globalObject, structure, sinkPtr, destructor));
}

extern "C" void* ${name}__fromJS(JSC::EncodedJSValue value)
{
    if (auto* sink = dynamicDowncast<WebCore::JS${name}>(JSC::JSValue::decode(value)))
        return sink->wrapped();

    if (auto* controller = dynamicDowncast<WebCore::${controller}>(JSC::JSValue::decode(value)))
        return controller->wrapped() ? controller->wrapped() : (controller->m_destinationClosed ? (void*)2 : nullptr);

    return (void*)1;
}

// JSSink::assign_to_stream (Sink.rs): records the controller as the sink's source, then pumps via JSSinkController__assignToStream.
extern "C" JSC::EncodedJSValue ${name}__createController(JSC::JSGlobalObject* arg0, void* sinkPtr)
{
    auto& vm = arg0->vm();
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(arg0);

    JSC::Structure* structure = WebCore::getDOMStructure<WebCore::${controller}>(vm, *globalObject);
    return JSC::JSValue::encode(WebCore::${controller}::create(vm, globalObject, structure, sinkPtr, 0));
}

`;
  }

  templ += `
JSC::EncodedJSValue WebCore::JSReadableSinkControllerBase::end(JSC::JSGlobalObject* globalObject)
{
    switch (m_sinkId) {
${classes
  .map(
    name =>
      `    case WebCore::SinkID::${name}: return WebCore::${names(name).controller}__endImpl(globalObject, uncheckedDowncast<WebCore::${names(name).controller}>(this));`,
  )
  .join("\n")}
    default: break;
    }
    RELEASE_ASSERT_NOT_REACHED();
}

JSC::EncodedJSValue WebCore::JSReadableSinkControllerBase::close(JSC::JSGlobalObject* globalObject, JSC::JSValue reason)
{
    JSC::EncodedJSValue encoded = reason.toBoolean(globalObject) ? JSC::JSValue::encode(reason) : JSC::JSValue::encode(JSC::JSValue());
    switch (m_sinkId) {
${classes
  .map(
    name =>
      `    case WebCore::SinkID::${name}: return WebCore::${names(name).controller}__closeWithReason(globalObject, uncheckedDowncast<WebCore::${names(name).controller}>(this), encoded);`,
  )
  .join("\n")}
    default: break;
    }
    RELEASE_ASSERT_NOT_REACHED();
}

extern "C" void JSSinkController__onReady(JSC::EncodedJSValue controllerValue, JSC::EncodedJSValue amt, JSC::EncodedJSValue offset)
{
    (void)amt;
    (void)offset;
    auto* controller = static_cast<WebCore::JSReadableSinkControllerBase*>(JSC::JSValue::decode(controllerValue).getObject());
    if (controller->m_sourceKind != WebCore::SinkSource::Pump)
        return;
    Bun::WebStreams::sinkControllerOnReady(controller->globalObject(), controller);
}

extern "C" void JSSinkController__onClose(JSC::EncodedJSValue controllerValue, JSC::EncodedJSValue reason)
{
    auto* controller = static_cast<WebCore::JSReadableSinkControllerBase*>(JSC::JSValue::decode(controllerValue).getObject());
    controller->m_destinationClosed = true;
    if (controller->m_sourceKind == WebCore::SinkSource::None)
        return;
    Bun::WebStreams::sinkControllerOnClose(controller->globalObject(), controller, JSC::JSValue::decode(reason), /* sinkClosed */ true);
}

extern "C" JSC::EncodedJSValue JSSinkController__assignToStream(JSC::JSGlobalObject* arg0, JSC::EncodedJSValue stream, JSC::EncodedJSValue controllerValue)
{
    Zig::GlobalObject* globalObject = reinterpret_cast<Zig::GlobalObject*>(arg0);
    return globalObject->assignToStream(JSC::JSValue::decode(stream), JSC::JSValue::decode(controllerValue));
}

static WebCore::JSReadableSinkControllerBase* pipeCell(JSC::EncodedJSValue value)
{
    return static_cast<WebCore::JSReadableSinkControllerBase*>(JSC::JSValue::decode(value).getObject());
}

extern "C" void JSSinkController__setPipe(JSC::EncodedJSValue cell, JSC::EncodedJSValue stream, JSC::EncodedJSValue done)
{
    auto* controller = pipeCell(cell);
    auto& vm = controller->vm();
    if (auto* streamObject = JSC::JSValue::decode(stream).getObject()) {
        controller->m_readableStream.set(vm, controller, streamObject);
        controller->m_pipeHoldsStream = true;
    } else {
        controller->m_pipeHoldsStream = false;
        controller->clearReadableStream();
    }
    controller->m_pipeDone.setMayBeNull(vm, controller, dynamicDowncast<JSC::JSPromise>(JSC::JSValue::decode(done)));
}

extern "C" JSC::EncodedJSValue JSSinkController__pipeStream(JSC::EncodedJSValue cell)
{
    auto* stream = pipeCell(cell)->m_readableStream.get();
    return JSC::JSValue::encode(stream ? JSC::JSValue(stream) : JSC::JSValue());
}

extern "C" void JSSinkController__clearPipeStream(JSC::EncodedJSValue cell)
{
    auto* controller = pipeCell(cell);
    controller->m_pipeHoldsStream = false;
    controller->clearReadableStream();
}

extern "C" void JSSinkController__setPipeDone(JSC::EncodedJSValue cell, JSC::EncodedJSValue done)
{
    auto* controller = pipeCell(cell);
    controller->m_pipeDone.setMayBeNull(controller->vm(), controller, dynamicDowncast<JSC::JSPromise>(JSC::JSValue::decode(done)));
}

extern "C" JSC::EncodedJSValue JSSinkController__pipeDone(JSC::EncodedJSValue cell)
{
    auto* done = pipeCell(cell)->m_pipeDone.get();
    return JSC::JSValue::encode(done ? JSC::JSValue(done) : JSC::JSValue());
}

extern "C" JSC::EncodedJSValue JSSinkController__takePipeDone(JSC::EncodedJSValue cell)
{
    auto* controller = pipeCell(cell);
    auto* done = controller->m_pipeDone.get();
    controller->m_pipeDone.clear();
    return JSC::JSValue::encode(done ? JSC::JSValue(done) : JSC::JSValue());
}

// The pipe's failure value shares m_failReason: close(error) stores the same value there, and every other writer runs after pull() settled.
extern "C" void JSSinkController__setPipeError(JSC::EncodedJSValue cell, JSC::EncodedJSValue error)
{
    auto* controller = pipeCell(cell);
    if (!controller->m_failReason)
        controller->m_failReason.set(controller->vm(), controller, JSC::JSValue::decode(error));
}

extern "C" JSC::EncodedJSValue JSSinkController__pipeError(JSC::EncodedJSValue cell)
{
    return JSC::JSValue::encode(pipeCell(cell)->m_failReason.get());
}

extern "C" void JSSinkController__detachPtr(JSC::EncodedJSValue controllerValue)
{
    JSC::JSValue value = JSC::JSValue::decode(controllerValue);
${classes
  .map(
    name =>
      `    if (auto* controller = dynamicDowncast<WebCore::${names(name).controller}>(value)) { controller->detach(); return; }`,
  )
  .join("\n")}
}

namespace WebCore {

void closeSinkControllerWithError(JSC::JSGlobalObject* globalObject, JSReadableSinkControllerBase* controller, JSC::JSValue error)
{
    JSC::EncodedJSValue reason = JSC::JSValue::encode(error);
${classes
  .map(
    name =>
      `    if (auto* typed = dynamicDowncast<${names(name).controller}>(controller)) { ${names(name).controller}__closeWithReason(globalObject, typed, reason); return; }`,
  )
  .join("\n")}
}

} // namespace WebCore
`;
  return templ;
}

// ── Rust output ────────────────────────────────────────────────────────────
// Emits `generated_jssink.rs`: `#[unsafe(no_mangle)] extern "C"` thunks for the
// per-sink symbols the C++ side (JSSink.cpp / headers.h) declares as
// `BUN_DECLARE_HOST_FUNCTION(${name}__{construct,write,end,flush,start})` plus
// the two non-host-fn externs `${name}__getInternalFd` / `${name}__memoryCost`.
// Each thunk calls an inherent method on the real sink struct in
// `crate::webcore`; a missing method is a compile error.
//
// Calling convention: `BUN_DECLARE_HOST_FUNCTION` and `endWithSink` use
// `SYSV_ABI` (= `extern "sysv64"` on win-x64, `"C"` elsewhere) — wrapped in
// `bun_jsc::jsc_host_abi!`. The remaining `ZIG_DECL` / plain `extern "C"`
// symbols (finalize/close/updateRef/getInternalFd/memoryCost) stay `extern "C"`.
function rustSink() {
  // All sink structs live (or will live) under `crate::webcore`.
  const sinkPaths: Record<string, string> = {
    ArrayBufferSink: "crate::webcore::array_buffer_sink::ArrayBufferSink",
    FileSink: "crate::webcore::file_sink::FileSink",
    HTTPResponseSink: "crate::webcore::streams::HTTPResponseSink",
    HTTPSResponseSink: "crate::webcore::streams::HTTPSResponseSink",
    NetworkSink: "crate::webcore::streams::NetworkSink",
    FetchRequestBodySink: "crate::webcore::fetch::fetch_request_body_sink::FetchRequestBodySink",
    HTMLRewriterSink: "crate::api::html_rewriter::RewriterPipe",
  };

  const symbols: string[] = [];
  // Safe-body thunks: every body either routes through a safe `host_fn::*`
  // helper (which centralises the raw-pointer deref + SAFETY contract for
  // `JSGlobalObject` / `CallFrame`) or takes its `m_sinkPtr` param as
  // `&`/`&mut ${name}` directly (ABI-identical to `void*` for non-null inputs;
  // every JSSink.cpp call site null-checks `m_sinkPtr`/`wrapped()` before
  // calling). The SYSV-ABI thunks are `unsafe fn` (mandated by `jsc_host_abi!`;
  // bodies remain safe — only C++ calls these); the plain-C thunks stay safe,
  // except `__finalize`, which may free the sink and so takes `*mut` (below).
  let templ = `// Auto-generated by src/codegen/generate-jssink.ts — DO NOT EDIT.
//
// Per-sink \`#[unsafe(no_mangle)]\` thunks satisfying the externs declared by
// JSSink.cpp / headers.h. Each thunk calls an inherent method on the real sink
// struct (re-exported here as \`\${name}\`). No trait, no opaque placeholder —
// a missing method is a hard compile error.
//
// Calling convention: \`BUN_DECLARE_HOST_FUNCTION\` and \`endWithSink\` use
// SYSV ABI (\`jsc_host_abi!\`); the \`ZIG_DECL\` / plain \`extern "C"\` symbols
// (finalize/close/updateRef/getInternalFd/memoryCost) stay \`extern "C"\`.
//
// Safe-body: \`m_sinkPtr\` params are typed \`&\`/\`&mut\` (every C++ caller
// null-checks first); host fns route through \`bun_jsc::host_fn::host_fn_static\`.
// \`__finalize\` is the exception: it may free the sink, so it keeps \`*mut\`.

#[allow(dead_code, unreachable_pub, unused)]
use bun_jsc::{self, host_fn, CallFrame, JSGlobalObject, JSValue};

`;

  for (const name of classes) {
    const rustPath = sinkPaths[name] ?? `crate::webcore::streams::${name}`;
    const JSSinkT = `crate::webcore::sink::JSSink::<${name}>`;
    templ += `// ════════════════════════════════════════════════════════════════════════════
// ${name}
// ════════════════════════════════════════════════════════════════════════════

/// Native backing type for \`JS${name}.m_sinkPtr\`.
#[allow(dead_code, unreachable_pub, unused)]
pub(crate) use ${rustPath} as ${name};

`;

    const hostFns = ["construct", "write", "end", "flush", "start"] as const;
    for (const fn of hostFns) {
      const sym = `${name}__${fn}`;
      symbols.push(sym);
      // BUN_DECLARE_HOST_FUNCTION → JSC_HOST_CALL_ATTRIBUTES → SYSV ABI.
      templ += `bun_jsc::jsc_host_abi! {
    #[allow(dead_code, unreachable_pub, unused)]
    #[unsafe(no_mangle)]
    pub unsafe fn ${sym}(global: &JSGlobalObject, callframe: &CallFrame) -> JSValue {
        host_fn::host_fn_static(global, callframe, ${JSSinkT}::js_${fn})
    }
}

`;
    }

    // extern "C" JSC::EncodedJSValue ${name}__getInternalFd(void* sinkPtr)
    // C++ caller passes `sink->wrapped()` (null-checked before calling).
    symbols.push(`${name}__getInternalFd`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub extern "C" fn ${name}__getInternalFd(this: &mut ${name}) -> JSValue {
    ${JSSinkT}::js_get_internal_fd(this)
}

`;

    // extern "C" size_t ${name}__memoryCost(void* sinkPtr)
    // C++ caller null-checks `sinkPtr` before calling.
    symbols.push(`${name}__memoryCost`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub extern "C" fn ${name}__memoryCost(this: &${name}) -> usize {
    ${JSSinkT}::js_memory_cost(this)
}

`;

    // ZIG_DECL void ${name}__finalize(void* sinkPtr) — called from
    // JS${name}::~JS${name} and ${name}__doClose.
    // C++ caller null-checks `m_sinkPtr` / `ptr` before calling. `*mut`, not
    // `&mut`: this call may free the sink (see `JsSinkType::finalize`).
    symbols.push(`${name}__finalize`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ${name}__finalize(this: *mut ${name}) {
    // SAFETY: C++ hands over its live \`m_sinkPtr\` once and never uses it again.
    unsafe { ${JSSinkT}::js_finalize(this) }
}

`;

    // extern "C" void ${name}__controllerFinalize(void* sinkPtr) — called from
    // ~JSReadable${name}Controller when the controller dies still attached.
    symbols.push(`${name}__controllerFinalize`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ${name}__controllerFinalize(this: *mut ${name}) {
    // SAFETY: as \`__finalize\`: the controller's live \`m_sinkPtr\`, handed over once.
    unsafe { ${JSSinkT}::js_controller_finalize(this) }
}

`;

    // extern "C" void ${name}__controllerDetached(void* sinkPtr, JSC::EncodedJSValue)
    // — called from JSReadable${name}Controller::detach() and its destructor.
    // C++ caller null-checks `m_sinkPtr` before calling.
    symbols.push(`${name}__controllerDetached`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub extern "C" fn ${name}__controllerDetached(this: &mut ${name}, controller: JSValue) {
    ${JSSinkT}::js_controller_detached(this, controller)
}

`;

    // ZIG_DECL JSC::EncodedJSValue ${name}__close(JSC::JSGlobalObject*, void* sinkPtr, JSC::EncodedJSValue reason)
    // C++ caller null-checks `ptr` before calling. `*mut`: a failing close can
    // re-enter the sink (see `JsSinkType::close_with_error`).
    symbols.push(`${name}__close`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub unsafe extern "C" fn ${name}__close(global: &JSGlobalObject, this: *mut ${name}, reason: JSValue) -> JSValue {
    // SAFETY: C++ passes its live, null-checked \`m_sinkPtr\`.
    unsafe { ${JSSinkT}::js_close(global, this, reason) }
}

`;

    // ZIG_DECL JSC::EncodedJSValue SYSV_ABI ${name}__endWithSink(void* sinkPtr, JSC::JSGlobalObject*)
    // headers.h declares this with `callconv(jsc.conv)` (SYSV_ABI) — sysv64 on
    // win-x64, "C" elsewhere. C++ caller null-checks `ptr` before calling.
    symbols.push(`${name}__endWithSink`);
    templ += `bun_jsc::jsc_host_abi! {
    #[allow(dead_code, unreachable_pub, unused)]
    #[unsafe(no_mangle)]
    pub unsafe fn ${name}__endWithSink(this: &mut ${name}, global: &JSGlobalObject) -> JSValue {
        ${JSSinkT}::js_end_with_sink(this, global)
    }
}

`;

    // ZIG_DECL void ${name}__updateRef(void* sinkPtr, bool)
    // C++ caller null-checks `m_sinkPtr` before calling.
    symbols.push(`${name}__updateRef`);
    templ += `#[allow(dead_code, unreachable_pub, unused)]
#[unsafe(no_mangle)]
pub extern "C" fn ${name}__updateRef(this: &mut ${name}, value: bool) {
    ${JSSinkT}::js_update_ref(this, value)
}

`;
  }

  templ += `// sinks: ${classes.length}, exported symbols: ${symbols.length}\n`;
  return { src: templ, symbols };
}

function lutInput() {
  let templ = "";
  for (let name of classes) {
    const { controller, controllerPrototypeName } = names(name);
    const protopad = `${controller}__close`.length;
    const padding = `${name}__doClose`.length;
    templ += `
/* Source for JS${name}PrototypeTableValues.lut.h
@begin JS${name}PrototypeTable
    close      ${`${name}__doClose`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 0
    flush      ${`${name}__flush`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 1
    end        ${`${name}__end`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 0
    start      ${`${name}__start`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 1
    write      ${`${name}__write`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 1
    ref        ${`${name}__ref`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 0
    unref      ${`${name}__unref`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 0
    _getFd      ${`${name}__getFd`.padEnd(padding + 8)} ReadOnly|DontDelete|Function 0
@end
*/


/* Source for ${controllerPrototypeName}TableValues.lut.h
@begin ${controllerPrototypeName}Table
    close        ${`${controller}__close`.padEnd(protopad + 4)}  ReadOnly|DontDelete|Function 0
    flush        ${`${name}__flush`.padEnd(protopad + 4)}  ReadOnly|DontDelete|Function 1
    end          ${`${controller}__end`.padEnd(protopad + 4)}  ReadOnly|DontDelete|Function 0
    start        ${`${name}__start`.padEnd(protopad + 4)}  ReadOnly|DontDelete|Function 1
    write        ${`${name}__write`.padEnd(protopad + 4)}  ReadOnly|DontDelete|Function 1
@end
*/
`;
  }

  return templ;
}

const outDir = resolve(process.argv[2]);
mkdirSync(outDir, { recursive: true });

writeFileSync(resolve(outDir + "/JSSink.h"), header());
writeFileSync(resolve(outDir + "/JSSink.cpp"), await implementation());
writeFileSync(resolve(outDir + "/JSSink.lut.txt"), lutInput());
{
  const { src, symbols } = rustSink();
  writeFileSync(resolve(outDir + "/generated_jssink.rs"), src);
  console.log(`generated_jssink.rs: ${classes.length} sinks, ${symbols.length} exported symbols`);
}

createHashTable(resolve(outDir + "/JSSink.lut.txt"), join(outDir, "JSSink.lut.h"));
