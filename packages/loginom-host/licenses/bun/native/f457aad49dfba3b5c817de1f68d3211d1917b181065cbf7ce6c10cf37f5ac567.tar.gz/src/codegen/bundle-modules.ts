// This script is run when you change anything in src/js/*
//
// Documentation is in src/js/README.md
//
// Originally, the builtin bundler only supported function files, but then the module files were
// added to this, which has made this entire setup extremely convoluted and a mess.
//
// One day, this entire setup should be rewritten, but also it would be cool if Bun natively
// supported macros that aren't json value -> json value. Otherwise, I'd use a real JS parser/ast
// library, instead of RegExp hacks.
import fs from "fs";
import { mkdir, writeFile } from "fs/promises";
import { builtinModules } from "node:module";
import path from "path";
import jsclasses from "./../jsc/bindings/js_classes";
import { sliceSourceCode } from "./builtin-parser";
import { createAssertClientJS, createLogClientJS } from "./client-js";
import { getJS2NativeCPP, getJS2NativeRust } from "./generate-js2native";
import { cap, checkAscii, engineStamp, sourceStamp, writeIfNotChanged, writeIfNotChangedBinary } from "./helpers";
import { createInternalModuleRegistry } from "./internal-module-registry-scanner";
import { define } from "./replacements";

const BASE = path.join(import.meta.dir, "../js");
const debug = process.argv[2] === "--debug=ON";
const CMAKE_BUILD_ROOT = process.argv[3];
const TYPES_DIR = process.argv[4];
const WEBKIT_VERSION = process.argv.find(arg => arg.startsWith("--webkit-version="))?.slice("--webkit-version=".length);

const timeString = 'Bundled "src/js" for ' + (debug ? "development" : "production");
console.time(timeString);

if (!CMAKE_BUILD_ROOT || !TYPES_DIR || !WEBKIT_VERSION) {
  console.error(
    "Usage: bun bundle-modules.ts --debug=[OFF|ON] <CMAKE_WORK_DIR> <TYPES_DIR> --webkit-version=<version>",
  );
  process.exit(1);
}

globalThis.CMAKE_BUILD_ROOT = CMAKE_BUILD_ROOT;
const bundleBuiltinFunctions = require("./bundle-functions").bundleBuiltinFunctions;

const TMP_DIR = path.join(CMAKE_BUILD_ROOT, "tmp_modules");
const CODEGEN_DIR = path.join(CMAKE_BUILD_ROOT, "codegen");
const JS_DIR = path.join(CMAKE_BUILD_ROOT, "js");

const t = new Bun.Transpiler({ loader: "tsx" });

let start = performance.now();
const silent = process.env.CLAUDECODE;
function markVerbose(log: string) {
  const now = performance.now();
  console.log(`${log} (${(now - start).toFixed(0)}ms)`);
  start = now;
}

const mark = silent ? (log: string) => {} : markVerbose;

const { moduleList, nativeModuleIds, nativeModuleEnumToId, nativeModuleEnums, requireTransformer, nativeStartIndex } =
  createInternalModuleRegistry(BASE);
globalThis.requireTransformer = requireTransformer;

// these logs surround a very weird issue where writing files and then bundling sometimes doesn't
// work, so i have lot of debug logs that blow up the console because not sure what is going on.
// that is also the reason for using `retry` when theoretically writing a file the first time
// should actually write the file.
const verbose = Bun.env.VERBOSE ? console.log : () => {};
async function retry(n, fn) {
  var err;
  while (n > 0) {
    try {
      await fn();
      return;
    } catch (e) {
      err = e;
      n--;
      await Bun.sleep(5);
    }
  }
  throw err;
}

const bunRepoRoot = path.join(CMAKE_BUILD_ROOT, "..", "..");

// Preprocess builtins
const bundledEntryPoints: string[] = [];
for (let i = 0; i < nativeStartIndex; i++) {
  try {
    const file = path.join(BASE, moduleList[i]);
    let input = fs.readFileSync(file, "utf8");

    if (!/\bexport\s+(?:function|class|const|default|{)/.test(input)) {
      if (input.includes("module.exports")) {
        throw new Error(
          "Do not use CommonJS module.exports in ESM modules. Use `export default { ... }` instead. See src/js/README.md",
        );
      } else {
        throw new Error(
          `Internal modules must have at least one ESM export statement in '${path.relative(bunRepoRoot, file)}' — see src/js/README.md`,
        );
      }
    }

    // TODO: there is no reason this cannot be converted automatically.
    // import { ... } from '...' -> `const { ... } = require('...')`
    const scannedImports = t.scan(input);
    for (const imp of scannedImports.imports) {
      if (imp.kind === "import-statement") {
        var isBuiltin = true;
        try {
          if (!builtinModules.includes(imp.path)) {
            requireTransformer(imp.path, moduleList[i]);
          }
        } catch {
          isBuiltin = false;
        }
        if (isBuiltin) {
          const err = new Error(
            `Cannot use ESM import statement within builtin modules. Use require("${imp.path}") instead. See src/js/README.md (from ${moduleList[i]})`,
          );
          err.name = "BunError";
          err["fileName"] = moduleList[i];
          throw err;
        }
      }
    }

    if (scannedImports.exports.includes("default") && scannedImports.exports.length > 1) {
      const err = new Error(
        `Using \`export default\` AND named exports together in builtin modules is unsupported. See src/js/README.md (from ${moduleList[i]})`,
      );
      err.name = "BunError";
      err["fileName"] = moduleList[i];
      throw err;
    }
    let importStatements: string[] = [];

    const processed = sliceSourceCode(
      "{" +
        input
          .replace(
            /\bimport(\s*type)?\s*(\{[^}]*\}|(\*\s*as)?\s[a-zA-Z0-9_$]+)\s*from\s*['"][^'"]+['"]/g,
            stmt => (importStatements.push(stmt), ""),
          )
          .replace(/export\s*{\s*}\s*;/g, ""),
      true,
      x => requireTransformer(x, moduleList[i]),
    );
    // Guard rail: builtin-parser.ts's regex-position heuristic only recognises
    // `/` as regex-start after `[(,=;:{]|return|=>`; a regex whose body has `)`
    // or `}` in any other position silently truncates. Fail loudly here.
    if (processed.rest.trim() !== "") {
      throw new Error(
        `sliceSourceCode truncated ${moduleList[i]} — likely a regex literal in a position builtin-parser.ts doesn't recognise. ` +
          `Leftover starts: ${processed.rest.slice(0, 80)}`,
      );
    }
    let fileToTranspile = `// GENERATED TEMP FILE - DO NOT EDIT
// Sourced from src/js/${moduleList[i]}
${importStatements.join("\n")}

${processed.result.slice(1).trim()}
;$$EXPORT$$(__intrinsic__exports).$$EXPORT_END$$;
`;

    // Attempt to optimize "$exports = ..." to a variableless return
    // otherwise, declare $exports so it works.
    let exportOptimization = false;
    fileToTranspile = fileToTranspile.replace(
      /__intrinsic__exports\s*=\s*(.*|.*\{[^\}]*}|.*\([^\)]*\))\n+\s*\$\$EXPORT\$\$\(__intrinsic__exports\).\$\$EXPORT_END\$\$;/,
      (_, a) => {
        exportOptimization = true;
        return "$$EXPORT$$(" + a.replace(/;$/, "") + ").$$EXPORT_END$$;";
      },
    );
    if (!exportOptimization) {
      fileToTranspile = `var $;` + fileToTranspile.replaceAll("__intrinsic__exports", "$");
    }
    const outputPath = path.join(TMP_DIR, moduleList[i].slice(0, -3) + ".ts");

    await mkdir(path.dirname(outputPath), { recursive: true });
    if (!fs.existsSync(path.dirname(outputPath))) {
      verbose("directory did not exist after mkdir twice:", path.dirname(outputPath));
    }

    fileToTranspile = "// @ts-nocheck\n" + fileToTranspile;

    try {
      await writeFile(outputPath, fileToTranspile);
      if (!fs.existsSync(outputPath)) {
        verbose("file did not exist after write:", outputPath);
        throw new Error("file did not exist after write: " + outputPath);
      }
      verbose("wrote to", outputPath, "successfully");
    } catch {
      await retry(3, async () => {
        await mkdir(path.dirname(outputPath), { recursive: true });
        await writeFile(outputPath, fileToTranspile);
        if (!fs.existsSync(outputPath)) {
          verbose("file did not exist after write:", outputPath);
          throw new Error("file did not exist after write: " + outputPath);
        }
        verbose("wrote to", outputPath, "successfully later");
      });
    }
    bundledEntryPoints.push(outputPath);
  } catch (error) {
    console.error(error);
    console.error(`While processing: ${moduleList[i]}`);
    process.exit(1);
  }
}

mark("Preprocess modules");

// directory caching stuff breaks this sometimes. CLI rules
const config_cli = [
  process.execPath,
  "build",
  ...bundledEntryPoints,
  ...(debug ? [] : ["--minify-syntax", "--keep-names"]),
  "--root",
  TMP_DIR,
  "--target",
  "bun",
  ...builtinModules.map(x => ["--external", x]).flat(),
  ...Object.keys(define)
    .map(x => [`--define`, `${x}=${define[x]}`])
    .flat(),
  "--define",
  `IS_BUN_DEVELOPMENT=${String(!!debug)}`,
  "--define",
  `__intrinsic__debug=${debug ? "$debug_log_enabled" : "false"}`,
  "--outdir",
  path.join(TMP_DIR, "modules_out"),
];
verbose("running: ", config_cli);
const out = Bun.spawnSync({
  cmd: config_cli,
  cwd: process.cwd(),
  env: process.env,
  stdio: ["pipe", "pipe", "pipe"],
});
if (out.exitCode !== 0) {
  console.error(out.stderr.toString());
  process.exit(out.exitCode);
}

mark("Bundle modules");

const outputs = new Map();

for (const entrypoint of bundledEntryPoints) {
  const file_path = entrypoint.slice(TMP_DIR.length + 1).replace(/\.ts$/, ".js");
  const output = fs.readFileSync(path.join(TMP_DIR, "modules_out", file_path), "utf8");
  let captured = `(function (){${output.replace("// @bun\n", "").trim()}})`;
  let usesDebug = output.includes("$debug_log");
  let usesAssert = output.includes("$assert");
  captured =
    captured
      .replace(/\$\$EXPORT\$\$\((.*)\).\$\$EXPORT_END\$\$;/, "return $1")
      .replace(/]\s*,\s*__(debug|assert)_end__\)/g, ")")
      .replace(/]\s*,\s*__debug_end__\)/g, ")")
      .replace(/import.meta.require\((.*?)\)/g, (expr, specifier) => {
        throw new Error(`Builtin Bundler: do not use import.meta.require() (in ${file_path}))`);
      })
      .replace(/return \$\nexport /, "return")
      .replace(/__intrinsic__/g, "@")
      .replace(/__no_intrinsic__/g, "") + "\n";
  captured = captured.replace(
    /function\s*\(.*?\)\s*{/,
    '$&"use strict";' +
      (usesDebug
        ? createLogClientJS(
            file_path.replace(".js", ""),
            idToPublicSpecifierOrEnumName(file_path).replace(/^node:|^bun:/, ""),
          )
        : "") +
      (usesAssert ? createAssertClientJS(idToPublicSpecifierOrEnumName(file_path).replace(/^node:|^bun:/, "")) : ""),
  );
  const errors = [...captured.matchAll(/@bundleError\((.*)\)/g)];
  if (errors.length) {
    throw new Error(`Errors in ${entrypoint}:\n${errors.map(x => x[1]).join("\n")}`);
  }

  const outputPath = path.join(JS_DIR, file_path);
  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, captured);
  outputs.set(file_path.replace(".js", ""), captured);
}

mark("Postprocesss modules");

/**
 * Physical layout order for the module-source blob: DFS post-order over the
 * static require() graph, so each module sits contiguous with its transitive
 * dependencies. Loading any builtin then reads one contiguous run of pages
 * instead of touching sources scattered across the blob. Roots are visited in
 * a fixed order (the popular entry modules first) so the layout is
 * deterministic; the graph over-approximates lazy requires, which only makes
 * neighbours of things that *might* co-load — free for layout.
 */
function layoutOrder(modules: string[], outputs: Map<string, string>): string[] {
  // The bundled sources already have require() rewritten to registry lookups,
  // `internalModuleRegistry, <index>` — the index is the position in
  // `modules`, which makes the edge list unambiguous.
  const requireRe = /internalModuleRegistry, ?(\d+)/g;
  const deps = new Map<string, string[]>();
  for (const id of modules) {
    const src = outputs.get(id.slice(0, -3).replaceAll("/", path.sep)) ?? "";
    const edges = new Set<string>();
    for (const m of src.matchAll(requireRe)) {
      const dep = modules[Number(m[1])];
      if (dep && dep !== id) edges.add(dep);
    }
    deps.set(id, [...edges]);
  }
  const hotRoots = [
    "node/fs.ts",
    "node/path.ts",
    "node/os.ts",
    "node/util.ts",
    "node/events.ts",
    "node/stream.ts",
    "node/child_process.ts",
    "node/crypto.ts",
    "node/http.ts",
    "node/https.ts",
    "node/net.ts",
    "node/url.ts",
    "node/buffer.ts",
    "node/tty.ts",
    "node/worker_threads.ts",
    "node/zlib.ts",
    "node/assert.ts",
    "node/timers.ts",
  ];
  const roots = [...hotRoots.filter(r => deps.has(r)), ...modules];
  const emitted = new Set<string>();
  const order: string[] = [];
  const visit = (id: string) => {
    if (emitted.has(id)) return;
    emitted.add(id);
    for (const dep of deps.get(id) ?? []) visit(dep);
    order.push(id);
  };
  for (const root of roots) visit(root);
  return order;
}

function idToEnumName(id: string) {
  return id
    .replace(/\.[mc]?[tj]s$/, "")
    .replace(/[^a-zA-Z0-9]+/g, " ")
    .split(" ")
    .map(x => (["jsc", "ffi", "vm", "tls", "os", "ws", "fs", "dns"].includes(x) ? x.toUpperCase() : cap(x)))
    .join("");
}

function idToPublicSpecifierOrEnumName(id: string) {
  if (id === "internal-for-testing.ts") return "bun:internal-for-testing"; // not in the `bun/` folder because it's added conditionally
  id = id.replace(/\.[mc]?[tj]s$/, "");
  if (id.startsWith("node/")) {
    return "node:" + id.slice(5).replaceAll(".", "/");
  } else if (id.startsWith("bun/")) {
    return "bun:" + id.slice(4).replaceAll(".", "/");
  } else if (id.startsWith("internal/")) {
    return "internal:" + id.slice(9).replaceAll(".", "/");
  } else if (id.startsWith("thirdparty/")) {
    return id.slice(11).replaceAll(".", "/");
  }
  return idToEnumName(id);
}

const { combinedSourceCode: functionsSource, privateNames } = await bundleBuiltinFunctions({
  typesDir: TYPES_DIR,
  requireTransformer,
});

mark("Bundle Functions");

// This is a file with a single macro that is used in defining InternalModuleRegistry.h
writeIfNotChanged(
  path.join(CODEGEN_DIR, "InternalModuleRegistry+numberOfModules.h"),
  `#define BUN_INTERNAL_MODULE_COUNT ${moduleList.length}
#define BUN_NATIVE_MODULE_START_INDEX ${nativeStartIndex}
`,
);

// This code slice is used in InternalModuleRegistry.h for inlining the enum. I dont think we
// actually use this enum but it's probably a good thing to include.
writeIfNotChanged(
  path.join(CODEGEN_DIR, "InternalModuleRegistry+enum.h"),
  `${
    moduleList
      .map((id, n) => {
        return `${idToEnumName(id)} = ${n},`;
      })
      .join("\n") + "\n"
  }
`,
);

// The bundled JS sources (builtin functions + internal modules) are linked into
// the executable as one contiguous read-only blob via `.incbin` in the generated
// `.S` below and addressed by {offset, length}. Emitting them as C++
// `static constexpr const char[]` byte-array initializers instead costs clang's
// frontend ~15s on the release build — millions of integer tokens to parse for
// ~2 MB of payload.
//
// The blob lives in its own executable section (`__TEXT,__bun_builtins` /
// `.bun_builtins` / `.bunblt`) and starts with a header + per-module index, so
// that a `bun build --compile --bytecode` running on another platform can read a
// target executable's builtin module sources (and their registry ids) straight out
// of the file. The runtime reads the same index; nothing is stored twice. The
// reader is src/exe_format/builtins.rs — keep the two in sync.
//
// Layout (little-endian u32 unless noted; offsets in the index are relative to `data`):
//   header:  magic[8] "BUNBLTNS", version, sourceStamp, moduleCount, modulesOffset,
//            depOffsetsOffset, depsOffset, dataOffset, dataLength, engineStamp, 0
//   modules: moduleCount × { nameOffset, nameLength, urlOffset, urlLength, codeOffset, codeLength }
//   depOffsets: u16[moduleCount + 1], deps: u16[]  (see internalModuleDependencyTable)
//   data:    [builtin functions combined source][\0][module 0][\0][module 1][\0]...[name\0url\0]...
// WebCoreJSBuiltins.cpp's internalCombinedSource is the span at data offset 0.
//
// A debug build's runtime reads the module sources from disk instead (BUN_DYNAMIC_JS_LOAD_PATH), but they are still
// here so that a debug bun works as a `--compile` target like any other.
// Bumped to 2 because bun 1.4.1 to 1.4.3 compile any version 1 section without checking engineStamp.
const BUILTINS_FORMAT_VERSION = 2;
const BUILTINS_HEADER_SIZE = 48;

// Identifies these module sources to bytecode generated from them ahead of time (bun build --compile embeds bytecode for
// the internal modules an app uses); computed over the bundled outputs so it is meaningful in debug builds too.
const internalModulesStamp = sourceStamp(
  moduleList.slice(0, nativeStartIndex).map(id => outputs.get(id.slice(0, -3).replaceAll("/", path.sep)) ?? ""),
);

// require() edges between JS internal modules (ids are enum order), as offsets into one flat list. `bun build --compile
// --bytecode` embeds bytecode for the builtins an app imports plus everything reachable through this table.
const internalModuleDependencyTable = (() => {
  const jsModules = moduleList.slice(0, nativeStartIndex);
  const requireRe = /internalModuleRegistry, ?(\d+)/g;
  const offsets: number[] = [];
  const flat: number[] = [];
  jsModules.forEach((id, n) => {
    offsets.push(flat.length);
    const src = outputs.get(id.slice(0, -3).replaceAll("/", path.sep)) ?? "";
    const edges = new Set<number>();
    // Lazy require() calls inside functions count too: internal/util/inspect, internal/fs/watch and friends are only
    // ever reached that way, and the first is loaded by nearly every program (util.inspect, format, console, error
    // paths). Carrying bytecode for a module that never loads costs bytes; parsing one that does costs startup time.
    for (const m of src.matchAll(requireRe)) {
      const dep = Number(m[1]);
      if (dep !== n && dep < nativeStartIndex) edges.add(dep);
    }
    flat.push(...[...edges].sort((a, b) => a - b));
  });
  offsets.push(flat.length);
  return { offsets, flat };
})();

let blob: Buffer;
let blobDataOffset: number;
{
  type Span = { offset: number; length: number };
  const code = new Map<string, Span>();
  const chunks: Buffer[] = [Buffer.from(functionsSource + "\0", "latin1")];
  let offset = chunks[0].length;
  const push = (text: string): Span => {
    const bytes = Buffer.from(text, "latin1");
    const span = { offset, length: bytes.length };
    chunks.push(bytes);
    offset += bytes.length;
    return span;
  };
  for (const id of layoutOrder(moduleList.slice(0, nativeStartIndex), outputs)) {
    const out = outputs.get(id.slice(0, -3).replaceAll("/", path.sep));
    if (!out) throw new Error(`Missing output for ${id}`);
    checkAscii(out);
    // The NUL keeps each entry a valid C string should anything downstream ever strlen into the blob.
    const span = push(out + "\0");
    code.set(id, { offset: span.offset, length: span.length - 1 });
  }
  const records: number[] = [];
  for (const id of moduleList.slice(0, nativeStartIndex)) {
    const name = push(idToPublicSpecifierOrEnumName(id) + "\0");
    const url = push("builtin://" + id.replace(/\.[mc]?[tj]s$/, "").replace(/[^a-zA-Z0-9]+/g, "/") + "\0");
    const { offset: codeOffset, length: codeLength } = code.get(id)!;
    records.push(name.offset, name.length - 1, url.offset, url.length - 1, codeOffset, codeLength);
  }
  const data = Buffer.concat(chunks);

  if (internalModuleDependencyTable.flat.length > 0xffff || nativeStartIndex > 0xffff)
    throw new Error("builtins section: dependency table no longer fits its u16 entries; widen depOffsets/deps");
  const align = (n: number, to: number) => (n + to - 1) & ~(to - 1);
  const modulesOffset = BUILTINS_HEADER_SIZE;
  const depOffsetsOffset = modulesOffset + records.length * 4;
  const depsOffset = depOffsetsOffset + internalModuleDependencyTable.offsets.length * 2;
  blobDataOffset = align(depsOffset + internalModuleDependencyTable.flat.length * 2, 16);

  blob = Buffer.alloc(blobDataOffset + data.length);
  blob.write("BUNBLTNS", 0, "latin1");
  [
    BUILTINS_FORMAT_VERSION,
    internalModulesStamp,
    nativeStartIndex,
    modulesOffset,
    depOffsetsOffset,
    depsOffset,
    blobDataOffset,
    data.length,
    engineStamp(WEBKIT_VERSION, privateNames),
    0,
  ].forEach((v, i) => blob.writeUInt32LE(v >>> 0, 8 + i * 4));
  records.forEach((v, i) => blob.writeUInt32LE(v, modulesOffset + i * 4));
  internalModuleDependencyTable.offsets.forEach((v, i) => blob.writeUInt16LE(v, depOffsetsOffset + i * 2));
  internalModuleDependencyTable.flat.forEach((v, i) => blob.writeUInt16LE(v, depsOffset + i * 2));
  data.copy(blob, blobDataOffset);
}

writeIfNotChangedBinary(path.join(CODEGEN_DIR, "InternalModuleRegistryConstants.bin"), blob);

writeIfNotChanged(
  path.join(CODEGEN_DIR, "InternalModuleRegistryConstants.S"),
  `// Generated by src/codegen/bundle-modules.ts
#if defined(__APPLE__)
.section __TEXT,__bun_builtins,regular,no_dead_strip
#define BUN_SYM(x) _##x
#elif defined(_WIN32)
.section .bunblt,"dr"
#define BUN_SYM(x) x
#else
.pushsection .note.GNU-stack, "", %progbits
.popsection
.section .bun_builtins,"a",%progbits
#define BUN_SYM(x) x
#endif

.globl BUN_SYM(bun_internal_modules_header)
.globl BUN_SYM(bun_internal_modules_data)
.p2align 4
BUN_SYM(bun_internal_modules_header):
.incbin "InternalModuleRegistryConstants.bin", 0, ${blobDataOffset}
BUN_SYM(bun_internal_modules_data):
.incbin "InternalModuleRegistryConstants.bin", ${blobDataOffset}
`,
);

// The C++ view of the section header/index above. Included only by InternalModuleRegistry.cpp.
writeIfNotChanged(
  path.join(CODEGEN_DIR, "InternalModuleRegistryConstants.h"),
  `// clang-format off
// Generated by src/codegen/bundle-modules.ts
#pragma once
#include <cstdint>

namespace Bun {
namespace InternalModuleRegistryConstants {

struct Header {
  char magic[8];
  uint32_t version;
  uint32_t sourceStamp;
  uint32_t moduleCount;
  uint32_t modulesOffset;
  uint32_t depOffsetsOffset;
  uint32_t depsOffset;
  uint32_t dataOffset;
  uint32_t dataLength;
  uint32_t engineStamp;
  uint32_t reserved;
};
static_assert(sizeof(Header) == ${BUILTINS_HEADER_SIZE});

// Offsets are relative to bun_internal_modules_data. name and url are NUL-terminated.
struct ModuleRecord {
  uint32_t nameOffset;
  uint32_t nameLength;
  uint32_t urlOffset;
  uint32_t urlLength;
  uint32_t codeOffset;
  uint32_t codeLength;
};

static constexpr uint32_t moduleCount = ${nativeStartIndex};

#ifdef BUN_DYNAMIC_JS_LOAD_PATH
static constexpr const char* fileNames[moduleCount] = {
  ${moduleList
    .slice(0, nativeStartIndex)
    .map(id => JSON.stringify(id.replace(/\.[mc]?[tj]s$/, ".js")))
    .join(",\n  ")}
};
#endif

} // namespace InternalModuleRegistryConstants
} // namespace Bun

extern "C" const Bun::InternalModuleRegistryConstants::Header bun_internal_modules_header;
extern "C" const char bun_internal_modules_data[];
`,
);

// This code slice is used in InternalModuleRegistry.cpp. It defines the loading function for modules.
// JS modules (ids below nativeStartIndex, in enum order) are rows of the section index above rather
// than switch arms; native modules keep a switch.
writeIfNotChanged(
  path.join(CODEGEN_DIR, "InternalModuleRegistry+createInternalModuleById.h"),
  `// clang-format off
JSValue InternalModuleRegistry::createInternalModuleById(JSGlobalObject* globalObject, VM& vm, Field id)
{
  if (static_cast<size_t>(id) < ${nativeStartIndex}) {
    return generateInternalModule(globalObject, vm, static_cast<uint32_t>(id));
  }
  switch (id) {
    // Native modules
    ${moduleList
      .map((id, n) => [id, n] as const)
      .filter(([, n]) => n >= nativeStartIndex)
      .map(
        ([id]) => `case Field::${idToEnumName(id)}: {
      return generateNativeModule(globalObject, vm, generateNativeModule_${nativeModuleEnums[id]});
    }`,
      )
      .join("\n    ")}
    default: {
      __builtin_unreachable();
    }
  }
  __builtin_unreachable();
}
`,
);

// This is a generated map for rust code (included by the `resolved_source_tag` module in
// src/jsc/lib.rs). Keys are the canonical builtin specifier strings fed to
// `ResolvedSourceTag::from_name`.
writeIfNotChanged(
  path.join(CODEGEN_DIR, "generated_resolved_source_tag.rs"),
  `// Generated by src/codegen/bundle-modules.ts — do not edit.
// Canonical builtin-module specifier -> InternalModuleRegistry tag (\`(1 << 9) | id\`),
// kept in lock-step with SyntheticModuleType.h.
bun_core::comptime_string_map! {
#[allow(dead_code, unreachable_pub, unused)]
static INTERNAL_MODULE_TAG: ResolvedSourceTag = {
${moduleList
  .slice(0, nativeStartIndex)
  .flatMap((id, n) => {
    const name = idToPublicSpecifierOrEnumName(id);
    const entry = `    b"${name}" => ResolvedSourceTag(${(1 << 9) | n}),`;
    // Rust's HardcodedModule surfaces this module as its npm specifier, so alias it to the same tag.
    return name === "vercel_fetch" ? [entry, `    b"@vercel/fetch" => ResolvedSourceTag(${(1 << 9) | n}),`] : [entry];
  })
  .join("\n")}
    // Native modules come after the JS modules.
${Object.entries(nativeModuleEnumToId)
  .map(
    ([_id, n], i) =>
      `    b"${moduleList[nativeStartIndex + i]}" => ResolvedSourceTag(${(1 << 9) | (n + nativeStartIndex)}),`,
  )
  .join("\n")}
};
}
`,
);

// Module keys with no InternalModuleRegistry entry that the resolver's alias table can still answer with
// (HardcodedModule.rs). They get ids after the registry range so `builtinModuleKeys` covers every alias target.
const registryModuleKeys = [
  ...moduleList.slice(0, nativeStartIndex).map(id => idToPublicSpecifierOrEnumName(id)),
  ...Object.keys(nativeModuleEnumToId).map((_id, i) => moduleList[nativeStartIndex + i]),
];
const builtinModuleKeyList = [
  ...registryModuleKeys,
  ...["bun", "bun:main", "bun:wrap", "bun:test", "node:buffer"].filter(k => !registryModuleKeys.includes(k)),
];

// C++: canonical key string per InternalModuleRegistry id (+ extras), for handing JSC an Identifier without a round
// trip through the resolver (ZigGlobalObject.cpp moduleLoaderResolve).
writeIfNotChanged(
  path.join(CODEGEN_DIR, "BuiltinModuleKeys.h"),
  `// Generated by src/codegen/bundle-modules.ts — do not edit.
#pragma once
namespace Bun {
static constexpr unsigned builtinModuleKeyCount = ${builtinModuleKeyList.length};
static constexpr ASCIILiteral builtinModuleKeys[builtinModuleKeyCount] = {
${builtinModuleKeyList.map(k => `    "${k}"_s,`).join("\n")}
};
}
`,
);

// Rust: the same index for a canonical key (the registry ids are `tag & ~(1 << 9)`; extras follow).
writeIfNotChanged(
  path.join(CODEGEN_DIR, "generated_builtin_module_key_index.rs"),
  `// Generated by src/codegen/bundle-modules.ts — do not edit. Index into BuiltinModuleKeys.h.
bun_core::comptime_string_map! {
#[allow(dead_code, unreachable_pub, unused)]
static BUILTIN_MODULE_KEY_INDEX: u16 = {
${builtinModuleKeyList.map((k, i) => `    b"${k}" => ${i},`).join("\n")}
};
}
`,
);

// This is a generated enum for c++ code (headers-handwritten.h)
writeIfNotChanged(
  path.join(CODEGEN_DIR, "SyntheticModuleType.h"),
  `enum SyntheticModuleType : uint32_t {
    JavaScript = 0,
    PackageJSONTypeModule = 1,
    PackageJSONTypeCommonJS = 2,
    Wasm = 3,
    ObjectModule = 4,
    File = 5,
    ESM = 6,
    JSONForObjectLoader = 7,
    ExportsObject = 8,
    ExportDefaultObject = 9,
    CommonJSCustomExtension = 10,
    // Built in modules are loaded through InternalModuleRegistry by numerical ID.
    // In this enum are represented as \`(1 << 9) & id\`
    InternalModuleRegistryFlag = 1 << 9,
${moduleList
  .slice(0, nativeStartIndex)
  .map((id, n) => `    ${idToEnumName(id)} = ${(1 << 9) | n},`)
  .join("\n")}
    // Native modules come after the JS modules
${Object.entries(nativeModuleEnumToId)
  .map(([id, n], i) => `    ${id} = ${(1 << 9) | (i + nativeStartIndex)},`)
  .join("\n")}
};

`,
);

// This is used in ModuleLoader.cpp to link to all the headers for native modules.
writeIfNotChanged(
  path.join(CODEGEN_DIR, "NativeModuleImpl.h"),
  Object.values(nativeModuleEnums)
    .map(value => `#include "../../jsc/modules/${value}Module.h"`)
    .join("\n") + "\n",
);

writeIfNotChanged(path.join(CODEGEN_DIR, "GeneratedJS2Native.h"), getJS2NativeCPP());

// Rust sibling: include!()'d by src/runtime/generated_js2native.rs
writeIfNotChanged(path.join(CODEGEN_DIR, "generated_js2native.rs"), getJS2NativeRust());

const generatedDTSPath = path.join(TYPES_DIR, "generated.d.ts");
writeIfNotChanged(
  generatedDTSPath,
  (() => {
    let dts = `
// GENERATED TEMP FILE - DO NOT EDIT
// generated by ${import.meta.path}

declare module "module" {
  global {
    interface PropertyDescriptor {
      __proto__?: any;
    }

    interface Function {
      readonly $call: Function.prototype["call"];
      readonly $apply: Function.prototype["apply"];
    }

    namespace NodeJS {
      interface Require {

`;

    dts += `        (id: "bun"): typeof import("bun");\n`;
    dts += `        (id: "bun:test"): typeof import("bun:test");\n`;
    dts += `        (id: "bun:jsc"): typeof import("bun:jsc");\n`;

    for (let i = 0; i < nativeStartIndex; i++) {
      const id = moduleList[i];
      const out = outputs.get(id.slice(0, -3).replaceAll("/", path.sep));
      if (!out) {
        throw new Error(`Missing output for ${id}`);
      }
      let internalName = idToPublicSpecifierOrEnumName(id);
      if (internalName.startsWith("internal:")) internalName = internalName.replace(":", "/");

      dts += `        (id: "${internalName}"): typeof import("${path.join(BASE, id)}").default;\n`;
    }

    dts += `
      }
    }
  }
}
`;

    for (const [name] of jsclasses) {
      dts += `\ndeclare function $inherits${name}(value: any): value is ${name};`;
    }

    return dts;
  })(),
);

mark("Generate Code");

const evalFiles = new Bun.Glob(path.join(BASE, "eval", "*.ts")).scanSync();
for (const file of evalFiles) {
  const {
    outputs: [output],
  } = await Bun.build({
    entrypoints: [file],

    // Shrink it.
    minify: !debug,

    target: "bun",
    format: "esm",
    env: "disable",
    define: {
      "process.platform": JSON.stringify(process.env.TARGET_PLATFORM ?? process.platform),
      "process.arch": JSON.stringify(process.env.TARGET_ARCH ?? process.arch),
    },
  });
  writeIfNotChanged(path.join(CODEGEN_DIR, "eval", path.basename(file)), await output.text());
}

if (!silent) {
  console.log("");
  console.timeEnd(timeString);
  console.log(
    `  %s kb`,
    Math.floor(
      (moduleList
        .slice(0, nativeStartIndex)
        .reduce((a, b) => a + outputs.get(b.slice(0, -3).replaceAll("/", path.sep)).length, 0) +
        globalThis.internalFunctionJSSize) /
        1000,
    ),
  );
  console.log(`  %s internal modules`, nativeStartIndex);
  console.log(`  %s native modules`, Object.keys(nativeModuleIds).length);
  console.log(
    `  %s internal functions across %s files`,
    globalThis.internalFunctionCount,
    globalThis.internalFunctionFileCount,
  );
}
