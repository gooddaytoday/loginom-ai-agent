//! E — expression node payloads for the JS AST.

use core::cmp::Ordering;
use core::fmt;

use bun_alloc::Arena as Bump;

use bun_alloc::AllocError;
use bun_collections::{VecExt, index_sort};
use bun_core::strings;

use crate::{Expr, ExprNodeIndex, ExprNodeList, G, OptionalChain, Ref, StoreRef};
use bun_alloc::ArenaVecExt as _;

// AST string fields are arena-owned (bulk-freed via Store/arena reset; never
// individually freed). `StoreStr` is `StoreRef`'s `[u8]` sibling: a thin
// lifetime-erased pointer with safe construction (no `transmute`) and
// `Deref<Target=[u8]>` under the same valid-until-arena-reset contract.
pub use crate::StoreStr as Str;

/// This represents an internal property name that can be mangled. The symbol
/// referenced by this expression should be a "SymbolMangledProp" symbol.
#[derive(Clone, Copy)]
pub struct NameOfSymbol {
    pub ref_: Ref,

    /// If true, a preceding comment contains "@__KEY__"
    ///
    /// Currently not used
    pub has_property_key_comment: bool,
}
impl Default for NameOfSymbol {
    fn default() -> Self {
        Self {
            ref_: Ref::NONE,
            has_property_key_comment: false,
        }
    }
}

pub struct Array {
    pub items: ExprNodeList,
    pub comma_after_spread: crate::Loc,
    pub is_single_line: bool,
    pub is_parenthesized: bool,
    pub was_originally_macro: bool,
    pub close_bracket_loc: crate::Loc,
}
impl Default for Array {
    fn default() -> Self {
        Self {
            items: bun_alloc::AstAlloc::vec(),
            comma_after_spread: crate::Loc::EMPTY,
            is_single_line: false,
            is_parenthesized: false,
            was_originally_macro: false,
            close_bracket_loc: crate::Loc::EMPTY,
        }
    }
}
// Live subset of `Array` accessors needed by downstream crates.
impl Array {
    /// `Vec::append` uses the global arena; `_bump` is kept
    /// for call-site shape parity and the eventual bump-arena Vec.
    pub fn push(&mut self, _bump: &Bump, item: Expr) -> Result<(), AllocError> {
        VecExt::append(&mut self.items, item);
        Ok(())
    }

    #[inline]
    pub fn slice(&self) -> &[Expr] {
        self.items.slice()
    }
}

impl Array {
    pub fn inline_spread_of_array_literals(
        &mut self,
        _bump: &Bump,
        estimated_count: usize,
    ) -> Result<ExprNodeList, AllocError> {
        // This over-allocates a little but it's fine
        // `Expr.data` is an enum (validity invariant), so an
        // expand-to-capacity + index-walk pattern would form `&mut [Expr]`
        // over invalid bit patterns. Push into reserved capacity instead —
        // same allocation profile (one upfront `with_capacity`), no uninit.
        let mut out: ExprNodeList =
            ExprNodeList::init_capacity(estimated_count + self.items.len_u32() as usize);
        // Reshaped for borrowck — iterate items via index so the &mut
        // borrow of `out` does not overlap a shared borrow of `self`.
        let items_len = self.items.len_u32() as usize;
        for idx in 0..items_len {
            let item = self.items.slice()[idx];
            match &item.data {
                crate::expr::Data::ESpread(val) => {
                    if let crate::expr::Data::EArray(inner) = &val.value.data {
                        for inner_item in inner.items.slice() {
                            if matches!(inner_item.data, crate::expr::Data::EMissing(_)) {
                                out.push(Expr::init(Undefined {}, inner_item.loc));
                            } else {
                                out.push(*inner_item);
                            }
                        }
                        // skip empty arrays
                        // don't include the inlined spread.
                        continue;
                    }
                    // non-arrays are kept in
                }
                _ => {}
            }

            out.push(item);
        }
        Ok(out)
    }

    // `toJS` lives in the `js_parser_jsc` crate's extension trait.

    /// Assumes each item in the array is a string
    pub fn alphabetize_strings(&mut self) {
        if cfg!(debug_assertions) {
            for item in self.items.slice() {
                debug_assert!(matches!(item.data, crate::expr::Data::EString(_)));
            }
        }
        index_sort::sort_slice_by(self.items.slice_mut(), array_sorter_is_less_than);
    }
}

pub struct Unary {
    pub op: crate::OpCode,
    pub value: ExprNodeIndex,
    pub flags: UnaryFlags,
}

bitflags::bitflags! {
    #[derive(Clone, Copy, Default, PartialEq, Eq, Debug)]
    #[repr(transparent)]
    pub struct UnaryFlags: u8 {
        /// The expression "typeof (0, x)" must not become "typeof x" if "x"
        /// is unbound because that could suppress a ReferenceError from "x".
        ///
        /// Also if we know a typeof operator was originally an identifier, then
        /// we know that this typeof operator always has no side effects (even if
        /// we consider the identifier by itself to have a side effect).
        ///
        /// Note that there *is* actually a case where "typeof x" can throw an error:
        /// when "x" is being referenced inside of its TDZ (temporal dead zone). TDZ
        /// checks are not yet handled correctly by Bun, so this possibility is
        /// currently ignored.
        const WAS_ORIGINALLY_TYPEOF_IDENTIFIER = 1 << 0;

        /// Similarly the expression "delete (0, x)" must not become "delete x"
        /// because that syntax is invalid in strict mode. We also need to make sure
        /// we don't accidentally change the return value:
        ///
        /// ```text
        /// Returns false:
        ///   "var a; delete (a)"
        ///   "var a = Object.freeze({b: 1}); delete (a.b)"
        ///   "var a = Object.freeze({b: 1}); delete (a?.b)"
        ///   "var a = Object.freeze({b: 1}); delete (a['b'])"
        ///   "var a = Object.freeze({b: 1}); delete (a?.['b'])"
        ///
        /// Returns true:
        ///   "var a; delete (0, a)"
        ///   "var a = Object.freeze({b: 1}); delete (true && a.b)"
        ///   "var a = Object.freeze({b: 1}); delete (false || a?.b)"
        ///   "var a = Object.freeze({b: 1}); delete (null ?? a?.['b'])"
        ///   "var a = Object.freeze({b: 1}); delete (true ? a['b'] : a['b'])"
        /// ```
        const WAS_ORIGINALLY_DELETE_OF_IDENTIFIER_OR_PROPERTY_ACCESS = 1 << 1;
    }
}

pub struct Binary {
    pub left: ExprNodeIndex,
    pub right: ExprNodeIndex,
    pub op: crate::OpCode,
}

// ── Leaf scalar payloads ───────────────────────────────────────────────────
// `toJS` impls live in the `js_parser_jsc` extension trait.

#[derive(Clone, Copy)]
pub struct Boolean {
    pub value: bool,
}

#[derive(Clone, Copy, Default)]
pub struct Null;
#[derive(Clone, Copy, Default)]
pub struct Undefined;
#[derive(Clone, Copy, Default)]
pub struct Missing;
#[derive(Clone, Copy, Default)]
pub struct This;
#[derive(Clone, Copy, Default)]
pub struct Super;
#[derive(Clone, Copy, Default)]
pub struct ImportMeta;

#[derive(Clone, Copy, Default)]
pub struct ImportMetaMain {
    /// If true, print `!import.meta.main` (or `require.main != module`).
    pub inverted: bool,
}

#[derive(Clone, Copy)]
pub struct NewTarget {
    pub range: crate::Range,
}

pub struct New {
    pub target: ExprNodeIndex,
    pub args: ExprNodeList,

    /// True if there is a comment containing "@__PURE__" or "#__PURE__" preceding
    /// this call expression. See the comment inside ECall for more details.
    pub can_be_unwrapped_if_unused: CallUnwrap,

    pub close_parens_loc: crate::Loc,
}
impl Default for New {
    fn default() -> Self {
        Self {
            target: ExprNodeIndex::EMPTY,
            args: bun_alloc::AstAlloc::vec(),
            can_be_unwrapped_if_unused: CallUnwrap::Never,
            close_parens_loc: crate::Loc::EMPTY,
        }
    }
}

#[derive(Clone, Copy)]
pub enum Special {
    /// emits `exports` or `module.exports` depending on `commonjs_named_exports_deoptimized`
    ModuleExports,
    /// `import.meta.hot`
    HotEnabled,
    /// Acts as .e_undefined, but allows property accesses to the rest of the HMR API.
    HotDisabled,
    /// `import.meta.hot.data` when HMR is enabled. Not reachable when it is disabled.
    HotData,
    /// `import.meta.hot.accept` when HMR is enabled. Truthy.
    HotAccept,
    /// Converted from `hot_accept` by the parser's import.meta.hot.accept
    /// handling when passed strings. Printed as `hmr.acceptSpecifiers`
    HotAcceptVisited,
    /// Prints the resolved specifier string for an import record
    /// (an `ImportRecord` index).
    ResolvedSpecifierString(u32),
}

pub struct Call {
    // Node:
    pub target: ExprNodeIndex,
    pub args: ExprNodeList,
    pub optional_chain: Option<OptionalChain>,
    pub is_direct_eval: bool,
    pub close_paren_loc: crate::Loc,

    /// True if there is a comment containing "@__PURE__" or "#__PURE__" preceding
    /// this call expression. This is an annotation used for tree shaking, and
    /// means that the call can be removed if it's unused. It does not mean the
    /// call is pure (e.g. it may still return something different if called twice).
    ///
    /// Note that the arguments are not considered to be part of the call. If the
    /// call itself is removed due to this annotation, the arguments must remain
    /// if they have side effects.
    pub can_be_unwrapped_if_unused: CallUnwrap,

    /// Used when printing to generate the source prop on the fly
    pub was_jsx_element: bool,
}
impl Default for Call {
    fn default() -> Self {
        Self {
            target: ExprNodeIndex::EMPTY,
            args: bun_alloc::AstAlloc::vec(),
            optional_chain: None,
            is_direct_eval: false,
            close_paren_loc: crate::Loc::EMPTY,
            can_be_unwrapped_if_unused: CallUnwrap::Never,
            was_jsx_element: false,
        }
    }
}
#[repr(u8)]
#[derive(Clone, Copy, PartialEq, Eq, Default)]
pub enum CallUnwrap {
    #[default]
    Never,
    IfUnused,
    IfUnusedAndToStringSafe,
}

pub struct Dot {
    // target is Node
    pub target: ExprNodeIndex,
    // Arena-owned slice (`StoreStr`: lifetime-erased arena ownership, bulk-freed
    // at `Store::reset()` — see `nodes.rs` StoreStr docs).
    pub name: Str,
    pub name_loc: crate::Loc,
    pub optional_chain: Option<OptionalChain>,

    /// If true, this property access is known to be free of side-effects. That
    /// means it can be removed if the resulting value isn't used.
    pub can_be_removed_if_unused: bool,

    /// If true, this property access is a function that, when called, can be
    /// unwrapped if the resulting value is unused. Unwrapping means discarding
    /// the call target but keeping any arguments with side effects.
    pub call_can_be_unwrapped_if_unused: CallUnwrap,

    /// `target` is an `EImportIdentifier` and this read was counted in
    /// `Part::import_symbol_property_uses` instead of as a use of the import,
    /// so the linker may bind it straight to the export it names
    /// (`LinkerGraph::import_member_bindings`).
    pub is_import_property_use: bool,
}
impl Default for Dot {
    fn default() -> Self {
        Self {
            target: ExprNodeIndex::EMPTY,
            name: Str::EMPTY,
            name_loc: crate::Loc::EMPTY,
            optional_chain: None,
            can_be_removed_if_unused: false,
            call_can_be_unwrapped_if_unused: CallUnwrap::Never,
            is_import_property_use: false,
        }
    }
}
pub struct Index {
    pub index: ExprNodeIndex,
    pub target: ExprNodeIndex,
    pub optional_chain: Option<OptionalChain>,
    /// See `Dot::is_import_property_use`.
    pub is_import_property_use: bool,
}

pub struct Arrow {
    pub args: crate::StoreSlice<G::Arg>,
    pub body: G::FnBody,

    pub is_async: bool,
    pub has_rest_arg: bool,
    /// Use shorthand if true and "Body" is a single return statement
    pub prefer_expr: bool,
    /// See `flags::Function::HasReactHooksSuppression`.
    pub has_react_hooks_suppression: bool,
}
// The fourth bool fits in existing trailing padding.
const _: () = assert!(core::mem::size_of::<Arrow>() == 32);
impl Arrow {
    pub const NOOP_RETURN_UNDEFINED: Arrow = Arrow {
        args: crate::StoreSlice::EMPTY,
        body: G::FnBody {
            loc: crate::Loc::EMPTY,
            stmts: crate::StoreSlice::EMPTY,
        },
        is_async: false,
        has_rest_arg: false,
        prefer_expr: false,
        has_react_hooks_suppression: false,
    };
}
impl Default for Arrow {
    fn default() -> Self {
        Self {
            args: crate::StoreSlice::EMPTY,
            body: G::FnBody {
                loc: crate::Loc::EMPTY,
                stmts: crate::StoreSlice::EMPTY,
            },
            is_async: false,
            has_rest_arg: false,
            prefer_expr: false,
            has_react_hooks_suppression: false,
        }
    }
}

pub struct Function {
    pub func: G::Fn,
}

/// 8-byte identifier expression payload. The three side-effect flags are packed
/// into `Ref`'s user-bit lane (bits 28..31, masked out of `Ref` identity) so
/// this — the most common `expr::Data` variant — fits in a single word, which
/// is what pulls `expr::Data` down to 16 bytes / `Expr` to 24 (vs. 16B with
/// padding for discrete bools).
///
/// `ref_` remains a public field so the ~100 existing `id.ref_` /
/// `Identifier { ref_, ..Default::default() }` sites stay untouched; flag
/// access goes through the accessor methods below.
///
/// **Hazard:** assigning a fresh `Ref` to `ref_` *clears the flags*. This is
/// fine for `visit_expr`'s `e_identifier` (sets `ref_` first then re-derives
/// the flags), but any `id.ref_ = new_ref` site that expects the
/// flags to survive must instead write
/// `id.ref_ = new_ref.with_user_bits_from(id.ref_)` — see `handle_identifier`.
#[derive(Clone, Copy)]
pub struct Identifier {
    pub ref_: Ref,
}
impl Default for Identifier {
    #[inline]
    fn default() -> Self {
        Self { ref_: Ref::NONE }
    }
}
impl Identifier {
    #[inline]
    pub const fn init(ref_: Ref) -> Identifier {
        Identifier { ref_ }
    }

    /// If we're inside a "with" statement, this identifier may be a property
    /// access. In that case it would be incorrect to remove this identifier since
    /// the property access may be a getter or setter with side effects.
    #[inline]
    pub const fn must_keep_due_to_with_stmt(self) -> bool {
        self.ref_.user_bit(0)
    }
    #[inline]
    pub fn set_must_keep_due_to_with_stmt(&mut self, v: bool) {
        self.ref_.set_user_bit(0, v);
    }

    /// If true, this identifier is known to not have a side effect (i.e. to not
    /// throw an exception) when referenced. If false, this identifier may or may
    /// not have side effects when referenced. This is used to allow the removal
    /// of known globals such as "Object" if they aren't used.
    #[inline]
    pub const fn can_be_removed_if_unused(self) -> bool {
        self.ref_.user_bit(1)
    }
    #[inline]
    pub fn set_can_be_removed_if_unused(&mut self, v: bool) {
        self.ref_.set_user_bit(1, v);
    }

    /// If true, this identifier represents a function that, when called, can be
    /// unwrapped if the resulting value is unused. Unwrapping means discarding
    /// the call target but keeping any arguments with side effects.
    #[inline]
    pub const fn call_can_be_unwrapped_if_unused(self) -> bool {
        self.ref_.user_bit(2)
    }
    #[inline]
    pub fn set_call_can_be_unwrapped_if_unused(&mut self, v: bool) {
        self.ref_.set_user_bit(2, v);
    }

    // Builder-style setters for the handful of sites that set flags up front.
    #[inline]
    pub const fn with_must_keep_due_to_with_stmt(self, v: bool) -> Self {
        Self {
            ref_: self.ref_.with_user_bit(0, v),
        }
    }
    #[inline]
    pub const fn with_can_be_removed_if_unused(self, v: bool) -> Self {
        Self {
            ref_: self.ref_.with_user_bit(1, v),
        }
    }
    #[inline]
    pub const fn with_call_can_be_unwrapped_if_unused(self, v: bool) -> Self {
        Self {
            ref_: self.ref_.with_user_bit(2, v),
        }
    }
}

/// This is similar to an `Identifier` but it represents a reference to an ES6
/// import item.
///
/// Depending on how the code is linked, the file containing this EImportIdentifier
/// may or may not be in the same module group as the file it was imported from.
///
/// If it's the same module group than we can just merge the import item symbol
/// with the corresponding symbol that was imported, effectively renaming them
/// to be the same thing and statically binding them together.
///
/// But if it's a different module group, then the import must be dynamically
/// evaluated using a property access off the corresponding namespace symbol,
/// which represents the result of a require() call.
///
/// It's stored as a separate type so it's not easy to confuse with a plain
/// identifier. For example, it'd be bad if code trying to convert "{x: x}" into
/// "{x}" shorthand syntax wasn't aware that the "x" in this case is actually
/// "{x: importedNamespace.x}". This separate type forces code to opt-in to
/// doing this instead of opt-out.
/// 8-byte import-identifier payload — `was_originally_identifier` rides in
/// `Ref` user bit 0 (see `Identifier` doc for the packing rationale).
#[derive(Clone, Copy)]
pub struct ImportIdentifier {
    pub ref_: Ref,
}
impl Default for ImportIdentifier {
    #[inline]
    fn default() -> Self {
        Self { ref_: Ref::NONE }
    }
}
impl ImportIdentifier {
    #[inline]
    pub const fn new(ref_: Ref, was_originally_identifier: bool) -> Self {
        // Strip any incoming user bits (the caller may pass an
        // `E::Identifier.ref_` carrying its own flags in bits 1/2) before
        // applying ours, so foreign flags can't leak into this node.
        Self {
            ref_: ref_
                .without_user_bits()
                .with_user_bit(0, was_originally_identifier),
        }
    }

    /// If true, this was originally an identifier expression such as "foo". If
    /// false, this could potentially have been a member access expression such
    /// as "ns.foo" off of an imported namespace object.
    #[inline]
    pub const fn was_originally_identifier(self) -> bool {
        self.ref_.user_bit(0)
    }
}

/// This is a dot expression on exports, such as `exports.<ref>`. It is given
/// it's own AST node to allow CommonJS unwrapping, in which this can just be
/// the identifier in the Ref
/// 8-byte CJS-export-identifier payload — `base` rides in `Ref` user bit 0
/// (`Exports` = 0, `ModuleDotExports` = 1; see `Identifier` doc for packing
/// rationale).
#[derive(Clone, Copy)]
pub struct CommonJSExportIdentifier {
    pub ref_: Ref,
}
impl Default for CommonJSExportIdentifier {
    #[inline]
    fn default() -> Self {
        Self { ref_: Ref::NONE }
    }
}
impl CommonJSExportIdentifier {
    #[inline]
    pub const fn new(ref_: Ref, base: CommonJSExportIdentifierBase) -> Self {
        // Strip any incoming user bits before applying ours — see
        // `ImportIdentifier::new`.
        Self {
            ref_: ref_.without_user_bits().with_user_bit(
                0,
                matches!(base, CommonJSExportIdentifierBase::ModuleDotExports),
            ),
        }
    }
    #[inline]
    pub const fn base(self) -> CommonJSExportIdentifierBase {
        if self.ref_.user_bit(0) {
            CommonJSExportIdentifierBase::ModuleDotExports
        } else {
            CommonJSExportIdentifierBase::Exports
        }
    }
}

/// The original variant of the dot expression must be known so that in the case that we
/// - fail to convert this to ESM
/// - ALSO see an assignment to `module.exports` (commonjs_module_exports_assigned_deoptimized)
/// It must be known if `exports` or `module.exports` was written in source
/// code, as the distinction will alter behavior. The fixup happens in the printer when
/// printing this node.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum CommonJSExportIdentifierBase {
    Exports,
    ModuleDotExports,
}

/// This is similar to EIdentifier but it represents class-private fields and
/// methods. It can be used where computed properties can be used, such as
/// EIndex and Property.
#[derive(Clone, Copy)]
pub struct PrivateIdentifier {
    pub ref_: Ref,
}

/// In development mode, the new JSX transform has a few special props
/// - `React.jsxDEV(type, arguments, key, isStaticChildren, source, self)`
/// - `arguments`:
///      `{ ...props, children: children, }`
/// - `source`: https://github.com/babel/babel/blob/ef87648f3f05ccc393f89dea7d4c7c57abf398ce/packages/babel-plugin-transform-react-jsx-source/src/index.js#L24-L48
///   ```text
///   {
///      fileName: string | null,
///      columnNumber: number | null,
///      lineNumber: number | null,
///   }
///   ```
/// - `children`:
///     - static the function is React.jsxsDEV, "jsxs" instead of "jsx"
///     - one child? the function is React.jsxDEV,
///     - no children? the function is React.jsxDEV and children is an empty array.
/// `isStaticChildren`: https://github.com/facebook/react/blob/4ca62cac45c288878d2532e5056981d177f9fdac/packages/react/src/jsx/ReactJSXElementValidator.js#L369-L384
///     This flag means children is an array of JSX Elements literals.
///     The documentation on this is sparse, but it appears that
///     React just calls Object.freeze on the children array.
///     Object.freeze, historically, is quite a bit slower[0] than just not doing that.
///     Given that...I am choosing to always pass "false" to this.
///     This also skips extra state that we'd need to track.
///     If React Fast Refresh ends up using this later, then we can revisit this decision.
///  [0]: https://github.com/automerge/automerge/issues/177
pub struct JSXElement {
    /// JSX tag name
    /// `<div>` => E.String.init("div")
    /// `<MyComponent>` => E.Identifier{.ref = symbolPointingToMyComponent }
    /// null represents a fragment
    pub tag: Option<ExprNodeIndex>,

    /// JSX props
    pub properties: G::PropertyList,

    /// JSX element children `<div>{this_is_a_child_element}</div>`
    pub children: ExprNodeList,

    /// needed to make sure parse and visit happen in the same order
    pub key_prop_index: i32,

    pub flags: crate::flags::JSXElementBitset,

    pub close_tag_loc: crate::Loc,
}
impl Default for JSXElement {
    fn default() -> Self {
        Self {
            tag: None,
            properties: bun_alloc::AstAlloc::vec(),
            children: bun_alloc::AstAlloc::vec(),
            key_prop_index: -1,
            flags: crate::flags::JSXElementBitset::default(),
            close_tag_loc: crate::Loc::EMPTY,
        }
    }
}

#[repr(u8)]
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum JSXSpecialProp {
    /// old react transform used this as a prop
    UnderscoreSelf,
    UnderscoreSource,
    Key,
    Ref,
    Any,
}
bun_core::comptime_string_map! {
    static JSX_SPECIAL_PROP_MAP: JSXSpecialProp = {
        b"key" => JSXSpecialProp::Key,
        b"ref" => JSXSpecialProp::Ref,
        b"__self" => JSXSpecialProp::UnderscoreSelf,
        b"__source" => JSXSpecialProp::UnderscoreSource,
    };
}

impl JSXSpecialProp {
    #[inline]
    pub fn from_bytes(s: &[u8]) -> Option<Self> {
        JSX_SPECIAL_PROP_MAP.get(s).copied()
    }
}

/// `packed(4)` lowers the alignment to 4 so `expr::Data` (and therefore `Expr`)
/// drop to align 4 and pack into 16 bytes; the `f64` stays a single scalar so
/// `.value()` is one `movsd`/`ldr`. The field is private because comparisons on
/// a packed `f64` field would require `&self.value` (an unaligned reference);
/// callers go through `value()` / `new()` which copy by value.
#[derive(Clone, Copy)]
#[repr(C, packed(4))]
pub struct Number {
    value: f64,
}

const _: () = assert!(core::mem::size_of::<Number>() == 8);
const _: () = assert!(core::mem::align_of::<Number>() == 4);

impl Number {
    #[inline(always)]
    pub const fn new(value: f64) -> Self {
        Number { value }
    }
    #[inline(always)]
    pub const fn value(self) -> f64 {
        self.value
    }
}

const DOUBLE_DIGIT: [&[u8]; 101] = [
    b"0", b"1", b"2", b"3", b"4", b"5", b"6", b"7", b"8", b"9", b"10", b"11", b"12", b"13", b"14",
    b"15", b"16", b"17", b"18", b"19", b"20", b"21", b"22", b"23", b"24", b"25", b"26", b"27",
    b"28", b"29", b"30", b"31", b"32", b"33", b"34", b"35", b"36", b"37", b"38", b"39", b"40",
    b"41", b"42", b"43", b"44", b"45", b"46", b"47", b"48", b"49", b"50", b"51", b"52", b"53",
    b"54", b"55", b"56", b"57", b"58", b"59", b"60", b"61", b"62", b"63", b"64", b"65", b"66",
    b"67", b"68", b"69", b"70", b"71", b"72", b"73", b"74", b"75", b"76", b"77", b"78", b"79",
    b"80", b"81", b"82", b"83", b"84", b"85", b"86", b"87", b"88", b"89", b"90", b"91", b"92",
    b"93", b"94", b"95", b"96", b"97", b"98", b"99", b"100",
];
const NEG_DOUBLE_DIGIT: [&[u8]; 101] = [
    b"-0", b"-1", b"-2", b"-3", b"-4", b"-5", b"-6", b"-7", b"-8", b"-9", b"-10", b"-11", b"-12",
    b"-13", b"-14", b"-15", b"-16", b"-17", b"-18", b"-19", b"-20", b"-21", b"-22", b"-23", b"-24",
    b"-25", b"-26", b"-27", b"-28", b"-29", b"-30", b"-31", b"-32", b"-33", b"-34", b"-35", b"-36",
    b"-37", b"-38", b"-39", b"-40", b"-41", b"-42", b"-43", b"-44", b"-45", b"-46", b"-47", b"-48",
    b"-49", b"-50", b"-51", b"-52", b"-53", b"-54", b"-55", b"-56", b"-57", b"-58", b"-59", b"-60",
    b"-61", b"-62", b"-63", b"-64", b"-65", b"-66", b"-67", b"-68", b"-69", b"-70", b"-71", b"-72",
    b"-73", b"-74", b"-75", b"-76", b"-77", b"-78", b"-79", b"-80", b"-81", b"-82", b"-83", b"-84",
    b"-85", b"-86", b"-87", b"-88", b"-89", b"-90", b"-91", b"-92", b"-93", b"-94", b"-95", b"-96",
    b"-97", b"-98", b"-99", b"-100",
];

impl Number {
    /// String concatenation with numbers is required by the TypeScript compiler for
    /// "constant expression" handling in enums. We can match the behavior of a JS VM
    /// by calling out to the APIs in WebKit which are responsible for this operation.
    ///
    /// This can return `None` in wasm builds to avoid linking JSC
    pub(crate) fn to_string(self, bump: &Bump) -> Option<Str> {
        Self::to_string_from_f64(self.value(), bump)
    }

    pub(crate) fn to_string_from_f64(value: f64, bump: &Bump) -> Option<Str> {
        if value == value.trunc() && (value < i32::MAX as f64 && value > i32::MIN as f64) {
            let int_value = value as i64;
            let abs = int_value.unsigned_abs();

            // do not allocate for a small set of constant numbers: -100 through 100
            if (abs as usize) < DOUBLE_DIGIT.len() {
                return Some(Str::new(if int_value < 0 {
                    NEG_DOUBLE_DIGIT[abs as usize]
                } else {
                    DOUBLE_DIGIT[abs as usize]
                }));
            }

            // i32 fits in 11 bytes ("-2147483648"); format on stack then bump-copy.
            let mut stack = [0u8; 16];
            let Ok(s) = bun_core::fmt::buf_print(&mut stack, format_args!("{}", int_value as i32))
            else {
                return None;
            };
            return Some(Str::new(bump.alloc_slice_copy(s)));
        }

        if value.is_nan() {
            return Some(Str::new(b"NaN"));
        }

        if value.is_infinite() && value.is_sign_negative() {
            return Some(Str::new(b"-Infinity"));
        }

        if value.is_infinite() {
            return Some(Str::new(b"Infinity"));
        }

        #[cfg(not(target_arch = "wasm32"))]
        {
            let mut buf = [0u8; 124];
            let s = bun_core::fmt::FormatDouble::dtoa(&mut buf, value);
            Some(Str::new(bump.alloc_slice_copy(s)))
        }
        #[cfg(target_arch = "wasm32")]
        {
            // do not attempt to implement the spec here, it would be error prone.
            None
        }
    }

    #[inline]
    pub fn to_usize(self) -> usize {
        self.to::<usize>()
    }

    pub(crate) fn to<T: NumberCast>(self) -> T {
        let clamped = self.value().trunc().max(0.0).min(T::MAX_AS_F64);
        T::from_f64(clamped)
    }

    // `toJS` alias deleted — lives in `js_parser_jsc` extension trait.
}

/// Helper trait for `Number::to<T>()`.
pub trait NumberCast: Copy {
    const MAX_AS_F64: f64;
    fn from_f64(v: f64) -> Self;
}
macro_rules! impl_number_cast {
    ($($t:ty),*) => {$(
        impl NumberCast for $t {
            const MAX_AS_F64: f64 = {
                let max = <$t>::MAX as f64;
                if max > f64::MAX { f64::MAX } else { max }
            };
            #[inline] fn from_f64(v: f64) -> Self { v as $t }
        }
    )*};
}
impl_number_cast!(usize);

pub struct BigInt {
    // Arena-owned slice (`StoreStr`: lifetime-erased arena ownership, bulk-freed
    // at `Store::reset()` — see `nodes.rs` StoreStr docs).
    pub value: Str,
}
impl BigInt {
    /// `value` may carry a `0x`/`0o`/`0b` prefix. A leading zero is otherwise
    /// a syntax error, so any literal that starts with `0` and has more than
    /// one character is a radix literal.
    #[inline]
    pub(crate) fn has_radix(v: &[u8]) -> bool {
        v.len() >= 2 && v[0] == b'0'
    }

    /// `Some(equal)` when the comparison is decidable from the source text, or
    /// `None` when either side has a radix prefix and the values differ.
    pub fn check_equality(a: &[u8], b: &[u8]) -> Option<bool> {
        if a == b {
            return Some(true);
        }
        if !Self::has_radix(a) && !Self::has_radix(b) {
            return Some(false);
        }
        None
    }
}

// ── immutable JSON nodes ───────────────────────────────────────────────────
// Compact, read-only object/array nodes: the JSON parser's native output.
// Children are `PropertyJSON` rows / inline `JsonValue`s in the document's `JsonTape`.

/// A JSON value inside an `ObjectJSON` / `ArrayJSON`. The layout is read
/// from C++ (`JSONRowsToJS.cpp`).
#[derive(Clone, Copy)]
#[repr(C, u32)]
pub enum JsonValue {
    Null = 0,
    Boolean(bool) = 1,
    Number(Number) = 2,
    String(Str) = 3,
    Object(StoreRef<ObjectJSON>) = 4,
    Array(StoreRef<ArrayJSON>) = 5,
}

const _: () = assert!(core::mem::size_of::<JsonValue>() == 16);
const _: () = assert!(core::mem::align_of::<JsonValue>() == 4);

impl JsonValue {
    pub(crate) fn write_to_hasher<H: bun_core::Hasher + ?Sized>(&self, hasher: &mut H) {
        match self {
            JsonValue::Null => hasher.update(&[0]),
            JsonValue::Boolean(b) => hasher.update(&[1, *b as u8]),
            JsonValue::Number(n) => {
                hasher.update(&[2]);
                hasher.update(&n.value().to_bits().to_le_bytes());
            }
            JsonValue::String(s) => {
                hasher.update(&[3]);
                hasher.update(s.slice());
            }
            JsonValue::Object(o) => {
                let o = o.get();
                hasher.update(&[4]);
                hasher.update(&(o.properties().len() as u32).to_le_bytes());
                for p in o.properties().iter() {
                    hasher.update(p.key.slice());
                    p.value.write_to_hasher(hasher);
                }
            }
            JsonValue::Array(a) => {
                let a = a.get();
                hasher.update(&[5]);
                hasher.update(&(a.items().len() as u32).to_le_bytes());
                for item in a.items().iter() {
                    item.write_to_hasher(hasher);
                }
            }
        }
    }

    #[inline]
    pub fn as_str(&self) -> Option<&[u8]> {
        match self {
            JsonValue::String(s) => Some(s.slice()),
            _ => None,
        }
    }

    #[inline]
    pub fn as_object(&self) -> Option<&ObjectJSON> {
        match self {
            JsonValue::Object(o) => Some(o.get()),
            _ => None,
        }
    }

    #[inline]
    pub fn as_array(&self) -> Option<&ArrayJSON> {
        match self {
            JsonValue::Array(a) => Some(a.get()),
            _ => None,
        }
    }
}

/// One `"key": value` row of an [`ObjectJSON`]. Layout read from C++.
#[derive(Clone, Copy)]
#[repr(C)]
pub struct PropertyJSON {
    pub key: Str,
    pub key_loc: crate::Loc,
    pub value: JsonValue,
}

const _: () = assert!(core::mem::size_of::<PropertyJSON>() == 32);
// Read from C++ (JSONRowsToJS.cpp), which asserts the same offsets.
const _: () = assert!(core::mem::offset_of!(PropertyJSON, key) == 0);
const _: () = assert!(core::mem::offset_of!(PropertyJSON, key_loc) == 12);
const _: () = assert!(core::mem::offset_of!(PropertyJSON, value) == 16);

/// Where a [`JsonTape`]'s buffers (and, in arena mode, the tape itself) live.
#[derive(Clone, Copy)]
pub enum TapeAlloc {
    Global,
    Arena(core::ptr::NonNull<Bump>),
}

// SAFETY: an arena tape is built and read on the thread that owns the arena.
unsafe impl Send for TapeAlloc {}
// SAFETY: see the `Send` impl.
unsafe impl Sync for TapeAlloc {}

// SAFETY: both arms forward to allocators that uphold the `Allocator` contract.
unsafe impl core::alloc::Allocator for TapeAlloc {
    fn allocate(
        &self,
        layout: core::alloc::Layout,
    ) -> Result<core::ptr::NonNull<[u8]>, core::alloc::AllocError> {
        match self {
            TapeAlloc::Global => core::alloc::Allocator::allocate(&std::alloc::Global, layout),
            TapeAlloc::Arena(a) => {
                // SAFETY: the arena outlives the tape (the type's contract).
                let arena: &Bump = unsafe { a.as_ref() };
                core::alloc::Allocator::allocate(&arena, layout)
            }
        }
    }

    unsafe fn deallocate(&self, ptr: core::ptr::NonNull<u8>, layout: core::alloc::Layout) {
        match self {
            // SAFETY: forwarding the caller's contract.
            TapeAlloc::Global => unsafe {
                core::alloc::Allocator::deallocate(&std::alloc::Global, ptr, layout)
            },
            TapeAlloc::Arena(a) => {
                // SAFETY: the arena outlives the tape (the type's contract).
                let arena: &Bump = unsafe { a.as_ref() };
                // SAFETY: forwarding the caller's contract to the arena.
                unsafe { core::alloc::Allocator::deallocate(&arena, ptr, layout) }
            }
        }
    }
}

/// How the bytes behind every [`Str`] on one tape are encoded. JSON tapes are
/// UTF-8 (WTF-8 where an escape named a lone surrogate); the XML parser also
/// produces Latin-1 tapes when its input was a Latin-1 string.
#[derive(Clone, Copy, PartialEq, Eq)]
#[repr(u8)]
pub enum StrEncoding {
    Utf8 = 0,
    Latin1 = 1,
    Utf16 = 2,
}

/// Everything one parsed JSON document allocates that does not borrow the source.
pub struct JsonTape {
    props: Vec<PropertyJSON, TapeAlloc>,
    items: Vec<JsonValue, TapeAlloc>,
    prop_value_locs: Vec<crate::Loc, TapeAlloc>,
    item_locs: Vec<crate::Loc, TapeAlloc>,
    str_chunks: Vec<Vec<u8, TapeAlloc>, TapeAlloc>,
    pub encoding: StrEncoding,
}

// SAFETY: only the parsing thread writes it; shared use afterwards is read-only.
unsafe impl Send for JsonTape {}
// SAFETY: see the `Send` impl.
unsafe impl Sync for JsonTape {}

impl JsonTape {
    const STR_CHUNK: usize = 4096;

    pub fn empty() -> JsonTape {
        Self::empty_in(TapeAlloc::Global)
    }

    pub fn empty_in(alloc: TapeAlloc) -> JsonTape {
        JsonTape {
            props: Vec::new_in(alloc),
            items: Vec::new_in(alloc),
            prop_value_locs: Vec::new_in(alloc),
            item_locs: Vec::new_in(alloc),
            str_chunks: Vec::new_in(alloc),
            encoding: StrEncoding::Utf8,
        }
    }

    /// Pre-size the row buffers (a growth step copies the whole tape).
    pub fn reserve(&mut self, props: usize, items: usize) {
        self.props.reserve(props);
        self.prop_value_locs.reserve(props);
        self.items.reserve(items);
        self.item_locs.reserve(items);
    }

    /// The tape allocation's own pointer, for [`ObjectJSON::new`] /
    /// [`ArrayJSON::new`].
    ///
    /// Takes `&mut self` so the result can never be a shared reborrow: the
    /// parser keeps writing through this pointer for the rest of the parse, and
    /// a `&JsonTape`-derived pointer is frozen and has no permission to do that.
    /// Build the pointer with this rather than a bare `NonNull::from`, so the
    /// borrow it is derived from cannot silently be the wrong one.
    #[inline]
    pub fn root_ptr(&mut self) -> core::ptr::NonNull<JsonTape> {
        core::ptr::NonNull::from(self)
    }

    #[inline]
    fn alloc(&self) -> TapeAlloc {
        *self.props.allocator()
    }

    #[inline]
    pub fn append_props(&mut self, rows: &[PropertyJSON], value_locs: &[crate::Loc]) -> (u32, u32) {
        let first = self.props.len() as u32;
        self.props.extend_from_slice(rows);
        self.prop_value_locs.extend_from_slice(value_locs);
        (first, rows.len() as u32)
    }

    #[inline]
    pub fn append_items(&mut self, rows: &[JsonValue], item_locs: &[crate::Loc]) -> (u32, u32) {
        let first = self.items.len() as u32;
        self.items.extend_from_slice(rows);
        self.item_locs.extend_from_slice(item_locs);
        (first, rows.len() as u32)
    }

    /// Copy decoded string bytes into the tape; chunks grow only within capacity and so never move.
    pub fn alloc_str(&mut self, bytes: &[u8]) -> Str {
        self.alloc_str_join(bytes, b"")
    }

    /// [`alloc_str`](Self::alloc_str) of the concatenation `a ++ b`.
    pub fn alloc_str_join(&mut self, a: &[u8], b: &[u8]) -> Str {
        let len = a.len() + b.len();
        let fits = self
            .str_chunks
            .last()
            .is_some_and(|c| c.capacity() - c.len() >= len);
        if !fits {
            let cap = len.max(Self::STR_CHUNK);
            let chunk: Vec<u8, TapeAlloc> = Vec::with_capacity_in(cap, self.alloc());
            self.str_chunks.push(chunk);
        }
        let chunk = self.str_chunks.last_mut().expect("chunk pushed above");
        let start = chunk.len();
        if len <= 32 {
            chunk.extend(a.iter().chain(b));
        } else {
            chunk.extend_from_slice(a);
            chunk.extend_from_slice(b);
        }
        Str::new(&chunk[start..])
    }

    /// The row buffers, for a reader that resolves spans itself.
    #[inline]
    pub fn raw_rows(&self) -> (*const PropertyJSON, *const JsonValue) {
        (self.props.as_ptr(), self.items.as_ptr())
    }

    #[inline]
    fn prop_value_locs_span(&self, first: u32, count: u32) -> Option<&[crate::Loc]> {
        self.prop_value_locs
            .get(first as usize..first as usize + count as usize)
    }

    #[inline]
    fn item_locs_span(&self, first: u32, count: u32) -> Option<&[crate::Loc]> {
        self.item_locs
            .get(first as usize..first as usize + count as usize)
    }

    #[inline]
    fn props_span(&self, first: u32, count: u32) -> &[PropertyJSON] {
        &self.props[first as usize..first as usize + count as usize]
    }

    /// Returns one object's properties, given the row range from its [`ObjectJSON::rows`].
    #[inline]
    pub fn properties(&self, rows: core::ops::Range<u32>) -> &[PropertyJSON] {
        &self.props[rows.start as usize..rows.end as usize]
    }

    #[inline]
    fn items_span(&self, first: u32, count: u32) -> &[JsonValue] {
        &self.items[first as usize..first as usize + count as usize]
    }
}

/// `Data::EObjectJSON`: a `(first, count)` span of the document's property-row tape.
#[repr(C)]
pub struct ObjectJSON {
    tape: core::ptr::NonNull<JsonTape>,
    first: u32,
    count: u32,
    pub close_brace_loc: crate::Loc,
    pub is_single_line: bool,
}

const _: () = assert!(core::mem::offset_of!(ObjectJSON, first) == 8);
const _: () = assert!(core::mem::offset_of!(ObjectJSON, count) == 12);
const _: () = assert!(core::mem::offset_of!(ArrayJSON, first) == 8);
const _: () = assert!(core::mem::offset_of!(ArrayJSON, count) == 12);

// SAFETY: the tape outlives the AST (`StoreRef`'s contract) and is read-only once parsing returns.
unsafe impl Send for ObjectJSON {}
// SAFETY: see the `Send` impl.
unsafe impl Sync for ObjectJSON {}

impl ObjectJSON {
    /// `tape` must be the document's [`JsonTape`], and must outlive this node.
    ///
    /// # Safety
    /// `tape` must carry the tape allocation's own provenance — the parser's
    /// `NonNull<JsonTape>` — **not** a `&JsonTape`/`&mut JsonTape` reborrow of
    /// it. The parser keeps appending to the tape after this node is built
    /// (sibling properties, the enclosing object, later strings), and each of
    /// those writes would invalidate a reborrow-derived pointer, making every
    /// later [`properties`](Self::properties) read UB.
    #[inline]
    pub unsafe fn new(
        tape: core::ptr::NonNull<JsonTape>,
        first: u32,
        count: u32,
        is_single_line: bool,
        close_brace_loc: crate::Loc,
    ) -> Self {
        ObjectJSON {
            tape,
            first,
            count,
            close_brace_loc,
            is_single_line,
        }
    }

    /// The tape this node's rows live on.
    #[inline]
    pub fn tape(&self) -> &JsonTape {
        // SAFETY: per the constructor's contract the tape outlives this node.
        unsafe { self.tape.as_ref() }
    }

    #[inline]
    pub fn properties(&self) -> &[PropertyJSON] {
        if self.count == 0 {
            return &[];
        }
        // SAFETY: per the constructor's contract the tape outlives this node.
        unsafe { self.tape.as_ref() }.props_span(self.first, self.count)
    }

    /// The tape rows that hold [`Self::properties`]. Code that keeps the tape alive longer than
    /// this node can store the range and read it back with [`JsonTape::properties`].
    #[inline]
    pub fn rows(&self) -> core::ops::Range<u32> {
        self.first..self.first + self.count
    }

    /// Parallel to [`Self::properties`]; `None` unless the parse recorded value locations.
    #[inline]
    pub fn value_locs(&self) -> Option<&[crate::Loc]> {
        if self.count == 0 {
            return Some(&[]);
        }
        // SAFETY: see `properties`.
        unsafe { self.tape.as_ref() }.prop_value_locs_span(self.first, self.count)
    }

    #[inline]
    pub fn get(&self, key: &[u8]) -> Option<&JsonValue> {
        self.properties()
            .iter()
            .find(|p| p.key.slice() == key)
            .map(|p| &p.value)
    }
}

/// `Data::EArrayJSON`: a `(first, count)` span of the document's item tape.
#[repr(C)]
pub struct ArrayJSON {
    tape: core::ptr::NonNull<JsonTape>,
    first: u32,
    count: u32,
    pub close_bracket_loc: crate::Loc,
    pub is_single_line: bool,
}

// SAFETY: see `ObjectJSON`.
unsafe impl Send for ArrayJSON {}
// SAFETY: see `ObjectJSON`.
unsafe impl Sync for ArrayJSON {}

impl ArrayJSON {
    /// `tape` must be the document's [`JsonTape`], and must outlive this node.
    ///
    /// # Safety
    /// Same provenance contract as [`ObjectJSON::new`].
    #[inline]
    pub unsafe fn new(
        tape: core::ptr::NonNull<JsonTape>,
        first: u32,
        count: u32,
        is_single_line: bool,
        close_bracket_loc: crate::Loc,
    ) -> Self {
        ArrayJSON {
            tape,
            first,
            count,
            close_bracket_loc,
            is_single_line,
        }
    }

    /// The tape this node's rows live on.
    #[inline]
    pub fn tape(&self) -> &JsonTape {
        // SAFETY: see `ObjectJSON::properties`.
        unsafe { self.tape.as_ref() }
    }

    #[inline]
    pub fn items(&self) -> &[JsonValue] {
        if self.count == 0 {
            return &[];
        }
        // SAFETY: see `ObjectJSON::properties`.
        unsafe { self.tape.as_ref() }.items_span(self.first, self.count)
    }

    /// Parallel to [`Self::items`]; `None` unless the parse recorded item locations.
    #[inline]
    pub fn item_locs(&self) -> Option<&[crate::Loc]> {
        if self.count == 0 {
            return Some(&[]);
        }
        // SAFETY: see `ObjectJSON::properties`.
        unsafe { self.tape.as_ref() }.item_locs_span(self.first, self.count)
    }
}

pub struct Object {
    pub properties: G::PropertyList,
    pub comma_after_spread: crate::Loc,
    pub is_single_line: bool,
    pub is_parenthesized: bool,
    pub was_originally_macro: bool,

    pub close_brace_loc: crate::Loc,
}
impl Default for Object {
    fn default() -> Self {
        Self {
            properties: bun_alloc::AstAlloc::vec(),
            comma_after_spread: crate::Loc::EMPTY,
            is_single_line: false,
            is_parenthesized: false,
            was_originally_macro: false,
            close_brace_loc: crate::Loc::EMPTY,
        }
    }
}

/// Dotted-key path used by the INI parser (`get_or_put_object`).
///
/// Node types are lifetime-free, so `next` is a raw `*mut Rope`
/// into the bump arena. Segments are bulk-freed at arena reset.
pub struct Rope {
    pub head: Expr,
    pub next: *mut Rope,
}
impl Rope {
    pub fn append(&mut self, expr: Expr, bump: &Bump) -> Result<*mut Rope, AllocError> {
        // Walk to the tail iteratively: recursing once per node overflows the
        // native stack on adversarially deep ropes (e.g. an `.npmrc` section
        // header with thousands of dot-separated segments).
        //
        // Arena-allocated Rope nodes are uniquely owned by the chain at this
        // point; route through `StoreRef::DerefMut` (the arena-backed handle
        // whose deref is centralised in `nodes.rs`).
        let mut tail = StoreRef::from_bump(self);
        while let Some(next) = core::ptr::NonNull::new(tail.next).map(StoreRef::from_non_null) {
            tail = next;
        }
        let rope: *mut Rope = bump.alloc(Rope {
            head: expr,
            next: core::ptr::null_mut(),
        });
        tail.next = rope;
        Ok(rope)
    }

    /// Re-borrow `next` as `Option<&Rope>`. Same `StoreRef` arena contract:
    /// the pointee is a bump allocation valid until arena reset. Centralises
    /// the one `unsafe` so the `get_or_put_object`/`get_rope` walkers
    /// don't repeat `if !next.is_null() { unsafe { &*next } }` at every hop.
    #[inline]
    pub(crate) fn next_ref<'a>(&self) -> Option<&'a Rope> {
        // SAFETY: `next` is either null or a bump-arena allocation valid until
        // arena reset. Read-only borrow; no `&mut` alias is
        // outstanding at any caller (the chain is fully built before walking).
        unsafe { self.next.cast_const().as_ref() }
    }
}

// thiserror is not a dep of this crate; hand-roll Error+Display.
#[derive(Debug, strum::IntoStaticStr)]
pub enum SetError {
    OutOfMemory,
    Clobber,
}
bun_core::impl_tag_error!(SetError);
bun_core::oom_from_alloc!(SetError);

// ── live Object accessor surface ───────────────────────────────────────────
// Adapted to the current `Vec` API (`append(v)`, `slice()`, `slice_mut()`).
// Sort helpers stay in the gated impl below.
impl Object {
    pub const EMPTY: Object = Object {
        properties: bun_alloc::AstAlloc::vec(),
        comma_after_spread: crate::Loc::EMPTY,
        is_single_line: false,
        is_parenthesized: false,
        was_originally_macro: false,
        close_brace_loc: crate::Loc::EMPTY,
    };

    pub fn get(&self, key: &[u8]) -> Option<Expr> {
        self.as_property(key).map(|q| q.expr)
    }

    pub fn as_property(&self, name: &[u8]) -> Option<crate::expr::Query> {
        for (i, prop) in self.properties.slice().iter().enumerate() {
            let Some(value) = prop.value else { continue };
            let Some(key) = &prop.key else { continue };
            let crate::expr::Data::EString(key_str) = &key.data else {
                continue;
            };
            if key_str.eql_bytes(name) {
                return Some(crate::expr::Query {
                    expr: value,
                    loc: key.loc,
                    i: i as u32,
                });
            }
        }
        None
    }

    pub fn has_property(&self, name: &[u8]) -> bool {
        for prop in self.properties.slice() {
            let Some(key) = &prop.key else { continue };
            let crate::expr::Data::EString(key_str) = &key.data else {
                continue;
            };
            if key_str.eql_bytes(name) {
                return true;
            }
        }
        false
    }

    pub fn put(&mut self, bump: &Bump, key: &[u8], expr: Expr) -> Result<(), AllocError> {
        if let Some(q) = self.as_property(key) {
            self.properties.slice_mut()[q.i as usize].value = Some(expr);
        } else {
            let key = Expr::allocate(bump, EString::init(key), expr.loc);
            VecExt::append(
                &mut self.properties,
                G::Property {
                    flags: own_key_property_flags(&key),
                    key: Some(key),
                    value: Some(expr),
                    ..G::Property::default()
                },
            );
        }
        Ok(())
    }

    pub fn put_string(&mut self, bump: &Bump, key: &[u8], value: &[u8]) -> Result<(), AllocError> {
        self.put(
            bump,
            key,
            Expr::allocate(bump, EString::init(value), crate::Loc::EMPTY),
        )
    }

    /// Walks `rope` segments, creating nested objects as needed, and returns
    /// the leaf `E.Object` expression.
    pub fn get_or_put_object(&mut self, rope: &Rope, _bump: &Bump) -> Result<Expr, SetError> {
        let head_key = match rope.head.data.e_string() {
            Some(s) => s.data,
            None => return Err(SetError::Clobber),
        };
        if let Some(existing) = self.get(&head_key) {
            match existing.data {
                crate::expr::Data::EArray(array) => {
                    let Some(next) = rope.next_ref() else {
                        return Err(SetError::Clobber);
                    };
                    if let Some(last) = array.items.last() {
                        if let crate::expr::Data::EObject(mut obj) = last.data {
                            return obj.get_or_put_object(next, _bump);
                        }
                        return Err(SetError::Clobber);
                    }
                    return Err(SetError::Clobber);
                }
                crate::expr::Data::EObject(mut object) => {
                    if let Some(next) = rope.next_ref() {
                        return object.get_or_put_object(next, _bump);
                    }
                    return Ok(existing);
                }
                _ => return Err(SetError::Clobber),
            }
        }

        if let Some(next) = rope.next_ref() {
            let obj = Expr::init(Object::default(), rope.head.loc);
            let out = match obj.data {
                crate::expr::Data::EObject(mut o) => o.get_or_put_object(next, _bump)?,
                _ => unreachable!(),
            };
            VecExt::append(
                &mut self.properties,
                G::Property {
                    key: Some(rope.head),
                    value: Some(obj),
                    flags: own_key_property_flags(&rope.head),
                    ..G::Property::default()
                },
            );
            return Ok(out);
        }

        let out = Expr::init(Object::default(), rope.head.loc);
        VecExt::append(
            &mut self.properties,
            G::Property {
                key: Some(rope.head),
                value: Some(out),
                flags: own_key_property_flags(&rope.head),
                ..G::Property::default()
            },
        );
        Ok(out)
    }
}

/// Data-file parsers (JSON/JSON5/TOML/YAML) define every key as an own
/// property, so an own `"__proto__"` string key must be marked computed:
/// a plain `"__proto__":` key in a printed object literal sets the prototype.
pub fn own_key_property_flags(key: &Expr) -> crate::flags::PropertySet {
    match &key.data {
        crate::expr::Data::EString(key_str) if key_str.eql_comptime(b"__proto__") => {
            crate::flags::Property::IsComputed.into()
        }
        _ => crate::flags::PROPERTY_NONE,
    }
}

// `toJS` alias deleted — lives in `js_parser_jsc` extension trait.
impl Object {
    /// Appends a property without checking for an existing key. Callers that
    /// need duplicate detection must check `as_property` with UTF-8 bytes
    /// first — a UTF-16 EString key's raw `data` view is not byte-comparable.
    pub fn append_property(&mut self, key: Expr, value: Expr) {
        VecExt::append(
            &mut self.properties,
            G::Property {
                flags: own_key_property_flags(&key),
                key: Some(key),
                value: Some(value),
                ..G::Property::default()
            },
        );
    }

    /// Assumes each key in the property is a string
    pub fn alphabetize_properties(&mut self) {
        #[cfg(debug_assertions)]
        {
            for prop in self.properties.slice() {
                debug_assert!(matches!(
                    prop.key.as_ref().expect("infallible: prop has key").data,
                    crate::expr::Data::EString(_)
                ));
            }
        }
        index_sort::sort_slice_by(self.properties.slice_mut(), object_sorter_is_less_than);
    }
}

fn object_sorter_is_less_than(lhs: &G::Property, rhs: &G::Property) -> Ordering {
    let a = lhs
        .key
        .as_ref()
        .unwrap()
        .data
        .e_string()
        .expect("infallible: variant checked")
        .data;
    let b = rhs
        .key
        .as_ref()
        .unwrap()
        .data
        .e_string()
        .expect("infallible: variant checked")
        .data;
    a.cmp(&b)
}

pub struct Spread {
    pub value: ExprNodeIndex,
}

/// Discriminants are shared with the C++ switch in
/// `Bun__Temporal__fromDateTimeLiteral`.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum TomlDateTimeKind {
    /// `1979-05-27T00:32:00-07:00` → `Temporal.Instant`
    OffsetDateTime = 1,
    /// `1979-05-27T07:32:00` → `Temporal.PlainDateTime`
    LocalDateTime = 2,
    /// `1979-05-27` → `Temporal.PlainDate`
    LocalDate = 3,
    /// `07:32:00` → `Temporal.PlainTime`
    LocalTime = 4,
}

impl TomlDateTimeKind {
    /// Unqualified Temporal class name (`Instant`, `PlainDateTime`, …).
    pub fn temporal_class(self) -> &'static [u8] {
        match self {
            TomlDateTimeKind::OffsetDateTime => b"Instant",
            TomlDateTimeKind::LocalDateTime => b"PlainDateTime",
            TomlDateTimeKind::LocalDate => b"PlainDate",
            TomlDateTimeKind::LocalTime => b"PlainTime",
        }
    }
}

/// JavaScript string literal type
// repr(C, align(8)): `StoreStr`/`StoreRef` are `packed(4)`, so under
// `repr(Rust)` the `data.ptr: NonNull<u8>` lands at a 4-but-not-8-aligned
// offset, and a `static EString = EString::from_static(b"...")` then emits an
// `ARM64_RELOC_UNSIGNED` at that offset which arm64 ld rejects. `repr(C)` pins
// `data` (the only field needing a static relocation) at offset 0; `align(8)`
// keeps the struct itself 8-aligned. `EString` is arena-stored (never inline
// in `Expr`), so this does not affect `Expr` size.
#[repr(C, align(8))]
pub struct EString {
    // A version of this where `utf8` and `value` are stored in a packed union, with len as a single u32 was attempted.
    // It did not improve benchmarks. Neither did converting this from a heap-allocated type to a stack-allocated type.
    // TODO: change this to *const anyopaque and change all uses to either .slice8() or .slice16()
    // Arena-owned slice (`StoreStr`: lifetime-erased arena ownership, bulk-freed
    // at `Store::reset()` — see `nodes.rs` StoreStr docs).
    pub data: Str,

    // A very simple rope implementation
    // We only use this for string folding, so this is kind of overkill
    // We don't need to deal with substrings
    pub next: Option<StoreRef<EString>>,
    pub end: Option<StoreRef<EString>>,
    pub rope_len: u32,
    pub prefer_template: bool,
    pub is_utf16: bool,
    /// Set only by the TOML parser on a date/time literal (`data` is its
    /// ASCII source text). The TOML AST never enters the JS visit passes;
    /// the sinks that materialize or print it check this tag and produce a
    /// Temporal value instead of a string.
    pub toml_datetime: Option<TomlDateTimeKind>,
}
// Also exported as `String`; `EString` avoids colliding with bun_core::String.
pub use EString as String;

/// [`EString::flattened`] result: the node itself, or an owned copy when a rope was flattened.
pub enum Flattened<'a> {
    Borrowed(&'a EString),
    Owned(EString),
}

impl core::ops::Deref for Flattened<'_> {
    type Target = EString;
    #[inline]
    fn deref(&self) -> &EString {
        match self {
            Flattened::Borrowed(s) => s,
            Flattened::Owned(s) => s,
        }
    }
}

impl Default for EString {
    fn default() -> Self {
        Self {
            data: Str::EMPTY,
            prefer_template: false,
            next: None,
            end: None,
            rope_len: 0,
            is_utf16: false,
            toml_datetime: None,
        }
    }
}

// Minimal live surface for `IntoExprData` / `Data` / `lexer.rs` callers.
impl EString {
    #[inline]
    pub const fn is_utf8(&self) -> bool {
        !self.is_utf16
    }
    #[inline]
    pub fn slice8(&self) -> &[u8] {
        debug_assert!(!self.is_utf16);
        self.data.slice()
    }
    #[inline]
    pub fn slice16(&self) -> &[u16] {
        debug_assert!(self.is_utf16);
        // SAFETY: when `is_utf16`, `data` was constructed by `init_utf16` from a
        // `&[u16]`: `data.ptr` is the original u16-aligned pointer (reinterpreted
        // as `*const u8` for storage only) and `data.len` deliberately stores the
        // **u16 element count**, not a byte count — so the backing allocation is
        // `2 * data.len` bytes and reading `data.len` u16s is in-bounds. Can't be
        // `bytemuck::cast_slice(self.data.slice())` because that would yield
        // `len/2` u16s; the lying-length encoding is load-bearing for `len()`/
        // `javascript_length()` and changing it is a cross-crate refactor (see
        // TODO above).
        //
        // The `c_void` hop is clippy's documented escape hatch for
        // `cast_ptr_alignment` ("alignment is externally guaranteed" — see the
        // u16-aligned invariant above); it is a no-op reinterpret, not FFI.
        unsafe {
            core::slice::from_raw_parts(
                self.data.as_ptr().cast::<core::ffi::c_void>().cast::<u16>(),
                self.data.len(),
            )
        }
    }
    /// Const constructor for `'static` literals (Prefill globals).
    pub const fn from_static(data: &'static [u8]) -> Self {
        Self {
            data: Str::new(data),
            prefer_template: false,
            next: None,
            end: None,
            rope_len: 0,
            is_utf16: false,
            toml_datetime: None,
        }
    }
    /// `data` is arena-owned (source text or `Expr.Data.Store` / bump arena)
    /// and bulk-freed; `StoreStr` records it under the `StoreRef` contract.
    pub fn init(data: &[u8]) -> Self {
        Self {
            data: Str::new(data),
            ..Default::default()
        }
    }

    /// A TOML date/time literal; `data` must be ASCII text `Temporal.*.from`
    /// accepts verbatim.
    pub fn init_toml_datetime(data: &[u8], kind: TomlDateTimeKind) -> Self {
        Self {
            data: Str::new(data),
            toml_datetime: Some(kind),
            ..Default::default()
        }
    }
    /// Construct from a UTF-16 slice (arena-owned). The `data` slice's `.len()`
    /// stores the **u16 element count** (not byte count); `slice16()` and
    /// friends rely on this. The pointer is reinterpreted to `*const u8` for
    /// storage only.
    pub fn init_utf16(data: &[u16]) -> Self {
        // `Str::new` only records `(ptr, len)`; we want the original `*const u16`
        // (reinterpreted as bytes) and the **u16 element count**. Safe-cast the
        // full `2*len` byte view, then reslice to the first `len` bytes — same
        // pointer/length pair as the old raw-slice construction, without an
        // `unsafe` block. Consumers must check `is_utf16` and re-slice via
        // `slice16`.
        let bytes = &bytemuck::cast_slice::<u16, u8>(data)[..data.len()];
        Self {
            data: Str::new(bytes),
            is_utf16: true,
            ..Default::default()
        }
    }
    /// E.String containing non-ascii characters may not fully work.
    /// https://github.com/oven-sh/bun/issues/11963
    /// More investigation is needed.
    pub fn init_re_encode_utf8(utf8: &[u8], bump: &Bump) -> EString {
        if strings::first_non_ascii(utf8).is_none() {
            Self::init(utf8)
        } else {
            // PERF: transcodes to a heap Vec then copies into the bump
            // arena — profile.
            // `fail_if_invalid = false` means the only possible error is `OutOfMemory`.
            let utf16 = bun_core::handle_oom(strings::to_utf16_alloc_for_real(utf8, false, false));
            let arena_slice: &mut [u16] = bump.alloc_slice_copy(&utf16);
            Self::init_utf16(arena_slice)
        }
    }
    /// Ensure `data` is UTF-8 (transcode from UTF-16 rope if needed).
    /// `lexer.rs::to_utf8_e_string` only ever calls this on a freshly-decoded
    /// non-rope string; the heavy rope-walk path is in the gated impl below.
    pub fn to_utf8(&mut self, bump: &Bump) -> Result<(), AllocError> {
        if !self.is_utf16 {
            return Ok(());
        }
        let v = strings::to_utf8_alloc(self.slice16());
        self.data = Str::new(bump.alloc_slice_copy(&v));
        self.is_utf16 = false;
        Ok(())
    }
}

// ── live EString accessor surface ──────────────────────────────────────────
// Subset of the gated impl below adapted to the current `bun_core` API
// (`eql_long::<CHECK_LEN>`, no bump-arena `to_utf8_alloc`). Heavy
// transcode/rope-clone paths stay gated.
impl EString {
    #[inline]
    pub fn len(&self) -> usize {
        if self.rope_len > 0 {
            self.rope_len as usize
        } else {
            self.data.len()
        }
    }
    #[inline]
    pub fn is_blank(&self) -> bool {
        self.len() == 0
    }
    #[inline]
    pub fn is_present(&self) -> bool {
        self.len() > 0
    }

    /// Flatten any rope and return UTF-8 bytes.
    /// Resolves the rope into the bump arena, then transcodes if UTF-16.
    pub fn slice<'b>(&mut self, bump: &'b Bump) -> &'b [u8] {
        self.resolve_rope_if_needed(bump);
        self.string(bump).expect("OOM")
    }

    pub fn eql_bytes(&self, other: &[u8]) -> bool {
        if self.is_utf8() {
            strings::eql_long(&self.data, other, true)
        } else {
            strings::utf16_eql_string(self.slice16(), other)
        }
    }

    pub fn eql_comptime(&self, value: &'static [u8]) -> bool {
        if !self.is_utf8() {
            debug_assert!(self.next.is_none(), "transpiler: utf-16 string is a rope");
            return strings::eql_comptime_utf16(self.slice16(), value);
        }
        if self.next.is_none() {
            return self.data == value;
        }
        self.eql8_rope(value)
    }

    fn eql8_rope(&self, value: &[u8]) -> bool {
        debug_assert!(self.next.is_some() && self.is_utf8());
        if self.rope_len as usize != value.len() {
            return false;
        }
        let mut i = 0usize;
        let mut next: Option<&EString> = Some(self);
        while let Some(cur) = next {
            if !strings::eql_long(&cur.data, &value[i..i + cur.data.len()], false) {
                return false;
            }
            i += cur.data.len();
            next = cur.next.as_ref().map(|r| r.get());
        }
        true
    }

    /// Flatten in place. Parser only; shared-AST readers use [`Self::flattened`].
    pub fn resolve_rope_if_needed(&mut self, bump: &Bump) {
        if self.next.is_none() || !self.is_utf8() {
            return;
        }
        self.data = Str::new(self.flatten_rope(bump));
        self.next = None;
    }

    /// `self` if not a rope, else a copy flattened into `bump`. Never writes to `self`.
    pub fn flattened(&self, bump: &Bump) -> Flattened<'_> {
        if self.next.is_none() || !self.is_utf8() {
            return Flattened::Borrowed(self);
        }
        let mut copy = self.shallow_clone();
        copy.data = Str::new(self.flatten_rope(bump));
        copy.next = None;
        Flattened::Owned(copy)
    }

    /// The rope's bytes, concatenated into a fresh `bump` slice.
    fn flatten_rope<'b>(&self, bump: &'b Bump) -> &'b [u8] {
        let mut bytes = bun_alloc::ArenaVec::<u8>::with_capacity_in(self.rope_len as usize, bump);
        bytes.extend_from_slice(&self.data);
        let mut str_ = self.next;
        while let Some(part) = str_ {
            bytes.extend_from_slice(&part.get().data);
            str_ = part.get().next;
        }
        bytes.into_bump_slice()
    }

    /// Return UTF-8 bytes, transcoding if UTF-16.
    /// The transcode allocates via the global arena then copies into `bump`.
    pub fn string<'b>(&self, bump: &'b Bump) -> Result<&'b [u8], AllocError> {
        if self.is_utf8() {
            // `self.data` is arena-owned with the same lifetime as `bump`;
            // StoreStr re-borrows under that contract.
            Ok(self.data.slice())
        } else {
            let v = strings::to_utf8_alloc(self.slice16());
            Ok(bump.alloc_slice_copy(&v))
        }
    }

    pub(crate) fn string_cloned<'b>(&self, bump: &'b Bump) -> Result<&'b [u8], AllocError> {
        if self.is_utf8() {
            Ok(bump.alloc_slice_copy(&self.data))
        } else {
            let v = strings::to_utf8_alloc(self.slice16());
            Ok(bump.alloc_slice_copy(&v))
        }
    }

    pub fn hash(&self) -> u64 {
        if self.is_blank() {
            return 0;
        }
        if self.is_utf8() {
            bun_wyhash::hash(&self.data)
        } else {
            bun_wyhash::hash(bytemuck::cast_slice::<u16, u8>(self.slice16()))
        }
    }
}

// ── EString surface ────────────────────────────────────────────────────────
// Ordering / equality / const-literal / rope-mutation helpers.
impl EString {
    pub const EMPTY: EString = EString::from_static(b"");

    pub fn is_identifier(&mut self, bump: &Bump) -> bool {
        if !self.is_utf8() {
            return crate::lexer_tables::is_identifier_utf16(self.slice16());
        }
        crate::lexer_tables::is_identifier(self.slice(bump))
    }

    /// Compares two strings lexicographically for JavaScript semantics.
    /// Both strings must share the same encoding (UTF-8 vs UTF-16).
    #[inline]
    pub fn order(&self, other: &EString) -> Ordering {
        debug_assert!(self.is_utf8() == other.is_utf8());
        if self.is_utf8() {
            strings::order(&self.data, &other.data)
        } else {
            strings::order_t(self.slice16(), other.slice16())
        }
    }

    pub fn javascript_length(&self) -> Option<u32> {
        if self.rope_len > 0 {
            // We only support ascii ropes for now
            return Some(self.rope_len);
        }
        if self.is_utf8() {
            if !strings::is_all_ascii(&self.data) {
                return None;
            }
            return Some(self.data.len() as u32);
        }
        Some(self.slice16().len() as u32)
    }

    // `eql`, split by operand type.
    pub fn eql_string(&self, other: &EString) -> bool {
        if self.is_utf8() {
            if other.is_utf8() {
                strings::eql_long(&self.data, &other.data, true)
            } else {
                strings::utf16_eql_string(other.slice16(), &self.data)
            }
        } else if other.is_utf8() {
            strings::utf16_eql_string(self.slice16(), &other.data)
        } else {
            self.slice16() == other.slice16()
        }
    }

    /// Shallow field-wise copy. `EString` is structurally `Copy` (slice ref +
    /// `Option<NonNull>` rope links + scalars) but does not derive it to keep
    /// rope-ownership intent explicit; use this for field-wise copies.
    #[inline]
    pub fn shallow_clone(&self) -> EString {
        EString {
            data: self.data,
            prefer_template: self.prefer_template,
            next: self.next,
            end: self.end,
            rope_len: self.rope_len,
            is_utf16: self.is_utf16,
            toml_datetime: self.toml_datetime,
        }
    }

    /// Link `other` onto this string's rope tail. Mutates both ropes: neither may have another owner.
    ///
    /// `other` MUST be Store/arena-allocated (callers pass
    /// `Expr::init(EString, ...).data.e_string_mut()` or a freshly
    /// `Store::append`ed node); its address is captured as a `StoreRef`.
    pub(crate) fn push(&mut self, other: &mut EString) {
        debug_assert!(self.is_utf8());
        debug_assert!(other.is_utf8());

        if other.rope_len == 0 {
            other.rope_len = other.data.len() as u32;
        }
        if self.rope_len == 0 {
            self.rope_len = self.data.len() as u32;
        }
        self.rope_len += other.rope_len;

        // Caller contract — `other` lives in the AST Store/arena and outlives
        // the next reset, so capturing its address as a `StoreRef` is sound.
        let other_ref = StoreRef::from_bump(other);
        if self.next.is_none() {
            self.next = Some(other_ref);
            self.end = Some(other_ref);
        } else {
            let mut end = self.end.unwrap();
            while end.get().next.is_some() {
                end = end.get().end.unwrap();
            }
            // `end` points into the live Store; rope nodes are mutated in
            // place via `StoreRef::DerefMut` (single-threaded visitor).
            end.next = Some(other_ref);
            self.end = Some(other_ref);
        }
    }
}

fn array_sorter_is_less_than(lhs: &Expr, rhs: &Expr) -> Ordering {
    lhs.data.e_string().unwrap().order(
        rhs.data
            .e_string()
            .expect("infallible: variant checked")
            .get(),
    )
}

impl fmt::Display for EString {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str("E.String")?;
        if self.next.is_none() {
            f.write_str("(")?;
            if self.is_utf8() {
                write!(f, "\"{}\"", bstr::BStr::new(&self.data))?;
            } else {
                write!(f, "\"{}\"", bun_core::fmt::utf16(self.slice16()))?;
            }
            f.write_str(")")?;
        } else {
            f.write_str("(rope: [")?;
            let mut it: Option<&EString> = Some(self);
            while let Some(part) = it {
                if part.is_utf8() {
                    write!(f, "\"{}\"", bstr::BStr::new(&part.data))?;
                } else {
                    write!(f, "\"{}\"", bun_core::fmt::utf16(part.slice16()))?;
                }
                it = part.next.as_deref();
                if it.is_some() {
                    f.write_str(" ")?;
                }
            }
            f.write_str("])")?;
        }
        Ok(())
    }
}

// value is in the Node
pub struct TemplatePart {
    pub value: ExprNodeIndex,
    pub tail_loc: crate::Loc,
    pub tail: TemplateContents,
}

pub struct Template {
    pub tag: Option<ExprNodeIndex>,
    /// Arena-owned mutable slice. Stored as a
    /// `StoreSlice` so writers (`substitute_single_use_symbol_in_expr`, the
    /// visit pass, `foldStringAddition`) retain mutable provenance. Use
    /// `parts()` / `parts_mut()` for ergonomic access; never null.
    pub parts: crate::StoreSlice<TemplatePart>,
    pub head: TemplateContents,
}

impl Template {
    /// Empty `StoreSlice<TemplatePart>` for parts-less templates (e.g. tagged
    /// no-substitution literals).
    #[inline]
    pub fn empty_parts() -> crate::StoreSlice<TemplatePart> {
        crate::StoreSlice::EMPTY
    }

    #[inline]
    pub fn parts(&self) -> &[TemplatePart] {
        self.parts.slice()
    }

    #[inline]
    pub fn parts_mut(&mut self) -> &mut [TemplatePart] {
        self.parts.slice_mut()
    }
}

pub enum TemplateContents {
    Cooked(EString),
    Raw(Str),
}
impl TemplateContents {
    pub(crate) fn is_utf8(&self) -> bool {
        matches!(self, TemplateContents::Cooked(c) if c.is_utf8())
    }

    bun_core::enum_unwrap!(pub TemplateContents, Cooked => fn cooked / cooked_mut -> EString);
}

impl TemplateContents {
    /// Field-wise copy. `EString` is structurally
    /// `Copy` but does not derive it; use `shallow_clone` for the cooked arm.
    #[inline]
    pub(crate) fn shallow_clone(&self) -> TemplateContents {
        match self {
            TemplateContents::Cooked(c) => TemplateContents::Cooked(c.shallow_clone()),
            TemplateContents::Raw(r) => TemplateContents::Raw(*r),
        }
    }
}

impl Template {
    /// "`a${'b'}c`" => "`abc`"
    pub fn fold(&mut self, bump: &Bump, loc: crate::Loc) -> Expr {
        if self.tag.is_some()
            || (matches!(self.head, TemplateContents::Cooked(_)) && !self.head.cooked().is_utf8())
        {
            // we only fold utf-8/ascii for now
            // `self` is Store/arena-allocated, so capturing its address as a
            // `StoreRef` is sound.
            return Expr {
                data: crate::expr::Data::ETemplate(StoreRef::from_bump(self)),
                loc,
            };
        }

        debug_assert!(matches!(self.head, TemplateContents::Cooked(_)));

        if self.parts().is_empty() {
            return Expr::init(core::mem::take(self.head.cooked_mut()), loc);
        }

        let mut parts =
            bun_alloc::ArenaVec::<TemplatePart>::with_capacity_in(self.parts().len(), bump);
        let mut head = Expr::init(core::mem::take(self.head.cooked_mut()), loc);
        for part_src in self.parts() {
            // Field-wise copy (TemplatePart is not `Copy` only
            // because `EString` does not derive it; all fields are structurally `Copy`).
            let mut part = TemplatePart {
                value: part_src.value,
                tail_loc: part_src.tail_loc,
                tail: part_src.tail.shallow_clone(),
            };
            debug_assert!(matches!(part.tail, TemplateContents::Cooked(_)));

            part.value = part.value.unwrap_inlined();

            match &part.value.data {
                crate::expr::Data::ENumber(n) => {
                    if let Some(s) = n.to_string(bump) {
                        part.value = Expr::init(EString::init(&s), part.value.loc);
                    }
                }
                crate::expr::Data::ENull(_) => {
                    part.value = Expr::init(EString::init(b"null"), part.value.loc);
                }
                crate::expr::Data::EBoolean(b) => {
                    part.value = Expr::init(
                        EString::init(if b.value { &b"true"[..] } else { &b"false"[..] }),
                        part.value.loc,
                    );
                }
                crate::expr::Data::EUndefined(_) => {
                    part.value = Expr::init(EString::init(b"undefined"), part.value.loc);
                }
                crate::expr::Data::EBigInt(value) => {
                    if !BigInt::has_radix(&value.value) {
                        part.value = Expr::init(EString::init(&value.value), part.value.loc);
                    }
                }
                _ => {}
            }

            if matches!(part.value.data, crate::expr::Data::EString(_))
                && part.tail.cooked().is_utf8()
                && part
                    .value
                    .data
                    .e_string()
                    .expect("infallible: variant checked")
                    .is_utf8()
            {
                if parts.is_empty() {
                    if part
                        .value
                        .data
                        .e_string()
                        .expect("infallible: variant checked")
                        .len()
                        > 0
                    {
                        head.data
                            .e_string_mut()
                            .expect("infallible: variant checked")
                            .push(
                                Expr::init(
                                    part.value
                                        .data
                                        .e_string()
                                        .expect("infallible: variant checked")
                                        .shallow_clone(),
                                    crate::Loc::EMPTY,
                                )
                                .data
                                .e_string_mut()
                                .unwrap(),
                            );
                    }

                    if part.tail.cooked().len() > 0 {
                        head.data
                            .e_string_mut()
                            .expect("infallible: variant checked")
                            .push(
                                Expr::init(core::mem::take(part.tail.cooked_mut()), part.tail_loc)
                                    .data
                                    .e_string_mut()
                                    .unwrap(),
                            );
                    }

                    continue;
                } else {
                    let prev_part = parts.last_mut().unwrap();
                    debug_assert!(matches!(prev_part.tail, TemplateContents::Cooked(_)));

                    if prev_part.tail.cooked().is_utf8() {
                        if part
                            .value
                            .data
                            .e_string()
                            .expect("infallible: variant checked")
                            .len()
                            > 0
                        {
                            prev_part.tail.cooked_mut().push(
                                Expr::init(
                                    part.value
                                        .data
                                        .e_string()
                                        .expect("infallible: variant checked")
                                        .shallow_clone(),
                                    crate::Loc::EMPTY,
                                )
                                .data
                                .e_string_mut()
                                .unwrap(),
                            );
                        }

                        if part.tail.cooked().len() > 0 {
                            prev_part.tail.cooked_mut().push(
                                Expr::init(core::mem::take(part.tail.cooked_mut()), part.tail_loc)
                                    .data
                                    .e_string_mut()
                                    .unwrap(),
                            );
                        }
                    } else {
                        parts.push(part);
                    }
                }
            } else {
                parts.push(part);
            }
        }

        if parts.is_empty() {
            // parts.deinit() — drop is implicit
            head.data
                .e_string_mut()
                .expect("infallible: variant checked")
                .resolve_rope_if_needed(bump);
            return head;
        }

        // Arena-owned mutable slice; `into_bump_slice_mut()` preserves write
        // provenance for downstream mutators.
        Expr::init(
            Template {
                tag: None,
                parts: crate::StoreSlice::from_bump(parts),
                head: TemplateContents::Cooked(
                    head.data
                        .e_string()
                        .expect("infallible: variant checked")
                        .shallow_clone(),
                ),
            },
            loc,
        )
    }
}

pub struct RegExp {
    // Arena-owned slice (`StoreStr`: lifetime-erased arena ownership, bulk-freed
    // at `Store::reset()` — see `nodes.rs` StoreStr docs).
    pub value: Str,

    /// This exists for JavaScript bindings
    /// The RegExp constructor expects flags as a second argument.
    /// We want to avoid re-lexing the flags, so we store them here.
    /// This is the index of the first character in a flag, not the "/"
    /// /foo/gim
    ///      ^
    pub flags_offset: Option<u16>,
}
impl RegExp {
    pub fn pattern(&self) -> &[u8] {
        // Between the first slash and the last: flags have none. Not `trim`: a pattern can end in `\/`.
        let end = bun_core::strings::last_index_of_char(&self.value, b'/').unwrap_or(0);
        self.value.get(1..end).unwrap_or_default()
    }

    pub fn flags(&self) -> &[u8] {
        // Behind the last slash. Not by `flags_offset`, which wraps at 65,536.
        let slash = bun_core::strings::last_index_of_char(&self.value, b'/');
        slash
            .and_then(|it| self.value.get(it + 1..))
            .unwrap_or_default()
    }
}

pub struct Await {
    pub value: ExprNodeIndex,
}

#[derive(Default)]
pub struct Yield {
    pub value: Option<ExprNodeIndex>,
    pub is_star: bool,
}

pub struct If {
    pub test: ExprNodeIndex,
    pub yes: ExprNodeIndex,
    pub no: ExprNodeIndex,
}

pub enum UnwrappedRequireMarker {}
/// Index into the parser's `imports_to_convert_from_require`.
pub type UnwrappedRequireIndex = bun_core::GenericIndex<u32, UnwrappedRequireMarker>;
pub type UnwrappedRequireIndexOptional =
    bun_core::GenericIndexOptional<u32, UnwrappedRequireMarker>;

#[derive(Clone, Copy)]
pub struct RequireString {
    pub import_record_index: u32,

    /// Set when `unwrap_commonjs_to_esm` turned this `require()` into an import.
    pub unwrapped_id: UnwrappedRequireIndexOptional,
}
impl Default for RequireString {
    fn default() -> Self {
        Self {
            import_record_index: 0,
            unwrapped_id: UnwrappedRequireIndexOptional::NONE,
        }
    }
}

#[derive(Clone, Copy)]
pub struct RequireResolveString {
    pub import_record_index: u32,
    // close_paren_loc: logger.Loc = logger.Loc.Empty,
}

pub struct InlinedEnum {
    pub value: ExprNodeIndex,
    // Arena-owned slice (`StoreStr`: lifetime-erased arena ownership, bulk-freed
    // at `Store::reset()` — see `nodes.rs` StoreStr docs).
    pub comment: Str,
}

pub struct Import {
    pub expr: ExprNodeIndex,
    pub options: ExprNodeIndex,
    pub import_record_index: u32,
    /// When bundling a string-literal `import("...")`, this is the synthetic
    /// namespace symbol minted by `transpose_import`. Property accesses /
    /// destructuring of the awaited result are recorded under this ref so the
    /// linker can tree-shake unused exports of the importee. `Ref::NONE` when
    /// not bundling or the specifier is non-constant.
    pub namespace_ref: Ref,
    // TODO:
    // Comments inside "import()" expressions have special meaning for Webpack.
    // Preserving comments inside these expressions makes it possible to use
    // esbuild as a TypeScript-to-JavaScript frontend for Webpack to improve
    // performance. We intentionally do not interpret these comments in esbuild
    // because esbuild is not Webpack. But we do preserve them since doing so is
    // harmless, easy to maintain, and useful to people. See the Webpack docs for
    // more info: https://webpack.js.org/api/module-methods/#magic-comments.
    // leading_interior_comments: []G.Comment = &([_]G.Comment{}),
}
impl Import {
    pub fn is_import_record_null(&self) -> bool {
        self.import_record_index == u32::MAX
    }

    pub fn import_record_loader(&self) -> Option<crate::Loader> {
        let crate::ExprData::EObject(obj) = &self.options.data else {
            return None;
        };
        let with = Object::get(obj, b"with").or_else(|| Object::get(obj, b"assert"))?;
        let crate::ExprData::EObject(with_obj) = &with.data else {
            return None;
        };
        let str_ = Object::get(with_obj, b"type")?.data.as_e_string()?;

        if !str_.is_utf16 {
            if let Some(loader) = crate::Loader::from_string(&str_.data) {
                if loader == crate::Loader::Sqlite {
                    let Some(embed) = Object::get(with_obj, b"embed") else {
                        return Some(loader);
                    };
                    let Some(embed_str) = embed.data.as_e_string() else {
                        return Some(loader);
                    };
                    if embed_str.eql_comptime(b"true") {
                        return Some(crate::Loader::SqliteEmbedded);
                    }
                }
                return Some(loader);
            }
        }

        None
    }
}

pub use G::Class;

// ──────────────────────────────────────────────────────────────────────────
// Tests
//
// Run under Miri (`bun run rust:miri -p bun_ast`): the JSON tape hands `(first,
// count)` spans to nodes that hold a raw `NonNull<JsonTape>` and read through
// it long after parsing appended more rows, so Tree Borrows is what proves the
// stored pointer survives those writes.
// ──────────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod json_tape_tests {
    use super::*;
    use crate::Loc;
    use core::ptr::NonNull;

    fn prop(key: Str, value: JsonValue) -> PropertyJSON {
        PropertyJSON {
            key,
            key_loc: Loc::EMPTY,
            value,
        }
    }

    /// Mirrors `Parser`'s ownership: the tape is a heap allocation the parser
    /// holds as a `NonNull` and reaches only through that pointer, handing the
    /// same pointer to every node it builds.
    struct TapeOwner(NonNull<JsonTape>);

    impl TapeOwner {
        fn new() -> Self {
            TapeOwner(
                NonNull::new(bun_core::heap::into_raw(Box::new(JsonTape::empty())))
                    .expect("non-null"),
            )
        }
        fn ptr(&self) -> NonNull<JsonTape> {
            self.0
        }
        /// `Parser::tape_mut` — a fresh reborrow of the root pointer per call.
        #[allow(clippy::mut_from_ref)]
        fn get(&self) -> &mut JsonTape {
            // SAFETY: sole owner; each call hands out one short-lived borrow.
            unsafe { &mut *self.0.as_ptr() }
        }
    }

    impl Drop for TapeOwner {
        fn drop(&mut self) {
            // SAFETY: sole owner of a `Box`-allocated tape.
            drop(unsafe { bun_core::heap::take(self.0.as_ptr()) });
        }
    }

    /// The parser keeps appending to the tape while it builds enclosing nodes.
    /// Mirrors `{"a": {"b": null}}`: the inner object's node is built first,
    /// then the outer object allocates a key and appends its own rows — writes
    /// the inner node must survive, because `properties()` is read afterwards.
    #[test]
    fn object_json_survives_later_tape_writes() {
        let tape = TapeOwner::new();

        // Inner `{"b": null}`.
        let kb = tape.get().alloc_str(b"b");
        let (first, count) = tape.get().append_props(&[prop(kb, JsonValue::Null)], &[]);
        // SAFETY: the tape's own pointer, as `Parser` passes it.
        let inner = unsafe { ObjectJSON::new(tape.ptr(), first, count, true, Loc::EMPTY) };

        // The parse continues: another string, then the outer object's rows.
        let ka = tape.get().alloc_str(b"a");
        let (first, count) = tape.get().append_props(&[prop(ka, JsonValue::Null)], &[]);
        // SAFETY: as above.
        let outer = unsafe { ObjectJSON::new(tape.ptr(), first, count, true, Loc::EMPTY) };

        // Post-parse reads, after every one of those writes.
        assert_eq!(inner.properties().len(), 1);
        assert_eq!(inner.properties()[0].key.slice(), b"b");
        assert_eq!(outer.properties().len(), 1);
        assert_eq!(outer.properties()[0].key.slice(), b"a");
        assert!(inner.get(b"b").is_some());
        assert!(inner.get(b"nope").is_none());
    }

    #[test]
    fn array_json_survives_later_tape_writes() {
        let tape = TapeOwner::new();

        let (first, count) = tape.get().append_items(&[JsonValue::Null], &[]);
        // SAFETY: the tape's own pointer, as `Parser` passes it.
        let inner = unsafe { ArrayJSON::new(tape.ptr(), first, count, true, Loc::EMPTY) };

        let (first, count) = tape.get().append_items(&[JsonValue::Boolean(true)], &[]);
        // SAFETY: as above.
        let outer = unsafe { ArrayJSON::new(tape.ptr(), first, count, true, Loc::EMPTY) };

        assert_eq!(inner.items().len(), 1);
        assert!(matches!(inner.items()[0], JsonValue::Null));
        assert_eq!(outer.items().len(), 1);
        assert!(matches!(outer.items()[0], JsonValue::Boolean(true)));
    }

    /// An empty span must not dereference the tape at all.
    #[test]
    fn zero_count_spans_do_not_read_the_tape() {
        let tape = TapeOwner::new();
        // SAFETY: the tape's own pointer.
        let o = unsafe { ObjectJSON::new(tape.ptr(), 0, 0, true, Loc::EMPTY) };
        // SAFETY: as above.
        let a = unsafe { ArrayJSON::new(tape.ptr(), 0, 0, true, Loc::EMPTY) };
        assert!(o.properties().is_empty());
        assert_eq!(o.value_locs(), Some(&[][..]));
        assert!(a.items().is_empty());
        assert_eq!(a.item_locs(), Some(&[][..]));
    }

    /// `alloc_str` hands out `Str`s pointing into chunks that must stay put as
    /// later strings spill into new chunks.
    #[test]
    fn alloc_str_chunks_never_move() {
        let tape = TapeOwner::new();
        let a = tape.get().alloc_str(b"first");
        // Force a fresh chunk: bigger than what is left in the current one.
        let big = vec![b'x'; JsonTape::STR_CHUNK + 1];
        let b = tape.get().alloc_str(&big);
        let c = tape.get().alloc_str(b"third");
        assert_eq!(a.slice(), b"first");
        assert_eq!(b.slice(), &big[..]);
        assert_eq!(c.slice(), b"third");
    }

    /// `Parser::new`'s arena arm roots the tape at the `&mut JsonTape` the
    /// allocator hands back, not at a `Box::into_raw`. Writes through that root
    /// must still be permitted: a shared reborrow here is frozen, so every
    /// `append_props` the parse performs afterwards would be UB. This is the
    /// shape the bundler's JSON imports take.
    #[test]
    fn tape_rooted_at_a_mutable_borrow_still_accepts_writes() {
        let mut owner = JsonTape::empty();
        // `root_ptr` takes `&mut self`, exactly as `arena.alloc(..)` yields.
        let tape_ptr = owner.root_ptr();
        // From here on reach the tape only through `tape_ptr`, as the parser does.
        // SAFETY: `tape_ptr` roots the tape; `owner` is untouched until it drops.
        let tape = |p: NonNull<JsonTape>| -> &mut JsonTape { unsafe { &mut *p.as_ptr() } };

        let kb = tape(tape_ptr).alloc_str(b"b");
        let (first, count) = tape(tape_ptr).append_props(&[prop(kb, JsonValue::Null)], &[]);
        // SAFETY: the tape's own pointer.
        let inner = unsafe { ObjectJSON::new(tape_ptr, first, count, true, Loc::EMPTY) };

        // The parse keeps appending after the node is built.
        let ka = tape(tape_ptr).alloc_str(b"a");
        let (first, count) = tape(tape_ptr).append_props(&[prop(ka, JsonValue::Null)], &[]);
        // SAFETY: as above.
        let outer = unsafe { ObjectJSON::new(tape_ptr, first, count, true, Loc::EMPTY) };

        assert_eq!(inner.properties()[0].key.slice(), b"b");
        assert_eq!(outer.properties()[0].key.slice(), b"a");
    }
}
