use crate as css;
use crate::CSSString;
use crate::css_values::easing::EasingFunction;
use crate::css_values::ident::{CustomIdent, DashedIdent, is_reserved_custom_ident};
use crate::css_values::number::{CSSNumber, CSSNumberFns};
use crate::css_values::time::Time;
use crate::generics::CssEql;
use crate::{Parser, PrintErr, Printer};
use bun_core::strings;

/// A value for the [animation](https://drafts.csswg.org/css-animations/#animation) shorthand property.
#[derive(CssEql)]
pub struct Animation {
    /// The animation name.
    pub name: AnimationName,
    /// The animation duration.
    pub(crate) duration: Time,
    /// The easing function for the animation.
    pub(crate) timing_function: EasingFunction,
    /// The number of times the animation will run.
    pub(crate) iteration_count: AnimationIterationCount,
    /// The direction of the animation.
    pub(crate) direction: AnimationDirection,
    /// The current play state of the animation.
    pub(crate) play_state: AnimationPlayState,
    /// The animation delay.
    pub(crate) delay: Time,
    /// The animation fill mode.
    pub(crate) fill_mode: AnimationFillMode,
    /// The animation timeline.
    pub(crate) timeline: AnimationTimeline,
}

impl Animation {
    pub(crate) fn deep_clone(&self, bump: &bun_alloc::Arena) -> Self {
        Animation {
            name: self.name.deep_clone(bump),
            duration: self.duration,
            timing_function: self.timing_function.clone(),
            iteration_count: self.iteration_count,
            direction: self.direction,
            play_state: self.play_state,
            delay: self.delay,
            fill_mode: self.fill_mode,
            timeline: self.timeline.deep_clone(bump),
        }
    }

    // PropertyFieldMap omitted: the animation *longhands* (animation-duration,
    // animation-delay, …) are still unparsed-only, so shorthand→longhand
    // expansion has nothing to map to yet. Re-add the field→PropertyIdTag table
    // once those longhand variants land.

    pub fn parse(input: &mut Parser) -> css::Result<Self> {
        let mut name: Option<AnimationName> = None;
        let mut duration: Option<Time> = None;
        let mut timing_function: Option<EasingFunction> = None;
        let mut iteration_count: Option<AnimationIterationCount> = None;
        let mut direction: Option<AnimationDirection> = None;
        let mut play_state: Option<AnimationPlayState> = None;
        let mut delay: Option<Time> = None;
        let mut fill_mode: Option<AnimationFillMode> = None;
        let mut timeline: Option<AnimationTimeline> = None;

        loop {
            if duration.is_none() {
                if let Ok(value) = input.try_parse(Time::parse) {
                    duration = Some(value);
                    continue;
                }
            }
            if timing_function.is_none() {
                if let Ok(value) = input.try_parse(EasingFunction::parse) {
                    timing_function = Some(value);
                    continue;
                }
            }
            if delay.is_none() {
                if let Ok(value) = input.try_parse(Time::parse) {
                    delay = Some(value);
                    continue;
                }
            }
            if iteration_count.is_none() {
                if let Ok(value) = input.try_parse(AnimationIterationCount::parse) {
                    iteration_count = Some(value);
                    continue;
                }
            }
            if direction.is_none() {
                if let Ok(value) = input.try_parse(AnimationDirection::parse) {
                    direction = Some(value);
                    continue;
                }
            }
            if fill_mode.is_none() {
                if let Ok(value) = input.try_parse(AnimationFillMode::parse) {
                    fill_mode = Some(value);
                    continue;
                }
            }
            if play_state.is_none() {
                if let Ok(value) = input.try_parse(AnimationPlayState::parse) {
                    play_state = Some(value);
                    continue;
                }
            }
            if name.is_none() {
                if let Ok(value) = input.try_parse(AnimationName::parse) {
                    name = Some(value);
                    continue;
                }
            }
            if timeline.is_none() {
                if let Ok(value) = input.try_parse(AnimationTimeline::parse) {
                    timeline = Some(value);
                    continue;
                }
            }
            break;
        }

        css::Result::Ok(Animation {
            name: name.unwrap_or(AnimationName::None),
            duration: duration.unwrap_or(Time::Seconds(0.0)),
            timing_function: timing_function.unwrap_or(EasingFunction::Ease),
            iteration_count: iteration_count.unwrap_or(AnimationIterationCount::Number(1.0)),
            direction: direction.unwrap_or(AnimationDirection::Normal),
            play_state: play_state.unwrap_or(AnimationPlayState::Running),
            delay: delay.unwrap_or(Time::Seconds(0.0)),
            fill_mode: fill_mode.unwrap_or(AnimationFillMode::None),
            timeline: timeline.unwrap_or(AnimationTimeline::Auto),
        })
    }

    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        // Extract the inner string slice up front so both the ident and
        // string variants share one code path.
        let name_str: Option<&[u8]> = match &self.name {
            AnimationName::None => None,
            AnimationName::Ident(ident) => Some(ident.v()),
            // SAFETY: arena-owned slice lives for the parse session.
            AnimationName::String(s) => Some(unsafe { crate::arena_str(*s) }),
        };

        // Unlike lightningcss — which only emits the components when a name is
        // present and relies on its declaration handler to never serialize a
        // name-less shorthand — Bun prints the `Animation` struct directly, so
        // the components must be emitted even when the name is `none`; otherwise
        // `animation: 2s` would collapse to `none` and lose its duration. The
        // keyword-disambiguation checks (a name spelled like a component keyword
        // forces that component to be shown) only apply when there is a name.
        let mut wrote_any = false;
        macro_rules! space {
            () => {
                if wrote_any {
                    dest.write_char(b' ')?;
                }
            };
        }

        if !self.duration.is_zero() || !self.delay.is_zero() {
            space!();
            self.duration.to_css(dest)?;
            wrote_any = true;
        }

        if !self.timing_function.is_ease() || name_str.is_some_and(EasingFunction::is_ident) {
            space!();
            self.timing_function.to_css(dest)?;
            wrote_any = true;
        }

        if !self.delay.is_zero() {
            space!();
            self.delay.to_css(dest)?;
            wrote_any = true;
        }

        if self.iteration_count != AnimationIterationCount::default()
            || name_str.is_some_and(|n| strings::eql_case_insensitive_ascii(n, b"infinite", true))
        {
            space!();
            self.iteration_count.to_css(dest)?;
            wrote_any = true;
        }

        if self.direction != AnimationDirection::default()
            || name_str.is_some_and(|n| {
                css::parse_utility::parse_string::<AnimationDirection>(
                    dest.arena,
                    n,
                    AnimationDirection::parse,
                )
                .is_ok()
            })
        {
            space!();
            self.direction.to_css(dest)?;
            wrote_any = true;
        }

        if self.fill_mode != AnimationFillMode::default()
            || name_str.is_some_and(|n| {
                !strings::eql_case_insensitive_ascii(n, b"none", true)
                    && css::parse_utility::parse_string::<AnimationFillMode>(
                        dest.arena,
                        n,
                        AnimationFillMode::parse,
                    )
                    .is_ok()
            })
        {
            space!();
            self.fill_mode.to_css(dest)?;
            wrote_any = true;
        }

        if self.play_state != AnimationPlayState::default()
            || name_str.is_some_and(|n| {
                css::parse_utility::parse_string::<AnimationPlayState>(
                    dest.arena,
                    n,
                    AnimationPlayState::parse,
                )
                .is_ok()
            })
        {
            space!();
            self.play_state.to_css(dest)?;
            wrote_any = true;
        }

        // A `none` name is redundant once other components were written, so only
        // emit the name when it is a real name or nothing else was written.
        if !matches!(self.name, AnimationName::None) || !wrote_any {
            space!();
            self.name.to_css(dest)?;
        }

        if !matches!(self.name, AnimationName::None)
            && self.timeline != AnimationTimeline::default()
        {
            dest.write_char(b' ')?;
            self.timeline.to_css(dest)?;
        }

        Ok(())
    }
}

/// A value for the [animation-name](https://drafts.csswg.org/css-animations/#animation-name) property.
// no `#[derive(PartialEq, Eq, Hash)]` — `CustomIdent`/`CSSString`
// carry raw `*const [u8]` arena pointers; derived eq/hash would compare by
// pointer. Hand-written `eql`/`hash` below compare by content.
#[derive(Clone, Copy)]
pub enum AnimationName {
    /// The `none` keyword.
    None,
    /// An identifier of a `@keyframes` rule.
    Ident(CustomIdent),
    /// A `<string>` name of a `@keyframes` rule.
    String(CSSString),
}

impl AnimationName {
    // hand-written (not `#[derive]`) because `CSSString` is a raw
    // `*const [u8]` arena pointer — generics blanket impls cover `&[u8]` but
    // not raw slices.
    pub fn eql(&self, other: &Self) -> bool {
        match (self, other) {
            (AnimationName::None, AnimationName::None) => true,
            (AnimationName::Ident(a), AnimationName::Ident(b)) => {
                use crate::generics::CssEql;
                a.eql(b)
            }
            (AnimationName::String(a), AnimationName::String(b)) => {
                // SAFETY: arena-owned slices live for the parse session.
                unsafe { bun_core::strings::eql(&**a, &**b) }
            }
            _ => false,
        }
    }

    pub(crate) fn hash(&self, hasher: &mut bun_wyhash::Wyhash) {
        match self {
            AnimationName::None => hasher.update(&0u32.to_ne_bytes()),
            AnimationName::Ident(i) => {
                hasher.update(&1u32.to_ne_bytes());
                i.hash(hasher);
            }
            AnimationName::String(s) => {
                hasher.update(&2u32.to_ne_bytes());
                // SAFETY: arena-owned slice.
                hasher.update(unsafe { crate::arena_str(*s) });
            }
        }
    }

    #[inline]
    pub(crate) fn deep_clone(&self, _bump: &bun_alloc::Arena) -> Self {
        // All payloads are `Copy` (arena slice pointers); identity copy.
        match self {
            AnimationName::None => AnimationName::None,
            AnimationName::Ident(i) => AnimationName::Ident(*i),
            AnimationName::String(s) => AnimationName::String(*s),
        }
    }

    pub fn parse(input: &mut Parser) -> css::Result<Self> {
        // `none` keyword, then `<string>`, else `<custom-ident>`.
        if input
            .try_parse(|i| i.expect_ident_matching(b"none"))
            .is_ok()
        {
            return Ok(AnimationName::None);
        }
        // `expect_string` returns a slice borrowing `&mut self`, which
        // `try_parse`'s `R` type param can't carry. Erase the lifetime through a
        // raw pointer inside the closure; the slice lives in the input arena and
        // outlives this parse (CSSString = &'static [u8]).
        if let Ok(s) = input.try_parse(|i| i.expect_string().map(std::ptr::from_ref::<[u8]>)) {
            return Ok(AnimationName::String(s));
        }
        let ident = CustomIdent::parse(input)?;
        Ok(AnimationName::Ident(ident))
    }

    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        let css_module_animation_enabled = if let Some(css_module) = &dest.css_module {
            css_module.config.animation
        } else {
            false
        };

        match self {
            AnimationName::None => return dest.write_str("none"),
            AnimationName::Ident(s) => {
                // SAFETY: arena-owned slice valid for 'bump.
                let name: &[u8] = unsafe { crate::arena_str(s.v) };
                if css_module_animation_enabled {
                    // reshaped for borrowck — capture arena/source_index
                    // before borrowing dest.css_module mutably.
                    let arena = dest.arena;
                    let source_index = dest.loc.source_index;
                    if let Some(css_module) = &mut dest.css_module {
                        css_module.get_reference(arena, name, source_index);
                    }
                }
                return s.to_css_with_options(dest, css_module_animation_enabled);
            }
            AnimationName::String(s) => {
                // SAFETY: arena-owned slice valid for 'bump.
                let name: &[u8] = unsafe { crate::arena_str(*s) };
                if css_module_animation_enabled {
                    // reshaped for borrowck
                    let arena = dest.arena;
                    let source_index = dest.loc.source_index;
                    if let Some(css_module) = &mut dest.css_module {
                        css_module.get_reference(arena, name, source_index);
                    }
                }

                // CSS-wide keywords and `none` cannot remove quotes
                if strings::eql_case_insensitive_ascii_check_length(name, b"none")
                    || is_reserved_custom_ident(name)
                {
                    return dest.serialize_string(name);
                }

                return dest.write_ident(name, css_module_animation_enabled);
            }
        }
    }
}

/// A value for the [animation-iteration-count](https://drafts.csswg.org/css-animations/#animation-iteration-count) property.
#[derive(Clone, Copy, PartialEq)]
pub enum AnimationIterationCount {
    /// The animation will repeat the specified number of times.
    Number(CSSNumber),
    /// The animation will repeat forever.
    Infinite,
}

impl AnimationIterationCount {
    // Port of `css.DeriveParse(@This()).parse` — payload (`number: f32`) declared
    // first, single void variant (`infinite`) last → try number, then ident.
    pub fn parse(input: &mut Parser) -> css::Result<Self> {
        if let Ok(v) = input.try_parse(CSSNumberFns::parse) {
            return Ok(AnimationIterationCount::Number(v));
        }
        input.expect_ident_matching(b"infinite")?;
        Ok(AnimationIterationCount::Infinite)
    }

    // Port of `css.DeriveToCss(@This()).toCss`.
    pub fn to_css(self, dest: &mut Printer) -> Result<(), PrintErr> {
        match self {
            AnimationIterationCount::Number(n) => CSSNumberFns::to_css(n, dest),
            AnimationIterationCount::Infinite => dest.write_str(b"infinite"),
        }
    }

    pub(crate) fn default() -> AnimationIterationCount {
        AnimationIterationCount::Number(1.0)
    }
}

/// A value for the [animation-direction](https://drafts.csswg.org/css-animations/#animation-direction) property.
#[derive(Clone, Copy, PartialEq, Eq, Hash, css::DefineEnumProperty)]
pub enum AnimationDirection {
    /// The animation is played as specified
    Normal,
    /// The animation is played in reverse.
    Reverse,
    /// The animation iterations alternate between forward and reverse.
    Alternate,
    /// The animation iterations alternate between forward and reverse, with reverse occurring first.
    AlternateReverse, // css: "alternate-reverse"
}

impl AnimationDirection {
    pub(crate) fn default() -> AnimationDirection {
        AnimationDirection::Normal
    }
}

/// A value for the [animation-play-state](https://drafts.csswg.org/css-animations/#animation-play-state) property.
#[derive(Clone, Copy, PartialEq, Eq, Hash, css::DefineEnumProperty)]
pub enum AnimationPlayState {
    /// The animation is playing.
    Running,
    /// The animation is paused.
    Paused,
}

impl AnimationPlayState {
    pub(crate) fn default() -> AnimationPlayState {
        AnimationPlayState::Running
    }
}

/// A value for the [animation-fill-mode](https://drafts.csswg.org/css-animations/#animation-fill-mode) property.
#[derive(Clone, Copy, PartialEq, Eq, Hash, css::DefineEnumProperty)]
pub enum AnimationFillMode {
    /// The animation has no effect while not playing.
    None,
    /// After the animation, the ending values are applied.
    Forwards,
    /// Before the animation, the starting values are applied.
    Backwards,
    /// Both forwards and backwards apply.
    Both,
}

impl AnimationFillMode {
    pub(crate) fn default() -> AnimationFillMode {
        AnimationFillMode::None
    }
}

/// A value for the [animation-timeline](https://drafts.csswg.org/css-animations-2/#animation-timeline) property.
pub enum AnimationTimeline {
    /// The animation's timeline is a DocumentTimeline, more specifically the default document timeline.
    Auto,
    /// The animation is not associated with a timeline.
    None,
    /// A timeline referenced by name.
    DashedIdent(DashedIdent),
}

impl AnimationTimeline {
    pub fn parse(input: &mut Parser) -> css::Result<Self> {
        let state = input.state();
        if let Ok(ident) = input.expect_ident() {
            if strings::eql_case_insensitive_ascii_check_length(ident, b"auto") {
                return Ok(AnimationTimeline::Auto);
            }
            if strings::eql_case_insensitive_ascii_check_length(ident, b"none") {
                return Ok(AnimationTimeline::None);
            }
            input.reset(&state);
        } else {
            input.reset(&state);
        }
        DashedIdent::parse(input).map(AnimationTimeline::DashedIdent)
    }

    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        match self {
            AnimationTimeline::Auto => dest.write_str(b"auto"),
            AnimationTimeline::None => dest.write_str(b"none"),
            AnimationTimeline::DashedIdent(d) => d.to_css(dest),
        }
    }

    pub(crate) fn default() -> AnimationTimeline {
        AnimationTimeline::Auto
    }

    pub(crate) fn deep_clone(&self, _bump: &bun_alloc::Arena) -> Self {
        match self {
            AnimationTimeline::Auto => AnimationTimeline::Auto,
            AnimationTimeline::None => AnimationTimeline::None,
            // `DashedIdent` is a `Copy` arena-slice pointer.
            AnimationTimeline::DashedIdent(d) => AnimationTimeline::DashedIdent(*d),
        }
    }
}

// hand-written `PartialEq` — `DashedIdent` carries a raw
// `*const [u8]` arena pointer; derive would compare by pointer, not content.
impl PartialEq for AnimationTimeline {
    fn eq(&self, other: &Self) -> bool {
        use crate::generics::CssEql;
        match (self, other) {
            (AnimationTimeline::Auto, AnimationTimeline::Auto) => true,
            (AnimationTimeline::None, AnimationTimeline::None) => true,
            (AnimationTimeline::DashedIdent(a), AnimationTimeline::DashedIdent(b)) => a.eql(b),
            _ => false,
        }
    }
}
