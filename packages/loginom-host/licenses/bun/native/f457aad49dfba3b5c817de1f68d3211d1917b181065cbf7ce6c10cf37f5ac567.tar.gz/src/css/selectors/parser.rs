//! CSS selector parser.
//! Originally derived from servo/lightningcss selector parsing.

use core::fmt;

use bun_alloc::{Arena as Bump, ArenaPtr};
use bun_core::strings;
use bun_css as css;
use bun_css::css_values::ident::{CustomIdent, Ident};
use bun_css::selector::serialize;
use bun_css::{
    CSSStringFns, IdentFns, Parser as CssParser, ParserOptions, PrintErr, Printer, SmallList,
    Token, TokenList,
};
use bun_wyhash::Wyhash;

use super::impl_;

use super::builder::SelectorBuilder;

/// `css::Result<T>` — the CSS parser result type (`Ok(T)` / `Err(css::ParseError)`).
type CResult<T> = css::Result<T>;

// Arena lifetimes: this module uses `Vec`/`Box` and a `Str`
// alias for source-borrowed byte slices until the crate-wide `'bump` re-threading
// (`bun_alloc::ArenaVec<'bump, T>` / `&'bump [u8]` per PORTING.md §Allocators
// (AST crates)) lands.
//
// NOTE: `Str` is `&'static [u8]` here (not `crate::Str = *const [u8]`) to match
// `crate::Token`'s payload shape (`Token::Ident(&'static [u8])` etc.) — every
// `Str` in this module originates from a token slice. The `'static` is a
// placeholder for the tokenizer source lifetime; it widens to `&'bump
// [u8]` once `Parser<'bump>` threads the arena lifetime.
type Str = &'static [u8]; // arena-backed `[]const u8` source slice

// ─── Protocol traits ─────────────────────────────────────────────────────────
// `eql` / `hash` / `deep_clone` are field/variant reflection, provided by
// `#[derive(CssEql, CssHash, DeepClone)]` (`bun_css_derive`). Non-generic
// grammar types below carry the derive directly; the `<Impl: SelectorImpl>`-
// generic types hand-write bodies (the derive's `where Impl: CssEql` bound is
// useless — equality recurses on `Impl::Assoc`, not `Impl`).
//
// `deep_clone` on the grammar types drops the `&Arena` parameter: `GenericSelector.components`
// is `Vec<_, ArenaPtr>` and clones into the *source* allocator (intra-arena only).
use css::generics::{CssEql, CssHash};

/// Drain a `SmallList<T, N>` into a `Box<[T]>`. `SmallList` has no `into_vec`;
/// this bitwise-moves each element out and `set_len(0)`s the source so its
/// `Drop` doesn't double-free.
fn small_list_into_box<T, const N: usize>(mut sl: SmallList<T, N>) -> Box<[T]> {
    let len = sl.len() as usize;
    let mut v: Vec<T> = Vec::with_capacity(len);
    {
        let src = sl.slice();
        for i in 0..len {
            // SAFETY: each index is read exactly once; `set_len(0)` below
            // prevents `SmallList::drop` from re-dropping the moved elements.
            unsafe { v.push(core::ptr::read(src.get_unchecked(i))) };
        }
    }
    sl.set_len(0);
    v.into_boxed_slice()
}

/// Allocate an ASCII-lowercased copy of `name` in the parse-session bump arena.
/// Returns a raw arena
/// pointer (`*const [u8]`) — `Ident.v`'s field type — so we don't fabricate a
/// `'static` lifetime (PORTING.md §Forbidden: never `Box::leak` to satisfy
/// `&'static`). Re-threading `&'bump Bump` would widen `Ident.v` to
/// `&'bump [u8]`.
#[inline]
fn arena_lowercase(bump: &Bump, name: &[u8]) -> *const [u8] {
    let buf = bump.alloc_slice_fill_copy(name.len(), 0u8);
    let _ = strings::copy_lowercase(name, buf);
    std::ptr::from_ref::<[u8]>(buf)
}

// ─── selector-slice protocol helpers ─────────────────────────────────────────
// `Box<[GenericSelector<Impl>]>` appears in `Component::{Negation,Where,Is,
// Any,Has}`, `NthOfSelectorData`, and (via `SelectorList.v`) at the top level.
// Hoisted as free fns so the hand-written `eql`/`hash`/`deep_clone` bodies
// below stay small.
#[inline]
fn eql_selector_slice<Impl: BunSelectorImpl>(
    a: &[GenericSelector<Impl>],
    b: &[GenericSelector<Impl>],
) -> bool {
    a.len() == b.len() && a.iter().zip(b).all(|(l, r)| l.eql(r))
}
#[inline]
fn hash_selector_slice<Impl: BunSelectorImpl>(s: &[GenericSelector<Impl>], hasher: &mut Wyhash) {
    for sel in s {
        sel.hash(hasher);
    }
}
#[inline]
fn deep_clone_selector_slice<Impl: BunSelectorImpl>(
    s: &[GenericSelector<Impl>],
) -> Box<[GenericSelector<Impl>]> {
    s.iter().map(|sel| sel.deep_clone()).collect()
}

/// Instantiation of generic selector structs using our implementation of the `SelectorImpl` trait.
pub type Component = GenericComponent<impl_::Selectors>;
pub type Selector = GenericSelector<impl_::Selectors>;
pub type SelectorList = GenericSelectorList<impl_::Selectors>;

/// The definition of whitespace per CSS Selectors Level 3 § 4.
pub(crate) const SELECTOR_WHITESPACE: &[u8] = &[b' ', b'\t', b'\n', b'\r', 0x0C];

/// The `SelectorImpl` shape. Implemented
/// by `impl_::Selectors` in `bun_css::selector::impl_`.
// `PartialEq + Clone` bounds dropped — the concrete assoc types
// (`values::ident::{Ident,IdentOrRef}`, `*const [u8]`) implement structural
// equality via the `CssEql` protocol (`generics::implement_eql`), not
// `core::cmp::PartialEq`. Every `eql`/`deep_clone`/`hash` callsite in this
// module forwards through `css::implement_*` which bound on `CssEql`/
// `DeepClone`/`CssHash`, so the std bounds were never load-bearing.
pub trait SelectorImpl: Sized {
    type AttrValue: Clone;
    type Identifier: Clone;
    type LocalIdentifier: Clone;
    type LocalName: Clone;
    type NamespaceUrl: Clone;
    type NamespacePrefix: Clone;
    type NonTSPseudoClass: Clone;
    type VendorPrefix: Clone;
    type PseudoElement: Clone;
}

/// Constrained `SelectorImpl` with the concrete assoc-type bundle Bun uses.
///
/// Every `parse_*` body assumes the concrete `selector.impl.Selectors` shapes
/// (the only instantiation). Rust can't see through the open `Impl::LocalName`
/// to `Ident`, so the parse functions bound on this sub-trait instead — the
/// associated-type equality clauses make `Impl::LocalName == Ident` etc.
/// visible to the body without monomorphizing the signature.
pub trait BunSelectorImpl:
    SelectorImpl<
        AttrValue = css::CSSString,
        Identifier = Ident,
        LocalIdentifier = css::css_values::ident::IdentOrRef,
        LocalName = Ident,
        NamespaceUrl = Str,
        NamespacePrefix = Ident,
        NonTSPseudoClass = PseudoClass,
        PseudoElement = PseudoElement,
        VendorPrefix = css::VendorPrefix,
    >
{
}
impl BunSelectorImpl for impl_::Selectors {}

// ─────────────────────────────────────────────────────────────────────────────
// attrs
// ─────────────────────────────────────────────────────────────────────────────
pub mod attrs {
    use super::*;

    #[derive(Clone)]
    pub struct NamespaceUrl<Impl: SelectorImpl> {
        pub(crate) prefix: Impl::NamespacePrefix,
        pub(crate) url: Impl::NamespaceUrl,
    }

    impl<Impl: BunSelectorImpl> NamespaceUrl<Impl> {
        pub fn eql(&self, rhs: &Self) -> bool {
            // `BunSelectorImpl` fixes `NamespacePrefix = Ident`, `NamespaceUrl = Str`.
            self.prefix.eql(&rhs.prefix) && strings::eql(self.url, rhs.url)
        }
        pub(crate) fn deep_clone(&self) -> Self {
            // `NamespaceUrl = &'static [u8]` (arena-backed) — identity copy.
            Self {
                prefix: self.prefix,
                url: self.url,
            }
        }
        pub(crate) fn hash(&self, hasher: &mut Wyhash) {
            self.prefix.hash(hasher);
            hasher.update(self.url);
        }
    }

    #[derive(Clone)]
    pub struct AttrSelectorWithOptionalNamespace<Impl: SelectorImpl> {
        pub(crate) namespace: Option<NamespaceConstraint<NamespaceUrl<Impl>>>,
        pub(crate) local_name: Impl::LocalName,
        pub(crate) local_name_lower: Impl::LocalName,
        pub(crate) operation: ParsedAttrSelectorOperation<Impl::AttrValue>,
        pub(crate) never_matches: bool,
    }

    impl<Impl: BunSelectorImpl> AttrSelectorWithOptionalNamespace<Impl> {
        pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
            dest.write_char(b'[')?;
            if let Some(nsp) = &self.namespace {
                match nsp {
                    NamespaceConstraint::Specific(v) => {
                        IdentFns::to_css(&v.prefix, dest)?;
                        dest.write_char(b'|')?;
                    }
                    NamespaceConstraint::Any => {
                        dest.write_str("*|")?;
                    }
                }
            }
            IdentFns::to_css(&self.local_name, dest)?;
            match &self.operation {
                ParsedAttrSelectorOperation::Exists => {}
                ParsedAttrSelectorOperation::WithValue {
                    operator,
                    case_sensitivity,
                    expected_value,
                } => {
                    operator.to_css(dest)?;
                    // try v.expected_value.toCss(dest);
                    CSSStringFns::to_css(expected_value, dest)?;
                    match case_sensitivity {
                        ParsedCaseSensitivity::CaseSensitive
                        | ParsedCaseSensitivity::AsciiCaseInsensitiveIfInHtmlElementInHtmlDocument => {}
                        ParsedCaseSensitivity::AsciiCaseInsensitive => {
                            dest.write_str(" i")?;
                        }
                        ParsedCaseSensitivity::ExplicitCaseSensitive => {
                            dest.write_str(" s")?;
                        }
                    }
                }
            }
            dest.write_char(b']')
        }

        pub fn eql(&self, rhs: &Self) -> bool {
            match (&self.namespace, &rhs.namespace) {
                (None, None) => true,
                (Some(a), Some(b)) => a.eql(b),
                _ => return false,
            }
            .then_some(())
            .is_some()
                && self.local_name.eql(&rhs.local_name)
                && self.local_name_lower.eql(&rhs.local_name_lower)
                && self.operation.eql(&rhs.operation)
                && self.never_matches == rhs.never_matches
        }
        pub(crate) fn deep_clone(&self) -> Self {
            Self {
                namespace: self.namespace.as_ref().map(|n| n.deep_clone()),
                local_name: self.local_name,
                local_name_lower: self.local_name_lower,
                operation: self.operation.deep_clone(),
                never_matches: self.never_matches,
            }
        }
        pub(crate) fn hash(&self, hasher: &mut Wyhash) {
            if let Some(ns) = &self.namespace {
                ns.hash(hasher);
            }
            self.local_name.hash(hasher);
            self.local_name_lower.hash(hasher);
            self.operation.hash(hasher);
            hasher.update(&[self.never_matches as u8]);
        }
    }

    #[derive(Clone, PartialEq, Eq)]
    pub enum NamespaceConstraint<NamespaceUrl> {
        Any,
        /// Empty string for no namespace
        Specific(NamespaceUrl),
    }

    impl<Impl: BunSelectorImpl> NamespaceConstraint<NamespaceUrl<Impl>> {
        pub fn eql(&self, rhs: &Self) -> bool {
            match (self, rhs) {
                (Self::Any, Self::Any) => true,
                (Self::Specific(a), Self::Specific(b)) => a.eql(b),
                _ => false,
            }
        }
        pub(crate) fn hash(&self, hasher: &mut Wyhash) {
            match self {
                Self::Any => hasher.update(&0u32.to_ne_bytes()),
                Self::Specific(n) => {
                    hasher.update(&1u32.to_ne_bytes());
                    n.hash(hasher);
                }
            }
        }
        pub(crate) fn deep_clone(&self) -> Self {
            match self {
                Self::Any => Self::Any,
                Self::Specific(n) => Self::Specific(n.deep_clone()),
            }
        }
    }

    #[derive(Clone, PartialEq, Eq)]
    pub enum ParsedAttrSelectorOperation<AttrValue> {
        Exists,
        WithValue {
            operator: AttrSelectorOperator,
            case_sensitivity: ParsedCaseSensitivity,
            expected_value: AttrValue,
        },
    }

    // Implemented for the concrete `AttrValue = css::CSSString`
    // (= `*const [u8]`) only — the sole `BunSelectorImpl` instantiation.
    impl ParsedAttrSelectorOperation<css::CSSString> {
        pub(crate) fn deep_clone(&self) -> Self {
            self.clone()
        }
        pub fn eql(&self, rhs: &Self) -> bool {
            match (self, rhs) {
                (Self::Exists, Self::Exists) => true,
                (
                    Self::WithValue {
                        operator: ao,
                        case_sensitivity: ac,
                        expected_value: av,
                    },
                    Self::WithValue {
                        operator: bo,
                        case_sensitivity: bc,
                        expected_value: bv,
                    },
                ) => {
                    ao == bo
                        && ac == bc
                        // SAFETY: arena-owned slices live for the parse session.
                        && unsafe { strings::eql(&**av, &**bv) }
                }
                _ => false,
            }
        }
        pub(crate) fn hash(&self, hasher: &mut Wyhash) {
            match self {
                Self::Exists => hasher.update(&0u32.to_ne_bytes()),
                Self::WithValue {
                    operator,
                    case_sensitivity,
                    expected_value,
                } => {
                    hasher.update(&1u32.to_ne_bytes());
                    operator.hash(hasher);
                    case_sensitivity.hash(hasher);
                    // SAFETY: arena-owned slice.
                    hasher.update(unsafe { crate::arena_str(*expected_value) });
                }
            }
        }
    }

    #[derive(Clone, Copy, PartialEq, Eq, Hash, CssEql, CssHash, css::generics::DeepClone)]
    pub enum AttrSelectorOperator {
        Equal,
        Includes,
        DashMatch,
        Prefix,
        Substring,
        Suffix,
    }

    impl AttrSelectorOperator {
        pub fn to_css(self, dest: &mut Printer) -> Result<(), PrintErr> {
            // https://drafts.csswg.org/cssom/#serializing-selectors
            // See "attribute selector".
            dest.write_str(match self {
                Self::Equal => "=",
                Self::Includes => "~=",
                Self::DashMatch => "|=",
                Self::Prefix => "^=",
                Self::Substring => "*=",
                Self::Suffix => "$=",
            })
        }
    }

    #[derive(Clone, Copy, PartialEq, Eq, Hash, CssEql, CssHash, css::generics::DeepClone)]
    pub enum ParsedCaseSensitivity {
        // 's' was specified.
        ExplicitCaseSensitive,
        // 'i' was specified.
        AsciiCaseInsensitive,
        // No flags were specified and HTML says this is a case-sensitive attribute.
        CaseSensitive,
        // No flags were specified and HTML says this is a case-insensitive attribute.
        AsciiCaseInsensitiveIfInHtmlElementInHtmlDocument,
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Specificity
// ─────────────────────────────────────────────────────────────────────────────

#[derive(Clone, Copy, Default)]
pub struct Specificity {
    pub(crate) id_selectors: u32,
    pub(crate) class_like_selectors: u32,
    pub(crate) element_selectors: u32,
}

impl Specificity {
    const MAX_10BIT: u32 = (1 << 10) - 1;

    pub(crate) fn to_u32(self) -> u32 {
        (self.id_selectors.min(Self::MAX_10BIT) << 20)
            | (self.class_like_selectors.min(Self::MAX_10BIT) << 10)
            | self.element_selectors.min(Self::MAX_10BIT)
    }

    pub(crate) fn from_u32(value: u32) -> Specificity {
        debug_assert!(value <= (Self::MAX_10BIT << 20 | Self::MAX_10BIT << 10 | Self::MAX_10BIT));
        Specificity {
            id_selectors: value >> 20,
            class_like_selectors: (value >> 10) & Self::MAX_10BIT,
            element_selectors: value & Self::MAX_10BIT,
        }
    }

    pub(crate) fn add(&mut self, rhs: Specificity) {
        self.id_selectors += rhs.id_selectors;
        self.element_selectors += rhs.element_selectors;
        self.class_like_selectors += rhs.class_like_selectors;
    }
}

pub(crate) fn compute_specificity<Impl: BunSelectorImpl>(iter: &[GenericComponent<Impl>]) -> u32 {
    let spec = compute_complex_selector_specificity::<Impl>(iter);
    spec.to_u32()
}

fn compute_complex_selector_specificity<Impl: BunSelectorImpl>(
    iter: &[GenericComponent<Impl>],
) -> Specificity {
    let mut specificity = Specificity::default();
    for simple_selector in iter {
        compute_simple_selector_specificity::<Impl>(simple_selector, &mut specificity);
    }
    specificity
}

fn compute_simple_selector_specificity<Impl: BunSelectorImpl>(
    simple_selector: &GenericComponent<Impl>,
    specificity: &mut Specificity,
) {
    use GenericComponent as C;
    match simple_selector {
        C::Combinator(_) => {
            unreachable!("Found combinator in simple selectors vector?");
        }
        C::Part(_) | C::PseudoElement(_) | C::LocalName(_) => {
            specificity.element_selectors += 1;
        }
        C::Slotted(selector) => {
            specificity.element_selectors += 1;
            // Note that due to the way ::slotted works we only compete with
            // other ::slotted rules, so the above rule doesn't really
            // matter, but we do it still for consistency with other
            // pseudo-elements.
            //
            // See: https://github.com/w3c/csswg-drafts/issues/1915
            specificity.add(Specificity::from_u32(selector.specificity()));
        }
        C::Host(maybe_selector) => {
            specificity.class_like_selectors += 1;
            if let Some(selector) = maybe_selector {
                // See: https://github.com/w3c/csswg-drafts/issues/1915
                specificity.add(Specificity::from_u32(selector.specificity()));
            }
        }
        C::Id(_) => {
            specificity.id_selectors += 1;
        }
        C::Class(_)
        | C::AttributeInNoNamespace { .. }
        | C::AttributeInNoNamespaceExists { .. }
        | C::AttributeOther(_)
        | C::Root
        | C::Empty
        | C::Scope
        | C::Nth(_)
        | C::NonTsPseudoClass(_) => {
            specificity.class_like_selectors += 1;
        }
        C::NthOf(nth_of_data) => {
            // https://drafts.csswg.org/selectors/#specificity-rules:
            //
            //     The specificity of the :nth-last-child() pseudo-class,
            //     like the :nth-child() pseudo-class, combines the
            //     specificity of a regular pseudo-class with that of its
            //     selector argument S.
            specificity.class_like_selectors += 1;
            let mut max: u32 = 0;
            for selector in nth_of_data.selectors.iter() {
                max = selector.specificity().max(max);
            }
            specificity.add(Specificity::from_u32(max));
        }
        C::Negation(_) | C::Is(_) | C::Any { .. } => {
            // https://drafts.csswg.org/selectors/#specificity-rules:
            //
            //     The specificity of an :is() pseudo-class is replaced by the
            //     specificity of the most specific complex selector in its
            //     selector list argument.
            let list: &[GenericSelector<Impl>] = match simple_selector {
                C::Negation(list) => list,
                C::Is(list) => list,
                C::Any { selectors, .. } => selectors,
                _ => unreachable!(),
            };
            let mut max: u32 = 0;
            for selector in list {
                max = selector.specificity().max(max);
            }
            specificity.add(Specificity::from_u32(max));
        }
        C::Where(_)
        | C::Has(_)
        | C::ExplicitUniversalType
        | C::ExplicitAnyNamespace
        | C::ExplicitNoNamespace
        | C::DefaultNamespace(_)
        | C::Namespace { .. } => {
            // Does not affect specificity
        }
        C::Nesting => {
            // No specificity contribution here. Whether `&` should
            // contribute specificity at this point is unresolved;
            // nesting substitution happens at print time, after
            // specificity is computed.
        }
    }
}

/// Build up a Selector.
/// selector : simple_selector_sequence [ combinator simple_selector_sequence ]* ;
///
/// `Err` means invalid selector.
fn parse_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
    nesting_requirement: NestingRequirement,
) -> CResult<GenericSelector<Impl>> {
    if nesting_requirement == NestingRequirement::Prefixed {
        let parser_state = input.state();
        if !input.expect_delim(b'&').is_ok() {
            return Err(input.new_custom_error(
                SelectorParseErrorKind::MissingNestingPrefix.into_default_parser_error(),
            ));
        }
        input.reset(&parser_state);
    }

    let mut builder = SelectorBuilder::<Impl>::init_in(ArenaPtr::new(input.arena()));

    'outer_loop: loop {
        // Parse a sequence of simple selectors.
        let empty = parse_compound_selector::<Impl>(parser, state, input, &mut builder)?;
        if empty {
            let kind: SelectorParseErrorKind = if builder.has_combinators() {
                SelectorParseErrorKind::DanglingCombinator
            } else {
                SelectorParseErrorKind::EmptySelector
            };
            return Err(input.new_custom_error(kind.into_default_parser_error()));
        }

        if state.after_any_pseudo() {
            let source_location = input.current_source_location();
            if let Ok(next) = input.next() {
                return Err(source_location.new_custom_error(
                    SelectorParseErrorKind::UnexpectedSelectorAfterPseudoElement(*next)
                        .into_default_parser_error(),
                ));
            }
            break;
        }

        // Parse a combinator
        let combinator: Combinator;
        let mut any_whitespace = false;
        loop {
            let before_this_token = input.state();
            let tok: &Token = match input.next_including_whitespace() {
                Ok(vv) => vv,
                Err(_) => break 'outer_loop,
            };
            match tok {
                Token::Whitespace(_) => {
                    any_whitespace = true;
                    continue;
                }
                // `Token::Delim` carries `u32` codepoint; cast to
                // `u8` for ASCII match (all CSS combinator delims are ASCII).
                Token::Delim(d) => match u8::try_from(*d).ok() {
                    Some(b'>') => {
                        if parser.deep_combinator_enabled()
                            && input
                                .try_parse(|i: &mut CssParser| -> CResult<()> {
                                    i.expect_delim(b'>')?;
                                    i.expect_delim(b'>')
                                })
                                .is_ok()
                        {
                            combinator = Combinator::DeepDescendant;
                        } else {
                            combinator = Combinator::Child;
                        }
                        break;
                    }
                    Some(b'+') => {
                        combinator = Combinator::NextSibling;
                        break;
                    }
                    Some(b'~') => {
                        combinator = Combinator::LaterSibling;
                        break;
                    }
                    Some(b'/') => {
                        if parser.deep_combinator_enabled() {
                            if input
                                .try_parse(|i: &mut CssParser| -> CResult<()> {
                                    i.expect_ident_matching(b"deep")?;
                                    i.expect_delim(b'/')
                                })
                                .is_ok()
                            {
                                combinator = Combinator::Deep;
                                break;
                            } else {
                                break 'outer_loop;
                            }
                        }
                    }
                    _ => {}
                },
                _ => {}
            }

            input.reset(&before_this_token);

            if any_whitespace {
                combinator = Combinator::Descendant;
                break;
            } else {
                break 'outer_loop;
            }
        }

        if !state.allows_combinators() {
            return Err(input.new_custom_error(
                SelectorParseErrorKind::InvalidState.into_default_parser_error(),
            ));
        }

        builder.push_combinator(combinator);
    }

    if !state.contains(SelectorParsingState::AFTER_NESTING) {
        match nesting_requirement {
            NestingRequirement::Implicit => {
                builder.add_nesting_prefix();
            }
            NestingRequirement::Contained | NestingRequirement::Prefixed => {
                return Err(input.new_custom_error(
                    SelectorParseErrorKind::MissingNestingSelector.into_default_parser_error(),
                ));
            }
            _ => {}
        }
    }

    let mut flags = SelectorFlags::empty();
    if state.contains(SelectorParsingState::AFTER_PSEUDO_ELEMENT)
        || state.contains(SelectorParsingState::AFTER_UNKNOWN_PSEUDO_ELEMENT)
    {
        flags |= SelectorFlags::HAS_PSEUDO;
    }
    if state.contains(SelectorParsingState::AFTER_SLOTTED) {
        flags |= SelectorFlags::HAS_SLOTTED;
    }
    if state.contains(SelectorParsingState::AFTER_PART) {
        flags |= SelectorFlags::HAS_PART;
    }
    let result = builder.build(flags);
    Ok(GenericSelector {
        specificity_and_flags: result.specificity_and_flags,
        components: result.components,
    })
}

/// simple_selector_sequence
/// : [ type_selector | universal ] [ HASH | class | attrib | pseudo | negation ]*
/// | [ HASH | class | attrib | pseudo | negation ]+
///
/// `Err(())` means invalid selector.
/// `Ok(true)` is an empty selector
fn parse_compound_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    state: &mut SelectorParsingState,
    input: &mut CssParser,
    builder: &mut SelectorBuilder<Impl>,
) -> CResult<bool> {
    input.skip_whitespace();

    let mut empty: bool = true;
    if parser.is_nesting_allowed() && input.try_parse(|i| i.expect_delim(b'&')).is_ok() {
        state.insert(SelectorParsingState::AFTER_NESTING);
        builder.push_simple_selector(GenericComponent::Nesting);
        empty = false;
    }

    if parse_type_selector::<Impl>(parser, input, *state, builder)? {
        empty = false;
    }

    loop {
        let result: SimpleSelectorParseResult<Impl> = {
            let ret = parse_one_simple_selector::<Impl>(parser, input, state)?;
            match ret {
                Some(result) => result,
                None => break,
            }
        };

        if empty {
            if let Some(url) = parser.default_namespace() {
                // If there was no explicit type selector, but there is a
                // default namespace, there is an implicit "<defaultns>|*" type
                // selector. Except for :host() or :not() / :is() / :where(),
                // where we ignore it.
                //
                // https://drafts.csswg.org/css-scoping/#host-element-in-tree:
                //
                //     When considered within its own shadow trees, the shadow
                //     host is featureless. Only the :host, :host(), and
                //     :host-context() pseudo-classes are allowed to match it.
                //
                // https://drafts.csswg.org/selectors-4/#featureless:
                //
                //     A featureless element does not match any selector at all,
                //     except those it is explicitly defined to match. If a
                //     given selector is allowed to match a featureless element,
                //     it must do so while ignoring the default namespace.
                //
                // https://drafts.csswg.org/selectors-4/#matches
                //
                //     Default namespace declarations do not affect the compound
                //     selector representing the subject of any selector within
                //     a :is() pseudo-class, unless that compound selector
                //     contains an explicit universal selector or type selector.
                //
                //     (Similar quotes for :where() / :not())
                //
                let ignore_default_ns = state
                    .contains(SelectorParsingState::SKIP_DEFAULT_NAMESPACE)
                    || matches!(
                        result,
                        SimpleSelectorParseResult::SimpleSelector(GenericComponent::Host(_))
                    );
                if !ignore_default_ns {
                    builder.push_simple_selector(GenericComponent::DefaultNamespace(url));
                }
            }
        }

        empty = false;

        match result {
            SimpleSelectorParseResult::SimpleSelector(s) => {
                builder.push_simple_selector(s);
            }
            SimpleSelectorParseResult::PartPseudo(selector) => {
                state.insert(SelectorParsingState::AFTER_PART);
                builder.push_combinator(Combinator::Part);
                builder.push_simple_selector(GenericComponent::Part(selector));
            }
            SimpleSelectorParseResult::SlottedPseudo(selector) => {
                state.insert(SelectorParsingState::AFTER_SLOTTED);
                builder.push_combinator(Combinator::SlotAssignment);
                builder.push_simple_selector(GenericComponent::Slotted(selector));
            }
            SimpleSelectorParseResult::PseudoElement(p) => {
                if !p.is_unknown() {
                    state.insert(SelectorParsingState::AFTER_PSEUDO_ELEMENT);
                    builder.push_combinator(Combinator::PseudoElement);
                } else {
                    state.insert(SelectorParsingState::AFTER_UNKNOWN_PSEUDO_ELEMENT);
                }

                if !p.accepts_state_pseudo_classes() {
                    state.insert(SelectorParsingState::AFTER_NON_STATEFUL_PSEUDO_ELEMENT);
                }

                if p.is_webkit_scrollbar() {
                    state.insert(SelectorParsingState::AFTER_WEBKIT_SCROLLBAR);
                }

                if p.is_view_transition() {
                    state.insert(SelectorParsingState::AFTER_VIEW_TRANSITION);
                }

                builder.push_simple_selector(GenericComponent::PseudoElement(p));
            }
        }
    }

    Ok(empty)
}

fn parse_relative_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
    nesting_requirement_: NestingRequirement,
) -> CResult<GenericSelector<Impl>> {
    // https://www.w3.org/TR/selectors-4/#parse-relative-selector
    let mut nesting_requirement = nesting_requirement_;
    let s = input.state();

    let combinator: Option<Combinator> = 'combinator: {
        let tok = input.next()?;
        if let Token::Delim(c) = tok {
            match u8::try_from(*c).ok() {
                Some(b'>') => break 'combinator Some(Combinator::Child),
                Some(b'+') => break 'combinator Some(Combinator::NextSibling),
                Some(b'~') => break 'combinator Some(Combinator::LaterSibling),
                _ => {}
            }
        }
        input.reset(&s);
        None
    };

    let scope: GenericComponent<Impl> = if nesting_requirement == NestingRequirement::Implicit {
        GenericComponent::Nesting
    } else {
        GenericComponent::Scope
    };

    if combinator.is_some() {
        nesting_requirement = NestingRequirement::None;
    }

    let mut selector = parse_selector::<Impl>(parser, input, state, nesting_requirement)?;
    if let Some(wombo_combo) = combinator {
        // https://www.w3.org/TR/selectors/#absolutizing
        selector
            .components
            .push(GenericComponent::Combinator(wombo_combo));
        selector.components.push(scope);
    }

    Ok(selector)
}

/// The [:dir()](https://drafts.csswg.org/selectors-4/#the-dir-pseudo) pseudo class.
// Re-export of the canonical `{ltr, rtl}` enum from `properties::text` — the
// selector and property grammars share one definition. The
// `#[derive(DefineEnumProperty)]` on the canonical provides `parse`/`to_css`/
// `as_str`; `CssEql`/`CssHash`/`DeepClone` come from `generics::inherent_bridge`.
pub use css::css_properties::text::Direction;

/// A pseudo class.
// `PartialEq` derive dropped — `Local`/`Global` carry
// `Box<Selector>` and `CustomFunction` carries `TokenList`, neither of which
// implements `PartialEq`. Equality goes through `eql()` (CssEql protocol).
#[derive(Clone, CssEql, CssHash)]
pub enum PseudoClass {
    /// https://drafts.csswg.org/selectors-4/#linguistic-pseudos
    /// The [:lang()](https://drafts.csswg.org/selectors-4/#the-lang-pseudo) pseudo class.
    Lang {
        /// A list of language codes.
        languages: Vec<Str>,
    },
    /// The [:dir()](https://drafts.csswg.org/selectors-4/#the-dir-pseudo) pseudo class.
    Dir {
        /// A direction.
        direction: Direction,
    },

    // https://drafts.csswg.org/selectors-4/#useraction-pseudos
    /// The [:hover](https://drafts.csswg.org/selectors-4/#the-hover-pseudo) pseudo class.
    Hover,
    /// The [:active](https://drafts.csswg.org/selectors-4/#the-active-pseudo) pseudo class.
    Active,
    /// The [:focus](https://drafts.csswg.org/selectors-4/#the-focus-pseudo) pseudo class.
    Focus,
    /// The [:focus-visible](https://drafts.csswg.org/selectors-4/#the-focus-visible-pseudo) pseudo class.
    FocusVisible,
    /// The [:focus-within](https://drafts.csswg.org/selectors-4/#the-focus-within-pseudo) pseudo class.
    FocusWithin,

    /// https://drafts.csswg.org/selectors-4/#time-pseudos
    /// The [:current](https://drafts.csswg.org/selectors-4/#the-current-pseudo) pseudo class.
    Current,
    /// The [:past](https://drafts.csswg.org/selectors-4/#the-past-pseudo) pseudo class.
    Past,
    /// The [:future](https://drafts.csswg.org/selectors-4/#the-future-pseudo) pseudo class.
    Future,

    /// https://drafts.csswg.org/selectors-4/#resource-pseudos
    /// The [:playing](https://drafts.csswg.org/selectors-4/#selectordef-playing) pseudo class.
    Playing,
    /// The [:paused](https://drafts.csswg.org/selectors-4/#selectordef-paused) pseudo class.
    Paused,
    /// The [:seeking](https://drafts.csswg.org/selectors-4/#selectordef-seeking) pseudo class.
    Seeking,
    /// The [:buffering](https://drafts.csswg.org/selectors-4/#selectordef-buffering) pseudo class.
    Buffering,
    /// The [:stalled](https://drafts.csswg.org/selectors-4/#selectordef-stalled) pseudo class.
    Stalled,
    /// The [:muted](https://drafts.csswg.org/selectors-4/#selectordef-muted) pseudo class.
    Muted,
    /// The [:volume-locked](https://drafts.csswg.org/selectors-4/#selectordef-volume-locked) pseudo class.
    VolumeLocked,

    /// The [:fullscreen](https://fullscreen.spec.whatwg.org/#:fullscreen-pseudo-class) pseudo class.
    Fullscreen(css::VendorPrefix),

    /// https://drafts.csswg.org/selectors/#display-state-pseudos
    /// The [:open](https://drafts.csswg.org/selectors/#selectordef-open) pseudo class.
    Open,
    /// The [:closed](https://drafts.csswg.org/selectors/#selectordef-closed) pseudo class.
    Closed,
    /// The [:modal](https://drafts.csswg.org/selectors/#modal-state) pseudo class.
    Modal,
    /// The [:picture-in-picture](https://drafts.csswg.org/selectors/#pip-state) pseudo class.
    PictureInPicture,

    /// https://html.spec.whatwg.org/multipage/semantics-other.html#selector-popover-open
    /// The [:popover-open](https://html.spec.whatwg.org/multipage/semantics-other.html#selector-popover-open) pseudo class.
    PopoverOpen,

    /// The [:defined](https://drafts.csswg.org/selectors-4/#the-defined-pseudo) pseudo class.
    Defined,

    /// https://drafts.csswg.org/selectors-4/#location
    /// The [:any-link](https://drafts.csswg.org/selectors-4/#the-any-link-pseudo) pseudo class.
    AnyLink(css::VendorPrefix),
    /// The [:link](https://drafts.csswg.org/selectors-4/#link-pseudo) pseudo class.
    Link,
    /// The [:local-link](https://drafts.csswg.org/selectors-4/#the-local-link-pseudo) pseudo class.
    LocalLink,
    /// The [:target](https://drafts.csswg.org/selectors-4/#the-target-pseudo) pseudo class.
    Target,
    /// The [:target-within](https://drafts.csswg.org/selectors-4/#the-target-within-pseudo) pseudo class.
    TargetWithin,
    /// The [:visited](https://drafts.csswg.org/selectors-4/#visited-pseudo) pseudo class.
    Visited,

    /// https://drafts.csswg.org/selectors-4/#input-pseudos
    /// The [:enabled](https://drafts.csswg.org/selectors-4/#enabled-pseudo) pseudo class.
    Enabled,
    /// The [:disabled](https://drafts.csswg.org/selectors-4/#disabled-pseudo) pseudo class.
    Disabled,
    /// The [:read-only](https://drafts.csswg.org/selectors-4/#read-only-pseudo) pseudo class.
    ReadOnly(css::VendorPrefix),
    /// The [:read-write](https://drafts.csswg.org/selectors-4/#read-write-pseudo) pseudo class.
    ReadWrite(css::VendorPrefix),
    /// The [:placeholder-shown](https://drafts.csswg.org/selectors-4/#placeholder) pseudo class.
    PlaceholderShown(css::VendorPrefix),
    /// The [:default](https://drafts.csswg.org/selectors-4/#the-default-pseudo) pseudo class.
    Default,
    /// The [:checked](https://drafts.csswg.org/selectors-4/#checked) pseudo class.
    Checked,
    /// The [:indeterminate](https://drafts.csswg.org/selectors-4/#indeterminate) pseudo class.
    Indeterminate,
    /// The [:blank](https://drafts.csswg.org/selectors-4/#blank) pseudo class.
    Blank,
    /// The [:valid](https://drafts.csswg.org/selectors-4/#valid-pseudo) pseudo class.
    Valid,
    /// The [:invalid](https://drafts.csswg.org/selectors-4/#invalid-pseudo) pseudo class.
    Invalid,
    /// The [:in-range](https://drafts.csswg.org/selectors-4/#in-range-pseudo) pseudo class.
    InRange,
    /// The [:out-of-range](https://drafts.csswg.org/selectors-4/#out-of-range-pseudo) pseudo class.
    OutOfRange,
    /// The [:required](https://drafts.csswg.org/selectors-4/#required-pseudo) pseudo class.
    Required,
    /// The [:optional](https://drafts.csswg.org/selectors-4/#optional-pseudo) pseudo class.
    Optional,
    /// The [:user-valid](https://drafts.csswg.org/selectors-4/#user-valid-pseudo) pseudo class.
    UserValid,
    /// The [:used-invalid](https://drafts.csswg.org/selectors-4/#user-invalid-pseudo) pseudo class.
    UserInvalid,

    /// The [:autofill](https://html.spec.whatwg.org/multipage/semantics-other.html#selector-autofill) pseudo class.
    Autofill(css::VendorPrefix),

    // CSS modules
    /// The CSS modules :local() pseudo class.
    Local {
        /// A local selector.
        selector: Box<Selector>,
    },
    /// The CSS modules :global() pseudo class.
    Global {
        /// A global selector.
        selector: Box<Selector>,
    },

    /// A [webkit scrollbar](https://webkit.org/blog/363/styling-scrollbars/) pseudo class.
    // https://webkit.org/blog/363/styling-scrollbars/
    WebkitScrollbar(WebKitScrollbarPseudoClass),
    /// An unknown pseudo class.
    Custom {
        /// The pseudo class name.
        name: Str,
    },
    /// An unknown functional pseudo class.
    CustomFunction {
        /// The pseudo class name.
        name: Str,
        /// The arguments of the pseudo class function.
        arguments: TokenList,
    },
}

impl PseudoClass {
    pub(crate) fn is_equivalent(&self, other: &PseudoClass) -> bool {
        use PseudoClass as P;
        if matches!(self, P::Fullscreen(_)) && matches!(other, P::Fullscreen(_)) {
            return true;
        }
        if matches!(self, P::AnyLink(_)) && matches!(other, P::AnyLink(_)) {
            return true;
        }
        if matches!(self, P::ReadOnly(_)) && matches!(other, P::ReadOnly(_)) {
            return true;
        }
        if matches!(self, P::ReadWrite(_)) && matches!(other, P::ReadWrite(_)) {
            return true;
        }
        if matches!(self, P::PlaceholderShown(_)) && matches!(other, P::PlaceholderShown(_)) {
            return true;
        }
        if matches!(self, P::Autofill(_)) && matches!(other, P::Autofill(_)) {
            return true;
        }
        self.eql(other)
    }

    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        // A buffered intermediate `Printer` would only matter for
        // length-dependent minification decisions made by callers (none
        // here), so write directly to `dest`.
        serialize::serialize_pseudo_class(self, dest, None)
    }

    // eql / hash — provided by `#[derive(CssEql, CssHash)]` (variant-wise; the
    // `Box<Selector>` arms recurse via the `CssEql for GenericSelector` impl
    // below). `deep_clone` is `Clone` — the selector AST is global-alloc and
    // every borrowed payload (`Str`, `Ident.v`) is an arena-static identity copy.
    pub(crate) fn deep_clone(&self) -> Self {
        self.clone()
    }

    pub(crate) fn get_prefix(&self) -> css::VendorPrefix {
        use PseudoClass as P;
        match self {
            P::Fullscreen(p)
            | P::AnyLink(p)
            | P::ReadOnly(p)
            | P::ReadWrite(p)
            | P::PlaceholderShown(p)
            | P::Autofill(p) => *p,
            _ => css::VendorPrefix::empty(),
        }
    }

    pub(crate) fn get_necessary_prefixes(
        &mut self,
        targets: &css::targets::Targets,
    ) -> css::VendorPrefix {
        use PseudoClass as P;
        use css::prefixes::Feature as F;
        let (p, feature): (&mut css::VendorPrefix, F) = match self {
            P::Fullscreen(p) => (p, F::PseudoClassFullscreen),
            P::AnyLink(p) => (p, F::PseudoClassAnyLink),
            P::ReadOnly(p) => (p, F::PseudoClassReadOnly),
            P::ReadWrite(p) => (p, F::PseudoClassReadWrite),
            P::PlaceholderShown(p) => (p, F::PseudoClassPlaceholderShown),
            P::Autofill(p) => (p, F::PseudoClassAutofill),
            _ => return css::VendorPrefix::empty(),
        };
        *p = targets.prefixes(*p, feature);
        *p
    }

    pub(crate) fn is_user_action_state(&self) -> bool {
        use PseudoClass as P;
        matches!(
            self,
            P::Active | P::Hover | P::Focus | P::FocusWithin | P::FocusVisible
        )
    }

    pub(crate) fn is_valid_before_webkit_scrollbar(&self) -> bool {
        !matches!(self, PseudoClass::WebkitScrollbar(_))
    }

    pub(crate) fn is_valid_after_webkit_scrollbar(&self) -> bool {
        use PseudoClass as P;
        matches!(
            self,
            P::WebkitScrollbar(_) | P::Enabled | P::Disabled | P::Hover | P::Active
        )
    }
}

/// A [webkit scrollbar](https://webkit.org/blog/363/styling-scrollbars/) pseudo class.
#[derive(Clone, Copy, PartialEq, Eq, Hash, CssEql, CssHash, css::generics::DeepClone)]
pub enum WebKitScrollbarPseudoClass {
    /// :horizontal
    Horizontal,
    /// :vertical
    Vertical,
    /// :decrement
    Decrement,
    /// :increment
    Increment,
    /// :start
    Start,
    /// :end
    End,
    /// :double-button
    DoubleButton,
    /// :single-button
    SingleButton,
    /// :no-button
    NoButton,
    /// :corner-present
    CornerPresent,
    /// :window-inactive
    WindowInactive,
}

/// A [webkit scrollbar](https://webkit.org/blog/363/styling-scrollbars/) pseudo element.
#[derive(Clone, Copy, PartialEq, Eq, Hash, CssHash)]
pub enum WebKitScrollbarPseudoElement {
    /// ::-webkit-scrollbar
    Scrollbar,
    /// ::-webkit-scrollbar-button
    Button,
    /// ::-webkit-scrollbar-track
    Track,
    /// ::-webkit-scrollbar-track-piece
    TrackPiece,
    /// ::-webkit-scrollbar-thumb
    Thumb,
    /// ::-webkit-scrollbar-corner
    Corner,
    /// ::-webkit-resizer
    Resizer,
}

impl WebKitScrollbarPseudoElement {
    #[inline]
    pub fn eql(self, rhs: Self) -> bool {
        self == rhs
    }
    // hash — via `#[derive(CssHash)]`.
}

// ─────────────────────────────────────────────────────────────────────────────
// SelectorParser
// ─────────────────────────────────────────────────────────────────────────────

pub struct SelectorParser<'a> {
    pub(crate) is_nesting_allowed: bool,
    pub(crate) options: &'a ParserOptions<'a>,
    // PERF: re-thread `&'bump Bump` here to restore arena allocation.
}

// Rust inherent associated types are unstable (rust#8995); the equivalent
// contract is the `BunSelectorImpl` blanket impl above, so expose the alias
// at module scope instead.

impl<'a> SelectorParser<'a> {
    pub(crate) fn new_local_identifier(
        &mut self,
        input: &mut CssParser,
        tag: css::CssRefTag,
        raw: Str,
        loc: usize,
    ) -> <impl_::Selectors as SelectorImpl>::LocalIdentifier {
        if input.flags.css_modules() {
            return <impl_::Selectors as SelectorImpl>::LocalIdentifier::from_ref(
                input.add_symbol_for_name(
                    raw,
                    tag,
                    bun_ast::Loc {
                        start: i32::try_from(loc).expect("int cast"),
                    },
                ),
                crate::values::ident::debug_ident(raw, input.arena()),
            );
        }
        let _ = (input, tag, loc);
        <impl_::Selectors as SelectorImpl>::LocalIdentifier::from_ident(Ident {
            v: std::ptr::from_ref::<[u8]>(raw),
        })
    }

    pub(crate) fn namespace_for_prefix(&mut self, prefix: Ident) -> Option<Str> {
        let _ = self;
        // SAFETY: `Ident.v` borrows the parser arena which outlives the parse
        // session (`'static` is a placeholder for the arena lifetime).
        Some(unsafe { crate::arena_str(prefix.v) })
    }

    pub(crate) fn parse_functional_pseudo_element(
        &mut self,
        name: Str,
        input: &mut CssParser,
    ) -> CResult<PseudoElement> {
        // This lookup is intentionally CASE-SENSITIVE: `::CUE(..)` /
        // `::View-Transition-Group(..)` fall through to `CustomFunction`,
        // so look up `name` verbatim with no case folding.
        //
        // PERF: 8 entries with near-unique lengths (3/6/10/19/19/21/26/30) —
        // a length-gated `match` rejects the overwhelmingly-common miss path
        // (unknown `::-webkit-foo(...)` etc.) on a single `usize` compare,
        // versus a hash lookup's hash + table load + slice compare. Only
        // len==19 has two candidates, disambiguated by one full slice compare
        // each. Stays a hand-rolled `match` (not `comptime_string_map!`)
        // because each arm parses `input` differently rather than yielding a
        // constant.
        match name.len() {
            3 if name == b"cue" => {
                return Ok(PseudoElement::CueFunction {
                    selector: Box::new(Selector::parse(self, input)?),
                });
            }
            6 if name == b"picker" => {
                return Ok(PseudoElement::PickerFunction {
                    identifier: Ident::parse(input)?,
                });
            }
            10 if name == b"cue-region" => {
                return Ok(PseudoElement::CueRegionFunction {
                    selector: Box::new(Selector::parse(self, input)?),
                });
            }
            19 => match name {
                b"view-transition-old" => {
                    return Ok(PseudoElement::ViewTransitionOld {
                        part: ViewTransitionPartSelector::parse(self, input)?,
                    });
                }
                b"view-transition-new" => {
                    return Ok(PseudoElement::ViewTransitionNew {
                        part: ViewTransitionPartSelector::parse(self, input)?,
                    });
                }
                _ => {}
            },
            21 if name == b"view-transition-group" => {
                return Ok(PseudoElement::ViewTransitionGroup {
                    part: ViewTransitionPartSelector::parse(self, input)?,
                });
            }
            26 if name == b"view-transition-image-pair" => {
                return Ok(PseudoElement::ViewTransitionImagePair {
                    part: ViewTransitionPartSelector::parse(self, input)?,
                });
            }
            30 if name == b"view-transition-group-children" => {
                return Ok(PseudoElement::ViewTransitionGroupChildren {
                    part: ViewTransitionPartSelector::parse(self, input)?,
                });
            }
            _ => {}
        }
        if !strings::starts_with(name, b"-") {
            self.options.warn(
                &input.new_custom_error(
                    SelectorParseErrorKind::UnsupportedPseudoClassOrElement(name)
                        .into_default_parser_error(),
                ),
            );
        }

        let mut args: Vec<css::css_properties::custom::TokenOrValue> = Vec::new();
        TokenList::parse_raw(input, &mut args, self.options, 0)?;
        Ok(PseudoElement::CustomFunction {
            name,
            arguments: TokenList { v: args },
        })
    }

    fn parse_is_and_where(&self) -> bool {
        let _ = self;
        true
    }

    /// Whether the given function name is an alias for the `:is()` function.
    fn parse_any_prefix(&self, name: &[u8]) -> Option<css::VendorPrefix> {
        crate::match_ignore_ascii_case! { name, {
            b"-webkit-any" => Some(css::VendorPrefix::WEBKIT),
            b"-moz-any" => Some(css::VendorPrefix::MOZ),
            _ => None,
        }}
    }

    pub(crate) fn parse_non_ts_pseudo_class(
        &mut self,
        loc: css::SourceLocation,
        name: Str,
    ) -> CResult<PseudoClass> {
        // @compileError(css.todo_stuff.match_ignore_ascii_case);
        let pseudo_class: PseudoClass = 'pseudo_class: {
            if let Some(pseudo) = lookup_non_ts_pseudo_class(name) {
                break 'pseudo_class pseudo;
            }
            if strings::starts_with_char(name, b'_') {
                self.options.warn(&loc.new_custom_error(
                    SelectorParseErrorKind::UnsupportedPseudoClassOrElement(name),
                ));
            } else if (self.options.css_modules.is_some()
                && strings::eql_case_insensitive_ascii_check_length(name, b"local"))
                || strings::eql_case_insensitive_ascii_check_length(name, b"global")
            {
                return Err(
                    loc.new_custom_error(SelectorParseErrorKind::AmbiguousCssModuleClass(name))
                );
            }
            return Ok(PseudoClass::Custom { name });
        };

        Ok(pseudo_class)
    }

    pub(crate) fn parse_host(&mut self) -> bool {
        true
    }

    pub(crate) fn parse_non_ts_functional_pseudo_class(
        &mut self,
        name: Str,
        parser: &mut CssParser,
    ) -> CResult<PseudoClass> {
        let pseudo_class = crate::match_ignore_ascii_case! { name, {
            b"lang" => {
                // `expect_ident_or_string` returns `&'_ [u8]`
                // (lifetime-tied to `&mut self`), which can't satisfy
                // `parse_comma_separated`'s HRTB. Clone the token to extract
                // the underlying `&'static [u8]` payload directly.
                let languages = parser.parse_comma_separated(|p| -> CResult<Str> {
                    let loc = p.current_source_location();
                    let tok = *p.next()?;
                    match tok {
                        Token::Ident(i) | Token::QuotedString(i) => Ok(i),
                        t => Err(loc.new_unexpected_token_error(t)),
                    }
                })?;
                return Ok(PseudoClass::Lang { languages });
            },
            b"dir" => PseudoClass::Dir {
                direction: Direction::parse(parser)?,
            },
            b"local" if self.options.css_modules.is_some() => PseudoClass::Local {
                selector: Box::new(Selector::parse(self, parser)?),
            },
            b"global" if self.options.css_modules.is_some() => PseudoClass::Global {
                selector: Box::new(Selector::parse(self, parser)?),
            },
            _ => {
                if !strings::starts_with_char(name, b'-') {
                    self.options.warn(
                        &parser.new_custom_error(
                            SelectorParseErrorKind::UnsupportedPseudoClassOrElement(name)
                                .into_default_parser_error(),
                        ),
                    );
                }
                let mut args: Vec<css::css_properties::custom::TokenOrValue> = Vec::new();
                css::TokenListFns::parse_raw(parser, &mut args, self.options, 0)?;
                PseudoClass::CustomFunction {
                    name,
                    arguments: TokenList { v: args },
                }
            },
        }};

        Ok(pseudo_class)
    }

    pub(crate) fn is_nesting_allowed(&self) -> bool {
        self.is_nesting_allowed
    }

    pub(crate) fn deep_combinator_enabled(&self) -> bool {
        self.options
            .flags
            .contains(css::ParserFlags::DEEP_SELECTOR_COMBINATOR)
    }

    pub(crate) fn default_namespace(
        &self,
    ) -> Option<<impl_::Selectors as SelectorImpl>::NamespaceUrl> {
        let _ = self;
        None
    }

    pub(crate) fn parse_part(&self) -> bool {
        let _ = self;
        true
    }

    pub(crate) fn parse_slotted(&self) -> bool {
        let _ = self;
        true
    }

    /// The error recovery that selector lists inside :is() and :where() have.
    fn is_and_where_error_recovery(&self) -> ParseErrorRecovery {
        let _ = self;
        ParseErrorRecovery::IgnoreInvalidSelector
    }

    pub(crate) fn parse_pseudo_element(
        &mut self,
        loc: css::SourceLocation,
        name: Str,
    ) -> CResult<PseudoElement> {
        let pseudo_element = lookup_pseudo_element(name).unwrap_or_else(|| {
            if !strings::starts_with_char(name, b'-') {
                self.options.warn(&loc.new_custom_error(
                    SelectorParseErrorKind::UnsupportedPseudoClassOrElement(name),
                ));
            }
            PseudoElement::Custom { name }
        });

        Ok(pseudo_element)
    }
}

/// Case-insensitive lookup table for `parse_non_ts_pseudo_class`.
fn lookup_non_ts_pseudo_class(name: &[u8]) -> Option<PseudoClass> {
    use PseudoClass as P;
    use WebKitScrollbarPseudoClass as WS;
    use css::VendorPrefix as VP;
    Some(crate::match_ignore_ascii_case! { name, {
        // https://drafts.csswg.org/selectors-4/#useraction-pseudos
        b"hover" => P::Hover,
        b"active" => P::Active,
        b"focus" => P::Focus,
        b"focus-visible" => P::FocusVisible,
        b"focus-within" => P::FocusWithin,
        // https://drafts.csswg.org/selectors-4/#time-pseudos
        b"current" => P::Current,
        b"past" => P::Past,
        b"future" => P::Future,
        // https://drafts.csswg.org/selectors-4/#resource-pseudos
        b"playing" => P::Playing,
        b"paused" => P::Paused,
        b"seeking" => P::Seeking,
        b"buffering" => P::Buffering,
        b"stalled" => P::Stalled,
        b"muted" => P::Muted,
        b"volume-locked" => P::VolumeLocked,
        // https://fullscreen.spec.whatwg.org/#:fullscreen-pseudo-class
        b"fullscreen" => P::Fullscreen(VP::NONE),
        b"-webkit-full-screen" => P::Fullscreen(VP::WEBKIT),
        b"-moz-full-screen" => P::Fullscreen(VP::MOZ),
        b"-ms-fullscreen" => P::Fullscreen(VP::MS),
        // https://drafts.csswg.org/selectors/#display-state-pseudos
        b"open" => P::Open,
        b"closed" => P::Closed,
        b"modal" => P::Modal,
        b"picture-in-picture" => P::PictureInPicture,
        // https://html.spec.whatwg.org/multipage/semantics-other.html#selector-popover-open
        b"popover-open" => P::PopoverOpen,
        // https://drafts.csswg.org/selectors-4/#the-defined-pseudo
        b"defined" => P::Defined,
        // https://drafts.csswg.org/selectors-4/#location
        b"any-link" => P::AnyLink(VP::NONE),
        b"-webkit-any-link" => P::AnyLink(VP::WEBKIT),
        b"-moz-any-link" => P::AnyLink(VP::MOZ),
        b"link" => P::Link,
        b"local-link" => P::LocalLink,
        b"target" => P::Target,
        b"target-within" => P::TargetWithin,
        b"visited" => P::Visited,
        // https://drafts.csswg.org/selectors-4/#input-pseudos
        b"enabled" => P::Enabled,
        b"disabled" => P::Disabled,
        b"read-only" => P::ReadOnly(VP::NONE),
        b"-moz-read-only" => P::ReadOnly(VP::MOZ),
        b"read-write" => P::ReadWrite(VP::NONE),
        b"-moz-read-write" => P::ReadWrite(VP::MOZ),
        b"placeholder-shown" => P::PlaceholderShown(VP::NONE),
        b"-moz-placeholder-shown" => P::PlaceholderShown(VP::MOZ),
        b"-ms-placeholder-shown" => P::PlaceholderShown(VP::MS),
        b"default" => P::Default,
        b"checked" => P::Checked,
        b"indeterminate" => P::Indeterminate,
        b"blank" => P::Blank,
        b"valid" => P::Valid,
        b"invalid" => P::Invalid,
        b"in-range" => P::InRange,
        b"out-of-range" => P::OutOfRange,
        b"required" => P::Required,
        b"optional" => P::Optional,
        b"user-valid" => P::UserValid,
        b"user-invalid" => P::UserInvalid,
        // https://html.spec.whatwg.org/multipage/semantics-other.html#selector-autofill
        b"autofill" => P::Autofill(VP::NONE),
        b"-webkit-autofill" => P::Autofill(VP::WEBKIT),
        b"-o-autofill" => P::Autofill(VP::O),
        // https://webkit.org/blog/363/styling-scrollbars/
        b"horizontal" => P::WebkitScrollbar(WS::Horizontal),
        b"vertical" => P::WebkitScrollbar(WS::Vertical),
        b"decrement" => P::WebkitScrollbar(WS::Decrement),
        b"increment" => P::WebkitScrollbar(WS::Increment),
        b"start" => P::WebkitScrollbar(WS::Start),
        b"end" => P::WebkitScrollbar(WS::End),
        b"double-button" => P::WebkitScrollbar(WS::DoubleButton),
        b"single-button" => P::WebkitScrollbar(WS::SingleButton),
        b"no-button" => P::WebkitScrollbar(WS::NoButton),
        b"corner-present" => P::WebkitScrollbar(WS::CornerPresent),
        b"window-inactive" => P::WebkitScrollbar(WS::WindowInactive),
        _ => return None,
    } })
}

/// Case-insensitive lookup table for `parse_pseudo_element`.
fn lookup_pseudo_element(name: &[u8]) -> Option<PseudoElement> {
    use PseudoElement as PE;
    use WebKitScrollbarPseudoElement as WS;
    use css::VendorPrefix as VP;
    Some(crate::match_ignore_ascii_case! { name, {
        b"before" => PE::Before,
        b"after" => PE::After,
        b"first-line" => PE::FirstLine,
        b"first-letter" => PE::FirstLetter,
        b"cue" => PE::Cue,
        b"cue-region" => PE::CueRegion,
        b"selection" => PE::Selection(VP::NONE),
        b"-moz-selection" => PE::Selection(VP::MOZ),
        b"placeholder" => PE::Placeholder(VP::NONE),
        b"-webkit-input-placeholder" => PE::Placeholder(VP::WEBKIT),
        b"-moz-placeholder" => PE::Placeholder(VP::MOZ),
        b"-ms-input-placeholder" => PE::Placeholder(VP::MS),
        b"marker" => PE::Marker,
        b"backdrop" => PE::Backdrop(VP::NONE),
        b"-webkit-backdrop" => PE::Backdrop(VP::WEBKIT),
        b"file-selector-button" => PE::FileSelectorButton(VP::NONE),
        b"-webkit-file-upload-button" => PE::FileSelectorButton(VP::WEBKIT),
        b"-ms-browse" => PE::FileSelectorButton(VP::MS),
        b"-webkit-scrollbar" => PE::WebkitScrollbar(WS::Scrollbar),
        b"-webkit-scrollbar-button" => PE::WebkitScrollbar(WS::Button),
        b"-webkit-scrollbar-track" => PE::WebkitScrollbar(WS::Track),
        b"-webkit-scrollbar-track-piece" => PE::WebkitScrollbar(WS::TrackPiece),
        b"-webkit-scrollbar-thumb" => PE::WebkitScrollbar(WS::Thumb),
        b"-webkit-scrollbar-corner" => PE::WebkitScrollbar(WS::Corner),
        b"-webkit-resizer" => PE::WebkitScrollbar(WS::Resizer),
        b"view-transition" => PE::ViewTransition,
        b"details-content" => PE::DetailsContent,
        b"picker-icon" => PE::PickerIcon,
        b"checkmark" => PE::Checkmark,
        _ => return None,
    } })
}

// ─────────────────────────────────────────────────────────────────────────────
// GenericSelectorList
// ─────────────────────────────────────────────────────────────────────────────

pub struct GenericSelectorList<Impl: SelectorImpl> {
    // PERF: make this equivalent to SmallVec<[Selector; 1]>
    pub(crate) v: SmallList<GenericSelector<Impl>, 1>,
}

impl<Impl: SelectorImpl> Default for GenericSelectorList<Impl> {
    fn default() -> Self {
        Self {
            v: SmallList::default(),
        }
    }
}

impl<Impl: SelectorImpl> GenericSelectorList<Impl> {
    /// Consume `self.v` and return a heap slice — used by `:is()`/`:where()`/
    /// `:has()`/`:not()`/`:nth-*(.. of ..)` which store `Box<[Selector]>` to
    /// keep `Component` small. See `small_list_into_box`.
    #[inline]
    pub(crate) fn into_boxed_selectors(self) -> Box<[GenericSelector<Impl>]> {
        small_list_into_box(self.v)
    }
}

impl<Impl: BunSelectorImpl> GenericSelectorList<Impl> {
    pub(crate) fn any_has_pseudo_element(&self) -> bool {
        for sel in self.v.slice() {
            if sel.has_pseudo_element() {
                return true;
            }
        }
        false
    }

    pub(crate) fn specifities_all_equal(&self) -> bool {
        if self.v.len() == 0 {
            return true;
        }
        if self.v.len() == 1 {
            return true;
        }
        let value = self.v.at(0).specificity();
        for sel in &self.v.slice()[1..] {
            if sel.specificity() != value {
                return false;
            }
        }
        true
    }

    pub fn parse(
        parser: &mut SelectorParser,
        input: &mut CssParser,
        error_recovery: ParseErrorRecovery,
        nesting_requirement: NestingRequirement,
    ) -> CResult<Self> {
        let mut state = SelectorParsingState::empty();
        Self::parse_with_state(
            parser,
            input,
            &mut state,
            error_recovery,
            nesting_requirement,
        )
    }

    pub(crate) fn parse_relative(
        parser: &mut SelectorParser,
        input: &mut CssParser,
        error_recovery: ParseErrorRecovery,
        nesting_requirement: NestingRequirement,
    ) -> CResult<Self> {
        let mut state = SelectorParsingState::empty();
        Self::parse_relative_with_state(
            parser,
            input,
            &mut state,
            error_recovery,
            nesting_requirement,
        )
    }

    pub(crate) fn parse_with_state(
        parser: &mut SelectorParser,
        input: &mut CssParser,
        state: &mut SelectorParsingState,
        recovery: ParseErrorRecovery,
        nesting_requirement: NestingRequirement,
    ) -> CResult<Self> {
        Self::parse_list_with_state(
            parser,
            input,
            state,
            recovery,
            nesting_requirement,
            parse_selector::<Impl>,
        )
    }

    pub(crate) fn parse_relative_with_state(
        parser: &mut SelectorParser,
        input: &mut CssParser,
        state: &mut SelectorParsingState,
        recovery: ParseErrorRecovery,
        nesting_requirement: NestingRequirement,
    ) -> CResult<Self> {
        Self::parse_list_with_state(
            parser,
            input,
            state,
            recovery,
            nesting_requirement,
            parse_relative_selector::<Impl>,
        )
    }

    fn parse_list_with_state(
        parser: &mut SelectorParser,
        input: &mut CssParser,
        state: &mut SelectorParsingState,
        recovery: ParseErrorRecovery,
        nesting_requirement: NestingRequirement,
        parse_one: fn(
            &mut SelectorParser,
            &mut CssParser,
            &mut SelectorParsingState,
            NestingRequirement,
        ) -> CResult<GenericSelector<Impl>>,
    ) -> CResult<Self> {
        let original_state = *state;
        let mut values: SmallList<GenericSelector<Impl>, 1> = SmallList::default();

        loop {
            // Reshaped for borrowck — capture a local flag instead of a
            // raw `*mut SelectorParsingState`, then fold into `state` after return.
            let mut saw_nesting = false;
            let selector =
                input.parse_until_before(css::Delimiters::COMMA, |input2: &mut CssParser| {
                    let mut selector_state = original_state;
                    let result =
                        parse_one(parser, input2, &mut selector_state, nesting_requirement);
                    if selector_state.contains(SelectorParsingState::AFTER_NESTING) {
                        saw_nesting = true;
                    }
                    result
                });
            if saw_nesting {
                state.insert(SelectorParsingState::AFTER_NESTING);
            }

            let was_ok = selector.is_ok();
            match selector {
                Ok(sel) => {
                    values.append(sel);
                }
                Err(e) => match recovery {
                    ParseErrorRecovery::DiscardList => return Err(e),
                    ParseErrorRecovery::IgnoreInvalidSelector => {}
                },
            }

            if let Ok(tok) = input.next() {
                if matches!(tok, Token::Comma) {
                    continue;
                }
                // Shouldn't have got a selector if getting here.
                debug_assert!(!was_ok);
            }
            return Ok(Self { v: values });
        }
    }

    pub(crate) fn from_selector(selector: GenericSelector<Impl>) -> Self {
        let mut result = Self::default();
        result.v.append(selector);
        result
    }

    pub(crate) fn deep_clone(&self) -> Self {
        let mut v = SmallList::<GenericSelector<Impl>, 1>::init_capacity(self.v.len());
        for sel in self.v.slice() {
            v.append(sel.deep_clone());
        }
        Self { v }
    }

    pub fn eql(&self, rhs: &Self) -> bool {
        eql_selector_slice(self.v.slice(), rhs.v.slice())
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        hash_selector_slice(self.v.slice(), hasher);
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GenericSelector
// ─────────────────────────────────────────────────────────────────────────────

/// -- original comment from servo --
/// A Selector stores a sequence of simple selectors and combinators. The
/// iterator classes allow callers to iterate at either the raw sequence level or
/// at the level of sequences of simple selectors separated by combinators. Most
/// callers want the higher-level iterator.
///
/// We store compound selectors internally right-to-left (in matching order).
/// Additionally, we invert the order of top-level compound selectors so that
/// each one matches left-to-right. This is because matching namespace, local name,
/// id, and class are all relatively cheap, whereas matching pseudo-classes might
/// be expensive (depending on the pseudo-class). Since authors tend to put the
/// pseudo-classes on the right, it's faster to start matching on the left.
///
/// This reordering doesn't change the semantics of selector matching, and we
/// handle it in to_css to make it invisible to serialization.
#[derive(Clone)]
pub struct GenericSelector<Impl: SelectorImpl> {
    pub(crate) specificity_and_flags: SpecificityAndFlags,
    pub(crate) components: Vec<GenericComponent<Impl>, ArenaPtr>,
}

impl<Impl: BunSelectorImpl> GenericSelector<Impl> {
    /// Parse a selector, without any pseudo-element.
    pub fn parse(parser: &mut SelectorParser, input: &mut CssParser) -> CResult<Self> {
        let mut state = SelectorParsingState::empty();
        parse_selector::<Impl>(parser, input, &mut state, NestingRequirement::None)
    }

    pub(crate) fn append(&mut self, component: GenericComponent<Impl>) {
        let index = 'index: {
            for (i, comp) in self.components.iter().enumerate() {
                match comp {
                    GenericComponent::Combinator(_) | GenericComponent::PseudoElement(_) => {
                        break 'index i;
                    }
                    _ => {}
                }
            }
            self.components.len()
        };
        self.components.insert(index, component);
    }

    pub(crate) fn deep_clone(&self) -> Self {
        let alloc = *self.components.allocator();
        let mut components = Vec::with_capacity_in(self.components.len(), alloc);
        components.extend(self.components.iter().map(|c| c.deep_clone()));
        Self {
            specificity_and_flags: self.specificity_and_flags,
            components,
        }
    }

    pub fn eql(&self, other: &Self) -> bool {
        self.specificity_and_flags.eql(&other.specificity_and_flags)
            && self.components.len() == other.components.len()
            && self
                .components
                .iter()
                .zip(other.components.iter())
                .all(|(a, b)| a.eql(b))
    }

    pub(crate) fn has_combinator(&self) -> bool {
        for c in &self.components {
            if let GenericComponent::Combinator(comb) = c {
                if comb.is_tree_combinator() {
                    return true;
                }
            }
        }
        false
    }

    pub(crate) fn has_pseudo_element(&self) -> bool {
        self.specificity_and_flags.has_pseudo_element()
    }

    /// Returns count of simple selectors and combinators in the Selector.
    pub(crate) fn len(&self) -> usize {
        self.components.len()
    }

    pub(crate) fn from_component(component: GenericComponent<Impl>) -> Self {
        Self::from_component_in(component, ArenaPtr::global())
    }

    pub(crate) fn from_component_in(component: GenericComponent<Impl>, alloc: ArenaPtr) -> Self {
        let mut builder = SelectorBuilder::<Impl>::init_in(alloc);
        if let Some(combinator) = component.as_combinator() {
            builder.push_combinator(combinator);
        } else {
            builder.push_simple_selector(component);
        }
        let result = builder.build(SelectorFlags::empty());
        Self {
            specificity_and_flags: result.specificity_and_flags,
            components: result.components,
        }
    }

    pub(crate) fn specificity(&self) -> u32 {
        self.specificity_and_flags.specificity
    }

    pub(crate) fn iter_raw_match_order(&self) -> RawMatchOrderIterator<'_, Impl> {
        RawMatchOrderIterator {
            slice: &self.components,
            i: 0,
        }
    }

    /// Returns an iterator over the sequence of simple selectors and
    /// combinators, in parse order (from left to right), starting from
    /// `offset`.
    pub(crate) fn iter_raw_parse_order_from(
        &self,
        offset: usize,
    ) -> RawParseOrderFromIter<'_, Impl> {
        RawParseOrderFromIter {
            slice: &self.components[0..self.components.len() - offset],
            i: 0,
        }
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        self.specificity_and_flags.hash(hasher);
        for c in &self.components {
            c.hash(hasher);
        }
    }
}

impl<Impl: BunSelectorImpl> CssEql for GenericSelector<Impl> {
    #[inline]
    fn eql(&self, other: &Self) -> bool {
        self.eql(other)
    }
}
impl<Impl: BunSelectorImpl> CssHash for GenericSelector<Impl> {
    #[inline]
    fn hash(&self, hasher: &mut Wyhash) {
        self.hash(hasher)
    }
}

pub struct RawMatchOrderIterator<'a, Impl: SelectorImpl> {
    slice: &'a [GenericComponent<Impl>],
    i: usize,
}

impl<'a, Impl: SelectorImpl> Iterator for RawMatchOrderIterator<'a, Impl> {
    type Item = &'a GenericComponent<Impl>;
    fn next(&mut self) -> Option<Self::Item> {
        if self.i >= self.slice.len() {
            return None;
        }
        let result = &self.slice[self.i];
        self.i += 1;
        Some(result)
    }
}

pub struct RawParseOrderFromIter<'a, Impl: SelectorImpl> {
    slice: &'a [GenericComponent<Impl>],
    i: usize,
}

impl<'a, Impl: SelectorImpl> Iterator for RawParseOrderFromIter<'a, Impl> {
    type Item = &'a GenericComponent<Impl>;
    fn next(&mut self) -> Option<Self::Item> {
        if !(self.i < self.slice.len()) {
            return None;
        }
        let result = &self.slice[self.slice.len() - 1 - self.i];
        self.i += 1;
        Some(result)
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// GenericComponent
// ─────────────────────────────────────────────────────────────────────────────

/// A CSS simple selector or combinator. We store both in the same enum for
/// optimal packing and cache performance, see [1].
///
/// [1] https://bugzilla.mozilla.org/show_bug.cgi?id=1357973
#[derive(Clone)]
pub enum GenericComponent<Impl: SelectorImpl> {
    Combinator(Combinator),

    ExplicitAnyNamespace,
    ExplicitNoNamespace,
    DefaultNamespace(Impl::NamespaceUrl),
    Namespace {
        prefix: Impl::NamespacePrefix,
        url: Impl::NamespaceUrl,
    },

    ExplicitUniversalType,
    LocalName(LocalName<Impl>),

    Id(Impl::LocalIdentifier),
    Class(Impl::LocalIdentifier),

    AttributeInNoNamespaceExists {
        local_name: Impl::LocalName,
        local_name_lower: Impl::LocalName,
    },
    /// Used only when local_name is already lowercase.
    AttributeInNoNamespace {
        local_name: Impl::LocalName,
        operator: attrs::AttrSelectorOperator,
        value: Impl::AttrValue,
        case_sensitivity: attrs::ParsedCaseSensitivity,
        never_matches: bool,
    },
    /// Use a Box in the less common cases with more data to keep size_of::<Component>() small.
    AttributeOther(Box<attrs::AttrSelectorWithOptionalNamespace<Impl>>),

    /// Pseudo-classes
    Negation(Box<[GenericSelector<Impl>]>),
    Root,
    Empty,
    Scope,
    Nth(NthSelectorData),
    NthOf(NthOfSelectorData<Impl>),
    NonTsPseudoClass(Impl::NonTSPseudoClass),
    /// The ::slotted() pseudo-element:
    ///
    /// https://drafts.csswg.org/css-scoping/#slotted-pseudo
    ///
    /// The selector here is a compound selector, that is, no combinators.
    ///
    /// NOTE(emilio): This should support a list of selectors, but as of this
    /// writing no other browser does, and that allows them to put ::slotted()
    /// in the rule hash, so we do that too.
    ///
    /// See https://github.com/w3c/csswg-drafts/issues/2158
    Slotted(GenericSelector<Impl>),
    /// The `::part` pseudo-element.
    ///   https://drafts.csswg.org/css-shadow-parts/#part
    Part(Box<[Impl::Identifier]>),
    /// The `:host` pseudo-class:
    ///
    /// https://drafts.csswg.org/css-scoping/#host-selector
    ///
    /// NOTE(emilio): This should support a list of selectors, but as of this
    /// writing no other browser does, and that allows them to put :host()
    /// in the rule hash, so we do that too.
    ///
    /// See https://github.com/w3c/csswg-drafts/issues/2158
    Host(Option<GenericSelector<Impl>>),
    /// The `:where` pseudo-class.
    ///
    /// https://drafts.csswg.org/selectors/#zero-matches
    ///
    /// The inner argument is conceptually a SelectorList, but we move the
    /// selectors to the heap to keep Component small.
    Where(Box<[GenericSelector<Impl>]>),
    /// The `:is` pseudo-class.
    ///
    /// https://drafts.csswg.org/selectors/#matches-pseudo
    ///
    /// Same comment as above re. the argument.
    Is(Box<[GenericSelector<Impl>]>),
    Any {
        vendor_prefix: Impl::VendorPrefix,
        selectors: Box<[GenericSelector<Impl>]>,
    },
    /// The `:has` pseudo-class.
    ///
    /// https://www.w3.org/TR/selectors/#relational
    Has(Box<[GenericSelector<Impl>]>),
    /// An implementation-dependent pseudo-element selector.
    PseudoElement(Impl::PseudoElement),
    /// A nesting selector:
    ///
    /// https://drafts.csswg.org/css-nesting-1/#nest-selector
    ///
    /// NOTE: This is a lightningcss addition.
    Nesting,
}

impl<Impl: BunSelectorImpl> GenericComponent<Impl> {
    pub(crate) fn as_class(&self) -> Option<&Impl::LocalIdentifier> {
        match self {
            Self::Class(v) => Some(v),
            _ => None,
        }
    }

    pub(crate) fn deep_clone(&self) -> Self {
        // Hand-written variant-walk.
        // Every borrowed payload (`Str`, `Ident.v`, `IdentOrRef`) is an
        // arena-static identity copy; owning containers (`Vec`/`Box`) recurse.
        use GenericComponent as C;
        match self {
            C::Combinator(c) => C::Combinator(*c),
            C::ExplicitAnyNamespace => C::ExplicitAnyNamespace,
            C::ExplicitNoNamespace => C::ExplicitNoNamespace,
            C::DefaultNamespace(u) => C::DefaultNamespace(*u),
            C::Namespace { prefix, url } => C::Namespace {
                prefix: *prefix,
                url: *url,
            },
            C::ExplicitUniversalType => C::ExplicitUniversalType,
            C::LocalName(ln) => C::LocalName(ln.deep_clone()),
            C::Id(i) => C::Id(*i),
            C::Class(i) => C::Class(*i),
            C::AttributeInNoNamespaceExists {
                local_name,
                local_name_lower,
            } => C::AttributeInNoNamespaceExists {
                local_name: *local_name,
                local_name_lower: *local_name_lower,
            },
            C::AttributeInNoNamespace {
                local_name,
                operator,
                value,
                case_sensitivity,
                never_matches,
            } => C::AttributeInNoNamespace {
                local_name: *local_name,
                operator: *operator,
                value: *value,
                case_sensitivity: *case_sensitivity,
                never_matches: *never_matches,
            },
            C::AttributeOther(a) => C::AttributeOther(Box::new(a.deep_clone())),
            C::Negation(s) => C::Negation(deep_clone_selector_slice(s)),
            C::Root => C::Root,
            C::Empty => C::Empty,
            C::Scope => C::Scope,
            C::Nth(n) => C::Nth(*n),
            C::NthOf(n) => C::NthOf(n.deep_clone()),
            C::NonTsPseudoClass(p) => C::NonTsPseudoClass(p.deep_clone()),
            C::Slotted(s) => C::Slotted(s.deep_clone()),
            C::Part(p) => C::Part(p.iter().cloned().collect()),
            C::Host(h) => C::Host(h.as_ref().map(|s| s.deep_clone())),
            C::Where(s) => C::Where(deep_clone_selector_slice(s)),
            C::Is(s) => C::Is(deep_clone_selector_slice(s)),
            C::Any {
                vendor_prefix,
                selectors,
            } => C::Any {
                vendor_prefix: *vendor_prefix,
                selectors: deep_clone_selector_slice(selectors),
            },
            C::Has(s) => C::Has(deep_clone_selector_slice(s)),
            C::PseudoElement(pe) => C::PseudoElement(pe.deep_clone()),
            C::Nesting => C::Nesting,
        }
    }

    pub fn eql(&self, rhs: &Self) -> bool {
        use GenericComponent as C;
        match (self, rhs) {
            (C::Combinator(a), C::Combinator(b)) => a.eql(b),
            (C::ExplicitAnyNamespace, C::ExplicitAnyNamespace)
            | (C::ExplicitNoNamespace, C::ExplicitNoNamespace)
            | (C::ExplicitUniversalType, C::ExplicitUniversalType)
            | (C::Root, C::Root)
            | (C::Empty, C::Empty)
            | (C::Scope, C::Scope)
            | (C::Nesting, C::Nesting) => true,
            (C::DefaultNamespace(a), C::DefaultNamespace(b)) => strings::eql(a, b),
            (
                C::Namespace {
                    prefix: ap,
                    url: au,
                },
                C::Namespace {
                    prefix: bp,
                    url: bu,
                },
            ) => ap.eql(bp) && strings::eql(au, bu),
            (C::LocalName(a), C::LocalName(b)) => a.eql(b),
            (C::Id(a), C::Id(b)) | (C::Class(a), C::Class(b)) => a.eql(b),
            (
                C::AttributeInNoNamespaceExists {
                    local_name: an,
                    local_name_lower: al,
                },
                C::AttributeInNoNamespaceExists {
                    local_name: bn,
                    local_name_lower: bl,
                },
            ) => an.eql(bn) && al.eql(bl),
            (
                C::AttributeInNoNamespace {
                    local_name: an,
                    operator: ao,
                    value: av,
                    case_sensitivity: ac,
                    never_matches: am,
                },
                C::AttributeInNoNamespace {
                    local_name: bn,
                    operator: bo,
                    value: bv,
                    case_sensitivity: bc,
                    never_matches: bm,
                },
            ) => {
                an.eql(bn)
                    && ao == bo
                    && ac == bc
                    && am == bm
                    // SAFETY: arena-owned slices live for the parse session.
                    && unsafe { strings::eql(&**av, &**bv) }
            }
            (C::AttributeOther(a), C::AttributeOther(b)) => a.eql(b),
            (C::Negation(a), C::Negation(b))
            | (C::Where(a), C::Where(b))
            | (C::Is(a), C::Is(b))
            | (C::Has(a), C::Has(b)) => eql_selector_slice(a, b),
            (C::Nth(a), C::Nth(b)) => a.eql(b),
            (C::NthOf(a), C::NthOf(b)) => a.eql(b),
            (C::NonTsPseudoClass(a), C::NonTsPseudoClass(b)) => a.eql(b),
            (C::Slotted(a), C::Slotted(b)) => a.eql(b),
            (C::Part(a), C::Part(b)) => {
                a.len() == b.len() && a.iter().zip(b.iter()).all(|(l, r)| l.eql(r))
            }
            (C::Host(a), C::Host(b)) => match (a, b) {
                (None, None) => true,
                (Some(a), Some(b)) => a.eql(b),
                _ => false,
            },
            (
                C::Any {
                    vendor_prefix: ap,
                    selectors: asel,
                },
                C::Any {
                    vendor_prefix: bp,
                    selectors: bsel,
                },
            ) => ap == bp && eql_selector_slice(asel, bsel),
            (C::PseudoElement(a), C::PseudoElement(b)) => a.eql(b),
            _ => false,
        }
    }

    pub(crate) fn as_combinator(&self) -> Option<Combinator> {
        if let Self::Combinator(c) = self {
            Some(*c)
        } else {
            None
        }
    }

    pub(crate) fn convert_helper_is(s: Box<[GenericSelector<Impl>]>) -> Self {
        Self::Is(s)
    }

    pub(crate) fn convert_helper_where(s: Box<[GenericSelector<Impl>]>) -> Self {
        Self::Where(s)
    }

    pub(crate) fn convert_helper_any(
        s: Box<[GenericSelector<Impl>]>,
        prefix: Impl::VendorPrefix,
    ) -> Self {
        Self::Any {
            vendor_prefix: prefix,
            selectors: s,
        }
    }

    /// Returns true if this is a combinator.
    pub(crate) fn is_combinator(&self) -> bool {
        matches!(self, Self::Combinator(_))
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        use GenericComponent as C;
        // Hash a variant tag, then the payload.
        // SAFETY: `GenericComponent` is `#[repr(Rust)]`; reading the discriminant
        // via `core::mem::discriminant` is stable but not byte-hashable. Use a
        // per-arm tag instead (CSS hashing is in-process dedup only —
        // self-consistency is the contract).
        macro_rules! tag {
            ($n:expr) => {
                hasher.update(&($n as u32).to_ne_bytes())
            };
        }
        match self {
            C::Combinator(c) => {
                tag!(0);
                CssHash::hash(c, hasher);
            }
            C::ExplicitAnyNamespace => tag!(1),
            C::ExplicitNoNamespace => tag!(2),
            C::DefaultNamespace(u) => {
                tag!(3);
                hasher.update(u);
            }
            C::Namespace { prefix, url } => {
                tag!(4);
                prefix.hash(hasher);
                hasher.update(url);
            }
            C::ExplicitUniversalType => tag!(5),
            C::LocalName(ln) => {
                tag!(6);
                ln.hash(hasher);
            }
            C::Id(i) => {
                tag!(7);
                i.hash(hasher);
            }
            C::Class(i) => {
                tag!(8);
                i.hash(hasher);
            }
            C::AttributeInNoNamespaceExists {
                local_name,
                local_name_lower,
            } => {
                tag!(9);
                local_name.hash(hasher);
                local_name_lower.hash(hasher);
            }
            C::AttributeInNoNamespace {
                local_name,
                operator,
                value,
                case_sensitivity,
                never_matches,
            } => {
                tag!(10);
                local_name.hash(hasher);
                CssHash::hash(operator, hasher);
                // SAFETY: arena-owned slice.
                hasher.update(unsafe { crate::arena_str(*value) });
                CssHash::hash(case_sensitivity, hasher);
                hasher.update(&[*never_matches as u8]);
            }
            C::AttributeOther(a) => {
                tag!(11);
                a.hash(hasher);
            }
            C::Negation(s) => {
                tag!(12);
                hash_selector_slice(s, hasher);
            }
            C::Root => tag!(13),
            C::Empty => tag!(14),
            C::Scope => tag!(15),
            C::Nth(n) => {
                tag!(16);
                n.hash(hasher);
            }
            C::NthOf(n) => {
                tag!(17);
                n.hash(hasher);
            }
            C::NonTsPseudoClass(p) => {
                tag!(18);
                CssHash::hash(p, hasher);
            }
            C::Slotted(s) => {
                tag!(19);
                s.hash(hasher);
            }
            C::Part(p) => {
                tag!(20);
                for id in p.iter() {
                    id.hash(hasher);
                }
            }
            C::Host(h) => {
                tag!(21);
                if let Some(s) = h {
                    s.hash(hasher);
                }
            }
            C::Where(s) => {
                tag!(22);
                hash_selector_slice(s, hasher);
            }
            C::Is(s) => {
                tag!(23);
                hash_selector_slice(s, hasher);
            }
            C::Any {
                vendor_prefix,
                selectors,
            } => {
                tag!(24);
                CssHash::hash(vendor_prefix, hasher);
                hash_selector_slice(selectors, hasher);
            }
            C::Has(s) => {
                tag!(25);
                hash_selector_slice(s, hasher);
            }
            C::PseudoElement(pe) => {
                tag!(26);
                CssHash::hash(pe, hasher);
            }
            C::Nesting => tag!(27),
        }
    }
}

impl<Impl: BunSelectorImpl> fmt::Display for GenericComponent<Impl> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        // A few variants get detail, the rest print
        // their tag name. `BunSelectorImpl`
        // pins `PseudoElement`/`LocalIdentifier` to the concrete types, whose
        // `Display` impls handle the payloads.
        match self {
            Self::LocalName(ln) => write!(f, "local_name={}", bstr::BStr::new(ln.name.v())),
            Self::Combinator(c) => write!(f, "combinator='{}'", c),
            Self::PseudoElement(pe) => write!(f, "pseudo_element={}", pe),
            Self::Class(c) => write!(f, "class={}", c),
            Self::ExplicitAnyNamespace => f.write_str("explicit_any_namespace"),
            Self::ExplicitNoNamespace => f.write_str("explicit_no_namespace"),
            Self::DefaultNamespace(_) => f.write_str("default_namespace"),
            Self::Namespace { .. } => f.write_str("namespace"),
            Self::ExplicitUniversalType => f.write_str("explicit_universal_type"),
            Self::Id(_) => f.write_str("id"),
            Self::AttributeInNoNamespaceExists { .. } => {
                f.write_str("attribute_in_no_namespace_exists")
            }
            Self::AttributeInNoNamespace { .. } => f.write_str("attribute_in_no_namespace"),
            Self::AttributeOther(_) => f.write_str("attribute_other"),
            Self::Negation(_) => f.write_str("negation"),
            Self::Root => f.write_str("root"),
            Self::Empty => f.write_str("empty"),
            Self::Scope => f.write_str("scope"),
            Self::Nth(_) => f.write_str("nth"),
            Self::NthOf(_) => f.write_str("nth_of"),
            Self::NonTsPseudoClass(_) => f.write_str("non_ts_pseudo_class"),
            Self::Slotted(_) => f.write_str("slotted"),
            Self::Part(_) => f.write_str("part"),
            Self::Host(_) => f.write_str("host"),
            Self::Where(_) => f.write_str("where"),
            Self::Is(_) => f.write_str("is"),
            Self::Any { .. } => f.write_str("any"),
            Self::Has(_) => f.write_str("has"),
            Self::Nesting => f.write_str("nesting"),
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// NthSelectorData / NthOfSelectorData
// ─────────────────────────────────────────────────────────────────────────────

/// The properties that comprise an :nth- pseudoclass as of Selectors 3 (e.g.,
/// nth-child(An+B)).
/// https://www.w3.org/TR/selectors-3/#nth-child-pseudo
#[derive(Clone, Copy, PartialEq, Eq)]
pub struct NthSelectorData {
    pub ty: NthType,
    pub(crate) is_function: bool,
    pub(crate) a: i32,
    pub(crate) b: i32,
}

impl NthSelectorData {
    /// Returns selector data for :only-{child,of-type}
    pub(crate) fn only(of_type: bool) -> NthSelectorData {
        NthSelectorData {
            ty: if of_type {
                NthType::OnlyOfType
            } else {
                NthType::OnlyChild
            },
            is_function: false,
            a: 0,
            b: 1,
        }
    }

    /// Returns selector data for :first-{child,of-type}
    pub(crate) fn first(of_type: bool) -> NthSelectorData {
        NthSelectorData {
            ty: if of_type {
                NthType::OfType
            } else {
                NthType::Child
            },
            is_function: false,
            a: 0,
            b: 1,
        }
    }

    /// Returns selector data for :last-{child,of-type}
    pub(crate) fn last(of_type: bool) -> NthSelectorData {
        NthSelectorData {
            ty: if of_type {
                NthType::LastOfType
            } else {
                NthType::LastChild
            },
            is_function: false,
            a: 0,
            b: 1,
        }
    }

    pub(crate) fn write_start(
        &self,
        dest: &mut Printer,
        is_function: bool,
    ) -> Result<(), PrintErr> {
        dest.write_str(match self.ty {
            NthType::Child => {
                if is_function {
                    ":nth-child("
                } else {
                    ":first-child"
                }
            }
            NthType::LastChild => {
                if is_function {
                    ":nth-last-child("
                } else {
                    ":last-child"
                }
            }
            NthType::OfType => {
                if is_function {
                    ":nth-of-type("
                } else {
                    ":first-of-type"
                }
            }
            NthType::LastOfType => {
                if is_function {
                    ":nth-last-of-type("
                } else {
                    ":last-of-type"
                }
            }
            NthType::OnlyChild => ":only-child",
            NthType::OnlyOfType => ":only-of-type",
            NthType::Col => ":nth-col(",
            NthType::LastCol => ":nth-last-col(",
        })
    }

    pub(crate) fn is_function_(&self) -> bool {
        self.a != 0 || self.b != 1
    }

    fn number_sign(num: i32) -> &'static str {
        if num >= 0 { "+" } else { "" }
    }

    pub(crate) fn write_affine(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        // PERF: this could be made faster
        if self.a == 0 && self.b == 0 {
            dest.write_char(b'0')
        } else if self.a == 1 && self.b == 0 {
            dest.write_char(b'n')
        } else if self.a == -1 && self.b == 0 {
            dest.write_str("-n")
        } else if self.b == 0 {
            dest.write_fmt(format_args!("{}n", self.a))
        } else if self.a == 2 && self.b == 1 {
            dest.write_str("odd")
        } else if self.a == 0 {
            dest.write_fmt(format_args!("{}", self.b))
        } else if self.a == 1 {
            dest.write_fmt(format_args!("n{}{}", Self::number_sign(self.b), self.b))
        } else if self.a == -1 {
            dest.write_fmt(format_args!("-n{}{}", Self::number_sign(self.b), self.b))
        } else {
            dest.write_fmt(format_args!(
                "{}n{}{}",
                self.a,
                Self::number_sign(self.b),
                self.b
            ))
        }
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        hasher.update(&(self.ty as u32).to_ne_bytes());
        hasher.update(&[self.is_function as u8]);
        hasher.update(&self.a.to_ne_bytes());
        hasher.update(&self.b.to_ne_bytes());
    }
}

/// The properties that comprise an :nth- pseudoclass as of Selectors 4 (e.g.,
/// nth-child(An+B [of S]?)).
/// https://www.w3.org/TR/selectors-4/#nth-child-pseudo
#[derive(Clone)]
pub struct NthOfSelectorData<Impl: SelectorImpl> {
    pub(crate) data: NthSelectorData,
    pub(crate) selectors: Box<[GenericSelector<Impl>]>,
}

impl<Impl: BunSelectorImpl> NthOfSelectorData<Impl> {
    pub fn eql(&self, rhs: &Self) -> bool {
        self.data.eql(&rhs.data) && eql_selector_slice(&self.selectors, &rhs.selectors)
    }
    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        self.data.hash(hasher);
        hash_selector_slice(&self.selectors, hasher);
    }
    pub(crate) fn deep_clone(&self) -> Self {
        Self {
            data: self.data,
            selectors: deep_clone_selector_slice(&self.selectors),
        }
    }
    pub(crate) fn nth_data(&self) -> NthSelectorData {
        self.data
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SelectorParsingState (packed struct(u16) — all-bool → bitflags!)
// ─────────────────────────────────────────────────────────────────────────────

bitflags::bitflags! {
    #[derive(Clone, Copy, PartialEq, Eq)]
    pub struct SelectorParsingState: u16 {
        /// Whether we should avoid adding default namespaces to selectors that
        /// aren't type or universal selectors.
        const SKIP_DEFAULT_NAMESPACE = 1 << 0;

        /// Whether we've parsed a ::slotted() pseudo-element already.
        ///
        /// If so, then we can only parse a subset of pseudo-elements, and
        /// whatever comes after them if so.
        const AFTER_SLOTTED = 1 << 1;

        /// Whether we've parsed a ::part() pseudo-element already.
        ///
        /// If so, then we can only parse a subset of pseudo-elements, and
        /// whatever comes after them if so.
        const AFTER_PART = 1 << 2;

        /// Whether we've parsed a pseudo-element (as in, an
        /// `Impl::PseudoElement` thus not accounting for `::slotted` or
        /// `::part`) already.
        ///
        /// If so, then other pseudo-elements and most other selectors are
        /// disallowed.
        const AFTER_PSEUDO_ELEMENT = 1 << 3;

        /// Whether we've parsed a non-stateful pseudo-element (again, as-in
        /// `Impl::PseudoElement`) already. If so, then other pseudo-classes are
        /// disallowed. If this flag is set, `AFTER_PSEUDO_ELEMENT` must be set
        /// as well.
        const AFTER_NON_STATEFUL_PSEUDO_ELEMENT = 1 << 4;

        /// Whether we explicitly disallow combinators.
        const DISALLOW_COMBINATORS = 1 << 5;

        /// Whether we explicitly disallow pseudo-element-like things.
        const DISALLOW_PSEUDOS = 1 << 6;

        /// Whether we have seen a nesting selector.
        const AFTER_NESTING = 1 << 7;

        const AFTER_WEBKIT_SCROLLBAR = 1 << 8;
        const AFTER_VIEW_TRANSITION = 1 << 9;
        const AFTER_UNKNOWN_PSEUDO_ELEMENT = 1 << 10;
    }
}

impl SelectorParsingState {
    /// Whether we are after any of the pseudo-like things.
    pub(crate) fn after_any_pseudo(self) -> bool {
        self.intersects(Self::AFTER_PART | Self::AFTER_SLOTTED | Self::AFTER_PSEUDO_ELEMENT)
    }

    pub(crate) fn allows_pseudos(self) -> bool {
        !self.contains(Self::AFTER_PSEUDO_ELEMENT) && !self.contains(Self::DISALLOW_PSEUDOS)
    }

    pub(crate) fn allows_part(self) -> bool {
        !self.contains(Self::DISALLOW_PSEUDOS) && !self.after_any_pseudo()
    }

    pub(crate) fn allows_slotted(self) -> bool {
        self.allows_part()
    }

    pub(crate) fn allows_tree_structural_pseudo_classes(self) -> bool {
        !self.after_any_pseudo()
    }

    pub(crate) fn allows_non_functional_pseudo_classes(self) -> bool {
        !self.contains(Self::AFTER_SLOTTED)
            && !self.contains(Self::AFTER_NON_STATEFUL_PSEUDO_ELEMENT)
    }

    pub(crate) fn allows_combinators(self) -> bool {
        !self.contains(Self::DISALLOW_COMBINATORS)
    }

    pub(crate) fn allows_custom_functional_pseudo_classes(self) -> bool {
        !self.after_any_pseudo()
    }
}

// ─────────────────────────────────────────────────────────────────────────────

#[derive(Clone, Copy, PartialEq, Eq)]
pub struct SpecificityAndFlags {
    /// There are two free bits here, since we use ten bits for each specificity
    /// kind (id, class, element).
    pub(crate) specificity: u32,
    /// There's padding after this field due to the size of the flags.
    pub(crate) flags: SelectorFlags,
}

impl SpecificityAndFlags {
    pub(crate) fn has_pseudo_element(self) -> bool {
        self.flags.contains(SelectorFlags::HAS_PSEUDO)
    }
    pub(crate) fn hash(self, hasher: &mut Wyhash) {
        hasher.update(&self.specificity.to_ne_bytes());
        hasher.update(&[self.flags.bits()]);
    }
}

bitflags::bitflags! {
    #[derive(Clone, Copy, PartialEq, Eq)]
    pub struct SelectorFlags: u8 {
        const HAS_PSEUDO = 1 << 0;
        const HAS_SLOTTED = 1 << 1;
        const HAS_PART = 1 << 2;
    }
}

/// How to treat invalid selectors in a selector list.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum ParseErrorRecovery {
    /// Discard the entire selector list, this is the default behavior for
    /// almost all of CSS.
    DiscardList,
    /// Ignore invalid selectors, potentially creating an empty selector list.
    ///
    /// This is the error recovery mode of :is() and :where()
    IgnoreInvalidSelector,
}

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum NestingRequirement {
    None,
    Prefixed,
    Contained,
    Implicit,
}

#[derive(Clone, Copy, PartialEq, Eq, Hash, strum::IntoStaticStr, CssHash)]
pub enum Combinator {
    Child,        // >
    Descendant,   // space
    NextSibling,  // +
    LaterSibling, // ~
    /// A dummy combinator we use to the left of pseudo-elements.
    ///
    /// It serializes as the empty string, and acts effectively as a child
    /// combinator in most cases.  If we ever actually start using a child
    /// combinator for this, we will need to fix up the way hashes are computed
    /// for revalidation selectors.
    PseudoElement,
    /// Another combinator used for ::slotted(), which represent the jump from
    /// a node to its assigned slot.
    SlotAssignment,

    /// Another combinator used for `::part()`, which represents the jump from
    /// the part to the containing shadow host.
    Part,

    /// Non-standard Vue >>> combinator.
    /// https://vue-loader.vuejs.org/guide/scoped-css.html#deep-selectors
    DeepDescendant,
    /// Non-standard /deep/ combinator.
    /// Appeared in early versions of the css-scoping-1 specification:
    /// https://www.w3.org/TR/2014/WD-css-scoping-1-20140403/#deep-combinator
    /// And still supported as an alias for >>> by Vue.
    Deep,
}

impl Combinator {
    // hash — via `#[derive(CssHash)]`.

    pub(crate) fn is_tree_combinator(self) -> bool {
        matches!(
            self,
            Self::Child | Self::Descendant | Self::NextSibling | Self::LaterSibling
        )
    }
}

impl fmt::Display for Combinator {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Child => write!(f, ">"),
            Self::Descendant => write!(f, "`descendant` (space)"),
            Self::NextSibling => write!(f, "+"),
            Self::LaterSibling => write!(f, "~"),
            other => write!(f, "{}", <&'static str>::from(*other)),
        }
    }
}

#[derive(Clone)]
pub enum SelectorParseErrorKind {
    InvalidState,
    ClassNeedsIdent(Token),
    PseudoElementExpectedIdent(Token),
    UnsupportedPseudoClassOrElement(Str),
    NoQualifiedNameInAttributeSelector(Token),
    UnexpectedTokenInAttributeSelector(Token),
    UnexpectedSelectorAfterPseudoElement(Token),
    InvalidQualNameInAttr(Token),
    ExpectedBarInAttr(Token),
    EmptySelector,
    DanglingCombinator,
    InvalidPseudoClassBeforeWebkitScrollbar,
    InvalidPseudoClassAfterWebkitScrollbar,
    InvalidPseudoClassAfterPseudoElement,
    MissingNestingSelector,
    MissingNestingPrefix,
    ExpectedNamespace(Str),
    BadValueInAttr(Token),
    ExplicitNamespaceUnexpectedToken(Token),
    UnexpectedIdent(Str),
    AmbiguousCssModuleClass(Str),
}

impl SelectorParseErrorKind {
    pub(crate) fn into_default_parser_error(self) -> css::ParserError {
        css::ParserError::selector_error(self.into_selector_error())
    }

    pub(crate) fn into_selector_error(self) -> css::SelectorError {
        // `error.rs::SelectorError` variants are snake_case
        // (`#[allow(non_camel_case_types)]`).
        use SelectorParseErrorKind as K;
        use css::SelectorError as S;
        match self {
            K::InvalidState => S::invalid_state,
            K::ClassNeedsIdent(token) => S::class_needs_ident(token),
            K::PseudoElementExpectedIdent(token) => S::pseudo_element_expected_ident(token),
            K::UnsupportedPseudoClassOrElement(name) => {
                S::unsupported_pseudo_class_or_element(name)
            }
            K::NoQualifiedNameInAttributeSelector(token) => {
                S::no_qualified_name_in_attribute_selector(token)
            }
            K::UnexpectedTokenInAttributeSelector(token) => {
                S::unexpected_token_in_attribute_selector(token)
            }
            K::InvalidQualNameInAttr(token) => S::invalid_qual_name_in_attr(token),
            K::ExpectedBarInAttr(token) => S::expected_bar_in_attr(token),
            K::EmptySelector => S::empty_selector,
            K::DanglingCombinator => S::dangling_combinator,
            K::InvalidPseudoClassBeforeWebkitScrollbar => {
                S::invalid_pseudo_class_before_webkit_scrollbar
            }
            K::InvalidPseudoClassAfterWebkitScrollbar => {
                S::invalid_pseudo_class_after_webkit_scrollbar
            }
            K::InvalidPseudoClassAfterPseudoElement => S::invalid_pseudo_class_after_pseudo_element,
            K::MissingNestingSelector => S::missing_nesting_selector,
            K::MissingNestingPrefix => S::missing_nesting_prefix,
            K::ExpectedNamespace(name) => S::expected_namespace(name),
            K::BadValueInAttr(token) => S::bad_value_in_attr(token),
            K::ExplicitNamespaceUnexpectedToken(token) => {
                S::explicit_namespace_unexpected_token(token)
            }
            K::UnexpectedIdent(ident) => S::unexpected_ident(ident),
            K::UnexpectedSelectorAfterPseudoElement(tok) => {
                S::unexpected_selector_after_pseudo_element(tok)
            }
            K::AmbiguousCssModuleClass(name) => S::ambiguous_css_module_class(name),
        }
    }
}

// `SourceLocation::new_custom_error` accepts `impl IntoParserError`.
impl css::IntoParserError for SelectorParseErrorKind {
    fn into_parser_error(self) -> css::ParserError {
        self.into_default_parser_error()
    }
}

pub(crate) enum SimpleSelectorParseResult<Impl: SelectorImpl> {
    SimpleSelector(GenericComponent<Impl>),
    PseudoElement(Impl::PseudoElement),
    SlottedPseudo(GenericSelector<Impl>),
    // todo_stuff.think_mem_mgmt
    PartPseudo(Box<[Impl::Identifier]>),
}

/// A pseudo element.
// See PseudoClass — `PartialEq` derive dropped (Box<Selector>/TokenList).
#[derive(Clone, CssEql, CssHash)]
pub enum PseudoElement {
    /// The [::after](https://drafts.csswg.org/css-pseudo-4/#selectordef-after) pseudo element.
    After,
    /// The [::before](https://drafts.csswg.org/css-pseudo-4/#selectordef-before) pseudo element.
    Before,
    /// The [::first-line](https://drafts.csswg.org/css-pseudo-4/#first-line-pseudo) pseudo element.
    FirstLine,
    /// The [::first-letter](https://drafts.csswg.org/css-pseudo-4/#first-letter-pseudo) pseudo element.
    FirstLetter,
    /// The [::selection](https://drafts.csswg.org/css-pseudo-4/#selectordef-selection) pseudo element.
    Selection(css::VendorPrefix),
    /// The [::placeholder](https://drafts.csswg.org/css-pseudo-4/#placeholder-pseudo) pseudo element.
    Placeholder(css::VendorPrefix),
    /// The [::marker](https://drafts.csswg.org/css-pseudo-4/#marker-pseudo) pseudo element.
    Marker,
    /// The [::backdrop](https://fullscreen.spec.whatwg.org/#::backdrop-pseudo-element) pseudo element.
    Backdrop(css::VendorPrefix),
    /// The [::file-selector-button](https://drafts.csswg.org/css-pseudo-4/#file-selector-button-pseudo) pseudo element.
    FileSelectorButton(css::VendorPrefix),
    /// A [webkit scrollbar](https://webkit.org/blog/363/styling-scrollbars/) pseudo element.
    WebkitScrollbar(WebKitScrollbarPseudoElement),
    /// The [::cue](https://w3c.github.io/webvtt/#the-cue-pseudo-element) pseudo element.
    Cue,
    /// The [::cue-region](https://w3c.github.io/webvtt/#the-cue-region-pseudo-element) pseudo element.
    CueRegion,
    /// The [::cue()](https://w3c.github.io/webvtt/#cue-selector) functional pseudo element.
    CueFunction {
        /// The selector argument.
        selector: Box<Selector>,
    },
    /// The [::cue-region()](https://w3c.github.io/webvtt/#cue-region-selector) functional pseudo element.
    CueRegionFunction {
        /// The selector argument.
        selector: Box<Selector>,
    },
    /// The [::view-transition](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#view-transition) pseudo element.
    ViewTransition,
    /// The [::view-transition-group()](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#view-transition-group-pt-name-selector) functional pseudo element.
    ViewTransitionGroup {
        /// A part selector.
        part: ViewTransitionPartSelector,
    },
    /// The [::view-transition-image-pair()](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#view-transition-image-pair-pt-name-selector) functional pseudo element.
    ViewTransitionImagePair {
        /// A part selector.
        part: ViewTransitionPartSelector,
    },
    /// The [::view-transition-old()](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#view-transition-old-pt-name-selector) functional pseudo element.
    ViewTransitionOld {
        /// A part selector.
        part: ViewTransitionPartSelector,
    },
    /// The [::view-transition-new()](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#view-transition-new-pt-name-selector) functional pseudo element.
    ViewTransitionNew {
        /// A part selector.
        part: ViewTransitionPartSelector,
    },
    /// The [::view-transition-group-children()](https://drafts.csswg.org/css-view-transitions-2/#::view-transition-group-children) functional pseudo element.
    ViewTransitionGroupChildren {
        /// A part selector.
        part: ViewTransitionPartSelector,
    },
    /// The [::details-content](https://drafts.csswg.org/css-pseudo-4/#details-content-pseudo) pseudo element.
    DetailsContent,
    /// The [::picker-icon](https://drafts.csswg.org/css-forms-1/#picker-icon-pseudo) pseudo element.
    PickerIcon,
    /// The [::checkmark](https://drafts.csswg.org/css-forms-1/#checkmark-pseudo) pseudo element.
    Checkmark,
    /// The [::picker()](https://drafts.csswg.org/css-forms-1/#picker-pseudo) functional pseudo element.
    PickerFunction {
        /// The identifier argument, e.g. `select` in `::picker(select)`.
        identifier: Ident,
    },
    /// An unknown pseudo element.
    Custom {
        /// The name of the pseudo element.
        name: Str,
    },
    /// An unknown functional pseudo element.
    CustomFunction {
        /// The name of the pseudo element.
        name: Str,
        /// The arguments of the pseudo element function.
        arguments: TokenList,
    },
}

impl PseudoElement {
    pub(crate) fn is_equivalent(&self, other: &PseudoElement) -> bool {
        use PseudoElement as PE;
        if matches!(self, PE::Selection(_)) && matches!(other, PE::Selection(_)) {
            return true;
        }
        if matches!(self, PE::Placeholder(_)) && matches!(other, PE::Placeholder(_)) {
            return true;
        }
        if matches!(self, PE::Backdrop(_)) && matches!(other, PE::Backdrop(_)) {
            return true;
        }
        if matches!(self, PE::FileSelectorButton(_)) && matches!(other, PE::FileSelectorButton(_)) {
            return true;
        }
        self.eql(other)
    }

    // eql / hash — provided by `#[derive(CssEql, CssHash)]`.
    pub(crate) fn deep_clone(&self) -> Self {
        self.clone()
    }

    pub(crate) fn get_necessary_prefixes(
        &mut self,
        targets: &css::targets::Targets,
    ) -> css::VendorPrefix {
        use PseudoElement as PE;
        use css::prefixes::Feature as F;
        let (p, feature): (&mut css::VendorPrefix, F) = match self {
            PE::Selection(p) => (p, F::PseudoElementSelection),
            PE::Placeholder(p) => (p, F::PseudoElementPlaceholder),
            PE::Backdrop(p) => (p, F::PseudoElementBackdrop),
            PE::FileSelectorButton(p) => (p, F::PseudoElementFileSelectorButton),
            _ => return css::VendorPrefix::empty(),
        };
        *p = targets.prefixes(*p, feature);
        *p
    }

    pub(crate) fn get_prefix(&self) -> css::VendorPrefix {
        use PseudoElement as PE;
        match self {
            PE::Selection(p) | PE::Placeholder(p) | PE::Backdrop(p) | PE::FileSelectorButton(p) => {
                *p
            }
            _ => css::VendorPrefix::empty(),
        }
    }

    pub(crate) fn valid_after_slotted(&self) -> bool {
        use PseudoElement as PE;
        matches!(
            self,
            PE::Before | PE::After | PE::Marker | PE::Placeholder(_) | PE::FileSelectorButton(_)
        )
    }

    pub(crate) fn is_unknown(&self) -> bool {
        matches!(
            self,
            PseudoElement::Custom { .. } | PseudoElement::CustomFunction { .. }
        )
    }

    pub(crate) fn accepts_state_pseudo_classes(&self) -> bool {
        let _ = self;
        // Be lienient.
        true
    }

    pub(crate) fn is_webkit_scrollbar(&self) -> bool {
        matches!(self, PseudoElement::WebkitScrollbar(_))
    }

    pub(crate) fn is_view_transition(&self) -> bool {
        use PseudoElement as PE;
        matches!(
            self,
            PE::ViewTransitionGroup { .. }
                | PE::ViewTransitionImagePair { .. }
                | PE::ViewTransitionNew { .. }
                | PE::ViewTransitionOld { .. }
                | PE::ViewTransitionGroupChildren { .. }
        )
    }

    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        // See PseudoClass::to_css — write directly to `dest`; no caller makes
        // length-dependent minification decisions here.
        serialize::serialize_pseudo_element(self, dest, None)
    }
}

impl fmt::Display for PseudoElement {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::After => "after",
            Self::Before => "before",
            Self::FirstLine => "first_line",
            Self::FirstLetter => "first_letter",
            Self::Selection(_) => "selection",
            Self::Placeholder(_) => "placeholder",
            Self::Marker => "marker",
            Self::Backdrop(_) => "backdrop",
            Self::FileSelectorButton(_) => "file_selector_button",
            Self::WebkitScrollbar(_) => "webkit_scrollbar",
            Self::Cue => "cue",
            Self::CueRegion => "cue_region",
            Self::CueFunction { .. } => "cue_function",
            Self::CueRegionFunction { .. } => "cue_region_function",
            Self::ViewTransition => "view_transition",
            Self::ViewTransitionGroup { .. } => "view_transition_group",
            Self::ViewTransitionImagePair { .. } => "view_transition_image_pair",
            Self::ViewTransitionOld { .. } => "view_transition_old",
            Self::ViewTransitionNew { .. } => "view_transition_new",
            Self::ViewTransitionGroupChildren { .. } => "view_transition_group_children",
            Self::DetailsContent => "details_content",
            Self::PickerIcon => "picker_icon",
            Self::Checkmark => "checkmark",
            Self::PickerFunction { .. } => "picker_function",
            Self::Custom { .. } => "custom",
            Self::CustomFunction { .. } => "custom_function",
        })
    }
}

/// An enum for the different types of :nth- pseudoclasses
#[derive(Clone, Copy, PartialEq, Eq, Hash)]
pub enum NthType {
    Child,
    LastChild,
    OnlyChild,
    OfType,
    LastOfType,
    OnlyOfType,
    Col,
    LastCol,
}

impl NthType {
    pub(crate) fn allows_of_selector(self) -> bool {
        self == NthType::Child || self == NthType::LastChild
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// parse_type_selector / parse_one_simple_selector / parse_attribute_selector
// ─────────────────────────────────────────────────────────────────────────────

/// * `Err(())`: Invalid selector, abort
/// * `Ok(false)`: Not a type selector, could be something else. `input` was not consumed.
/// * `Ok(true)`: Length 0 (`*|*`), 1 (`*|E` or `ns|*`) or 2 (`|E` or `ns|E`)
pub(crate) fn parse_type_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: SelectorParsingState,
    sink: &mut SelectorBuilder<Impl>,
) -> CResult<bool> {
    let result = match parse_qualified_name::<Impl>(parser, input, false) {
        Ok(v) => v,
        Err(e) => {
            if matches!(
                e.kind,
                css::ParseErrorKind::basic(css::BasicParseErrorKind::end_of_input)
            ) {
                return Ok(false);
            }
            return Err(e);
        }
    };

    let (namespace, local_name) = match result {
        OptionalQName::None(_) => return Ok(false),
        OptionalQName::Some(ns, ln) => (ns, ln),
    };

    if state.after_any_pseudo() {
        return Err(input
            .new_custom_error(SelectorParseErrorKind::InvalidState.into_default_parser_error()));
    }

    match namespace {
        QNamePrefix::ImplicitAnyNamespace => {}
        QNamePrefix::ImplicitDefaultNamespace(url) => {
            sink.push_simple_selector(GenericComponent::DefaultNamespace(url));
        }
        QNamePrefix::ExplicitNamespace(prefix, url) => {
            let component: GenericComponent<Impl> = 'component: {
                if let Some(default_url) = parser.default_namespace() {
                    if url == default_url {
                        break 'component GenericComponent::DefaultNamespace(url);
                    }
                }
                GenericComponent::Namespace { prefix, url }
            };
            sink.push_simple_selector(component);
        }
        QNamePrefix::ExplicitNoNamespace => {
            sink.push_simple_selector(GenericComponent::ExplicitNoNamespace);
        }
        QNamePrefix::ExplicitAnyNamespace => {
            // Element type selectors that have no namespace
            // component (no namespace separator) represent elements
            // without regard to the element's namespace (equivalent
            // to "*|") unless a default namespace has been declared
            // for namespaced selectors (e.g. in CSS, in the style
            // sheet). If a default namespace has been declared,
            // such selectors will represent only elements in the
            // default namespace.
            // -- Selectors § 6.1.1
            // So we'll have this act the same as the
            // QNamePrefix::ImplicitAnyNamespace case.
            // For lightning css this logic was removed, should be handled when matching.
            sink.push_simple_selector(GenericComponent::ExplicitAnyNamespace);
        }
        QNamePrefix::ImplicitNoNamespace => {
            unreachable!("Should not be returned with in_attr_selector = false");
        }
    }

    if let Some(name) = local_name {
        sink.push_simple_selector(GenericComponent::LocalName(LocalName {
            lower_name: {
                // PERF: check if it's already lowercase
                Ident {
                    v: arena_lowercase(input.arena(), name),
                }
            },
            name: Ident {
                v: std::ptr::from_ref::<[u8]>(name),
            },
        }));
    } else {
        sink.push_simple_selector(GenericComponent::ExplicitUniversalType);
    }

    Ok(true)
}

/// Parse a simple selector other than a type selector.
///
/// * `Err(())`: Invalid selector, abort
/// * `Ok(None)`: Not a simple selector, could be something else. `input` was not consumed.
/// * `Ok(Some(_))`: Parsed a simple selector or pseudo-element
pub(crate) fn parse_one_simple_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
) -> CResult<Option<SimpleSelectorParseResult<Impl>>> {
    type S<Impl> = SimpleSelectorParseResult<Impl>;

    let start = input.state();
    let token_location = input.current_source_location();
    let token_loc = input.position();
    let token = match input.next_including_whitespace() {
        Ok(v) => *v,
        Err(_) => {
            input.reset(&start);
            return Ok(None);
        }
    };

    match token {
        Token::IdHash(id) => {
            if state.after_any_pseudo() {
                return Err(token_location.new_custom_error(
                    SelectorParseErrorKind::UnexpectedSelectorAfterPseudoElement(Token::IdHash(id))
                        .into_default_parser_error(),
                ));
            }
            let component = GenericComponent::Id(parser.new_local_identifier(
                input,
                css::CssRefTag::ID,
                id,
                token_loc,
            ));
            return Ok(Some(S::SimpleSelector(component)));
        }
        Token::OpenSquare => {
            if state.after_any_pseudo() {
                return Err(token_location.new_custom_error(
                    SelectorParseErrorKind::UnexpectedSelectorAfterPseudoElement(Token::OpenSquare)
                        .into_default_parser_error(),
                ));
            }
            let attr = input.parse_nested_block(|input2: &mut CssParser| {
                parse_attribute_selector::<Impl>(parser, input2)
            })?;
            return Ok(Some(S::SimpleSelector(attr)));
        }
        Token::Colon => {
            let location = input.current_source_location();
            let (is_single_colon, next_token): (bool, Token) =
                match *input.next_including_whitespace()? {
                    Token::Colon => (false, *input.next_including_whitespace()?),
                    t => (true, t),
                };
            let (name, is_functional): (Str, bool) = match next_token {
                Token::Ident(name) => (name, false),
                Token::Function(name) => (name, true),
                t => {
                    let e = SelectorParseErrorKind::PseudoElementExpectedIdent(t);
                    return Err(input.new_custom_error(e.into_default_parser_error()));
                }
            };
            let is_pseudo_element = !is_single_colon || is_css2_pseudo_element(name);
            if is_pseudo_element {
                if !state.allows_pseudos() {
                    return Err(input.new_custom_error(
                        SelectorParseErrorKind::InvalidState.into_default_parser_error(),
                    ));
                }
                let pseudo_element: Impl::PseudoElement = if is_functional {
                    if parser.parse_part()
                        && strings::eql_case_insensitive_ascii_check_length(name, b"part")
                    {
                        if !state.allows_part() {
                            return Err(input.new_custom_error(
                                SelectorParseErrorKind::InvalidState.into_default_parser_error(),
                            ));
                        }

                        let names = input.parse_nested_block(
                            |input2: &mut CssParser| -> CResult<Box<[Impl::Identifier]>> {
                                // todo_stuff.think_about_mem_mgmt
                                let mut result: Vec<Impl::Identifier> = Vec::with_capacity(1);

                                result.push(Ident {
                                    v: input2.expect_ident()?,
                                });

                                while !input2.is_exhausted() {
                                    result.push(Ident {
                                        v: input2.expect_ident()?,
                                    });
                                }

                                Ok(result.into_boxed_slice())
                            },
                        )?;

                        return Ok(Some(S::PartPseudo(names)));
                    }

                    if parser.parse_slotted()
                        && strings::eql_case_insensitive_ascii_check_length(name, b"slotted")
                    {
                        if !state.allows_slotted() {
                            return Err(input.new_custom_error(
                                SelectorParseErrorKind::InvalidState.into_default_parser_error(),
                            ));
                        }
                        let selector = input.parse_nested_block(|input2: &mut CssParser| {
                            parse_inner_compound_selector::<Impl>(parser, input2, state)
                        })?;
                        return Ok(Some(S::SlottedPseudo(selector)));
                    }

                    input.parse_nested_block(|i: &mut CssParser| {
                        parser.parse_functional_pseudo_element(name, i)
                    })?
                } else {
                    parser.parse_pseudo_element(location, name)?
                };

                if state.contains(SelectorParsingState::AFTER_SLOTTED)
                    && pseudo_element.valid_after_slotted()
                {
                    return Ok(Some(S::PseudoElement(pseudo_element)));
                }

                return Ok(Some(S::PseudoElement(pseudo_element)));
            } else {
                let pseudo_class: GenericComponent<Impl> = if is_functional {
                    input.parse_nested_block(|input2: &mut CssParser| {
                        parse_functional_pseudo_class::<Impl>(parser, input2, name, state)
                    })?
                } else {
                    parse_simple_pseudo_class::<Impl>(parser, location, name, *state)?
                };
                return Ok(Some(S::SimpleSelector(pseudo_class)));
            }
        }
        Token::Delim(d) => match u8::try_from(d).ok() {
            Some(b'.') => {
                if state.after_any_pseudo() {
                    return Err(token_location.new_custom_error(
                        SelectorParseErrorKind::UnexpectedSelectorAfterPseudoElement(Token::Delim(
                            b'.' as u32,
                        ))
                        .into_default_parser_error(),
                    ));
                }
                let location = input.current_source_location();
                let class = match *input.next_including_whitespace()? {
                    Token::Ident(class) => class,
                    t => {
                        let e = SelectorParseErrorKind::ClassNeedsIdent(t);
                        return Err(location.new_custom_error(e.into_default_parser_error()));
                    }
                };
                return Ok(Some(S::SimpleSelector(GenericComponent::Class(
                    parser.new_local_identifier(input, css::CssRefTag::CLASS, class, token_loc),
                ))));
            }
            Some(b'&') => {
                if parser.is_nesting_allowed() {
                    state.insert(SelectorParsingState::AFTER_NESTING);
                    return Ok(Some(S::SimpleSelector(GenericComponent::Nesting)));
                }
            }
            _ => {}
        },
        _ => {}
    }

    input.reset(&start);
    Ok(None)
}

pub(crate) fn parse_attribute_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
) -> CResult<GenericComponent<Impl>> {
    type N<Impl> = attrs::NamespaceConstraint<attrs::NamespaceUrl<Impl>>;

    let (namespace, local_name): (Option<N<Impl>>, Str) = 'brk: {
        input.skip_whitespace();

        let qname = parse_qualified_name::<Impl>(parser, input, true)?;
        match qname {
            OptionalQName::None(t) => {
                return Err(input.new_custom_error(
                    SelectorParseErrorKind::NoQualifiedNameInAttributeSelector(t)
                        .into_default_parser_error(),
                ));
            }
            OptionalQName::Some(ns, ln) => {
                let ln = ln.unwrap_or_else(|| unreachable!());
                break 'brk (
                    match ns {
                        QNamePrefix::ImplicitNoNamespace | QNamePrefix::ExplicitNoNamespace => None,
                        QNamePrefix::ExplicitNamespace(prefix, url) => {
                            Some(attrs::NamespaceConstraint::Specific(attrs::NamespaceUrl {
                                prefix,
                                url,
                            }))
                        }
                        QNamePrefix::ExplicitAnyNamespace => Some(attrs::NamespaceConstraint::Any),
                        QNamePrefix::ImplicitAnyNamespace
                        | QNamePrefix::ImplicitDefaultNamespace(_) => {
                            unreachable!("Not returned with in_attr_selector = true");
                        }
                    },
                    ln,
                );
            }
        }
    };

    let location = input.current_source_location();
    let operator: attrs::AttrSelectorOperator = 'operator: {
        let tok = match input.next() {
            Ok(v) => *v,
            Err(_) => {
                // [foo]
                let local_name_lower: *const [u8] = arena_lowercase(input.arena(), local_name);
                if let Some(ns) = namespace {
                    let x = attrs::AttrSelectorWithOptionalNamespace::<Impl> {
                        namespace: Some(ns),
                        local_name: Ident { v: local_name },
                        local_name_lower: Ident {
                            v: local_name_lower,
                        },
                        never_matches: false,
                        operation: attrs::ParsedAttrSelectorOperation::Exists,
                    };
                    return Ok(GenericComponent::AttributeOther(Box::new(x)));
                } else {
                    return Ok(GenericComponent::AttributeInNoNamespaceExists {
                        local_name: Ident { v: local_name },
                        local_name_lower: Ident {
                            v: local_name_lower,
                        },
                    });
                }
            }
        };

        match tok {
            // [foo=bar]
            Token::Delim(d) if d == b'=' as u32 => {
                break 'operator attrs::AttrSelectorOperator::Equal;
            }
            // [foo~=bar]
            Token::IncludeMatch => break 'operator attrs::AttrSelectorOperator::Includes,
            // [foo|=bar]
            Token::DashMatch => break 'operator attrs::AttrSelectorOperator::DashMatch,
            // [foo^=bar]
            Token::PrefixMatch => break 'operator attrs::AttrSelectorOperator::Prefix,
            // [foo*=bar]
            Token::SubstringMatch => break 'operator attrs::AttrSelectorOperator::Substring,
            // [foo$=bar]
            Token::SuffixMatch => break 'operator attrs::AttrSelectorOperator::Suffix,
            _ => {}
        }
        return Err(location.new_custom_error(
            SelectorParseErrorKind::UnexpectedTokenInAttributeSelector(tok)
                .into_default_parser_error(),
        ));
    };

    // `expect_ident_or_string` returns `&'_ [u8]` (lifetime-tied to
    // `&mut *input`); `parse_attribute_flags(input)` below needs `input` again.
    // Clone the token so the borrow is released before we re-borrow.
    let value_str: Str = {
        let value_loc = input.current_source_location();
        let tok = *input.next()?;
        match tok {
            Token::Ident(v) | Token::QuotedString(v) => v,
            t => {
                return Err(value_loc.new_custom_error(
                    SelectorParseErrorKind::BadValueInAttr(t).into_default_parser_error(),
                ));
            }
        }
    };
    let never_matches = match operator {
        attrs::AttrSelectorOperator::Equal | attrs::AttrSelectorOperator::DashMatch => false,
        attrs::AttrSelectorOperator::Includes => {
            value_str.is_empty() || strings::index_of_any(value_str, SELECTOR_WHITESPACE).is_some()
        }
        attrs::AttrSelectorOperator::Prefix
        | attrs::AttrSelectorOperator::Substring
        | attrs::AttrSelectorOperator::Suffix => value_str.is_empty(),
    };

    let attribute_flags = parse_attribute_flags(input)?;

    let value: Impl::AttrValue = std::ptr::from_ref::<[u8]>(value_str);
    let (local_name_lower, local_name_is_ascii_lowercase): (Impl::LocalName, bool) = 'brk: {
        let first_uppercase = 'a: {
            for (i, &b) in local_name.iter().enumerate() {
                if b >= b'A' && b <= b'Z' {
                    break 'a Some(i);
                }
            }
            None
        };
        if let Some(first_uppercase) = first_uppercase {
            let str_ = &local_name[first_uppercase..];
            let lowered: *const [u8] = arena_lowercase(input.arena(), str_);
            break 'brk (Ident { v: lowered }, false);
        } else {
            break 'brk (
                Ident {
                    v: std::ptr::from_ref::<[u8]>(local_name),
                },
                true,
            );
        }
    };
    let case_sensitivity: attrs::ParsedCaseSensitivity =
        attribute_flags.to_case_sensitivity(local_name_lower.v(), namespace.is_some());
    if namespace.is_some() && !local_name_is_ascii_lowercase {
        Ok(GenericComponent::AttributeOther(Box::new(
            attrs::AttrSelectorWithOptionalNamespace::<Impl> {
                namespace,
                local_name: Ident {
                    v: std::ptr::from_ref::<[u8]>(local_name),
                },
                local_name_lower,
                never_matches,
                operation: attrs::ParsedAttrSelectorOperation::WithValue {
                    operator,
                    case_sensitivity,
                    expected_value: value,
                },
            },
        )))
    } else {
        Ok(GenericComponent::AttributeInNoNamespace {
            local_name: Ident { v: local_name },
            operator,
            value,
            case_sensitivity,
            never_matches,
        })
    }
}

/// Returns whether the name corresponds to a CSS2 pseudo-element that
/// can be specified with the single colon syntax (in addition to the
/// double-colon syntax, which can be used for all pseudo-elements).
pub(crate) fn is_css2_pseudo_element(name: &[u8]) -> bool {
    // ** Do not add to this list! **
    crate::match_ignore_ascii_case! { name, {
        b"before" | b"after" | b"first-line" | b"first-letter" => true,
        _ => false,
    }}
}

/// Parses one compound selector suitable for nested stuff like :-moz-any, etc.
pub(crate) fn parse_inner_compound_selector<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
) -> CResult<GenericSelector<Impl>> {
    let mut child_state = {
        let mut child_state = *state;
        child_state.insert(SelectorParsingState::DISALLOW_PSEUDOS);
        child_state.insert(SelectorParsingState::DISALLOW_COMBINATORS);
        child_state
    };
    let result = parse_selector::<Impl>(parser, input, &mut child_state, NestingRequirement::None)?;
    if child_state.contains(SelectorParsingState::AFTER_NESTING) {
        state.insert(SelectorParsingState::AFTER_NESTING);
    }
    Ok(result)
}

pub(crate) fn parse_functional_pseudo_class<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    name: Str,
    state: &mut SelectorParsingState,
) -> CResult<GenericComponent<Impl>> {
    crate::match_ignore_ascii_case! { name, {
        b"nth-child" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::Child),
        b"nth-of-type" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::OfType),
        b"nth-last-child" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::LastChild),
        b"nth-last-of-type" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::LastOfType),
        b"nth-col" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::Col),
        b"nth-last-col" => return parse_nth_pseudo_class::<Impl>(parser, input, *state, NthType::LastCol),
        b"is" => if parser.parse_is_and_where() {
            return parse_is_or_where::<Impl, _>(parser, input, state, |s| GenericComponent::convert_helper_is(s));
        },
        b"where" => if parser.parse_is_and_where() {
            return parse_is_or_where::<Impl, _>(parser, input, state, |s| GenericComponent::convert_helper_where(s));
        },
        b"has" => return parse_has::<Impl>(parser, input, state),
        b"host" => {
            if !state.allows_tree_structural_pseudo_classes() {
                return Err(input.new_custom_error(
                    SelectorParseErrorKind::InvalidState.into_default_parser_error(),
                ));
            }
            return Ok(GenericComponent::Host(Some(
                parse_inner_compound_selector::<Impl>(parser, input, state)?,
            )));
        },
        b"not" => return parse_negation::<Impl>(parser, input, state),
        _ => {},
    } }

    if let Some(prefix) = parser.parse_any_prefix(name) {
        return parse_is_or_where::<Impl, _>(parser, input, state, move |s| {
            GenericComponent::convert_helper_any(s, prefix)
        });
    }

    if !state.allows_custom_functional_pseudo_classes() {
        return Err(input
            .new_custom_error(SelectorParseErrorKind::InvalidState.into_default_parser_error()));
    }

    let result = parser.parse_non_ts_functional_pseudo_class(name, input)?;

    Ok(GenericComponent::NonTsPseudoClass(result))
}

pub(crate) fn parse_simple_pseudo_class<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    location: css::SourceLocation,
    name: Str,
    state: SelectorParsingState,
) -> CResult<GenericComponent<Impl>> {
    if !state.allows_non_functional_pseudo_classes() {
        return Err(location
            .new_custom_error(SelectorParseErrorKind::InvalidState.into_default_parser_error()));
    }

    if state.allows_tree_structural_pseudo_classes() {
        crate::match_ignore_ascii_case! { name, {
            b"first-child" => return Ok(GenericComponent::Nth(NthSelectorData::first(false))),
            b"last-child" => return Ok(GenericComponent::Nth(NthSelectorData::last(false))),
            b"only-child" => return Ok(GenericComponent::Nth(NthSelectorData::only(false))),
            b"root" => return Ok(GenericComponent::Root),
            b"empty" => return Ok(GenericComponent::Empty),
            b"scope" => return Ok(GenericComponent::Scope),
            b"host" => if parser.parse_host() {
                return Ok(GenericComponent::Host(None));
            },
            b"first-of-type" => return Ok(GenericComponent::Nth(NthSelectorData::first(true))),
            b"last-of-type" => return Ok(GenericComponent::Nth(NthSelectorData::last(true))),
            b"only-of-type" => return Ok(GenericComponent::Nth(NthSelectorData::only(true))),
            _ => {},
        } }
    }

    // The view-transition pseudo elements accept the :only-child pseudo class.
    // https://w3c.github.io/csswg-drafts/css-view-transitions-1/#pseudo-root
    if state.contains(SelectorParsingState::AFTER_VIEW_TRANSITION) {
        if strings::eql_case_insensitive_ascii_check_length(name, b"only-child") {
            return Ok(GenericComponent::Nth(NthSelectorData::only(false)));
        }
    }

    let pseudo_class = parser.parse_non_ts_pseudo_class(location, name)?;
    if state.contains(SelectorParsingState::AFTER_WEBKIT_SCROLLBAR) {
        if !pseudo_class.is_valid_after_webkit_scrollbar() {
            return Err(location.new_custom_error(
                SelectorParseErrorKind::InvalidPseudoClassAfterWebkitScrollbar
                    .into_default_parser_error(),
            ));
        }
    } else if state.contains(SelectorParsingState::AFTER_PSEUDO_ELEMENT) {
        if !pseudo_class.is_user_action_state() {
            return Err(location.new_custom_error(
                SelectorParseErrorKind::InvalidPseudoClassAfterPseudoElement
                    .into_default_parser_error(),
            ));
        }
    } else if !pseudo_class.is_valid_before_webkit_scrollbar() {
        return Err(location.new_custom_error(
            SelectorParseErrorKind::InvalidPseudoClassBeforeWebkitScrollbar
                .into_default_parser_error(),
        ));
    }

    Ok(GenericComponent::NonTsPseudoClass(pseudo_class))
}

pub(crate) fn parse_nth_pseudo_class<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: SelectorParsingState,
    ty: NthType,
) -> CResult<GenericComponent<Impl>> {
    if !state.allows_tree_structural_pseudo_classes() {
        return Err(input
            .new_custom_error(SelectorParseErrorKind::InvalidState.into_default_parser_error()));
    }

    let (a, b) = css::nth::parse_nth(input)?;
    let nth_data = NthSelectorData {
        ty,
        is_function: true,
        a,
        b,
    };

    if !ty.allows_of_selector() {
        return Ok(GenericComponent::Nth(nth_data));
    }

    // Try to parse "of <selector-list>".
    if input.try_parse(|i| i.expect_ident_matching(b"of")).is_err() {
        return Ok(GenericComponent::Nth(nth_data));
    }

    // Whitespace between "of" and the selector list is optional
    // https://github.com/w3c/csswg-drafts/issues/8285
    let mut child_state = {
        let mut s = state;
        s.insert(SelectorParsingState::SKIP_DEFAULT_NAMESPACE);
        s.insert(SelectorParsingState::DISALLOW_PSEUDOS);
        s
    };

    // The of-list is a <complex-real-selector-list>, which is not forgiving: one
    // invalid selector invalidates the whole pseudo-class. Forgiving recovery would
    // leave the list empty, which has no valid serialization (`:nth-child(2n of )`).
    let selectors = GenericSelectorList::<Impl>::parse_with_state(
        parser,
        input,
        &mut child_state,
        ParseErrorRecovery::DiscardList,
        NestingRequirement::None,
    )?;

    Ok(GenericComponent::NthOf(NthOfSelectorData {
        data: nth_data,
        selectors: selectors.into_boxed_selectors(),
    }))
}

/// `func` must take `Box<[GenericSelector<Impl>]>` (plus any captured extras) and
/// return a `GenericComponent<Impl>`.
pub(crate) fn parse_is_or_where<Impl: BunSelectorImpl, F>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
    func: F,
) -> CResult<GenericComponent<Impl>>
where
    F: FnOnce(Box<[GenericSelector<Impl>]>) -> GenericComponent<Impl>,
{
    debug_assert!(parser.parse_is_and_where());
    // https://drafts.csswg.org/selectors/#matches-pseudo:
    //
    //     Pseudo-elements cannot be represented by the matches-any
    //     pseudo-class; they are not valid within :is().
    //
    let mut child_state = {
        let mut child_state = *state;
        child_state.insert(SelectorParsingState::SKIP_DEFAULT_NAMESPACE);
        child_state.insert(SelectorParsingState::DISALLOW_PSEUDOS);
        child_state
    };

    let inner = GenericSelectorList::<Impl>::parse_with_state(
        parser,
        input,
        &mut child_state,
        parser.is_and_where_error_recovery(),
        NestingRequirement::None,
    )?;
    if child_state.contains(SelectorParsingState::AFTER_NESTING) {
        state.insert(SelectorParsingState::AFTER_NESTING);
    }

    let selector_slice = inner.into_boxed_selectors();

    // The closure captures extra args directly (e.g. `prefix` for `:any()`).
    let result = func(selector_slice);

    Ok(result)
}

pub(crate) fn parse_has<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
) -> CResult<GenericComponent<Impl>> {
    let mut child_state = *state;
    // Since https://github.com/w3c/csswg-drafts/issues/7676, :has() takes a
    // <relative-selector-list>, which is not forgiving. Forgiving recovery would
    // leave the list empty, which has no valid serialization (`:has()`).
    let inner = GenericSelectorList::<Impl>::parse_relative_with_state(
        parser,
        input,
        &mut child_state,
        ParseErrorRecovery::DiscardList,
        NestingRequirement::None,
    )?;

    if child_state.contains(SelectorParsingState::AFTER_NESTING) {
        state.insert(SelectorParsingState::AFTER_NESTING);
    }
    Ok(GenericComponent::Has(inner.into_boxed_selectors()))
}

/// Level 3: Parse **one** simple_selector.  (Though we might insert a second
/// implied "<defaultns>|*" type selector.)
pub(crate) fn parse_negation<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    state: &mut SelectorParsingState,
) -> CResult<GenericComponent<Impl>> {
    let mut child_state = *state;
    child_state.insert(SelectorParsingState::SKIP_DEFAULT_NAMESPACE);
    child_state.insert(SelectorParsingState::DISALLOW_PSEUDOS);

    let list = GenericSelectorList::<Impl>::parse_with_state(
        parser,
        input,
        &mut child_state,
        ParseErrorRecovery::DiscardList,
        NestingRequirement::None,
    )?;

    if child_state.contains(SelectorParsingState::AFTER_NESTING) {
        state.insert(SelectorParsingState::AFTER_NESTING);
    }

    Ok(GenericComponent::Negation(list.into_boxed_selectors()))
}

pub(crate) enum OptionalQName<Impl: SelectorImpl> {
    Some(QNamePrefix<Impl>, Option<Str>),
    None(Token),
}

pub(crate) enum QNamePrefix<Impl: SelectorImpl> {
    ImplicitNoNamespace,                          // `foo` in attr selectors
    ImplicitAnyNamespace,                         // `foo` in type selectors, without a default ns
    ImplicitDefaultNamespace(Impl::NamespaceUrl), // `foo` in type selectors, with a default ns
    ExplicitNoNamespace,                          // `|foo`
    ExplicitAnyNamespace,                         // `*|foo`
    ExplicitNamespace(Impl::NamespacePrefix, Impl::NamespaceUrl), // `prefix|foo`
}

/// * `Err(())`: Invalid selector, abort
/// * `Ok(None(token))`: Not a simple selector, could be something else. `input` was not consumed,
///                      but the token is still returned.
/// * `Ok(Some(namespace, local_name))`: `None` for the local name means a `*` universal selector
pub(crate) fn parse_qualified_name<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    input: &mut CssParser,
    in_attr_selector: bool,
) -> CResult<OptionalQName<Impl>> {
    let start = input.state();

    let tok = match input.next_including_whitespace() {
        Ok(v) => *v,
        Err(e) => {
            input.reset(&start);
            return Err(e);
        }
    };
    match &tok {
        Token::Ident(value) => {
            let value = *value;
            let after_ident = input.state();
            let n = if let Ok(t) = input.next_including_whitespace() {
                matches!(t, Token::Delim(d) if *d == b'|' as u32)
            } else {
                false
            };
            if n {
                let prefix: Impl::NamespacePrefix = Ident { v: value };
                let result: Option<Impl::NamespaceUrl> =
                    parser.namespace_for_prefix(Ident { v: value });
                let url: Impl::NamespaceUrl = match result {
                    Some(url) => url,
                    None => {
                        return Err(input.new_custom_error(
                            SelectorParseErrorKind::UnsupportedPseudoClassOrElement(value)
                                .into_default_parser_error(),
                        ));
                    }
                };
                return parse_qualified_name_eplicit_namespace_helper::<Impl>(
                    input,
                    QNamePrefix::ExplicitNamespace(prefix, url),
                    in_attr_selector,
                );
            } else {
                input.reset(&after_ident);
                if in_attr_selector {
                    return Ok(OptionalQName::Some(
                        QNamePrefix::ImplicitNoNamespace,
                        Some(value),
                    ));
                }
                return Ok(parse_qualified_name_default_namespace_helper::<Impl>(
                    parser,
                    Some(value),
                ));
            }
        }
        Token::Delim(c) => match u8::try_from(*c).ok() {
            Some(b'*') => {
                let after_star = input.state();
                let result = input.next_including_whitespace();
                if let Ok(t) = &result {
                    if matches!(t, Token::Delim(d) if *d == b'|' as u32) {
                        return parse_qualified_name_eplicit_namespace_helper::<Impl>(
                            input,
                            QNamePrefix::ExplicitAnyNamespace,
                            in_attr_selector,
                        );
                    }
                }
                // Reshaped for borrowck — clone token before reset.
                let result_cloned = result.cloned();
                input.reset(&after_star);
                if in_attr_selector {
                    let t = result_cloned?;
                    return Err(after_star
                        .source_location()
                        .new_custom_error(SelectorParseErrorKind::ExpectedBarInAttr(t)));
                } else {
                    return Ok(parse_qualified_name_default_namespace_helper::<Impl>(
                        parser, None,
                    ));
                }
            }
            Some(b'|') => {
                return parse_qualified_name_eplicit_namespace_helper::<Impl>(
                    input,
                    QNamePrefix::ExplicitNoNamespace,
                    in_attr_selector,
                );
            }
            _ => {}
        },
        _ => {}
    }
    input.reset(&start);
    Ok(OptionalQName::None(tok))
}

fn parse_qualified_name_default_namespace_helper<Impl: BunSelectorImpl>(
    parser: &mut SelectorParser,
    local_name: Option<Str>,
) -> OptionalQName<Impl> {
    let namespace: QNamePrefix<Impl> = if let Some(url) = parser.default_namespace() {
        QNamePrefix::ImplicitDefaultNamespace(url)
    } else {
        QNamePrefix::ImplicitAnyNamespace
    };
    OptionalQName::Some(namespace, local_name)
}

fn parse_qualified_name_eplicit_namespace_helper<Impl: BunSelectorImpl>(
    input: &mut CssParser,
    namespace: QNamePrefix<Impl>,
    in_attr_selector: bool,
) -> CResult<OptionalQName<Impl>> {
    let location = input.current_source_location();
    let t = *input.next_including_whitespace()?;
    match &t {
        Token::Ident(local_name) => return Ok(OptionalQName::Some(namespace, Some(*local_name))),
        // `*` is only a valid local name outside of attribute selectors;
        // `[ns|*]` must fall through to the `InvalidQualNameInAttr` error below.
        Token::Delim(c) if *c == b'*' as u32 && !in_attr_selector => {
            return Ok(OptionalQName::Some(namespace, None));
        }
        _ => {}
    }
    if in_attr_selector {
        let e = SelectorParseErrorKind::InvalidQualNameInAttr(t);
        return Err(location.new_custom_error(e));
    }
    Err(location.new_custom_error(SelectorParseErrorKind::ExplicitNamespaceUnexpectedToken(t)))
}

#[derive(Clone, PartialEq)]
pub struct LocalName<Impl: SelectorImpl> {
    pub name: Impl::LocalName,
    pub(crate) lower_name: Impl::LocalName,
}

impl<Impl: BunSelectorImpl> LocalName<Impl> {
    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        IdentFns::to_css(&self.name, dest)
    }
    pub fn eql(&self, rhs: &Self) -> bool {
        self.name.eql(&rhs.name) && self.lower_name.eql(&rhs.lower_name)
    }
    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        self.name.hash(hasher);
        self.lower_name.hash(hasher);
    }
    pub(crate) fn deep_clone(&self) -> Self {
        Self {
            name: self.name,
            lower_name: self.lower_name,
        }
    }
}

/// An attribute selector can have 's' or 'i' as flags, or no flags at all.
#[derive(Clone, Copy, PartialEq, Eq)]
pub enum AttributeFlags {
    // Matching should be case-sensitive ('s' flag).
    CaseSensitive,
    // Matching should be case-insensitive ('i' flag).
    AsciiCaseInsensitive,
    // No flags.  Matching behavior depends on the name of the attribute.
    CaseSensitivityDependsOnName,
}

impl AttributeFlags {
    pub(crate) fn to_case_sensitivity(
        self,
        local_name: &[u8],
        have_namespace: bool,
    ) -> attrs::ParsedCaseSensitivity {
        match self {
            AttributeFlags::CaseSensitive => attrs::ParsedCaseSensitivity::ExplicitCaseSensitive,
            AttributeFlags::AsciiCaseInsensitive => {
                attrs::ParsedCaseSensitivity::AsciiCaseInsensitive
            }
            AttributeFlags::CaseSensitivityDependsOnName => {
                // <https://html.spec.whatwg.org/multipage/#selectors>
                if !have_namespace && HTML_CASE_INSENSITIVE_ATTRIBUTES.contains(local_name) {
                    return attrs::ParsedCaseSensitivity::AsciiCaseInsensitiveIfInHtmlElementInHtmlDocument;
                }
                attrs::ParsedCaseSensitivity::CaseSensitive
            }
        }
    }
}

bun_core::comptime_string_set! {
    /// HTML attributes whose value is matched ASCII-case-insensitively when no
    /// explicit `s`/`i` flag is given on the attribute selector.
    /// <https://html.spec.whatwg.org/multipage/#selectors>
    ///
    /// PERF: probed on every `[attr=val]` selector, where the dominant inputs
    /// (`class`, `href`, `data-*`, `aria-*`) are *misses*. The generated
    /// length dispatch plus constant-length compare trees rejects those
    /// without hashing; LLVM lowers each leaf to word loads compared against
    /// immediates.
    static HTML_CASE_INSENSITIVE_ATTRIBUTES = {
        b"dir",
        b"rel",
        b"rev",
        b"axis",
        b"face",
        b"lang",
        b"link",
        b"text",
        b"type",
        b"align",
        b"alink",
        b"clear",
        b"color",
        b"defer",
        b"frame",
        b"media",
        b"rules",
        b"scope",
        b"shape",
        b"vlink",
        b"accept",
        b"method",
        b"nohref",
        b"nowrap",
        b"target",
        b"valign",
        b"bgcolor",
        b"charset",
        b"checked",
        b"compact",
        b"declare",
        b"enctype",
        b"noshade",
        b"codetype",
        b"disabled",
        b"hreflang",
        b"language",
        b"multiple",
        b"noresize",
        b"readonly",
        b"selected",
        b"direction",
        b"scrolling",
        b"valuetype",
        b"http_equiv",
        b"accept_charset",
    };
}

/// A [view transition part name](https://w3c.github.io/csswg-drafts/css-view-transitions-1/#typedef-pt-name-selector).
#[derive(Clone)]
pub enum ViewTransitionPartName {
    /// *
    All,
    /// <custom-ident>
    Name(CustomIdent),
}

impl ViewTransitionPartName {
    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        match self {
            Self::All => dest.write_str("*"),
            Self::Name(name) => name.to_css(dest),
        }
    }

    pub fn parse(input: &mut CssParser) -> CResult<ViewTransitionPartName> {
        if input.try_parse(|i| i.expect_delim(b'*')).is_ok() {
            return Ok(Self::All);
        }

        Ok(Self::Name(CustomIdent::parse(input)?))
    }

    pub fn eql(&self, rhs: &Self) -> bool {
        match (self, rhs) {
            (Self::All, Self::All) => true,
            (Self::Name(a), Self::Name(b)) => a.eql(b),
            _ => false,
        }
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        match self {
            Self::All => hasher.update(&0u32.to_ne_bytes()),
            Self::Name(n) => {
                hasher.update(&1u32.to_ne_bytes());
                n.hash(hasher);
            }
        }
    }
}

/// A [view transition part selector](https://w3c.github.io/csswg-drafts/css-view-transitions-2/#typedef-pt-name-and-class-selector).
#[derive(Clone)]
pub struct ViewTransitionPartSelector {
    /// The view transition part name.
    pub name: Option<ViewTransitionPartName>,
    /// The view transition classes, each written as `.<custom-ident>`.
    pub classes: Box<[<impl_::Selectors as SelectorImpl>::LocalIdentifier]>,
}

impl ViewTransitionPartSelector {
    pub fn to_css(&self, dest: &mut Printer) -> Result<(), PrintErr> {
        if let Some(name) = &self.name {
            name.to_css(dest)?;
        }
        for class in self.classes.iter() {
            dest.write_char(b'.')?;
            dest.write_ident_or_ref(*class, dest.css_module.is_some())?;
        }
        Ok(())
    }

    pub fn parse(
        parser: &mut SelectorParser<'_>,
        input: &mut CssParser,
    ) -> CResult<ViewTransitionPartSelector> {
        input.skip_whitespace();
        let name = input.try_parse(ViewTransitionPartName::parse);

        // White space is not allowed between the name and a class, or inside the classes.
        let mut classes = Vec::new();
        loop {
            let start = input.state();
            let loc = input.position();
            let is_dot = matches!(
                input.next_including_whitespace(),
                Ok(Token::Delim(d)) if *d == u32::from(b'.')
            );
            if !is_dot {
                input.reset(&start);
                break;
            }
            let location = input.current_source_location();
            let class = match *input.next_including_whitespace()? {
                Token::Ident(class) => class,
                t => {
                    let e = SelectorParseErrorKind::ClassNeedsIdent(t);
                    return Err(location.new_custom_error(e.into_default_parser_error()));
                }
            };
            if crate::values::ident::is_reserved_custom_ident(class) {
                return Err(location.new_unexpected_token_error(Token::Ident(class)));
            }
            classes.push(parser.new_local_identifier(input, css::CssRefTag::CLASS, class, loc));
        }

        let name = match name {
            Ok(name) => Some(name),
            Err(e) if classes.is_empty() => return Err(e),
            Err(_) => None,
        };
        Ok(ViewTransitionPartSelector {
            name,
            classes: classes.into_boxed_slice(),
        })
    }

    pub fn eql(&self, rhs: &Self) -> bool {
        let names_eql = match (&self.name, &rhs.name) {
            (None, None) => true,
            (Some(a), Some(b)) => a.eql(b),
            _ => false,
        };
        names_eql
            && self.classes.len() == rhs.classes.len()
            && self
                .classes
                .iter()
                .zip(rhs.classes.iter())
                .all(|(a, b)| a.eql(b))
    }

    pub(crate) fn hash(&self, hasher: &mut Wyhash) {
        if let Some(name) = &self.name {
            name.hash(hasher);
        }
        for class in self.classes.iter() {
            hasher.update(&2u32.to_ne_bytes());
            class.hash(hasher);
        }
    }
}

pub(crate) fn parse_attribute_flags(input: &mut CssParser) -> CResult<AttributeFlags> {
    let location = input.current_source_location();
    let token = match input.next() {
        Ok(v) => *v,
        Err(_) => {
            // Selectors spec says language-defined; HTML says it depends on the
            // exact attribute name.
            return Ok(AttributeFlags::CaseSensitivityDependsOnName);
        }
    };

    let ident = if let Token::Ident(ident) = &token {
        *ident
    } else {
        return Err(location.new_basic_unexpected_token_error(token));
    };

    if strings::eql_case_insensitive_ascii_check_length(ident, b"i") {
        Ok(AttributeFlags::AsciiCaseInsensitive)
    } else if strings::eql_case_insensitive_ascii_check_length(ident, b"s") {
        Ok(AttributeFlags::CaseSensitive)
    } else {
        Err(location.new_basic_unexpected_token_error(token))
    }
}

crate::css_eql_partialeq!(NthSelectorData, SpecificityAndFlags, Combinator);
