use crate::css_parser::{CssResult as Result, Parser, PrintErr, Printer};
use crate::values::number::{CSSNumber, CSSNumberFns};

/// A CSS [`<ratio>`](https://www.w3.org/TR/css-values-4/#ratios) value,
/// representing the ratio of two numeric values.
#[derive(Debug, Clone, Copy, PartialEq)]
pub struct Ratio {
    pub(crate) numerator: CSSNumber,
    pub(crate) denominator: CSSNumber,
}

impl Ratio {
    pub(crate) fn parse(input: &mut Parser) -> Result<Ratio> {
        let first = CSSNumberFns::parse(input)?;
        let second = if input.try_parse(|i| i.expect_delim(b'/')).is_ok() {
            CSSNumberFns::parse(input)?
        } else {
            1.0
        };

        Ok(Ratio {
            numerator: first,
            denominator: second,
        })
    }

    /// Parses a ratio where both operands are required.
    pub(crate) fn parse_required(input: &mut Parser) -> Result<Ratio> {
        let first = CSSNumberFns::parse(input)?;
        input.expect_delim(b'/')?;
        let second = CSSNumberFns::parse(input)?;
        Ok(Ratio {
            numerator: first,
            denominator: second,
        })
    }

    pub(crate) fn to_css(self, dest: &mut Printer) -> core::result::Result<(), PrintErr> {
        CSSNumberFns::to_css(self.numerator, dest)?;
        if self.denominator != 1.0 {
            dest.delim(b'/', true)?;
            CSSNumberFns::to_css(self.denominator, dest)?;
        }
        Ok(())
    }

    pub(crate) fn add_f32(self, other: f32) -> Ratio {
        Ratio {
            numerator: self.numerator + other,
            denominator: self.denominator,
        }
    }
}
