//! Hand-maintained colorspace conversion graph.

use super::color::{
    A98, HSL, HWB, LAB, LCH, OKLAB, OKLCH, P3, ProPhoto, RGBA, Rec2020, SRGB, SRGBLinear, XYZd50,
    XYZd65,
};

// Helper: every generated conversion routes through exactly one intermediate
// colorspace (`const xyz: Via = this.into(.Via); return xyz.into(.Dst);`).
// Deliberately not `#[inline]`: with the hint, every use site inlines the
// whole chain of matrix conversions down to the base impls.
macro_rules! convert_via {
    ($src:ty => $via:ty => $dst:ty) => {
        impl From<$src> for $dst {
            fn from(c: $src) -> $dst {
                let via: $via = <$via>::from(c);
                <$dst>::from(via)
            }
        }
    };
}

// ─── convert_RGBA ─────────────────────────────────────────────────────────
convert_via!(RGBA => SRGB => LAB);
convert_via!(RGBA => SRGB => LCH);
convert_via!(RGBA => SRGB => OKLAB);
convert_via!(RGBA => SRGB => OKLCH);
convert_via!(RGBA => SRGB => P3);
convert_via!(RGBA => SRGB => SRGBLinear);
convert_via!(RGBA => SRGB => A98);
convert_via!(RGBA => SRGB => ProPhoto);
convert_via!(RGBA => SRGB => XYZd50);
convert_via!(RGBA => SRGB => XYZd65);
convert_via!(RGBA => SRGB => Rec2020);
convert_via!(RGBA => SRGB => HSL);
convert_via!(RGBA => SRGB => HWB);

// ─── convert_LAB ──────────────────────────────────────────────────────────
convert_via!(LAB => XYZd50 => XYZd65);
convert_via!(LAB => XYZd65 => OKLAB);
convert_via!(LAB => XYZd65 => OKLCH);
convert_via!(LAB => XYZd65 => SRGB);
convert_via!(LAB => XYZd65 => SRGBLinear);
convert_via!(LAB => XYZd65 => P3);
convert_via!(LAB => XYZd65 => A98);
convert_via!(LAB => XYZd65 => ProPhoto);
convert_via!(LAB => XYZd65 => Rec2020);
convert_via!(LAB => XYZd65 => HSL);
convert_via!(LAB => XYZd65 => HWB);
convert_via!(LAB => SRGB   => RGBA);

// ─── convert_SRGB ─────────────────────────────────────────────────────────
convert_via!(SRGB => XYZd65     => LAB);
convert_via!(SRGB => XYZd65     => LCH);
convert_via!(SRGB => SRGBLinear => XYZd65);
convert_via!(SRGB => XYZd65     => OKLAB);
convert_via!(SRGB => XYZd65     => OKLCH);
convert_via!(SRGB => XYZd65     => P3);
convert_via!(SRGB => XYZd65     => A98);
convert_via!(SRGB => XYZd65     => ProPhoto);
convert_via!(SRGB => XYZd65     => Rec2020);
convert_via!(SRGB => XYZd65     => XYZd50);

// ─── convert_HSL ──────────────────────────────────────────────────────────
convert_via!(HSL => XYZd65 => LAB);
convert_via!(HSL => XYZd65 => LCH);
convert_via!(HSL => XYZd65 => P3);
convert_via!(HSL => XYZd65 => SRGBLinear);
convert_via!(HSL => XYZd65 => A98);
convert_via!(HSL => XYZd65 => ProPhoto);
convert_via!(HSL => XYZd65 => XYZd50);
convert_via!(HSL => XYZd65 => Rec2020);
convert_via!(HSL => XYZd65 => OKLAB);
convert_via!(HSL => XYZd65 => OKLCH);
convert_via!(HSL => SRGB   => XYZd65);
convert_via!(HSL => SRGB   => HWB);
// `From<HSL> for RGBA` — handwritten in color.rs (skipped)

// ─── convert_HWB ──────────────────────────────────────────────────────────
convert_via!(HWB => XYZd65 => LAB);
convert_via!(HWB => XYZd65 => LCH);
convert_via!(HWB => XYZd65 => P3);
convert_via!(HWB => XYZd65 => SRGBLinear);
convert_via!(HWB => XYZd65 => A98);
convert_via!(HWB => XYZd65 => ProPhoto);
convert_via!(HWB => XYZd65 => XYZd50);
convert_via!(HWB => XYZd65 => Rec2020);
convert_via!(HWB => SRGB   => HSL);
convert_via!(HWB => SRGB   => XYZd65);
convert_via!(HWB => XYZd65 => OKLAB);
convert_via!(HWB => XYZd65 => OKLCH);
// `From<HWB> for RGBA` — handwritten in color.rs (skipped)

// ─── convert_SRGBLinear ───────────────────────────────────────────────────
convert_via!(SRGBLinear => XYZd65 => LAB);
convert_via!(SRGBLinear => XYZd65 => LCH);
convert_via!(SRGBLinear => XYZd65 => P3);
convert_via!(SRGBLinear => XYZd65 => OKLAB);
convert_via!(SRGBLinear => XYZd65 => OKLCH);
convert_via!(SRGBLinear => XYZd65 => A98);
convert_via!(SRGBLinear => XYZd65 => ProPhoto);
convert_via!(SRGBLinear => XYZd65 => Rec2020);
convert_via!(SRGBLinear => XYZd65 => XYZd50);
convert_via!(SRGBLinear => XYZd65 => HSL);
convert_via!(SRGBLinear => XYZd65 => HWB);
convert_via!(SRGBLinear => SRGB   => RGBA);

// ─── convert_P3 ───────────────────────────────────────────────────────────
convert_via!(P3 => XYZd65 => LAB);
convert_via!(P3 => XYZd65 => LCH);
convert_via!(P3 => XYZd65 => SRGB);
convert_via!(P3 => XYZd65 => SRGBLinear);
convert_via!(P3 => XYZd65 => OKLAB);
convert_via!(P3 => XYZd65 => OKLCH);
convert_via!(P3 => XYZd65 => A98);
convert_via!(P3 => XYZd65 => ProPhoto);
convert_via!(P3 => XYZd65 => Rec2020);
convert_via!(P3 => XYZd65 => XYZd50);
convert_via!(P3 => XYZd65 => HSL);
convert_via!(P3 => XYZd65 => HWB);
convert_via!(P3 => SRGB   => RGBA);

// ─── convert_A98 ──────────────────────────────────────────────────────────
convert_via!(A98 => XYZd65 => LAB);
convert_via!(A98 => XYZd65 => LCH);
convert_via!(A98 => XYZd65 => SRGB);
convert_via!(A98 => XYZd65 => P3);
convert_via!(A98 => XYZd65 => SRGBLinear);
convert_via!(A98 => XYZd65 => OKLAB);
convert_via!(A98 => XYZd65 => OKLCH);
convert_via!(A98 => XYZd65 => ProPhoto);
convert_via!(A98 => XYZd65 => Rec2020);
convert_via!(A98 => XYZd65 => XYZd50);
convert_via!(A98 => XYZd65 => HSL);
convert_via!(A98 => XYZd65 => HWB);
convert_via!(A98 => SRGB   => RGBA);

// ─── convert_ProPhoto ─────────────────────────────────────────────────────
convert_via!(ProPhoto => XYZd50 => XYZd65);
convert_via!(ProPhoto => XYZd65 => LAB);
convert_via!(ProPhoto => XYZd65 => LCH);
convert_via!(ProPhoto => XYZd65 => SRGB);
convert_via!(ProPhoto => XYZd65 => P3);
convert_via!(ProPhoto => XYZd65 => SRGBLinear);
convert_via!(ProPhoto => XYZd65 => A98);
convert_via!(ProPhoto => XYZd65 => OKLAB);
convert_via!(ProPhoto => XYZd65 => OKLCH);
convert_via!(ProPhoto => XYZd65 => Rec2020);
convert_via!(ProPhoto => XYZd65 => HSL);
convert_via!(ProPhoto => XYZd65 => HWB);
convert_via!(ProPhoto => SRGB   => RGBA);

// ─── convert_Rec2020 ──────────────────────────────────────────────────────
convert_via!(Rec2020 => XYZd65 => LAB);
convert_via!(Rec2020 => XYZd65 => LCH);
convert_via!(Rec2020 => XYZd65 => SRGB);
convert_via!(Rec2020 => XYZd65 => P3);
convert_via!(Rec2020 => XYZd65 => SRGBLinear);
convert_via!(Rec2020 => XYZd65 => A98);
convert_via!(Rec2020 => XYZd65 => ProPhoto);
convert_via!(Rec2020 => XYZd65 => XYZd50);
convert_via!(Rec2020 => XYZd65 => OKLAB);
convert_via!(Rec2020 => XYZd65 => OKLCH);
convert_via!(Rec2020 => XYZd65 => HSL);
convert_via!(Rec2020 => XYZd65 => HWB);
convert_via!(Rec2020 => SRGB   => RGBA);

// ─── convert_XYZd50 ───────────────────────────────────────────────────────
convert_via!(XYZd50 => XYZd65 => LCH);
convert_via!(XYZd50 => XYZd65 => SRGB);
convert_via!(XYZd50 => XYZd65 => P3);
convert_via!(XYZd50 => XYZd65 => SRGBLinear);
convert_via!(XYZd50 => XYZd65 => A98);
convert_via!(XYZd50 => XYZd65 => OKLAB);
convert_via!(XYZd50 => XYZd65 => OKLCH);
convert_via!(XYZd50 => XYZd65 => Rec2020);
convert_via!(XYZd50 => XYZd65 => HSL);
convert_via!(XYZd50 => XYZd65 => HWB);
convert_via!(XYZd50 => SRGB   => RGBA);

// ─── convert_XYZd65 ───────────────────────────────────────────────────────
convert_via!(XYZd65 => XYZd50     => LAB);
convert_via!(XYZd65 => XYZd50     => ProPhoto);
convert_via!(XYZd65 => OKLAB      => OKLCH);
convert_via!(XYZd65 => LAB        => LCH);
convert_via!(XYZd65 => SRGBLinear => SRGB);
convert_via!(XYZd65 => SRGB       => HSL);
convert_via!(XYZd65 => SRGB       => HWB);
convert_via!(XYZd65 => SRGB       => RGBA);

// ─── convert_LCH ──────────────────────────────────────────────────────────
convert_via!(LCH => LAB    => XYZd65);
convert_via!(LCH => XYZd65 => OKLAB);
convert_via!(LCH => XYZd65 => OKLCH);
convert_via!(LCH => XYZd65 => SRGB);
convert_via!(LCH => XYZd65 => SRGBLinear);
convert_via!(LCH => XYZd65 => P3);
convert_via!(LCH => XYZd65 => A98);
convert_via!(LCH => XYZd65 => ProPhoto);
convert_via!(LCH => XYZd65 => Rec2020);
convert_via!(LCH => XYZd65 => XYZd50);
convert_via!(LCH => XYZd65 => HSL);
convert_via!(LCH => XYZd65 => HWB);
convert_via!(LCH => SRGB   => RGBA);

// ─── convert_OKLAB ────────────────────────────────────────────────────────
convert_via!(OKLAB => XYZd65 => LAB);
convert_via!(OKLAB => XYZd65 => LCH);
convert_via!(OKLAB => XYZd65 => SRGB);
convert_via!(OKLAB => XYZd65 => P3);
convert_via!(OKLAB => XYZd65 => SRGBLinear);
convert_via!(OKLAB => XYZd65 => A98);
convert_via!(OKLAB => XYZd65 => ProPhoto);
convert_via!(OKLAB => XYZd65 => XYZd50);
convert_via!(OKLAB => XYZd65 => Rec2020);
convert_via!(OKLAB => XYZd65 => HSL);
convert_via!(OKLAB => XYZd65 => HWB);
convert_via!(OKLAB => SRGB   => RGBA);

// ─── convert_OKLCH ────────────────────────────────────────────────────────
convert_via!(OKLCH => OKLAB  => XYZd65);
convert_via!(OKLCH => XYZd65 => LAB);
convert_via!(OKLCH => XYZd65 => LCH);
convert_via!(OKLCH => XYZd65 => SRGB);
convert_via!(OKLCH => XYZd65 => P3);
convert_via!(OKLCH => XYZd65 => SRGBLinear);
convert_via!(OKLCH => XYZd65 => A98);
convert_via!(OKLCH => XYZd65 => ProPhoto);
convert_via!(OKLCH => XYZd65 => XYZd50);
convert_via!(OKLCH => XYZd65 => Rec2020);
convert_via!(OKLCH => XYZd65 => HSL);
convert_via!(OKLCH => XYZd65 => HWB);
convert_via!(OKLCH => SRGB   => RGBA);
