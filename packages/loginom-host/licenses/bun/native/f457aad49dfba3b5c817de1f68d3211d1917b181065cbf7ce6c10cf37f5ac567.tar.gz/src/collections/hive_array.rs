use core::cell::{Cell, UnsafeCell};
use core::marker::PhantomData;
use core::mem::{ManuallyDrop, MaybeUninit, size_of};
use core::ops::Deref;
use core::ptr::NonNull;

use bun_core::asan;

/// Fixed-width occupancy bitset for [`HiveArray`].
///
/// [`IntegerBitSet`](crate::bit_set::IntegerBitSet) is backed by a single
/// `usize`, so for `N > 64` it silently held only 64 usable bits — every
/// `HiveArray<_, 128/256/2048>` pool degraded to 64 effective slots and spilled
/// to the heap fallback on the 65th in-flight item. Under HTTP load (the
/// `Body::Value` 256-slot pool, the `RequestContext` 2048-slot pool) this turned
/// every request into a `Box::new`.
///
/// We can't spell `[usize; (CAPACITY+63)/64]` without `generic_const_exprs`
/// (which would virally add `where` bounds on every `HiveArray` consumer), so
/// this uses a fixed `[Cell<usize>; 32]` backing array — 2048 bits, which is the
/// largest in-tree `HiveArray` capacity. Only the first `ceil(CAPACITY/64)`
/// words are touched, so smaller pools pay 256 B of dead storage (negligible
/// next to `buffer`). The words are `Cell` so the bitset can be mutated through
/// a `&self` pool, matching `HiveArray`'s interior-mutability model.
#[repr(C)]
pub struct HiveBitSet<const CAPACITY: usize> {
    masks: [Cell<usize>; HIVE_BITSET_WORDS],
}

const HIVE_BITSET_WORDS: usize = 32;
const WORD_BITS: usize = usize::BITS as usize;

impl<const CAPACITY: usize> HiveBitSet<CAPACITY> {
    const NUM_WORDS: usize = if CAPACITY == 0 {
        0
    } else {
        CAPACITY.div_ceil(WORD_BITS)
    };
    const _FITS: () = assert!(
        CAPACITY <= HIVE_BITSET_WORDS * WORD_BITS,
        "HiveArray CAPACITY exceeds HiveBitSet backing (raise HIVE_BITSET_WORDS)"
    );
    /// Mask of valid bits in the last live word (all-ones when CAPACITY is a
    /// multiple of 64; otherwise zeros in the high padding bits).
    const LAST_WORD_MASK: usize = {
        let rem = CAPACITY % WORD_BITS;
        if rem == 0 {
            usize::MAX
        } else {
            (1usize << rem) - 1
        }
    };

    pub const fn init_empty() -> Self {
        Self {
            masks: [const { Cell::new(0) }; HIVE_BITSET_WORDS],
        }
    }

    #[inline]
    pub(crate) fn is_set(&self, index: usize) -> bool {
        debug_assert!(index < CAPACITY);
        (self.masks[index / WORD_BITS].get() >> (index % WORD_BITS)) & 1 != 0
    }

    /// Private — toggling occupancy from outside `HiveArray` while a
    /// `HiveSlot`/`HiveBox` for the same index is alive would let a
    /// re-`claim()` alias it. Use [`HiveArray::claim`]/[`get_init`](HiveArray::get_init)/
    /// [`put`](HiveArray::put)/[`box_at`](HiveArray::box_at).
    #[inline]
    fn set(&self, index: usize) {
        debug_assert!(index < CAPACITY);
        let w = index / WORD_BITS;
        self.masks[w].set(self.masks[w].get() | (1usize << (index % WORD_BITS)));
    }

    /// Private — see [`set`](Self::set).
    #[inline]
    fn unset(&self, index: usize) {
        debug_assert!(index < CAPACITY);
        let w = index / WORD_BITS;
        self.masks[w].set(self.masks[w].get() & !(1usize << (index % WORD_BITS)));
    }

    #[inline]
    pub fn find_first_set(&self) -> Option<usize> {
        let mut i = 0;
        while i < Self::NUM_WORDS {
            let m = self.masks[i].get();
            if m != 0 {
                return Some(i * WORD_BITS + m.trailing_zeros() as usize);
            }
            i += 1;
        }
        None
    }

    #[inline]
    pub fn find_first_unset(&self) -> Option<usize> {
        let mut i = 0;
        while i < Self::NUM_WORDS {
            let live_mask = if i + 1 == Self::NUM_WORDS {
                Self::LAST_WORD_MASK
            } else {
                usize::MAX
            };
            let inv = !self.masks[i].get() & live_mask;
            if inv != 0 {
                return Some(i * WORD_BITS + inv.trailing_zeros() as usize);
            }
            i += 1;
        }
        None
    }

    /// Forward iterator over set bits. Mirrors `IntegerBitSet::iter_set`.
    #[inline]
    pub fn iter_set(&self) -> HiveBitSetIter<CAPACITY> {
        self.iterator::<true, true>()
    }

    /// Signature mirrors `IntegerBitSet::iterator` so existing
    /// `hive.used.iterator::<true, true>()` callers compile unchanged. Only
    /// the `<KIND_SET=true, DIR_FWD=true>` combination is implemented (the
    /// only one used in-tree); other params assert.
    #[inline]
    pub fn iterator<const KIND_SET: bool, const DIR_FWD: bool>(&self) -> HiveBitSetIter<CAPACITY> {
        const {
            assert!(
                KIND_SET && DIR_FWD,
                "HiveBitSet::iterator only supports <true,true>"
            )
        };
        // Snapshot the live words into a non-`Cell` array so the iterator can
        // outlive transient mutations of the source bitset.
        HiveBitSetIter {
            masks: self.masks.each_ref().map(Cell::get),
            word: 0,
        }
    }
}

pub struct HiveBitSetIter<const CAPACITY: usize> {
    masks: [usize; HIVE_BITSET_WORDS],
    word: usize,
}

impl<const CAPACITY: usize> HiveBitSetIter<CAPACITY> {
    #[inline]
    #[allow(clippy::should_implement_trait)]
    pub fn next(&mut self) -> Option<usize> {
        while self.word < HiveBitSet::<CAPACITY>::NUM_WORDS {
            let m = self.masks[self.word];
            if m != 0 {
                let bit = m.trailing_zeros() as usize;
                self.masks[self.word] &= m - 1;
                return Some(self.word * WORD_BITS + bit);
            }
            self.word += 1;
        }
        None
    }
}

/// An array that efficiently tracks which elements are in use.
/// The pointers are intended to be stable
/// Sorta related to https://www.open-std.org/jtc1/sc22/wg21/docs/papers/2021/p0447r15.html
///
/// All slot operations take `&self` and the buffer is `UnsafeCell` — slot
/// pointers come from `UnsafeCell::get()` and so survive `&self` reborrows of
/// the pool (the `bumpalo` / `typed-arena` shape). `HiveArray` is `!Sync`.
pub struct HiveArray<T, const CAPACITY: usize> {
    buffer: UnsafeCell<[MaybeUninit<T>; CAPACITY]>,
    pub used: HiveBitSet<CAPACITY>,
}

impl<T, const CAPACITY: usize> HiveArray<T, CAPACITY> {
    pub const fn init() -> Self {
        Self {
            buffer: UnsafeCell::new([const { MaybeUninit::uninit() }; CAPACITY]),
            used: HiveBitSet::init_empty(),
        }
    }

    /// Placement-new constructor: write the empty state directly into `*out`
    /// without materializing `Self` on the stack.
    ///
    /// `Self` embeds `[MaybeUninit<T>; CAPACITY]` inline, which for the
    /// install pools (`NetworkTask` × 128, `Task` × 64) is hundreds of KB.
    /// Rust has no result-location semantics, so `out.write(Self::init())`
    /// first builds the value in the caller's frame and `memcpy`s it — LLVM
    /// does **not** elide that temporary. This entry point only writes the
    /// 256 B `used` bitset; `buffer` is `MaybeUninit` and needs no
    /// initialization (uninitialized bytes are a valid bit-pattern for it).
    ///
    /// # Safety
    /// `out` must be non-null, properly aligned, and valid for writes of
    /// `size_of::<Self>()` bytes. The previous contents are not dropped.
    #[inline]
    pub(crate) unsafe fn init_in_place(out: *mut Self) {
        // SAFETY: caller contract — `out` is aligned and writable; only the
        // `used` field is projected and written.
        unsafe {
            core::ptr::addr_of_mut!((*out).used).write(HiveBitSet::init_empty());
        }
        // `buffer: UnsafeCell<[MaybeUninit<T>; CAPACITY]>` intentionally untouched.
    }

    /// Heap-allocate an empty hive without staging `Self` on the stack.
    pub fn new_boxed() -> Box<Self> {
        let mut out = Box::<Self>::new_uninit();
        // SAFETY: fresh aligned allocation; `init_in_place` writes the only field that needs it.
        unsafe {
            Self::init_in_place(out.as_mut_ptr());
            out.assume_init()
        }
    }

    /// Raw pointer to slot `index`. Carries the buffer's `UnsafeCell` tag so
    /// it survives later `&self` reborrows. Safe to obtain; deref requires
    /// the slot to be claimed and initialized.
    #[inline]
    pub fn ptr_at(&self, index: usize) -> *mut T {
        // `assert!`, not `debug_assert!` — `ptr.add()` past the end is UB, not
        // a panic, in release builds. Keep this a safe `pub fn`.
        assert!(index < CAPACITY);
        // SAFETY: `index < CAPACITY` (asserted above); in-bounds offset.
        unsafe {
            self.buffer
                .get()
                .cast::<MaybeUninit<T>>()
                .add(index)
                .cast::<T>()
        }
    }

    /// Recover a [`HiveBox`] for a slot whose [`index_of`](Self::index_of)
    /// was stored across a callback. `None` if `index` is out of bounds or
    /// the slot is free — a stale index is `None`, not UB.
    ///
    /// # Safety
    /// The slot at `index`, if occupied, must hold a fully-initialized `T`,
    /// and no other live access path ([`HiveSlot`], [`HiveBox`], `*mut T`) to
    /// it may exist. The bitset check cannot prove this: [`claim`](Self::claim)
    /// sets the `used` bit *before* the slot is written, so safe code holding a
    /// claim token can have an occupied-but-uninit slot. Pools that only use
    /// [`get_init`](Self::get_init) (which writes before returning) trivially
    /// satisfy this.
    #[inline]
    pub unsafe fn box_at(&self, index: usize) -> Option<HiveBox<'_, T, CAPACITY>> {
        if index >= CAPACITY || !self.used.is_set(index) {
            return None;
        }
        Some(HiveBox {
            // SAFETY: `index < CAPACITY` (checked above); `ptr_at` is in-bounds.
            slot: unsafe { NonNull::new_unchecked(self.ptr_at(index)) },
            owner: self,
        })
    }

    /// One-shot claim + write. Preferred entry point — no uninit window.
    ///
    /// Returns `None` (and does **not** consume `value`'s slot) if the hive
    /// is full; on `None` the caller still owns `value` and must drop it.
    #[inline]
    pub fn get_init(&self, value: T) -> Option<NonNull<T>> {
        Some(self.claim()?.write(value))
    }

    /// Low-level reservation. Only when [`get_init`](Self::get_init) is
    /// insufficient — typically when the caller must interleave fallible
    /// work between claim and commit, or perform `repr(C)` placement-new
    /// through [`HiveSlot::addr`].
    pub fn claim(&self) -> Option<HiveSlot<'_, T, CAPACITY>> {
        let index = self.used.find_first_unset()?;
        self.used.set(index);
        // SAFETY: `index < CAPACITY` ⇒ in-bounds; `UnsafeCell::get` is non-null.
        let slot = unsafe {
            NonNull::new_unchecked(self.buffer.get().cast::<MaybeUninit<T>>().add(index))
        };
        asan::unpoison(slot.as_ptr().cast(), size_of::<T>());
        Some(HiveSlot {
            slot,
            owner: core::ptr::from_ref(self),
            _marker: PhantomData,
        })
    }

    /// Recycle a slot **without** running `T::drop`. If `value` does not point
    /// into this hive, returns `false` and is a no-op. Use when the caller has
    /// already moved the contents out / destructured them, or when `T` is POD
    /// and the slot is being released on an error path before it was fully
    /// initialized.
    ///
    /// # Safety
    /// No live token ([`HiveSlot`], [`HiveBox`]) may exist for this slot — once
    /// the `used` bit is cleared, [`claim`](Self::claim) can hand it out
    /// again, aliasing the stale token's `DerefMut`/`Drop`.
    pub(crate) unsafe fn put_raw(&self, value: *mut T) -> bool {
        let Some(index) = self.index_of(value) else {
            return false;
        };
        debug_assert!(self.used.is_set(index as usize));
        asan::poison(value.cast(), size_of::<T>());
        self.used.unset(index as usize);
        true
    }

    pub fn at(&self, index: u16) -> *mut T {
        debug_assert!((index as usize) < CAPACITY);
        let ret = self.ptr_at(index as usize);
        asan::assert_unpoisoned(ret.cast::<u8>());
        ret
    }

    pub fn index_of(&self, value: *const T) -> Option<u32> {
        asan::assert_unpoisoned(value.cast::<u8>());
        let start = self.buffer.get().cast::<T>();
        // One-past-the-end pointer of `buffer`; `wrapping_add` is sound for
        // the in-allocation offset and matches `add` exactly here.
        let end = start.wrapping_add(CAPACITY);
        if !((value as usize) >= (start as usize) && (value as usize) < (end as usize)) {
            return None;
        }

        // aligned to the size of T
        let index = ((value as usize) - (start as usize)) / size_of::<T>();
        debug_assert!(index < CAPACITY);
        debug_assert!(self.ptr_at(index).cast_const() == value);
        Some(u32::try_from(index).expect("int cast"))
    }

    /// Drop every occupied slot in place and mark it free. Runs from
    /// [`Drop`]; also callable explicitly when an owner wants to release
    /// slot payloads earlier than the hive itself is dropped.
    ///
    /// # Safety
    /// Every slot whose `used` bit is set must hold a fully-initialized `T`
    /// (the invariant [`get_init`](Self::get_init) /
    /// [`claim`](Self::claim)+[`write`](HiveSlot::write) maintain). A slot
    /// claimed but never written violates this and makes the
    /// `drop_in_place` UB.
    pub(crate) unsafe fn drop_all(&mut self) {
        if core::mem::needs_drop::<T>() {
            // `iter_set` snapshots the bitset, so `unset` inside the loop is
            // invisible to it. Unsetting before `drop_in_place` means a later
            // `drop_all` (e.g. from `Drop` after an explicit call) never
            // revisits an already-dropped slot.
            let mut iter = self.used.iter_set();
            while let Some(index) = iter.next() {
                let slot = self.ptr_at(index);
                self.used.unset(index);
                // SAFETY: caller contract — `used` bit set ⇒ slot is a fully
                // initialized `T` (see fn doc).
                unsafe { core::ptr::drop_in_place(slot) };
                asan::poison(slot.cast(), size_of::<T>());
            }
        }
        self.used = HiveBitSet::init_empty();
    }

    /// Return a slot to the pool, dropping the contained `T` in place.
    ///
    /// Returns `false` (and drops nothing) if `value` does not point into
    /// this hive's buffer.
    ///
    /// # Safety
    /// If `value` points into this hive, it must point to a fully-initialized
    /// `T` previously handed out by this hive and written by the caller. The slot is dropped in place; passing a moved-from or
    /// uninitialized slot is UB for `T` with drop glue.
    pub unsafe fn put(&self, value: *mut T) -> bool {
        let Some(index) = self.index_of(value) else {
            return false;
        };

        debug_assert!(self.used.is_set(index as usize));
        debug_assert!(self.ptr_at(index as usize).cast_const() == value.cast_const());

        // Several `T` carry owned heap data (e.g. `NumberScope.name_counts:
        // StringHashMap`, `NetworkTask.url_buf: Box<[u8]>`); drop the slot
        // before recycling so the put/get cycle does not leak it. Callers that
        // pre-clean fields (`PooledSocket::release_parked_refs`) leave only
        // trivially-droppable residuals, so this is idempotent for them.
        // SAFETY: caller contract — `value` is a fully-initialized `T` in `buffer`.
        unsafe { core::ptr::drop_in_place(value) };
        asan::poison(value.cast(), size_of::<T>());

        self.used.unset(index as usize);
        true
    }
}

impl<T, const CAPACITY: usize> Drop for HiveArray<T, CAPACITY> {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: `get_init` sets `used` and writes the slot in one `&self`
        // call, and `claim()` hands out a `HiveSlot<'_>` that borrows the pool
        // (its Drop unsets the bit if never written), so by the time
        // `&mut self` is obtainable every `used` slot is fully initialized.
        unsafe { self.drop_all() };
    }
}

// ──────────────────────────────────────────────────────────────────────────
// HiveSlot
// ──────────────────────────────────────────────────────────────────────────

/// Linear reservation token for a claimed-but-uninitialized hive slot.
///
/// `HiveArray` slots are `[MaybeUninit<T>; CAP]`. A two-phase claim-then-
/// `ptr::write` contract opens three UB hazards in the gap: (H1) early-return / `?` / panic
/// leaves the slot claimed-uninit so a later `put()` drops garbage; (H2)
/// `&mut *p` over uninit `T` is instant validity UB when `T` has niches; (H3)
/// partial field-write then `assume_init_ref` on the whole slot.
///
/// `HiveSlot` encodes the invariant **"a `used` slot is always fully
/// initialized"** in the type system: you cannot obtain the stable
/// initialized `*mut T` without going through [`write`](Self::write) (or the
/// `unsafe` [`assume_init`](Self::assume_init) escape hatch). If the token is
/// dropped (early return, `?`, panic) the slot is released **without** running
/// `T::drop` — it was never written.
///
/// Two-pointer-sized; `owner` discriminates release behavior:
///   - non-null ⇒ `*const HiveArray<T, CAP>` (release = unset `used` bit + poison),
///   - null     ⇒ heap `Box<MaybeUninit<T>>` (release = dealloc, no `T::drop`).
#[must_use = "claimed hive slot is leaked if neither written nor dropped"]
pub struct HiveSlot<'h, T, const CAPACITY: usize> {
    slot: NonNull<MaybeUninit<T>>,
    /// Typed `*const` (not `usize` + low-bit tag) so provenance survives `Drop`.
    /// Null = heap-fallback sentinel (`from_ref(self)` is never null).
    owner: *const HiveArray<T, CAPACITY>,
    _marker: PhantomData<&'h HiveArray<T, CAPACITY>>,
}

impl<'h, T, const CAPACITY: usize> HiveSlot<'h, T, CAPACITY> {
    /// Stable address of the slot. Safe to capture (e.g. register as a
    /// libuv/uws user-data pointer) **before** [`write`](Self::write), as long
    /// as nothing dereferences it until after `write()`.
    #[inline]
    pub fn addr(&self) -> NonNull<T> {
        self.slot.cast::<T>()
    }

    /// Move `value` into the slot and return the stable initialized pointer.
    /// Consumes the token (its `Drop` does not run).
    #[inline]
    pub fn write(self, value: T) -> NonNull<T> {
        let this = ManuallyDrop::new(self);
        let p = this.slot.cast::<T>();
        // SAFETY: `slot` is a unique claimed reservation; nothing reads through
        // it before this write. Writing through the raw ptr (not `&mut`) keeps
        // the `UnsafeCell` tag alive for callers holding sibling slot pointers.
        unsafe { p.as_ptr().write(value) };
        p
    }

    /// Caller has fully initialized the slot by writing through
    /// [`addr`](Self::addr). Consumes the token.
    ///
    /// # Safety
    /// Every field of `T` must be initialized, including padding-adjacent
    /// niches (enum discriminants, `NonNull`, `Box`, `&`). Calling this on a
    /// partially-written slot is the exact UB this type exists to prevent.
    #[inline]
    pub unsafe fn assume_init(self) -> NonNull<T> {
        let this = ManuallyDrop::new(self);
        this.slot.cast::<T>()
    }
}

impl<T, const CAPACITY: usize> Drop for HiveSlot<'_, T, CAPACITY> {
    fn drop(&mut self) {
        if !self.owner.is_null() {
            // Inline hive slot: unset the `used` bit and re-poison. Do NOT
            // `drop_in_place` — the slot was never `.write()`n.
            let hive = self.owner;
            // SAFETY: `owner` was set from `from_ref(self)` in `HiveArray::claim`
            // and the hive outlives `'h` (PhantomData lifetime).
            unsafe {
                let index = (*hive)
                    .index_of(self.slot.as_ptr().cast::<T>())
                    .expect("HiveSlot points outside its owning hive");
                asan::poison(self.slot.as_ptr().cast(), size_of::<T>());
                (*hive).used.unset(index as usize);
            }
        } else {
            // Heap fallback slot: reclaim the `Box<MaybeUninit<T>>` allocation.
            // `MaybeUninit<T>` has no drop glue, so this deallocates without
            // touching `T`.
            // SAFETY: `slot` was produced by `Box::leak(Box::<MaybeUninit<T>>::new_uninit())`
            // in `Fallback::claim` and has not been freed.
            drop(unsafe { Box::from_raw(self.slot.as_ptr()) });
        }
    }
}

/// Single-owner handle to an initialized [`HiveArray`] slot. `Box<T>`-shaped:
/// `Drop` returns the slot to the pool, [`into_inner`](Self::into_inner)
/// extracts the value. Single-owner (no `Clone`), so [`DerefMut`] is sound.
///
/// For pools whose tokens cross an opaque round-trip as a slot *index* (e.g.
/// the c-ares callback context in `dns_jsc`), store
/// [`HiveArray::index_of`] and recover via [`HiveArray::box_at`].
pub struct HiveBox<'a, T, const CAPACITY: usize> {
    slot: NonNull<T>,
    owner: &'a HiveArray<T, CAPACITY>,
}

impl<'a, T, const CAPACITY: usize> HiveBox<'a, T, CAPACITY> {
    /// Extract the value, freeing the slot.
    #[inline]
    pub fn into_inner(self) -> T {
        let this = ManuallyDrop::new(self);
        // SAFETY: `slot` is a fully-initialized `T` exclusively owned by this box.
        let value = unsafe { core::ptr::read(this.slot.as_ptr()) };
        // SAFETY: `this` is being consumed — no other token for this slot exists.
        unsafe { this.owner.put_raw(this.slot.as_ptr()) };
        value
    }
}

impl<T, const CAPACITY: usize> Deref for HiveBox<'_, T, CAPACITY> {
    type Target = T;
    #[inline]
    fn deref(&self) -> &T {
        // SAFETY: `slot` is a fully-initialized, exclusively-owned `T`.
        unsafe { self.slot.as_ref() }
    }
}

impl<T, const CAPACITY: usize> core::ops::DerefMut for HiveBox<'_, T, CAPACITY> {
    #[inline]
    fn deref_mut(&mut self) -> &mut T {
        // SAFETY: `slot` is a fully-initialized, exclusively-owned `T`; no
        // `Clone` impl, so this is the only `&mut` access path.
        unsafe { self.slot.as_mut() }
    }
}

impl<T, const CAPACITY: usize> Drop for HiveBox<'_, T, CAPACITY> {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: `slot` is a fully-initialized `T` owned by this box; `put`
        // drops it in place and frees the slot.
        unsafe { self.owner.put(self.slot.as_ptr()) };
    }
}

// Rust cannot nest a generic struct that captures outer generics, so this lives
// at module scope with the same parameters as `HiveArray`. The hive is always
// materialized; the `CAPACITY > 0` checks below gate its use.
pub struct Fallback<T, const CAPACITY: usize> {
    pub hive: HiveArray<T, CAPACITY>,
}

impl<T, const CAPACITY: usize> Fallback<T, CAPACITY> {
    pub const fn init() -> Self {
        Self {
            hive: HiveArray::init(),
        }
    }

    /// Placement-new constructor — see [`HiveArray::init_in_place`]. Only
    /// writes the 256 B occupancy bitset; the `[MaybeUninit<T>; CAPACITY]`
    /// buffer is left untouched.
    ///
    /// # Safety
    /// `out` must be non-null, properly aligned, and valid for writes of
    /// `size_of::<Self>()` bytes. The previous contents are not dropped.
    #[inline]
    pub unsafe fn init_in_place(out: *mut Self) {
        // SAFETY: caller contract.
        unsafe { HiveArray::<T, CAPACITY>::init_in_place(core::ptr::addr_of_mut!((*out).hive)) };
    }

    /// Heap-allocate an empty `Fallback` without materializing it on the
    /// stack first.
    ///
    /// `Box::new(Self::init())` is the obvious spelling, but Rust has no
    /// guaranteed result-location semantics: for the 2048-slot
    /// `RequestContext` pool (`sizeof ≈ 816 KB`) LLVM emits the bitset
    /// zeros into a stack temporary and then `memcpy`s the **full** 816 KB
    /// into the heap allocation, committing both ~812 KB of stack pages and
    /// ~812 KB of heap pages that are never read. This entry point allocates
    /// raw heap storage and writes only the 256-byte `used` bitset via
    /// [`init_in_place`](Self::init_in_place); the `[MaybeUninit<T>; CAPACITY]`
    /// buffer is left untouched (uninitialized bytes are a valid bit-pattern
    /// for `MaybeUninit`).
    ///
    /// The returned allocation is leaked — callers stash it in a per-thread
    /// static for the process lifetime.
    #[inline]
    pub fn new_boxed() -> NonNull<Self> {
        let mut boxed = Box::<Self>::new_uninit();
        // SAFETY: `boxed` is a fresh heap allocation — non-null, aligned for
        // `Self`, and valid for writes of `size_of::<Self>()` bytes.
        unsafe { Self::init_in_place(boxed.as_mut_ptr()) };
        // SAFETY: `init_in_place` fully initialized `hive.used`; `hive.buffer`
        // is `[MaybeUninit<T>; CAPACITY]`, for which uninitialized bytes are a
        // valid representation. Every field of `Self` is therefore valid.
        NonNull::from(Box::leak(unsafe { boxed.assume_init() }))
    }

    /// One-shot claim + write. Preferred entry point — no uninit window.
    /// Infallible: spills to a heap `Box<T>` when the inline hive is full.
    #[inline]
    pub fn get_init(&self, value: T) -> NonNull<T> {
        self.claim().write(value)
    }

    /// See [`HiveArray::claim`]. Infallible: when the inline hive is full,
    /// the returned token owns a freshly-allocated heap slot (tagged so its
    /// `Drop` deallocates without running `T::drop`).
    pub fn claim(&self) -> HiveSlot<'_, T, CAPACITY> {
        if CAPACITY > 0 {
            if let Some(slot) = self.hive.claim() {
                return slot;
            }
        }
        let slot = NonNull::from(Box::leak(Box::<T>::new_uninit()));
        HiveSlot {
            slot,
            // Null ⇒ heap slot. The hive pointer is not needed on the release
            // path (dealloc is `Box::from_raw(slot)`).
            owner: core::ptr::null(),
            _marker: PhantomData,
        }
    }

    /// Return a slot to the pool, dropping the contained `T`.
    ///
    /// # Safety
    /// `value` must point to a fully-initialized `T` previously obtained from
    /// [`get_init`](Self::get_init) / [`claim`](Self::claim) on this `Fallback`
    /// and subsequently written by the caller.
    pub unsafe fn put(&self, value: *mut T) {
        if CAPACITY > 0 {
            // SAFETY: caller contract — `value` is fully initialized.
            if unsafe { self.hive.put(value) } {
                return;
            }
        }

        // SAFETY: `value` was produced by the heap-fallback path of `claim()` /
        // `get()` (it is not in the hive), and the caller has since fully
        // initialized it. `destroy` reconstructs the `Box<T>` and runs `T::drop`.
        unsafe { bun_core::heap::destroy(value) };
    }
}

// ──────────────────────────────────────────────────────────────────────────
// HiveRef
// ──────────────────────────────────────────────────────────────────────────
//
// Lives here (not in the `bun` crate) because every consumer names it through
// `bun_collections::HiveRef`, and its only collaborator is `Fallback` above.
//
// The self-referential pool type is spelled out as
// `Fallback<HiveRef<T, CAPACITY>, CAPACITY>`. CAPACITY is `usize` to line up
// with `HiveArray`/`Fallback`'s const generic.

/// Intrusive ref-counted slot allocated from a `HiveArray::Fallback` pool.
/// `pool` is a BACKREF (LIFETIMES.tsv class) — the pool strictly outlives
/// every `HiveRef` it hands out, so a raw pointer is the honest mapping.
///
/// Prefer [`HiveRefHandle`] in new code; the raw `init`/`ref_`/`unref` family
/// remains for FFI ingress points that hold the slot as a `*mut HiveRef`.
#[repr(C)]
pub struct HiveRef<T, const CAPACITY: usize> {
    pub(crate) ref_count: Cell<u32>,
    pub pool: *const Fallback<HiveRef<T, CAPACITY>, CAPACITY>,
    pub value: T,
}

impl<T, const CAPACITY: usize> HiveRef<T, CAPACITY> {
    /// Allocate a slot from `pool` (heap fallback when full) and initialize it
    /// with `value` at refcount 1.
    ///
    /// # Safety
    /// `pool` must be valid for the entire lifetime of the returned
    /// `HiveRef` (i.e. until its `ref_count` drops to zero and it is `put`
    /// back). Callers hold the pool in a long-lived owner (e.g. `VirtualMachine`).
    pub(crate) unsafe fn init(value: T, pool: *const Fallback<Self, CAPACITY>) -> *mut Self {
        // SAFETY: caller contract — `pool` is dereferenceable.
        unsafe {
            (*pool)
                .get_init(HiveRef {
                    ref_count: Cell::new(1),
                    pool,
                    value,
                })
                .as_ptr()
        }
    }

    #[inline]
    pub(crate) fn ref_(&self) -> &Self {
        self.ref_count.set(self.ref_count.get() + 1);
        self
    }

    /// Returns `None` when the count hit zero and the slot was returned to
    /// the pool.
    ///
    /// # Safety
    /// `this` must point at a live `HiveRef` produced by [`init`](Self::init).
    /// On `None` the slot has been recycled — do not use `this` afterward.
    pub(crate) unsafe fn unref(this: *mut Self) -> Option<*mut Self> {
        // SAFETY: caller contract — `this` is a live `HiveRef` slot, and
        // `(*this).pool` outlives every slot it hands out (`init` contract).
        // `Fallback::put` runs `T::drop` (drops the whole `HiveRef` in place).
        unsafe {
            let ref_count = (*this).ref_count.get();
            (*this).ref_count.set(ref_count - 1);
            if ref_count == 1 {
                let pool = (*this).pool;
                (*pool).put(this);
                return None;
            }
        }
        Some(this)
    }
}

/// Owning handle to a refcounted [`HiveRef`] pool slot. `Clone` increments,
/// `Drop` decrements and recycles when the count hits zero. Cross FFI with
/// [`as_ptr`](Self::as_ptr) / [`from_raw`](Self::from_raw), like `Rc`/`Box`.
pub struct HiveRefHandle<T, const CAP: usize> {
    ptr: NonNull<HiveRef<T, CAP>>,
}

impl<T, const CAP: usize> HiveRefHandle<T, CAP> {
    /// The one place the type-level invariant is asserted: a handle exists
    /// ⇒ `ref_count >= 1` ⇒ the slot is live and initialized. `Deref`/`Clone`
    /// route through here so they're plain safe code.
    #[inline]
    fn slot(&self) -> &HiveRef<T, CAP> {
        // SAFETY: type invariant (above).
        unsafe { self.ptr.as_ref() }
    }

    /// Allocate a slot from `pool` with refcount 1.
    ///
    /// # Safety
    /// `pool` must outlive every handle/raw pointer derived from it.
    pub unsafe fn new(value: T, pool: *const Fallback<HiveRef<T, CAP>, CAP>) -> Self {
        // SAFETY: caller contract — `pool` is dereferenceable + outlives the slot.
        let ptr = unsafe { HiveRef::init(value, pool) };
        Self {
            ptr: NonNull::new(ptr).expect("Fallback::get_init returned null"),
        }
    }

    /// Reclaim ownership of a `+1` ref previously leaked as a raw pointer
    /// (e.g. via [`as_ptr`](Self::as_ptr) + `mem::forget`).
    ///
    /// # Safety
    /// `ptr` must be a live slot whose `+1` has not already been released.
    #[inline]
    pub unsafe fn from_raw(ptr: *mut HiveRef<T, CAP>) -> Self {
        Self {
            ptr: NonNull::new(ptr).expect("HiveRefHandle::from_raw(null)"),
        }
    }

    /// Raw pointer for FFI/intrusive use. Does not affect the refcount.
    #[inline]
    pub fn as_ptr(&self) -> *mut HiveRef<T, CAP> {
        self.ptr.as_ptr()
    }
}

impl<T, const CAP: usize> Deref for HiveRefHandle<T, CAP> {
    type Target = T;
    #[inline]
    fn deref(&self) -> &T {
        &self.slot().value
    }
}

impl<T, const CAP: usize> Clone for HiveRefHandle<T, CAP> {
    #[inline]
    fn clone(&self) -> Self {
        self.slot().ref_();
        Self { ptr: self.ptr }
    }
}

impl<T, const CAP: usize> Drop for HiveRefHandle<T, CAP> {
    #[inline]
    fn drop(&mut self) {
        // SAFETY: type invariant — `ptr` is live; `unref` recycles on count==0.
        unsafe { HiveRef::unref(self.ptr.as_ptr()) };
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Drop-counting payload. Each test that needs it owns its own `Cell` so
    /// tests stay independent (`AtomicU32` static would leak counts across
    /// tests run in the same process).
    struct Tracked<'c> {
        v: u64,
        drops: &'c core::cell::Cell<u32>,
    }
    impl Drop for Tracked<'_> {
        fn drop(&mut self) {
            self.drops.set(self.drops.get() + 1);
        }
    }

    #[test]
    fn hive_slot_drop_releases_without_dtor() {
        let drops = core::cell::Cell::new(0u32);
        let mk = |v| Tracked { v, drops: &drops };

        let a = HiveArray::<Tracked, 4>::init();
        // Dropped token releases the slot without running Drop.
        drop(a.claim().unwrap());
        assert!(!a.used.is_set(0));
        assert_eq!(drops.get(), 0);

        // write() commits and put() drops.
        let p = a.get_init(mk(7)).unwrap();
        assert!(a.used.is_set(0));
        assert_eq!(drops.get(), 0);
        // SAFETY: `p` is a fully-initialized hive slot.
        unsafe { a.put(p.as_ptr()) };
        assert_eq!(drops.get(), 1);

        // put_raw() does not drop.
        let p = a.get_init(mk(8)).unwrap();
        // SAFETY: `p` is the only token for its slot.
        assert!(unsafe { a.put_raw(p.as_ptr()) });
        assert_eq!(drops.get(), 1);

        // Fallback heap path: dropped token deallocates without Drop.
        let f = Fallback::<Tracked, 0>::init();
        drop(f.claim());
        assert_eq!(drops.get(), 1);
        let p = f.get_init(mk(9));
        // SAFETY: heap slot from this Fallback.
        unsafe { f.put(p.as_ptr()) };
        assert_eq!(drops.get(), 2);

        // Dropping the pool itself drops every still-occupied slot.
        a.get_init(mk(10)).unwrap();
        a.get_init(mk(11)).unwrap();
        assert_eq!(drops.get(), 2);
        drop(a);
        assert_eq!(drops.get(), 4);
    }

    #[test]
    fn slot_write_matches_addr() {
        let a = HiveArray::<[u32; 2], 4>::init();

        // write() returns the same address as addr().
        let slot = a.claim().unwrap();
        let pre = slot.addr().as_ptr();
        let p = slot.write([30, 40]);
        assert_eq!(pre, p.as_ptr());
        // SAFETY: slot is initialized.
        unsafe {
            assert_eq!(*p.as_ptr(), [30, 40]);
        }
        // SAFETY: `p` is the only token for its slot.
        assert!(unsafe { a.put_raw(p.as_ptr()) });
    }

    #[test]
    fn at_returns_claimed_slot() {
        let a = HiveArray::<u64, 4>::init();
        let p0 = a.get_init(100).unwrap();
        let p1 = a.get_init(200).unwrap();
        assert_eq!(a.at(0), p0.as_ptr());
        assert_eq!(a.at(1), p1.as_ptr());
        assert_eq!(a.ptr_at(0), p0.as_ptr());
        assert_eq!(a.ptr_at(1), p1.as_ptr());
        // SAFETY: both slots are initialized.
        unsafe {
            assert_eq!(*a.at(0), 100);
            assert_eq!(*a.at(1), 200);
        }
        // SAFETY: only token for its slot.
        assert!(unsafe { a.put_raw(p0.as_ptr()) });
        // SAFETY: only token for its slot.
        assert!(unsafe { a.put_raw(p1.as_ptr()) });
    }

    #[test]
    fn fallback_inline_then_heap() {
        const CAP: usize = 2;
        let drops = core::cell::Cell::new(0u32);
        let mk = |v| Tracked { v, drops: &drops };

        let f = Fallback::<Tracked, CAP>::init();

        // Two inline slots, then two heap slots.
        let inline0 = f.get_init(mk(0));
        let inline1 = f.get_init(mk(1));
        let heap0 = f.get_init(mk(2));
        let heap1 = f.get_init(mk(3));

        assert!(f.hive.index_of(inline0.as_ptr()).is_some());
        assert!(f.hive.index_of(inline1.as_ptr()).is_some());
        assert!(f.hive.index_of(heap0.as_ptr()).is_none());
        assert!(f.hive.index_of(heap1.as_ptr()).is_none());
        // SAFETY: all four are initialized.
        unsafe {
            assert_eq!((*inline0.as_ptr()).v, 0);
            assert_eq!((*inline1.as_ptr()).v, 1);
            assert_eq!((*heap0.as_ptr()).v, 2);
            assert_eq!((*heap1.as_ptr()).v, 3);
        }

        // Return one inline, one heap — interleaved with new claims.
        // SAFETY: `inline0` and `heap0` are initialized slots from `f`.
        unsafe {
            f.put(inline0.as_ptr());
            f.put(heap0.as_ptr());
        }
        assert_eq!(drops.get(), 2);

        // The freed inline slot is reused; the freed heap slot is gone.
        let reuse = f.get_init(mk(4));
        assert_eq!(reuse.as_ptr(), inline0.as_ptr());

        // SAFETY: remaining live slots.
        unsafe {
            f.put(inline1.as_ptr());
            f.put(heap1.as_ptr());
            f.put(reuse.as_ptr());
        }
        assert_eq!(drops.get(), 5);
    }

    #[test]
    fn fallback_claim_drop_inline_and_heap() {
        // Inline token: dropping releases the bit.
        let f = Fallback::<u64, 1>::init();
        drop(f.claim());
        assert!(!f.hive.used.is_set(0));

        // Heap token (CAP=0 forces it): dropping deallocates without touching
        // the hive — its `owner` is null. Pin the inline slot first so the
        // bit-stays-set assertion is meaningful for the CAP>0 case too.
        let f = Fallback::<u64, 1>::init();
        let inline = f.get_init(1);
        assert!(f.hive.used.is_set(0));
        drop(f.claim());
        assert!(f.hive.used.is_set(0));
        // SAFETY: `inline` is a live initialized slot from `f`.
        unsafe { f.put(inline.as_ptr()) };
        assert!(!f.hive.used.is_set(0));
    }

    #[test]
    fn fallback_new_boxed_and_init_in_place() {
        const CAP: usize = 4;

        let boxed = Fallback::<u64, CAP>::new_boxed();
        // SAFETY: `new_boxed` returns a valid heap allocation.
        unsafe {
            let f = &*boxed.as_ptr();
            for i in 0..CAP {
                let p = f.get_init(i as u64 * 10);
                assert!(f.hive.index_of(p.as_ptr()).is_some());
                assert_eq!(*p.as_ptr(), i as u64 * 10);
            }
            // 5th claim spills to heap.
            let p = f.get_init(999);
            assert!(f.hive.index_of(p.as_ptr()).is_none());
            f.put(p.as_ptr());
            // `new_boxed` is leaked by design; reclaim for the test.
            drop(Box::from_raw(boxed.as_ptr()));
        }
    }

    #[test]
    fn hive_ref_lifecycle() {
        let drops = core::cell::Cell::new(0u32);

        const CAP: usize = 2;
        type Pool<'c> = Fallback<HiveRef<Tracked<'c>, CAP>, CAP>;
        let pool: Pool = Fallback::init();
        let pool_ptr: *const Pool = &pool;

        // Inline allocation: ref to 2, unref to 1, unref to 0 → returned.
        // SAFETY: `pool` outlives every HiveRef created from `pool_ptr`.
        let r = unsafe {
            HiveRef::init(
                Tracked {
                    v: 1,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        // SAFETY: `r` is live (ref_count == 1) until the final unref returns None.
        unsafe {
            assert_eq!((*r).ref_count.get(), 1);
            (*r).ref_();
            assert_eq!((*r).ref_count.get(), 2);
            assert!(HiveRef::unref(r).is_some());
            assert_eq!((*r).ref_count.get(), 1);
            assert!(HiveRef::unref(r).is_none());
        }
        assert_eq!(drops.get(), 1);

        // Heap allocation: fill the hive first, then init another.
        // SAFETY: same pool contract.
        let inline0 = unsafe {
            HiveRef::init(
                Tracked {
                    v: 2,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        let inline1 = unsafe {
            HiveRef::init(
                Tracked {
                    v: 3,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        let heap = unsafe {
            HiveRef::init(
                Tracked {
                    v: 4,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        assert!(pool.hive.index_of(inline0).is_some());
        assert!(pool.hive.index_of(inline1).is_some());
        assert!(pool.hive.index_of(heap).is_none());
        // SAFETY: all three are live.
        unsafe {
            assert!(HiveRef::unref(heap).is_none());
            assert!(HiveRef::unref(inline1).is_none());
            assert!(HiveRef::unref(inline0).is_none());
        }
        assert_eq!(drops.get(), 4);
    }

    #[test]
    fn hive_ref_handle_lifecycle() {
        let drops = core::cell::Cell::new(0u32);

        const CAP: usize = 1;
        type Pool<'c> = Fallback<HiveRef<Tracked<'c>, CAP>, CAP>;
        let pool: Pool = Fallback::init();
        let pool_ptr: *const Pool = &pool;

        // Drop releases the slot when the count hits zero.
        // SAFETY: `pool` outlives every handle.
        let h = unsafe {
            HiveRefHandle::new(
                Tracked {
                    v: 1,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        assert_eq!(h.v, 1);
        let h2 = h.clone();
        assert_eq!(h2.v, 1);
        drop(h);
        assert_eq!(drops.get(), 0);
        drop(h2);
        assert_eq!(drops.get(), 1);

        // Heap fallback path (CAP=1, second handle spills).
        // SAFETY: `pool` outlives every handle.
        let inline = unsafe {
            HiveRefHandle::new(
                Tracked {
                    v: 3,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        let heap = unsafe {
            HiveRefHandle::new(
                Tracked {
                    v: 4,
                    drops: &drops,
                },
                pool_ptr,
            )
        };
        assert!(pool.hive.index_of(inline.as_ptr()).is_some());
        assert!(pool.hive.index_of(heap.as_ptr()).is_none());
        drop(heap);
        drop(inline);
        assert_eq!(drops.get(), 3);
    }

    #[test]
    fn hive_bitset_iteration() {
        let a = HiveArray::<u8, 8>::init();
        assert_eq!(a.used.find_first_set(), None);
        assert_eq!(a.used.find_first_unset(), Some(0));

        // Claim slots 0..3, then free 0 and 2 so the set is {1, 3}.
        let s0 = a.get_init(0).unwrap();
        let _s1 = a.get_init(1).unwrap();
        let s2 = a.get_init(2).unwrap();
        let _s3 = a.get_init(3).unwrap();
        // SAFETY: only token for its slot.
        assert!(unsafe { a.put_raw(s0.as_ptr()) });
        // SAFETY: only token for its slot.
        assert!(unsafe { a.put_raw(s2.as_ptr()) });

        assert_eq!(a.used.find_first_set(), Some(1));
        assert_eq!(a.used.find_first_unset(), Some(0));

        let mut it = a.used.iter_set();
        assert_eq!(it.next(), Some(1));
        assert_eq!(it.next(), Some(3));
        assert_eq!(it.next(), None);

        // The explicit-param form is the same as iter_set().
        let mut it = a.used.iterator::<true, true>();
        assert_eq!(it.next(), Some(1));
        assert_eq!(it.next(), Some(3));
        assert_eq!(it.next(), None);
    }

    #[test]
    fn init_in_place_zeroes_only_bitset() {
        let mut a: MaybeUninit<HiveArray<u64, 4>> = MaybeUninit::uninit();
        // SAFETY: stack allocation, properly aligned, valid for writes.
        unsafe {
            HiveArray::init_in_place(a.as_mut_ptr());
            let a = &*a.as_ptr();
            assert_eq!(a.used.find_first_set(), None);
            let p = a.get_init(7).unwrap();
            assert_eq!(*p.as_ptr(), 7);
            // `p` is the only token for its slot; already inside the outer
            // `unsafe` block.
            assert!(a.put_raw(p.as_ptr()));
        }
    }

    #[test]
    fn hive_box_lifecycle() {
        let drops = core::cell::Cell::new(0u32);
        let mk = |v| Tracked { v, drops: &drops };

        let pool = HiveArray::<Tracked, 4>::init();
        fn box_for<'p, 'c>(
            pool: &'p HiveArray<Tracked<'c>, 4>,
            p: NonNull<Tracked<'c>>,
        ) -> (usize, HiveBox<'p, Tracked<'c>, 4>) {
            let i = pool.index_of(p.as_ptr()).unwrap() as usize;
            // SAFETY: `p` was just returned by `get_init`; no other access path.
            (i, unsafe { pool.box_at(i) }.unwrap())
        }

        // box_at → Deref/DerefMut → Drop returns the slot, drops T.
        {
            let (i, mut b) = box_for(&pool, pool.get_init(mk(1)).unwrap());
            assert_eq!(b.v, 1);
            b.v = 11;
            assert_eq!(b.v, 11);
            assert!(pool.used.is_set(i));
        }
        assert_eq!(drops.get(), 1);
        assert!(!pool.used.is_set(0));

        // box_at → into_inner extracts T without running its Drop.
        let (i, b) = box_for(&pool, pool.get_init(mk(2)).unwrap());
        let val = b.into_inner();
        assert_eq!(val.v, 2);
        assert_eq!(drops.get(), 1);
        assert!(!pool.used.is_set(i));
        drop(val);
        assert_eq!(drops.get(), 2);

        // Claim → store index → recover via box_at — the dns.rs pattern.
        let p0 = pool.get_init(mk(10)).unwrap();
        let p1 = pool.get_init(mk(20)).unwrap();
        let (i0, i1) = (
            pool.index_of(p0.as_ptr()).unwrap() as usize,
            pool.index_of(p1.as_ptr()).unwrap() as usize,
        );
        // SAFETY: `i0`/`i1` were claimed above; no other access path.
        let v1 = unsafe { pool.box_at(i1) }.unwrap().into_inner();
        let v0 = unsafe { pool.box_at(i0) }.unwrap().into_inner();
        assert_eq!(v0.v, 10);
        assert_eq!(v1.v, 20);
        assert!(!pool.used.is_set(i0));
        assert!(!pool.used.is_set(i1));
        // Stale index: bit was unset by `into_inner()`, second recovery is `None`.
        // SAFETY: stale/OOB indices are caught at runtime — `None`, not UB.
        assert!(unsafe { pool.box_at(i0) }.is_none());
        assert!(unsafe { pool.box_at(999) }.is_none());
    }
}
