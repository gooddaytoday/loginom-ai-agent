//! Open-addressing hash map — linear-probe, tombstone-on-delete, power-of-two
//! capacity, 80% max load. Layout (and therefore iteration order) is
//! load-bearing: callers snapshot the iteration sequence (e.g. lockfile debug
//! stringify).
//!
//! Storage is split: `Vec<u8>` for metadata + `Vec<Option<(K, V)>>` for
//! slots. This costs an `Option` discriminant per slot but keeps the
//! implementation in safe Rust; slot indices and the metadata state machine
//! determine iteration order.

use core::borrow::Borrow;
use core::hash::Hash;
use core::marker::PhantomData;

use crate::identity_context::{IdentityContext, IdentityHash};

// ─── Metadata byte ─────────────────────────────────────────────────────────
// bit 7 = `used`, bits 0..7 = `fingerprint`.
const SLOT_FREE: u8 = 0x00; // used=0, fp=0
const SLOT_TOMBSTONE: u8 = 0x01; // used=0, fp=1

#[inline]
fn meta_is_used(m: u8) -> bool {
    m & 0x80 != 0
}
#[inline]
fn meta_is_free(m: u8) -> bool {
    m == SLOT_FREE
}
#[inline]
fn meta_is_tombstone(m: u8) -> bool {
    m == SLOT_TOMBSTONE
}
#[inline]
fn meta_fingerprint(m: u8) -> u8 {
    m & 0x7F
}
/// Top 7 bits of the 64-bit hash.
#[inline]
fn take_fingerprint(hash: u64) -> u8 {
    (hash >> (64 - 7)) as u8
}
#[inline]
fn meta_fill(fp: u8) -> u8 {
    0x80 | (fp & 0x7F)
}

const MINIMAL_CAPACITY: u32 = 8;
/// Maximum load percentage before growth. All instantiations use 80, so this
/// is a const rather than a generic parameter.
const MAX_LOAD_PERCENTAGE: u64 = 80;

#[inline]
fn capacity_for_size(size: u32) -> u32 {
    let new_cap = ((size as u64 * 100) / MAX_LOAD_PERCENTAGE + 1) as u32;
    new_cap.next_power_of_two()
}

// ─── HashContext ───────────────────────────────────────────────────────────
// The hash/eql strategy is a stateless trait keyed on a zero-sized marker
// type. `AutoHashContext` is the default; `IdentityContext<K>` covers the
// `hash(k) == k` case used for pre-hashed keys.

/// Hash/eql strategy for [`HashMap`]. Implement on a zero-sized marker type.
pub trait HashContext<K: ?Sized> {
    fn ctx_hash(key: &K) -> u64;
    fn ctx_eql(a: &K, b: &K) -> bool;
}

/// `std.AutoHashMap` context — wyhash over the key's `Hash` representation.
#[derive(Default, Clone, Copy)]
pub struct AutoHashContext;

impl<K: Hash + Eq + ?Sized> HashContext<K> for AutoHashContext {
    #[inline]
    fn ctx_hash(key: &K) -> u64 {
        // wyhash routed through `core::hash::Hash`; exact bucket order for
        // this context isn't relied on by any test today.
        bun_wyhash::auto_hash(key)
    }
    #[inline]
    fn ctx_eql(a: &K, b: &K) -> bool {
        a == b
    }
}

impl<K: IdentityHash> HashContext<K> for IdentityContext<K> {
    #[inline]
    fn ctx_hash(key: &K) -> u64 {
        key.identity_hash()
    }
    #[inline]
    fn ctx_eql(a: &K, b: &K) -> bool {
        a == b
    }
}

// ─── HashMap ───────────────────────────────────────────────────────────────

pub struct HashMap<K, V, C = AutoHashContext> {
    metadata: Vec<u8>,
    slots: Vec<Option<(K, V)>>,
    size: u32,
    /// Slots writable before a grow (counts free *and* tombstone consumption).
    available: u32,
    _ctx: PhantomData<C>,
}

impl<K, V, C> Default for HashMap<K, V, C> {
    #[inline]
    fn default() -> Self {
        Self {
            metadata: Vec::new(),
            slots: Vec::new(),
            size: 0,
            available: 0,
            _ctx: PhantomData,
        }
    }
}

impl<K, V, C> HashMap<K, V, C> {
    #[inline]
    pub fn new() -> Self {
        Self::default()
    }

    #[inline]
    pub fn len(&self) -> usize {
        self.size as usize
    }
    #[inline]
    pub fn is_empty(&self) -> bool {
        self.size == 0
    }
    #[inline]
    pub fn capacity(&self) -> usize {
        self.metadata.len()
    }

    /// Release storage.
    #[inline]
    pub fn deinit(&mut self) {
        *self = Self::default();
    }

    /// Clear all entries, retaining capacity.
    pub fn clear(&mut self) {
        if self.metadata.is_empty() {
            return;
        }
        for m in self.metadata.iter_mut() {
            *m = SLOT_FREE;
        }
        for s in self.slots.iter_mut() {
            *s = None;
        }
        self.size = 0;
        self.available = ((self.metadata.len() as u64 * MAX_LOAD_PERCENTAGE) / 100) as u32;
    }

    /// Debug-mode pointer-stability assertion. No-op stub kept so callers can
    /// keep their lock/unlock bracketing without `#[cfg]` noise at every call
    /// site (see `SavedSourceMap`).
    #[inline]
    pub fn lock_pointers(&self) {}
    /// See [`lock_pointers`](Self::lock_pointers).
    #[inline]
    pub fn unlock_pointers(&self) {}

    pub fn iter(&self) -> Iter<'_, K, V> {
        Iter {
            metadata: &self.metadata,
            slots: &self.slots,
            idx: 0,
            remaining: self.size,
        }
    }
    pub fn iter_mut(&mut self) -> IterMut<'_, K, V> {
        IterMut {
            metadata: &self.metadata,
            slots: self.slots.iter_mut(),
            idx: 0,
            remaining: self.size,
        }
    }
    pub fn keys(&self) -> Keys<'_, K, V> {
        Keys { inner: self.iter() }
    }
    pub fn values(&self) -> Values<'_, K, V> {
        Values { inner: self.iter() }
    }
    pub fn values_mut(&mut self) -> ValuesMut<'_, K, V> {
        ValuesMut {
            inner: self.iter_mut(),
        }
    }
}

impl<K, V, C: HashContext<K>> HashMap<K, V, C> {
    pub fn with_capacity(capacity: usize) -> Self {
        let mut m = Self::default();
        if capacity > 0 {
            let _ = m.ensure_total_capacity(capacity);
        }
        m
    }

    /// Grow so `new_size` elements fit without further allocation. `Result`
    /// kept for call-site `?` symmetry.
    pub fn ensure_total_capacity(&mut self, new_size: usize) -> Result<(), bun_alloc::AllocError> {
        let new_size = new_size as u32;
        if new_size > self.size {
            self.grow_if_needed(new_size - self.size);
        }
        Ok(())
    }

    pub fn ensure_unused_capacity(
        &mut self,
        additional: usize,
    ) -> Result<(), bun_alloc::AllocError> {
        self.ensure_total_capacity(self.size as usize + additional)
    }

    /// std `reserve` — alias of [`ensure_unused_capacity`] for callers ported
    /// from the old `std::collections::HashMap` Deref.
    #[inline]
    pub fn reserve(&mut self, additional: usize) {
        let _ = self.ensure_unused_capacity(additional);
    }

    fn load(&self) -> u32 {
        let max_load = ((self.metadata.len() as u64 * MAX_LOAD_PERCENTAGE) / 100) as u32;
        debug_assert!(max_load >= self.available);
        max_load - self.available
    }

    fn grow_if_needed(&mut self, new_count: u32) {
        if new_count > self.available {
            self.grow(capacity_for_size(self.load() + new_count));
        }
    }

    #[cold]
    fn grow(&mut self, new_capacity: u32) {
        let new_cap = new_capacity.max(MINIMAL_CAPACITY);
        debug_assert!(new_cap as usize > self.metadata.len());
        debug_assert!(new_cap.is_power_of_two());

        let mut map = Self {
            metadata: vec![SLOT_FREE; new_cap as usize],
            // LSAN: this Vec is owned by the map and freed by HashMap's auto-Drop.
            // A leak reported here means the *container* HashMap leaked, not grow().
            slots: Vec::with_capacity(new_cap as usize),
            ..Default::default()
        };
        for _ in 0..new_cap {
            map.slots.push(None);
        }
        map.available = ((new_cap as u64 * MAX_LOAD_PERCENTAGE) / 100) as u32;

        if self.size != 0 {
            let old_cap = self.metadata.len();
            for i in 0..old_cap {
                if !meta_is_used(self.metadata[i]) {
                    continue;
                }
                if let Some((k, v)) = self.slots[i].take() {
                    map.put_assume_capacity_no_clobber(k, v);
                }
                if map.size == self.size {
                    break;
                }
            }
        }

        *self = map;
    }

    /// Linear-probe insert assuming the key is absent and `available > 0`.
    fn put_assume_capacity_no_clobber(&mut self, key: K, value: V) {
        let cap = self.metadata.len();
        let hash = C::ctx_hash(&key);
        let mask = cap - 1;
        let mut idx = (hash as usize) & mask;

        while meta_is_used(self.metadata[idx]) {
            idx = (idx + 1) & mask;
        }

        debug_assert!(self.available > 0);
        self.available -= 1;

        let fp = take_fingerprint(hash);
        self.metadata[idx] = meta_fill(fp);
        self.slots[idx] = Some((key, value));
        self.size += 1;
    }

    /// Probe for `key`, stop on free, skip tombstones.
    fn get_index<Q>(&self, key: &Q) -> Option<usize>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        if self.size == 0 {
            return None;
        }
        let cap = self.metadata.len();
        let hash = C::ctx_hash(key);
        let mask = cap - 1;
        let fp = take_fingerprint(hash);
        let mut limit = cap;
        let mut idx = (hash as usize) & mask;

        while !meta_is_free(self.metadata[idx]) && limit != 0 {
            if meta_is_used(self.metadata[idx]) && meta_fingerprint(self.metadata[idx]) == fp {
                if let Some((k, _)) = &self.slots[idx] {
                    if C::ctx_eql(key, k.borrow()) {
                        return Some(idx);
                    }
                }
            }
            limit -= 1;
            idx = (idx + 1) & mask;
        }
        None
    }

    pub fn get<Q>(&self, key: &Q) -> Option<&V>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key)
            .and_then(|i| self.slots[i].as_ref().map(|(_, v)| v))
    }

    pub fn get_mut<Q>(&mut self, key: &Q) -> Option<&mut V>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key)
            .and_then(move |i| self.slots[i].as_mut().map(|(_, v)| v))
    }

    pub fn get_key_value<Q>(&self, key: &Q) -> Option<(&K, &V)>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key)
            .and_then(|i| self.slots[i].as_ref().map(|(k, v)| (k, v)))
    }

    #[inline]
    pub fn contains_key<Q>(&self, key: &Q) -> bool
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key).is_some()
    }

    /// Alias for [`contains_key`](Self::contains_key).
    #[inline]
    pub fn contains(&self, key: &K) -> bool {
        self.get_index(key).is_some()
    }

    /// Grow-on-demand insert-or-lookup probe. Returns
    /// the slot index and whether it was already occupied; the slot is left
    /// `None` on miss so the caller can write the (K, V) pair.
    fn get_or_put_slot(&mut self, key: &K) -> (usize, bool) {
        self.grow_if_needed(1);

        let cap = self.metadata.len();
        let hash = C::ctx_hash(key);
        let mask = cap - 1;
        let fp = take_fingerprint(hash);
        let mut limit = cap;
        let mut idx = (hash as usize) & mask;
        let mut first_tombstone_idx = cap; // invalid sentinel

        while !meta_is_free(self.metadata[idx]) && limit != 0 {
            if meta_is_used(self.metadata[idx]) && meta_fingerprint(self.metadata[idx]) == fp {
                if let Some((k, _)) = &self.slots[idx] {
                    if C::ctx_eql(key, k) {
                        return (idx, true);
                    }
                }
            } else if first_tombstone_idx == cap && meta_is_tombstone(self.metadata[idx]) {
                first_tombstone_idx = idx;
            }
            limit -= 1;
            idx = (idx + 1) & mask;
        }

        if first_tombstone_idx < cap {
            idx = first_tombstone_idx;
        }
        self.available -= 1;
        self.metadata[idx] = meta_fill(fp);
        self.size += 1;
        (idx, false)
    }

    /// Single-probe insert-or-lookup. Uninit values cannot be exposed through
    /// a `&mut V`, so `V: Default` and on miss the slot is default-initialised
    /// — callers overwrite `*value_ptr` when `!found_existing`.
    pub fn get_or_put(
        &mut self,
        key: K,
    ) -> Result<crate::hash_map::GetOrPutResult<'_, V>, bun_alloc::AllocError>
    where
        V: Default,
    {
        let (idx, found_existing) = self.get_or_put_slot(&key);
        if !found_existing {
            self.slots[idx] = Some((key, V::default()));
        }
        let value_ptr = &mut self.slots[idx].as_mut().unwrap().1;
        Ok(crate::hash_map::GetOrPutResult {
            found_existing,
            value_ptr,
        })
    }

    /// std `insert` — returns the previous value if any.
    pub fn insert(&mut self, key: K, value: V) -> Option<V> {
        let (idx, found_existing) = self.get_or_put_slot(&key);
        if found_existing {
            let slot = self.slots[idx].as_mut().unwrap();
            Some(core::mem::replace(&mut slot.1, value))
        } else {
            self.slots[idx] = Some((key, value));
            None
        }
    }

    /// Insert or overwrite.
    #[inline]
    pub fn put(&mut self, key: K, value: V) -> Result<(), bun_alloc::AllocError> {
        self.insert(key, value);
        Ok(())
    }

    /// Insert asserting the key is new.
    pub fn put_no_clobber(&mut self, key: K, value: V) -> Result<(), bun_alloc::AllocError> {
        let prev = self.insert(key, value);
        debug_assert!(prev.is_none(), "putNoClobber: key already present");
        Ok(())
    }

    fn remove_by_index(&mut self, idx: usize) -> Option<(K, V)> {
        self.metadata[idx] = SLOT_TOMBSTONE;
        let kv = self.slots[idx].take();
        self.size -= 1;
        self.available += 1;
        kv
    }

    /// std `remove`.
    pub fn remove<Q>(&mut self, key: &Q) -> Option<V>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key)
            .and_then(|i| self.remove_by_index(i).map(|(_, v)| v))
    }

    /// std `remove_entry`.
    pub fn remove_entry<Q>(&mut self, key: &Q) -> Option<(K, V)>
    where
        K: Borrow<Q>,
        C: HashContext<Q>,
        Q: ?Sized,
    {
        self.get_index(key).and_then(|i| self.remove_by_index(i))
    }

    /// Remove and return the owned `{key, value}` pair.
    pub fn fetch_remove(&mut self, key: &K) -> Option<crate::hash_map::KV<K, V>> {
        self.remove_entry(key)
            .map(|(k, v)| crate::hash_map::KV { key: k, value: v })
    }

    /// std `retain`. Calls `keep` exactly once per entry.
    pub fn retain(&mut self, mut keep: impl FnMut(&K, &mut V) -> bool) {
        for idx in 0..self.slots.len() {
            if let Some((key, value)) = &mut self.slots[idx]
                && !keep(key, value)
            {
                let _ = self.remove_by_index(idx);
            }
        }
    }

    /// std `entry` API. `VacantEntry::insert` does a second probe (re-runs
    /// `get_or_put_slot`); acceptable for the few callers that use it.
    pub fn entry(&mut self, key: K) -> MapEntry<'_, K, V, C> {
        match self.get_index(&key) {
            Some(idx) => MapEntry::Occupied(OccupiedEntry { map: self, idx }),
            None => MapEntry::Vacant(VacantEntry { map: self, key }),
        }
    }
}

// ─── Iterators ─────────────────────────────────────────────────────────────

pub struct Iter<'a, K, V> {
    metadata: &'a [u8],
    slots: &'a [Option<(K, V)>],
    idx: usize,
    remaining: u32,
}
impl<'a, K, V> Iterator for Iter<'a, K, V> {
    type Item = (&'a K, &'a V);
    fn next(&mut self) -> Option<Self::Item> {
        if self.remaining == 0 {
            return None;
        }
        while self.idx < self.metadata.len() {
            let i = self.idx;
            self.idx += 1;
            if meta_is_used(self.metadata[i]) {
                self.remaining -= 1;
                let (k, v) = self.slots[i].as_ref().unwrap();
                return Some((k, v));
            }
        }
        None
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.remaining as usize, Some(self.remaining as usize))
    }
}
impl<K, V> ExactSizeIterator for Iter<'_, K, V> {}

pub struct IterMut<'a, K, V> {
    metadata: &'a [u8],
    slots: core::slice::IterMut<'a, Option<(K, V)>>,
    idx: usize,
    remaining: u32,
}
impl<'a, K, V> Iterator for IterMut<'a, K, V> {
    type Item = (&'a K, &'a mut V);
    fn next(&mut self) -> Option<Self::Item> {
        if self.remaining == 0 {
            return None;
        }
        for slot in self.slots.by_ref() {
            let i = self.idx;
            self.idx += 1;
            if meta_is_used(self.metadata[i]) {
                self.remaining -= 1;
                let (k, v) = slot.as_mut().unwrap();
                return Some((&*k, v));
            }
        }
        None
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        (self.remaining as usize, Some(self.remaining as usize))
    }
}
impl<K, V> ExactSizeIterator for IterMut<'_, K, V> {}

pub struct Keys<'a, K, V> {
    inner: Iter<'a, K, V>,
}
impl<'a, K, V> Iterator for Keys<'a, K, V> {
    type Item = &'a K;
    #[inline]
    fn next(&mut self) -> Option<&'a K> {
        self.inner.next().map(|(k, _)| k)
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}
impl<K, V> ExactSizeIterator for Keys<'_, K, V> {}

pub struct Values<'a, K, V> {
    inner: Iter<'a, K, V>,
}
impl<'a, K, V> Iterator for Values<'a, K, V> {
    type Item = &'a V;
    #[inline]
    fn next(&mut self) -> Option<&'a V> {
        self.inner.next().map(|(_, v)| v)
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}
impl<K, V> ExactSizeIterator for Values<'_, K, V> {}

pub struct ValuesMut<'a, K, V> {
    inner: IterMut<'a, K, V>,
}
impl<'a, K, V> Iterator for ValuesMut<'a, K, V> {
    type Item = &'a mut V;
    #[inline]
    fn next(&mut self) -> Option<&'a mut V> {
        self.inner.next().map(|(_, v)| v)
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        self.inner.size_hint()
    }
}
impl<K, V> ExactSizeIterator for ValuesMut<'_, K, V> {}

impl<'a, K, V, C> IntoIterator for &'a HashMap<K, V, C> {
    type Item = (&'a K, &'a V);
    type IntoIter = Iter<'a, K, V>;
    fn into_iter(self) -> Self::IntoIter {
        self.iter()
    }
}
impl<'a, K, V, C> IntoIterator for &'a mut HashMap<K, V, C> {
    type Item = (&'a K, &'a mut V);
    type IntoIter = IterMut<'a, K, V>;
    fn into_iter(self) -> Self::IntoIter {
        self.iter_mut()
    }
}

// ─── Entry API ─────────────────────────────────────────────────────────────

pub enum MapEntry<'a, K, V, C> {
    Occupied(OccupiedEntry<'a, K, V, C>),
    Vacant(VacantEntry<'a, K, V, C>),
}
pub struct OccupiedEntry<'a, K, V, C> {
    map: &'a mut HashMap<K, V, C>,
    idx: usize,
}
pub struct VacantEntry<'a, K, V, C> {
    map: &'a mut HashMap<K, V, C>,
    key: K,
}

impl<'a, K, V, C> MapEntry<'a, K, V, C>
where
    C: HashContext<K>,
{
    pub fn or_insert_with<F: FnOnce() -> V>(self, f: F) -> &'a mut V {
        match self {
            MapEntry::Occupied(o) => o.into_mut(),
            MapEntry::Vacant(v) => v.insert(f()),
        }
    }
    pub fn or_default(self) -> &'a mut V
    where
        V: Default,
    {
        self.or_insert_with(V::default)
    }
}

impl<'a, K, V, C> OccupiedEntry<'a, K, V, C> {
    #[inline]
    pub fn get(&self) -> &V {
        &self.map.slots[self.idx].as_ref().unwrap().1
    }
    #[inline]
    pub fn get_mut(&mut self) -> &mut V {
        &mut self.map.slots[self.idx].as_mut().unwrap().1
    }
    #[inline]
    pub fn into_mut(self) -> &'a mut V {
        &mut self.map.slots[self.idx].as_mut().unwrap().1
    }
}

impl<'a, K, V, C: HashContext<K>> VacantEntry<'a, K, V, C> {
    pub fn insert(self, value: V) -> &'a mut V {
        let (idx, found) = self.map.get_or_put_slot(&self.key);
        debug_assert!(!found);
        self.map.slots[idx] = Some((self.key, value));
        &mut self.map.slots[idx].as_mut().unwrap().1
    }
}

#[cfg(test)]
mod retain_tests {
    use super::*;

    /// `keep` is shown each entry once, and the entries it accepts are still found by key.
    fn check(keys: &[u64], rejected: &[u64]) {
        // The home slot is `key & 7`, so the keys choose the runs.
        let mut map: HashMap<u64, u32, IdentityContext<u64>> = HashMap::new();
        for &key in keys {
            map.insert(key, 0);
        }
        assert_eq!(map.capacity(), 8);
        map.retain(|key, shown| {
            *shown += 1;
            !rejected.contains(key)
        });
        let mut left: Vec<(u64, u32)> = map.iter().map(|(key, shown)| (*key, *shown)).collect();
        left.sort_unstable();
        let mut expected: Vec<(u64, u32)> = (keys.iter().filter(|key| !rejected.contains(key)))
            .map(|&key| (key, 1))
            .collect();
        expected.sort_unstable();
        assert_eq!(left, expected);
        assert_eq!(map.len(), expected.len());
        for (key, _) in expected {
            assert_eq!(map.get(&key), Some(&1));
        }
    }

    #[test]
    fn retain_shows_each_entry_once() {
        // 2 and 10 share home slot 2: 10 is in slot 3, behind the rejected entry.
        check(&[2, 10, 3], &[2]);
        check(&[2, 10, 3], &[2, 10]);
        // The run wraps: 6 in slot 6, 14 in slot 7, 22 in slot 0.
        check(&[6, 14, 22], &[6]);
        check(&[6, 14, 22], &[14]);
        check(&[6, 14, 22, 30, 7, 15], &[6, 30]);
        check(&[2, 10, 3], &[]);
    }
}
