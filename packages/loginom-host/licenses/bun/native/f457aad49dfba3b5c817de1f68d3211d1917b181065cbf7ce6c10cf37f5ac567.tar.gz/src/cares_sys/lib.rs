#![allow(non_camel_case_types)]
#![warn(unused_must_use)]

#[path = "c_ares.rs"]
pub mod c_ares_draft;

/// Winsock typedefs not provided by `libc` on `x86_64-pc-windows-msvc`.
#[cfg(windows)]
pub mod winsock {
    use core::ffi::c_int;
    pub(crate) type socklen_t = c_int; // ws2tcpip.h: `typedef int socklen_t;`
    // Same nominal type as `bun_sys::posix::sockaddr*`; sin_addr is `in_addr{s_addr}`
    // (vs the previous `[u8;4]`) but the only caller (c_ares.rs `get_sockaddr`)
    // takes `&raw mut → cast<c_void>`, so the field's nominal type is transparent.
    pub(crate) use bun_libuv_sys::{sockaddr, sockaddr_in, sockaddr_in6};
}

/// `c_ares` and `c_ares_draft` resolve to the same module.
pub use c_ares_draft as c_ares;

// Crate-root re-exports for callers that reference `bun_cares_sys::ares_inet_*`
// directly (e.g. `bun_boringssl`).
pub use c_ares::{ares_inet_ntop, ares_inet_pton};

/// Thin wrapper over `ares_inet_ntop`: writes the textual address into `dst`
/// and returns the slice up to (excluding) the trailing NUL on success.
/// `dst[len] == 0` is guaranteed on `Some`, so callers needing a C string can
/// rely on it.
///
/// # Safety
/// `src` must point to a valid `in_addr` (af == AF_INET) or `in6_addr`
/// (af == AF_INET6).
#[inline]
pub unsafe fn ntop(
    af: core::ffi::c_int,
    src: *const core::ffi::c_void,
    dst: &mut [u8],
) -> Option<&[u8]> {
    // SAFETY: caller contract guarantees `src` points to a valid `in_addr` /
    // `in6_addr` matching `af`; `dst` is a Rust slice so `dst.as_mut_ptr()` is
    // valid for `dst.len()` writes, and `ares_inet_ntop` writes at most `size`
    // bytes (including the trailing NUL) per c-ares docs.
    if unsafe {
        c_ares::ares_inet_ntop(
            af,
            src,
            dst.as_mut_ptr(),
            dst.len() as c_ares::ares_socklen_t,
        )
    }
    .is_null()
    {
        return None;
    }
    Some(bun_core::ffi::slice_to_nul(dst))
}
