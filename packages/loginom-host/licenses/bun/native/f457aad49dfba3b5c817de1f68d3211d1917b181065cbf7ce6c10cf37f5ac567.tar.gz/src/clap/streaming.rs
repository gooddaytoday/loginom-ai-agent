use core::sync::atomic::{AtomicBool, Ordering};

use bun_core::Output;
use bun_core::strings;

use crate as clap;
use crate::args::ArgIter;

// Disabled because not all CLI arguments are parsed with Clap.
pub static WARN_ON_UNRECOGNIZED_FLAG: AtomicBool = AtomicBool::new(false);

/// The result returned from StreamingClap.next
pub(crate) struct Arg<'p, 'a, Id> {
    pub param: &'p clap::Param<Id>,
    pub value: Option<&'a [u8]>,
}

#[derive(Copy, Clone)]
pub struct Chaining<'a> {
    pub(crate) arg: &'a [u8],
    pub(crate) index: usize,
}

pub enum State<'a> {
    Normal,
    Chaining(Chaining<'a>),
    RestArePositional,
}

#[derive(thiserror::Error, strum::IntoStaticStr, Debug, Copy, Clone, PartialEq, Eq)]
pub(crate) enum ArgError {
    #[error("DoesntTakeValue")]
    DoesntTakeValue,
    #[error("MissingValue")]
    MissingValue,
    #[error("InvalidArgument")]
    InvalidArgument,
}

#[derive(Copy, Clone, PartialEq, Eq)]
enum ArgKind {
    Long,
    Short,
    Positional,
}

struct ArgInfo<'a> {
    arg: &'a [u8],
    kind: ArgKind,
}

/// A command line argument parser which, given an ArgIterator, will parse arguments according
/// to the params. StreamingClap parses in an iterating manner, so you have to use a loop together with
/// StreamingClap.next to parse all the arguments of your program.
///
/// `'p` is the borrow lifetime (params/iter/diagnostic); `'a` is the arg-data lifetime
/// yielded by `ArgIterator` (e.g. `'static` for `OsIterator`). Splitting them lets
/// callers use a locally-borrowed param table with process-lifetime argv.
pub struct StreamingClap<'p, 'a, Id, ArgIterator> {
    pub params: &'p [clap::Param<Id>],
    pub(crate) iter: &'p mut ArgIterator,
    pub(crate) state: State<'a>,
    pub(crate) positional: Option<&'p clap::Param<Id>>,
    pub(crate) diagnostic: Option<&'p mut clap::Diagnostic>,
    pub(crate) short_aliases: &'static [(&'static [u8], &'static [u8])],
    pub(crate) unknown_long_flags_are_positional: bool,
    pub(crate) unknown_long_flags_are_errors: bool,
    pub(crate) ignored_long_flags: clap::IgnoredLongFlags,
}

// ArgIterator is the
// `args::ArgIter<'a>` trait so `next()`/`remain()` resolve.
impl<'p, 'a, Id, ArgIterator> StreamingClap<'p, 'a, Id, ArgIterator>
where
    ArgIterator: ArgIter<'a>,
{
    /// Get the next Arg that matches a Param.
    pub(crate) fn next(&mut self) -> Result<Option<Arg<'p, 'a, Id>>, ArgError> {
        match self.state {
            State::Normal => self.normal(),
            State::Chaining(state) => self.chainging(state),
            State::RestArePositional => {
                let param = self.positional_param().unwrap_or_else(|| unreachable!());
                let Some(value) = self.iter.next() else {
                    return Ok(None);
                };
                Ok(Some(Arg {
                    param,
                    value: Some(value),
                }))
            }
        }
    }

    fn normal(&mut self) -> Result<Option<Arg<'p, 'a, Id>>, ArgError> {
        let Some(arg_info) = self.parse_next_arg()? else {
            return Ok(None);
        };
        let arg = arg_info.arg;

        match arg_info.kind {
            ArgKind::Long => {
                let eql_index = strings::index_of_char_usize(arg, b'=');
                let name: &[u8] = if let Some(i) = eql_index {
                    &arg[0..i]
                } else {
                    arg
                };

                let maybe_value: Option<&[u8]> = if let Some(i) = eql_index {
                    Some(&arg[i + 1..])
                } else {
                    None
                };

                // Copy the slice ref so `&mut self` is free inside the loop.
                let params = self.params;
                for param in params {
                    if !param.names.matches_long(name) {
                        continue;
                    }

                    if param.takes_value == clap::Values::None
                        || param.takes_value == clap::Values::OneOptional
                    {
                        if param.takes_value == clap::Values::None && maybe_value.is_some() {
                            return Err(self.err(arg, None, Some(name), ArgError::DoesntTakeValue));
                        }

                        return Ok(Some(Arg {
                            param,
                            value: maybe_value,
                        }));
                    }

                    let value = 'blk: {
                        if let Some(v) = maybe_value {
                            break 'blk v;
                        }

                        break 'blk match self.iter.next() {
                            Some(v) => v,
                            None => {
                                return Err(self.err(
                                    arg,
                                    None,
                                    Some(name),
                                    ArgError::MissingValue,
                                ));
                            }
                        };
                    };

                    return Ok(Some(Arg {
                        param,
                        value: Some(value),
                    }));
                }

                if self.unknown_long_flags_are_errors && !self.iter.last_is_from_bun_options() {
                    let next = self.iter.remain().first().copied().unwrap_or_default();
                    let is_own_flag =
                        |name: &[u8]| params.iter().any(|param| param.names.matches_long(name));
                    let Some(value_is_next_arg) =
                        (self.ignored_long_flags).value_is_next_arg(name, next, is_own_flag)
                    else {
                        return Err(self.err(arg, None, Some(name), ArgError::InvalidArgument));
                    };
                    if value_is_next_arg && maybe_value.is_none() {
                        let _ = self.iter.next();
                    }
                    return self.next();
                }

                // unrecognized command
                // if flag else arg
                if arg_info.kind == ArgKind::Long || arg_info.kind == ArgKind::Short {
                    if WARN_ON_UNRECOGNIZED_FLAG.load(Ordering::Relaxed) {
                        bun_core::warn!(
                            "unrecognized flag: {}{}\n",
                            if arg_info.kind == ArgKind::Long {
                                "--"
                            } else {
                                "-"
                            },
                            bstr::BStr::new(name),
                        );
                        Output::flush();
                    }

                    // continue parsing after unrecognized flag
                    return self.next();
                }

                if WARN_ON_UNRECOGNIZED_FLAG.load(Ordering::Relaxed) {
                    bun_core::warn!("unrecognized argument: {}\n", bstr::BStr::new(name));
                    Output::flush();
                }
                Ok(None)
            }
            ArgKind::Short => self.chainging(Chaining { arg, index: 0 }),
            ArgKind::Positional => {
                if let Some(param) = self.positional_param() {
                    // If we find a positional with the value `--` then we
                    // interpret the rest of the arguments as positional
                    // arguments.
                    if arg == b"--" {
                        self.state = State::RestArePositional;
                        // return null to terminate arg parsing
                        let Some(value) = self.iter.next() else {
                            return Ok(None);
                        };
                        return Ok(Some(Arg {
                            param,
                            value: Some(value),
                        }));
                    }

                    Ok(Some(Arg {
                        param,
                        value: Some(arg),
                    }))
                } else {
                    Err(self.err(arg, None, None, ArgError::InvalidArgument))
                }
            }
        }
    }

    fn chainging(&mut self, state: Chaining<'a>) -> Result<Option<Arg<'p, 'a, Id>>, ArgError> {
        let arg = state.arg;
        let index = state.index;
        let next_index = index + 1;

        // Copy the slice ref so `&mut self` is free inside the loop.
        let params = self.params;
        for param in params {
            let Some(short) = param.names.short else {
                continue;
            };
            if short != arg[index] {
                continue;
            }

            // Before we return, we have to set the new state of the clap.
            // (Hoisting this above the returns is fine — every path
            // below returns, and nothing between here and those returns reads
            // `self.state`.)
            if arg.len() <= next_index || param.takes_value != clap::Values::None {
                self.state = State::Normal;
            } else {
                self.state = State::Chaining(Chaining {
                    arg,
                    index: next_index,
                });
            }

            let next_is_eql = if next_index < arg.len() {
                arg[next_index] == b'='
            } else {
                false
            };
            if param.takes_value == clap::Values::None
                || param.takes_value == clap::Values::OneOptional
            {
                if next_is_eql && param.takes_value == clap::Values::None {
                    return Err(self.err(arg, Some(short), None, ArgError::DoesntTakeValue));
                }
                return Ok(Some(Arg { param, value: None }));
            }

            if arg.len() <= next_index {
                let value = match self.iter.next() {
                    Some(v) => v,
                    None => {
                        return Err(self.err(arg, Some(short), None, ArgError::MissingValue));
                    }
                };

                return Ok(Some(Arg {
                    param,
                    value: Some(value),
                }));
            }

            if next_is_eql {
                return Ok(Some(Arg {
                    param,
                    value: Some(&arg[next_index + 1..]),
                }));
            }

            return Ok(Some(Arg {
                param,
                value: Some(&arg[next_index..]),
            }));
        }

        Err(self.err(arg, Some(arg[index]), None, ArgError::InvalidArgument))
    }

    fn positional_param(&mut self) -> Option<&'p clap::Param<Id>> {
        if let Some(p) = self.positional {
            return Some(p);
        }

        for param in self.params {
            if param.names.long.is_some() {
                continue;
            }
            if param.names.short.is_some() {
                continue;
            }

            self.positional = Some(param);
            return Some(param);
        }

        None
    }

    fn parse_next_arg(&mut self) -> Result<Option<ArgInfo<'a>>, ArgError> {
        let Some(mut full_arg) = self.iter.next() else {
            return Ok(None);
        };
        // Only flag-shaped tokens reach here (option values and `--` targets are pulled straight
        // off `iter`); restrict rewrites so a mapping never touches `-`/`--` or a positional,
        // per the contract on `ParseOptions::short_aliases`.
        if full_arg.starts_with(b"-") && full_arg != b"-" && full_arg != b"--" {
            for (from, to) in self.short_aliases {
                let value_is_next_arg = from
                    .strip_prefix(full_arg)
                    .and_then(|rest| rest.strip_prefix(b"="))
                    .is_some_and(|value| self.iter.remain().first() == Some(&value));
                if value_is_next_arg {
                    let _ = self.iter.next();
                }
                if value_is_next_arg || full_arg == *from {
                    full_arg = to;
                    break;
                }
            }
            if full_arg.is_empty() {
                return self.parse_next_arg();
            }
        }
        if full_arg == b"--" || full_arg == b"-" {
            return Ok(Some(ArgInfo {
                arg: full_arg,
                kind: ArgKind::Positional,
            }));
        }
        if full_arg.starts_with(b"--") {
            if self.unknown_long_flags_are_positional {
                let name = &full_arg[2..];
                let name = &name[..strings::index_of_char_usize(name, b'=').unwrap_or(name.len())];
                if !self
                    .params
                    .iter()
                    .any(|param| param.names.matches_long(name))
                {
                    return Ok(Some(ArgInfo {
                        arg: full_arg,
                        kind: ArgKind::Positional,
                    }));
                }
            }
            return Ok(Some(ArgInfo {
                arg: &full_arg[2..],
                kind: ArgKind::Long,
            }));
        }
        if full_arg.starts_with(b"-") {
            return Ok(Some(ArgInfo {
                arg: &full_arg[1..],
                kind: ArgKind::Short,
            }));
        }

        Ok(Some(ArgInfo {
            arg: full_arg,
            kind: ArgKind::Positional,
        }))
    }

    fn err(&mut self, arg: &[u8], short: Option<u8>, long: Option<&[u8]>, e: ArgError) -> ArgError {
        if let Some(d) = self.diagnostic.as_deref_mut() {
            // `Diagnostic` owns
            // its bytes (error path only) — see lib.rs.
            d.arg = arg.to_vec();
            d.short = short;
            d.long = long.map(|l| l.to_vec());
        }
        e
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::args;

    fn test_no_err(
        params: &[clap::Param<u8>],
        args_strings: &[&[u8]],
        results: &[Arg<'_, '_, u8>],
    ) {
        let mut iter = args::SliceIterator {
            remain: args_strings,
        };
        let mut c = StreamingClap::<u8, args::SliceIterator> {
            short_aliases: &[],
            unknown_long_flags_are_positional: false,
            unknown_long_flags_are_errors: false,
            ignored_long_flags: Default::default(),
            params,
            iter: &mut iter,
            state: State::Normal,
            positional: None,
            diagnostic: None,
        };

        for res in results {
            let arg = c
                .next()
                .expect("unreachable")
                .unwrap_or_else(|| unreachable!());
            assert!(core::ptr::eq(res.param, arg.param));
            let Some(expected_value) = res.value else {
                assert_eq!(None::<&[u8]>, arg.value);
                continue;
            };
            let actual_value = arg.value.unwrap_or_else(|| unreachable!());
            assert_eq!(expected_value, actual_value);
        }

        if c.next().expect("unreachable").is_some() {
            unreachable!();
        }
    }

    fn test_err(params: &[clap::Param<u8>], args_strings: &[&[u8]], expected: &[u8]) {
        let mut diag = clap::Diagnostic::default();
        let mut iter = args::SliceIterator {
            remain: args_strings,
        };
        let mut c = StreamingClap::<u8, args::SliceIterator> {
            short_aliases: &[],
            unknown_long_flags_are_positional: false,
            unknown_long_flags_are_errors: false,
            ignored_long_flags: Default::default(),
            params,
            iter: &mut iter,
            state: State::Normal,
            positional: None,
            diagnostic: Some(&mut diag),
        };
        loop {
            match c.next() {
                Ok(Some(_)) => {}
                Ok(None) => break,
                Err(_err) => {
                    // Bun's `Diagnostic::report` deliberately ignores its writer arg
                    // and routes through `bun_core::Output` (stderr),
                    // so the rendered message can't be captured here.
                    // Instead, rebuild the flag name the
                    // same way `report` does from the diagnostic fields and assert
                    // the expected message names it in quotes.
                    let mut name_buf = [0u8; 1024];
                    let captured: &[u8] = if let Some(s) = diag.short {
                        name_buf[0] = b'-';
                        name_buf[1] = s;
                        &name_buf[..2]
                    } else if let Some(l) = diag.long.as_deref() {
                        name_buf[0] = b'-';
                        name_buf[1] = b'-';
                        name_buf[2..2 + l.len()].copy_from_slice(l);
                        &name_buf[..2 + l.len()]
                    } else {
                        &diag.arg
                    };
                    let quoted = [b"'".as_slice(), captured, b"'"].concat();
                    // Naive search: `cargo test -p bun_clap` does not link the
                    // highway kernels behind `bun_core::strings::contains`.
                    assert!(
                        (0..expected.len()).any(|i| expected[i..].starts_with(&quoted)),
                        "expected message {:?} does not name captured arg {:?}",
                        bstr::BStr::new(expected),
                        bstr::BStr::new(captured),
                    );
                    return;
                }
            }
        }

        assert!(false);
    }

    #[test]
    fn short_params() {
        let params: [clap::Param<u8>; 4] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    short: Some(b'a'),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                names: clap::Names {
                    short: Some(b'b'),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 2,
                names: clap::Names {
                    short: Some(b'c'),
                    ..Default::default()
                },
                takes_value: clap::Values::One,
                ..Default::default()
            },
            clap::Param {
                id: 3,
                names: clap::Names {
                    short: Some(b'd'),
                    ..Default::default()
                },
                takes_value: clap::Values::Many,
                ..Default::default()
            },
        ];

        let a = &params[0];
        let b = &params[1];
        let c = &params[2];
        let d = &params[3];

        test_no_err(
            &params,
            &[
                b"-a", b"-b", b"-ab", b"-ba", b"-c", b"0", b"-c=0", b"-ac", b"0", b"-ac=0", b"-d=0",
            ],
            &[
                Arg {
                    param: a,
                    value: None,
                },
                Arg {
                    param: b,
                    value: None,
                },
                Arg {
                    param: a,
                    value: None,
                },
                Arg {
                    param: b,
                    value: None,
                },
                Arg {
                    param: b,
                    value: None,
                },
                Arg {
                    param: a,
                    value: None,
                },
                Arg {
                    param: c,
                    value: Some(b"0"),
                },
                Arg {
                    param: c,
                    value: Some(b"0"),
                },
                Arg {
                    param: a,
                    value: None,
                },
                Arg {
                    param: c,
                    value: Some(b"0"),
                },
                Arg {
                    param: a,
                    value: None,
                },
                Arg {
                    param: c,
                    value: Some(b"0"),
                },
                Arg {
                    param: d,
                    value: Some(b"0"),
                },
            ],
        );
    }

    #[test]
    fn long_params() {
        let params: [clap::Param<u8>; 4] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                names: clap::Names {
                    long: Some(b"bb"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 2,
                names: clap::Names {
                    long: Some(b"cc"),
                    ..Default::default()
                },
                takes_value: clap::Values::One,
                ..Default::default()
            },
            clap::Param {
                id: 3,
                names: clap::Names {
                    long: Some(b"dd"),
                    ..Default::default()
                },
                takes_value: clap::Values::Many,
                ..Default::default()
            },
        ];

        let aa = &params[0];
        let bb = &params[1];
        let cc = &params[2];
        let dd = &params[3];

        test_no_err(
            &params,
            &[b"--aa", b"--bb", b"--cc", b"0", b"--cc=0", b"--dd=0"],
            &[
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: bb,
                    value: None,
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: dd,
                    value: Some(b"0"),
                },
            ],
        );
    }

    #[test]
    fn positional_params() {
        let params: [clap::Param<u8>; 1] = [clap::Param {
            id: 0,
            takes_value: clap::Values::One,
            ..Default::default()
        }];

        test_no_err(
            &params,
            &[b"aa", b"bb"],
            &[
                Arg {
                    param: &params[0],
                    value: Some(b"aa"),
                },
                Arg {
                    param: &params[0],
                    value: Some(b"bb"),
                },
            ],
        );
    }

    #[test]
    fn all_params() {
        let params: [clap::Param<u8>; 4] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    short: Some(b'a'),
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                names: clap::Names {
                    short: Some(b'b'),
                    long: Some(b"bb"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 2,
                names: clap::Names {
                    short: Some(b'c'),
                    long: Some(b"cc"),
                    ..Default::default()
                },
                takes_value: clap::Values::One,
                ..Default::default()
            },
            clap::Param {
                id: 3,
                takes_value: clap::Values::One,
                ..Default::default()
            },
        ];

        let aa = &params[0];
        let bb = &params[1];
        let cc = &params[2];
        let positional = &params[3];

        test_no_err(
            &params,
            &[
                b"-a",
                b"-b",
                b"-ab",
                b"-ba",
                b"-c",
                b"0",
                b"-c=0",
                b"-ac",
                b"0",
                b"-ac=0",
                b"--aa",
                b"--bb",
                b"--cc",
                b"0",
                b"--cc=0",
                b"something",
                b"-",
                b"--",
                b"--cc=0",
                b"-a",
            ],
            &[
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: bb,
                    value: None,
                },
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: bb,
                    value: None,
                },
                Arg {
                    param: bb,
                    value: None,
                },
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: aa,
                    value: None,
                },
                Arg {
                    param: bb,
                    value: None,
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: cc,
                    value: Some(b"0"),
                },
                Arg {
                    param: positional,
                    value: Some(b"something"),
                },
                Arg {
                    param: positional,
                    value: Some(b"-"),
                },
                Arg {
                    param: positional,
                    value: Some(b"--cc=0"),
                },
                Arg {
                    param: positional,
                    value: Some(b"-a"),
                },
            ],
        );
    }

    #[test]
    fn errors() {
        let params: [clap::Param<u8>; 2] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    short: Some(b'a'),
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                names: clap::Names {
                    short: Some(b'c'),
                    long: Some(b"cc"),
                    ..Default::default()
                },
                takes_value: clap::Values::One,
                ..Default::default()
            },
        ];
        test_err(&params, &[b"q"], b"Invalid argument 'q'\n");
        test_err(&params, &[b"-q"], b"Invalid argument '-q'\n");
        // Unrecognized long flags are skipped (opt-in warning), not errors.
        test_no_err(&params, &[b"--q"], &[]);
        test_no_err(&params, &[b"--q=1"], &[]);
        test_err(
            &params,
            &[b"-a=1"],
            b"The argument '-a' does not take a value\n",
        );
        test_err(
            &params,
            &[b"--aa=1"],
            b"The argument '--aa' does not take a value\n",
        );
        test_err(
            &params,
            &[b"-c"],
            b"The argument '-c' requires a value but none was supplied\n",
        );
        test_err(
            &params,
            &[b"--cc"],
            b"The argument '--cc' requires a value but none was supplied\n",
        );
    }

    #[test]
    fn unknown_long_flags_are_positional() {
        let params: [clap::Param<u8>; 2] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                takes_value: clap::Values::Many,
                ..Default::default()
            },
        ];
        let args: &[&[u8]] = &[b"--q", b"x", b"--aa", b"--q=1", b"--", b"--aa"];
        let mut iter = args::SliceIterator { remain: args };
        let mut c = StreamingClap::<u8, args::SliceIterator> {
            short_aliases: &[],
            unknown_long_flags_are_positional: true,
            unknown_long_flags_are_errors: false,
            ignored_long_flags: Default::default(),
            params: &params,
            iter: &mut iter,
            state: State::Normal,
            positional: None,
            diagnostic: None,
        };
        let mut seen: Vec<(u8, Option<&[u8]>)> = Vec::new();
        while let Some(arg) = c.next().expect("unreachable") {
            seen.push((arg.param.id, arg.value));
        }
        let expected: &[(u8, Option<&[u8]>)] = &[
            (1, Some(b"--q")),
            (1, Some(b"x")),
            (0, None),
            (1, Some(b"--q=1")),
            (1, Some(b"--aa")),
        ];
        assert_eq!(expected, &seen[..]);
    }

    #[test]
    fn short_aliases() {
        let params: [clap::Param<u8>; 2] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                takes_value: clap::Values::Many,
                ..Default::default()
            },
        ];
        let args: &[&[u8]] = &[
            b"--b", b"x", b"--c=1", b"--c", b"1", b"--c", b"2", b"--d", b"--e=1", b"--e", b"1",
            b"--", b"--b",
        ];
        let mut iter = args::SliceIterator { remain: args };
        let mut c = StreamingClap::<u8, args::SliceIterator> {
            short_aliases: &[
                (b"--b", b"--aa"),
                (b"--c=1", b"--aa"),
                (b"--d", b""),
                (b"--e=1", b""),
            ],
            unknown_long_flags_are_positional: true,
            unknown_long_flags_are_errors: false,
            ignored_long_flags: Default::default(),
            params: &params,
            iter: &mut iter,
            state: State::Normal,
            positional: None,
            diagnostic: None,
        };
        let mut seen: Vec<(u8, Option<&[u8]>)> = Vec::new();
        while let Some(arg) = c.next().expect("unreachable") {
            seen.push((arg.param.id, arg.value));
        }
        let expected: &[(u8, Option<&[u8]>)] = &[
            (0, None),
            (1, Some(b"x")),
            (0, None),
            (0, None),
            (1, Some(b"--c")),
            (1, Some(b"2")),
            (1, Some(b"--b")),
        ];
        assert_eq!(expected, &seen[..]);
    }

    #[test]
    fn unknown_long_flags_are_errors() {
        let params: [clap::Param<u8>; 2] = [
            clap::Param {
                id: 0,
                names: clap::Names {
                    long: Some(b"aa"),
                    ..Default::default()
                },
                ..Default::default()
            },
            clap::Param {
                id: 1,
                takes_value: clap::Values::Many,
                ..Default::default()
            },
        ];
        let parse = |args: &[&[u8]]| {
            let mut diag = clap::Diagnostic::default();
            let mut iter = args::SliceIterator { remain: args };
            let mut c = StreamingClap::<u8, args::SliceIterator> {
                short_aliases: &[],
                unknown_long_flags_are_positional: false,
                unknown_long_flags_are_errors: true,
                ignored_long_flags: Default::default(),
                params: &params,
                iter: &mut iter,
                state: State::Normal,
                positional: None,
                diagnostic: Some(&mut diag),
            };
            loop {
                match c.next() {
                    Ok(Some(_)) => {}
                    Ok(None) => return None,
                    Err(err) => {
                        assert_eq!(err, ArgError::InvalidArgument);
                        break;
                    }
                }
            }
            diag.long().map(<[u8]>::to_vec)
        };
        assert_eq!(parse(&[b"--aa", b"x", b"--", b"--q"]), None);
        assert_eq!(parse(&[b"x", b"--q", b"y"]), Some(b"q".to_vec()));
        assert_eq!(parse(&[b"--q=1"]), Some(b"q".to_vec()));
    }
}
