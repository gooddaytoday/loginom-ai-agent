#![warn(unused_must_use)]
use bun_core::{self, Output};

pub mod args;
pub mod comptime;
pub mod error;
pub mod streaming;

pub use comptime::{ComptimeClap, ConvertedTable};
pub use error::{Error, Result};

// Proc-macro backend — do not call these directly; use `parse_param!` / `param!` /
// `parse_params!` below, which inject `$crate` so the expansion resolves `Param`/
// `Help`/`Names`/`Values` regardless of how `bun_clap` is aliased at the call site.
#[doc(hidden)]
pub use bun_clap_macros::{__parse_param_impl, __parse_params_impl};

/// Parse a single param spec string (e.g. `"-h, --help  Display this help"`)
/// into a const `Param<Help>` literal at compile time.
///
/// The argument **must** be a string literal; parse errors surface as compile
/// errors at the call site.
#[macro_export]
macro_rules! parse_param {
    ($lit:literal $(,)?) => {
        $crate::__parse_param_impl!($crate, $lit)
    };
}

/// Alias for [`parse_param!`].
#[macro_export]
macro_rules! param {
    ($lit:literal $(,)?) => {
        $crate::__parse_param_impl!($crate, $lit)
    };
}

/// Const-time `Param<Help>` slice concatenation
/// over param tables. Produces a `&'static [Param<Help>]`
/// baked into rodata; no `LazyLock`, no heap, no init closure in `.text`.
///
/// Every `$part` must be a `const`-evaluable `&[Param<Help>]` (a `const` item or
/// `&[literal, …]`); referencing a `static` is rejected by const-eval (E0013).
#[macro_export]
macro_rules! concat_params {
    ($($part:expr),* $(,)?) => {{
        const __PARTS: &[&[$crate::Param<$crate::Help>]] = &[$($part),*];
        const __ARR: [$crate::Param<$crate::Help>; $crate::__param_slices_len(__PARTS)] =
            $crate::__param_slices_concat::<{ $crate::__param_slices_len(__PARTS) }>(__PARTS);
        &__ARR
    }};
}

/// Build a `&'static ConvertedTable` from a const-evaluable
/// `&[Param<Help>]` at compile time. The converted `[Param<usize>; N]`
/// array, the three category counts, the short-name index, *and* the sorted
/// long-name hash index all land in rodata, so [`parse_with_table`] does no
/// heap allocation, no sorting, no locking, and `args.flag(b"--foo")`
/// resolves via O(log n) binary search at runtime (or O(1) when paired with
/// [`comptime::find_param_index`] inside `const { }`).
///
/// ```ignore
/// pub const AUTO_PARAMS: &[Param<Help>] = concat_params!(...);
/// pub static AUTO_TABLE: &ConvertedTable = comptime_table!(AUTO_PARAMS);
/// ```
///
/// Pass `, cold` for every table off the trivial-script / `bun --version`
/// cold-start path (`bun run` / `bun build` / `bun test` / `bun install` /
/// `bun pm` / `bun x` / …) so it stays in plain `.rodata` instead of padding
/// the contiguous `.rodata.startup` run (see the per-arm notes below):
///
/// ```ignore
/// pub static RUN_TABLE: &ConvertedTable = comptime_table!(RUN_PARAMS, cold);
/// ```
#[macro_export]
macro_rules! comptime_table {
    // Hot table — the default-command param table that `bun <file>` and
    // `bun --version` dereference on cold start. Cluster every nested `__CONV` /
    // `__LONG` / `__TABLE` static into `.rodata.startup`: with
    // `-Zfunction-sections` each `static` otherwise lands in its own
    // `.rodata.<sym>` input section that fat-LTO emits in crate-alphabetical
    // order — one minor fault per scattered table on first touch. Pinning them
    // adjacent lets the trivial-script cold path fault the converted arrays,
    // long-name index, and `ConvertedTable` header in with one shared
    // fault-around window. Non-PIE `bun` has zero runtime relocations, so these
    // stay in plain rodata even with the `&'static [u8]` help strings they point
    // at. Linux-only: the section-name syntax is ELF-specific. Use sparingly —
    // only `AUTO_TABLE` should take this arm; everything else passes `, cold`.
    ($params:expr) => {
        $crate::comptime_table!(
            @build
            { #[cfg_attr(any(target_os = "linux", target_os = "android"), unsafe(link_section = ".rodata.startup"))] }
            $params
        )
    };
    // Cold tables — `bun run` / `bun build` / `bun test` / `bun install` /
    // `bun pm` / `bun x` and friends. `.rodata.startup` is deliberately one
    // contiguous block faulted in with a single read-around on every cold start
    // (including `bun --version`); padding it with param tables those paths
    // never touch only grows that run. Leave these in plain `.rodata` —
    // `src/startup.order` still clusters the ones a sampled cold path hits.
    ($params:expr, cold) => {
        $crate::comptime_table!(@build { } $params)
    };
    (@build { $(#[$attr:meta])* } $params:expr) => {{
        const __P: &[$crate::Param<$crate::Help>] = $params;
        const __N: usize = __P.len();
        $(#[$attr])*
        static __CONV: [$crate::Param<usize>; __N] =
            $crate::comptime::convert_params_array::<$crate::Help, __N>(__P);
        const __M: usize = $crate::comptime::count_long_entries(__P);
        $(#[$attr])*
        static __LONG: [$crate::comptime::LongEntry; __M] =
            $crate::comptime::build_long_index::<$crate::Help, __M>(__P);
        $(#[$attr])*
        static __TABLE: $crate::ConvertedTable = $crate::ConvertedTable::from_const(
            &__CONV,
            $crate::comptime::count_flags(__P),
            $crate::comptime::count_single(__P),
            $crate::comptime::count_multi(__P),
            &__LONG,
        );
        &__TABLE
    }};
}

#[doc(hidden)]
pub const fn __param_slices_len(parts: &[&[Param<Help>]]) -> usize {
    let mut n = 0;
    let mut i = 0;
    while i < parts.len() {
        n += parts[i].len();
        i += 1;
    }
    n
}

#[doc(hidden)]
pub const fn __param_slices_concat<const N: usize>(parts: &[&[Param<Help>]]) -> [Param<Help>; N] {
    // Placeholder element for the pre-fill; every slot is overwritten below.
    const DUMMY: Param<Help> = Param {
        id: Help {
            msg: b"",
            msg_plain: b"",
            value: b"",
        },
        names: Names {
            short: None,
            long: None,
            long_aliases: &[],
        },
        takes_value: Values::None,
    };
    let mut out = [DUMMY; N];
    let mut idx = 0;
    let mut i = 0;
    while i < parts.len() {
        let part = parts[i];
        let mut j = 0;
        while j < part.len() {
            out[idx] = part[j];
            idx += 1;
            j += 1;
        }
        i += 1;
    }
    // Const-eval panic (build error) if the caller's `N` undercounts.
    assert!(idx == N);
    out
}

/// Parse a `;`-separated list of param spec strings into a
/// `&'static [Param<Help>]` at compile time.
///
/// ```ignore
/// static PARAMS: &[Param<Help>] = parse_params! {
///     "-h, --help          Display this help";
///     "-v, --version       Print the version";
/// };
/// ```
#[macro_export]
macro_rules! parse_params {
    ($($lit:literal);* $(;)?) => {
        $crate::__parse_params_impl!($crate, $($lit);*)
    };
}

/// The names a `Param` can have.
#[derive(Clone, Copy, Default)]
pub struct Names {
    /// '-' prefix
    pub short: Option<u8>,

    /// '--' prefix (primary name, used for display/help)
    pub long: Option<&'static [u8]>,

    /// Additional '--' prefixed aliases (e.g., --grep as alias for --test-name-pattern)
    pub long_aliases: &'static [&'static [u8]],
}

impl Names {
    /// Check if the given name matches the primary long name or any alias
    pub fn matches_long(&self, name: &[u8]) -> bool {
        if let Some(l) = self.long {
            if name == l {
                return true;
            }
        }
        for alias in self.long_aliases {
            if name == *alias {
                return true;
            }
        }
        false
    }
}

/// Whether a param takes no value (a flag), one value, or can be specified multiple times.
#[repr(u8)]
#[derive(Clone, Copy, PartialEq, Eq, Default, Debug)]
pub enum Values {
    #[default]
    None,
    One,
    Many,
    OneOptional,
}

/// Represents a parameter for the command line.
/// Parameters come in three kinds:
///   * Short ("-a"): Should be used for the most commonly used parameters in your program.
///     * They can take a value three different ways.
///       * "-a value"
///       * "-a=value"
///       * "-avalue"
///     * They chain if they don't take values: "-abc".
///       * The last given parameter can take a value in the same way that a single parameter can:
///         * "-abc value"
///         * "-abc=value"
///         * "-abcvalue"
///   * Long ("--long-param"): Should be used for less common parameters, or when no single
///     character can describe the paramter.
///     * They can take a value two different ways.
///       * "--long-param value"
///       * "--long-param=value"
///   * Positional: Should be used as the primary parameter of the program, like a filename or
///     an expression to parse.
///     * Positional parameters have both names.long and names.short == None.
///     * Positional parameters must take a value.
#[derive(Clone, Copy)]
pub struct Param<Id> {
    pub id: Id,
    pub names: Names,
    pub takes_value: Values,
}

impl<Id: Default> Default for Param<Id> {
    fn default() -> Self {
        Self {
            id: Id::default(),
            names: Names::default(),
            takes_value: Values::None,
        }
    }
}

// NOTE: the runtime spec parser (`fn parse_param` / `parse_long_names` /
// `parse_param_rest` / `ParseParamError` / `TokenizeAny`) was removed — the
// canonical implementation lives in `bun_clap_macros` and runs at compile time
// via `parse_param!` / `param!` / `parse_params!` above. All param specs are
// string literals, so there is no runtime caller.

#[cfg(test)]
fn expect_param(expect: Param<Help>, actual: Param<Help>) {
    assert_eq!(expect.id.msg, actual.id.msg);
    assert_eq!(expect.id.value, actual.id.value);
    assert_eq!(expect.names.short, actual.names.short);
    assert_eq!(expect.takes_value, actual.takes_value);
    if let Some(long) = expect.names.long {
        assert_eq!(long, actual.names.long.unwrap());
    } else {
        assert_eq!(None::<&[u8]>, actual.names.long);
    }
}

/// Optional diagnostics used for reporting useful errors
// Borrowing `arg`/`name.long` from the arg iterator would tie
// that lifetime through `&mut Diagnostic` with invariance headaches, and this is
// an error-path-only struct, so it owns its bytes instead. The `name: Names` field
// is flattened to `short`/`long` because `Names.long` is `&'static`.
#[derive(Default)]
pub struct Diagnostic {
    pub(crate) arg: Vec<u8>,
    pub(crate) short: Option<u8>,
    pub(crate) long: Option<Vec<u8>>,
}

impl Diagnostic {
    /// Without the dashes.
    pub fn long(&self) -> Option<&[u8]> {
        self.long.as_deref()
    }

    /// Default diagnostics reporter when all you want is English with no colors.
    /// Use this as a reference for implementing your own if needed.
    ///
    /// Error path only — never reached on the trivial-script / `bun -p` cold
    /// start. `#[cold]` + `#[inline(never)]` so the formatting machinery lands
    /// in `.text.unlikely`, away from the cold-start working set.
    #[cold]
    #[inline(never)]
    pub fn report<W>(&self, _stream: W, err: crate::Error) -> crate::Result<()> {
        let mut name_buf = [0u8; 1024];
        let name: &[u8] = if let Some(s) = self.short {
            name_buf[0] = b'-';
            name_buf[1] = s;
            name_buf[2] = 0;
            &name_buf[0..2]
        } else if let Some(l) = self.long.as_deref() {
            name_buf[0] = b'-';
            name_buf[1] = b'-';
            let long = &l[0..l.len().min(name_buf.len() - 2)];
            name_buf[2..][0..long.len()].copy_from_slice(long);
            &name_buf[0..2 + long.len()]
        } else {
            &self.arg
        };

        let name = bstr::BStr::new(name);
        match err {
            crate::Error::DoesntTakeValue => bun_core::pretty_errorln!(
                "<red>error<r><d>:<r> The argument '{}' does not take a value.",
                name
            ),
            crate::Error::MissingValue => bun_core::pretty_errorln!(
                "<red>error<r><d>:<r> The argument '{}' requires a value but none was supplied.",
                name
            ),
            crate::Error::InvalidArgument => {
                bun_core::pretty_errorln!("<red>error<r><d>:<r> Invalid Argument '{}'", name)
            }
        }
        bun_core::Output::flush();
        Ok(())
    }
}

#[derive(Clone, Copy)]
pub struct Help {
    /// The description text exactly as written in the param spec — may still
    /// contain `<tag>` colour markup. Source for the ANSI form built lazily
    /// by [`pretty_help_desc`] on the `bun --help` colour path.
    pub msg: &'static [u8],
    /// `msg` with `<tag>` colour markup stripped — the non-TTY / piped help form.
    /// Precomputed at compile time by `parse_param!` (the strip is the only
    /// transform that needs to be ready without a TTY); the ANSI-coloured form is
    /// derived from `msg` on demand instead of being baked into rodata.
    pub msg_plain: &'static [u8],
    pub value: &'static [u8],
}

impl Default for Help {
    fn default() -> Self {
        Self {
            msg: b"",
            msg_plain: b"",
            value: b"",
        }
    }
}

/// Options that can be set to customize the behavior of parsing.
#[derive(Default)]
pub struct ParseOptions<'a> {
    pub diagnostic: Option<&'a mut Diagnostic>,
    pub stop_after_positional_at: usize,
    /// Whole-token rewrites applied only where a token is being classified as a
    /// flag, never to an option's value or a `--` target. Node keeps its own
    /// aliases on exactly that branch (node_options-inl.h).
    /// An alias written as `--name=value` also matches the two tokens `--name value`. An empty
    /// replacement removes the flag from the arguments.
    pub short_aliases: &'static [(&'static [u8], &'static [u8])],
    /// A `--flag` or `--flag=value` that no param names is a positional, with its dashes, in its
    /// place among the others. For a command that hands flags on: `bun check --strict`. Otherwise
    /// such a flag is skipped.
    pub unknown_long_flags_are_positional: bool,
    /// Such a flag fails the parse, unless it comes from `BUN_OPTIONS`, which applies to every
    /// command.
    pub unknown_long_flags_are_errors: bool,
    pub ignored_long_flags: IgnoredLongFlags,
}

/// Long flags, written without the dashes, that are skipped instead of failing the parse when
/// `unknown_long_flags_are_errors` is set.
#[derive(Default, Clone, Copy)]
pub struct IgnoredLongFlags {
    /// Skips `--name`, `--no-name`, `--name=value`, `--name true` and `--name false`.
    pub flags: &'static [&'static [u8]],
    /// Skips `--name=value` and `--name value`, unless `value` starts with a dash. Also skips
    /// `--no-name`, like for the command's own flags.
    pub options: &'static [&'static [u8]],
    /// Skips every `--name` and `--name=value` whose name starts with one of these.
    pub prefixes: &'static [&'static [u8]],
}

impl IgnoredLongFlags {
    /// Returns `None` if `--name` isn't skipped. Otherwise returns whether `next`, the argument
    /// after it, is its value. `is_own_flag` tells whether the command has a flag of that name.
    pub fn value_is_next_arg(
        &self,
        name: &[u8],
        next: &[u8],
        is_own_flag: impl Fn(&[u8]) -> bool,
    ) -> Option<bool> {
        if self.options.contains(&name) {
            return Some(!next.starts_with(b"-"));
        }
        if self.flags.contains(&name)
            || name.strip_prefix(b"no-").is_some_and(|positive| {
                self.flags.contains(&positive)
                    || self.options.contains(&positive)
                    || (!self.flags.is_empty() && is_own_flag(positive))
            })
        {
            return Some(next == b"true" || next == b"false");
        }
        (self.prefixes.iter())
            .any(|prefix| name.starts_with(prefix))
            .then_some(false)
    }
}

// Help/usage/error rendering — none of this is on the cold-start hot chain
// (`bun -p '1+1'` / `bun --version` / plain `bun <file>` never call into the
// help or diagnostics path). Mark every entry point `#[cold]` + `#[inline(never)]`
// so rustc emits them in `.text.unlikely.*` sections that the linker clusters
// together, keeping them out of the pages faulted in on a normal invocation.
#[cold]
#[inline(never)]
fn get_help_simple(param: &Param<Help>) -> &'static [u8] {
    param.id.msg
}

/// The param description with `<tag>` colour markup resolved — ANSI escapes when
/// stdout is a colour-capable TTY, stripped otherwise.
///
/// The tag-stripped form ([`Help::msg_plain`]) is precomputed in rodata; the
/// ANSI form is *not* — it is rewritten from [`Help::msg`] here, only when colour
/// output is actually requested. That `<tag>`→ANSI rewrite only ever runs on
/// `bun --help` / `bun run --help`; `--print` and ordinary runs never reach this
/// path, so they pay neither the per-invocation reparse nor the extra rodata a
/// baked-in `msg_ansi` array would cost on every flag and subcommand. (The
/// colour case is rare enough that doing the rewrite
/// lazily at runtime is the better trade for binary size.)
#[cold]
#[inline(never)]
#[allow(clippy::disallowed_methods)] // template is a runtime help-string parameter
fn pretty_help_desc(param: &Param<Help>) -> std::borrow::Cow<'static, [u8]> {
    if Output::enable_ansi_colors_stdout() {
        std::borrow::Cow::Owned(bun_core::output::pretty_fmt_runtime(param.id.msg, true))
    } else {
        std::borrow::Cow::Borrowed(param.id.msg_plain)
    }
}

pub struct Args<Id: 'static> {
    pub(crate) clap: ComptimeClap<Id>,
}

impl<Id: 'static> Args<Id> {
    pub fn flag(&self, name: &'static [u8]) -> bool {
        self.clap.flag(name)
    }

    pub fn option(&self, name: &'static [u8]) -> Option<&'static [u8]> {
        self.clap.option(name)
    }

    pub fn options(&self, name: &'static [u8]) -> &[&'static [u8]] {
        self.clap.options(name)
    }

    /// Returns true if the parameter was passed. Works for flags and for parameters that take
    /// values.
    pub fn has(&self, name: &'static [u8]) -> bool {
        self.clap.has(name)
    }

    pub fn positionals(&self) -> &[&'static [u8]] {
        self.clap.positionals()
    }

    pub fn remaining(&self) -> &[&'static [u8]] {
        self.clap.remaining()
    }
}

/// Same as `parse_ex` but uses the `args::OsIterator` by default.
///
/// **Cold path** — the startup hot set uses [`parse_with_table`] against a
/// rodata [`comptime_table!`]. This entry point performs a runtime conversion
/// (`ConvertedTable::for_params`) and is only used by non-startup commands
/// (`bun install`, `bun create`), so it's `#[cold]` + `#[inline(never)]`.
#[cold]
#[inline(never)]
pub fn parse<Id: 'static>(
    params: &'static [Param<Id>],
    opt: ParseOptions<'_>,
) -> crate::Result<Args<Id>> {
    let mut iter = args::OsIterator::init();

    let clap = parse_ex::<Id, _>(
        params,
        &mut iter,
        ParseOptions {
            diagnostic: opt.diagnostic,
            stop_after_positional_at: opt.stop_after_positional_at,
            short_aliases: opt.short_aliases,
            unknown_long_flags_are_positional: opt.unknown_long_flags_are_positional,
            unknown_long_flags_are_errors: opt.unknown_long_flags_are_errors,
            ignored_long_flags: opt.ignored_long_flags,
        },
    )?;
    Ok(Args { clap })
}

/// Same as [`parse`] but takes a pre-converted rodata [`ConvertedTable`]
/// (built via [`comptime_table!`]). This is the zero-runtime-conversion entry
/// point — no Vec/sort/lock on the startup path.
pub fn parse_with_table<Id: 'static>(
    table: &'static ConvertedTable,
    opt: ParseOptions<'_>,
) -> crate::Result<Args<Id>> {
    let mut iter = args::OsIterator::init();
    let clap = ComptimeClap::<Id>::parse_with_table(
        table,
        &mut iter,
        ParseOptions {
            diagnostic: opt.diagnostic,
            stop_after_positional_at: opt.stop_after_positional_at,
            short_aliases: opt.short_aliases,
            unknown_long_flags_are_positional: opt.unknown_long_flags_are_positional,
            unknown_long_flags_are_errors: opt.unknown_long_flags_are_errors,
            ignored_long_flags: opt.ignored_long_flags,
        },
    )?;
    Ok(Args { clap })
}

/// Parses the command line arguments passed into the program based on an
/// array of `Param`s.
///
/// **Cold path** — see [`parse`]; the startup hot path is [`parse_with_table`].
#[cold]
#[inline(never)]
pub(crate) fn parse_ex<Id: 'static, I>(
    params: &'static [Param<Id>],
    iter: &mut I,
    opt: ParseOptions<'_>,
) -> crate::Result<ComptimeClap<Id>>
where
    I: args::ArgIter<'static>,
{
    ComptimeClap::<Id>::parse(params, iter, opt)
}

#[cold]
#[inline(never)]
pub(crate) fn simple_print_param(param: &Param<Help>) -> crate::Result<()> {
    bun_core::pretty!("\n");
    if let Some(s) = param.names.short {
        if param.takes_value != Values::None && param.names.long.is_none() {
            bun_core::pretty!("  <cyan>-{}<r><d><cyan>=\\<val\\><r>", s as char);
        } else {
            bun_core::pretty!("  <cyan>-{}<r>", s as char);
        }
    } else {
        bun_core::pretty!("    ");
    }
    if let Some(l) = param.names.long {
        if param.names.short.is_some() {
            bun_core::pretty!(", ");
        } else {
            bun_core::pretty!("  ");
        }

        if param.takes_value != Values::None {
            bun_core::pretty!("<cyan>--{}<r><d><cyan>=\\<val\\><r>", bstr::BStr::new(l));
        } else {
            bun_core::pretty!("<cyan>--{}<r>", bstr::BStr::new(l));
        }
    } else {
        bun_core::pretty!("    ");
    }
    Ok(())
}

/// Display width of a single param's flag column: `--long` plus the literal
/// `=<val>` suffix (6 bytes) when it takes a value. Kept in lockstep with
/// `simple_print_param`'s `"=<val>"` literal — change both together.
#[cold]
#[inline(never)]
fn param_display_width(param: &Param<Help>) -> usize {
    let flags_len = param.names.long.map_or(0, |l| l.len());
    let value_len: usize = if param.takes_value != Values::None {
        6
    } else {
        0
    };
    flags_len + value_len
}

#[cold]
#[inline(never)]
fn compute_max_help_spacing(params: &[Param<Help>]) -> usize {
    let mut res: usize = 2;
    for param in params {
        // Params with no help text are hidden (skipped by `simple_help` /
        // `simple_help_bun_top_level`), so they must not widen the column.
        if get_help_simple(param).is_empty() {
            continue;
        }
        res = res.max(param_display_width(param));
    }
    res
}

#[cold]
#[inline(never)]
pub fn simple_help(params: &[Param<Help>]) {
    let max_spacing: usize = compute_max_help_spacing(params);

    for param in params {
        if param.names.short.is_none() && param.names.long.is_none() {
            continue;
        }

        let desc_text = get_help_simple(param);
        if desc_text.is_empty() {
            continue;
        }

        // create a string with spaces_len spaces
        let total_len = param_display_width(param);
        let num_spaces_after = max_spacing - total_len;
        let spaces_after = vec![b' '; num_spaces_after];

        simple_print_param(param).expect("unreachable");
        // `pretty_help_desc` resolves the `<tag>` markup
        // (ANSI on a colour TTY, stripped otherwise) so `--help` output is
        // tag-clean regardless of which helper a command uses.
        let desc = pretty_help_desc(param);
        bun_core::pretty!(
            "  {}  {}",
            bstr::BStr::new(&spaces_after),
            bstr::BStr::new(desc.as_ref()),
        );
    }
}

#[cold]
#[inline(never)]
pub fn simple_help_bun_top_level(params: &[Param<Help>]) {
    // `computed_max_spacing` is not const-evaluable over a
    // slice param, so the overflow check is a runtime debug_assert below.
    const MAX_SPACING: usize = 30;
    const SPACE_BUF: &[u8; MAX_SPACING] = b"                              ";

    let computed_max_spacing: usize = compute_max_help_spacing(params);

    debug_assert!(
        computed_max_spacing <= MAX_SPACING,
        "a parameter is too long to be nicely printed in `bun --help`"
    );

    for param in params {
        if !(param.names.short.is_none() && param.names.long.is_none()) {
            let desc_text = get_help_simple(param);
            if !desc_text.is_empty() {
                simple_print_param(param).expect("unreachable");

                let total_len = param_display_width(param);
                let num_spaces_after = MAX_SPACING - total_len;

                // `pretty_help_desc`
                // resolves the markup (ANSI on a colour TTY, stripped otherwise).
                let desc = pretty_help_desc(param);
                bun_core::pretty!(
                    "{}{}",
                    bstr::BStr::new(&SPACE_BUF[0..num_spaces_after]),
                    bstr::BStr::new(desc.as_ref()),
                );
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_param_test() {
        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"value",
                    ..Default::default()
                },
                names: Names {
                    short: Some(b's'),
                    long: Some(b"long"),
                    ..Default::default()
                },
                takes_value: Values::One,
            },
            parse_param!("-s, --long <value> Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"value",
                    ..Default::default()
                },
                names: Names {
                    short: Some(b's'),
                    long: Some(b"long"),
                    ..Default::default()
                },
                takes_value: Values::Many,
            },
            parse_param!("-s, --long <value>... Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"value",
                    ..Default::default()
                },
                names: Names {
                    long: Some(b"long"),
                    ..Default::default()
                },
                takes_value: Values::One,
            },
            parse_param!("--long <value> Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"value",
                    ..Default::default()
                },
                names: Names {
                    short: Some(b's'),
                    ..Default::default()
                },
                takes_value: Values::One,
            },
            parse_param!("-s <value> Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    ..Default::default()
                },
                names: Names {
                    short: Some(b's'),
                    long: Some(b"long"),
                    ..Default::default()
                },
                ..Default::default()
            },
            parse_param!("-s, --long Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    ..Default::default()
                },
                names: Names {
                    short: Some(b's'),
                    ..Default::default()
                },
                ..Default::default()
            },
            parse_param!("-s Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    ..Default::default()
                },
                names: Names {
                    long: Some(b"long"),
                    ..Default::default()
                },
                ..Default::default()
            },
            parse_param!("--long Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"A | B",
                    ..Default::default()
                },
                names: Names {
                    long: Some(b"long"),
                    ..Default::default()
                },
                takes_value: Values::One,
            },
            parse_param!("--long <A | B> Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"A",
                    ..Default::default()
                },
                names: Names::default(),
                takes_value: Values::One,
            },
            parse_param!("<A> Help text"),
        );

        expect_param(
            Param {
                id: Help {
                    msg: b"Help text",
                    value: b"A",
                    ..Default::default()
                },
                names: Names::default(),
                takes_value: Values::Many,
            },
            parse_param!("<A>... Help text"),
        );

        // Error-case specs ("--long,", "-ss", "-", trailing comma) are now
        // compile errors via the proc-macro and are not assertable at runtime.
    }

    // Compile-time check: the macro output is const-evaluable in a `static`.
    static MACRO_PARAMS: &[Param<Help>] = &[
        parse_param!("-s, --long <value> Help text"),
        parse_param!("-c, --config <STR>?  Specify path to config"),
        parse_param!("--test-name-pattern/--grep <STR>...  Filter tests"),
        parse_param!("<POS> ...  positional"),
        param!("-h, --help  Display this help"),
    ];

    static MACRO_PARAMS_SLICE: &[Param<Help>] = parse_params! {
        "-h, --help          Display this help";
        "-v, --version       Print the version";
        "<POS> ...           ";
    };

    #[test]
    fn parse_param_macro_static_tables() {
        // Static-table sanity.
        assert_eq!(MACRO_PARAMS[0].names.short, Some(b's'));
        assert_eq!(MACRO_PARAMS[0].names.long, Some(b"long" as &[u8]));
        assert_eq!(MACRO_PARAMS[0].id.value, b"value");
        assert_eq!(MACRO_PARAMS[0].takes_value, Values::One);

        assert_eq!(MACRO_PARAMS[1].takes_value, Values::OneOptional);
        assert_eq!(MACRO_PARAMS[1].id.value, b"STR");

        // Aliases — the proc-macro restores the static alias array the runtime parser drops.
        assert_eq!(
            MACRO_PARAMS[2].names.long,
            Some(b"test-name-pattern" as &[u8])
        );
        assert_eq!(MACRO_PARAMS[2].names.long_aliases, &[b"grep" as &[u8]]);
        assert_eq!(MACRO_PARAMS[2].takes_value, Values::Many);

        // Positional.
        assert_eq!(MACRO_PARAMS[3].names.short, None);
        assert_eq!(MACRO_PARAMS[3].names.long, None);
        assert_eq!(MACRO_PARAMS[3].id.value, b"POS");

        // parse_params! slice form.
        assert_eq!(MACRO_PARAMS_SLICE.len(), 3);
        assert_eq!(MACRO_PARAMS_SLICE[0].names.short, Some(b'h'));
        assert_eq!(MACRO_PARAMS_SLICE[0].names.long, Some(b"help" as &[u8]));
        assert_eq!(MACRO_PARAMS_SLICE[1].names.long, Some(b"version" as &[u8]));
        assert_eq!(MACRO_PARAMS_SLICE[2].takes_value, Values::One);
    }

    // Compile-time check: comptime_table!/find_param_index are const-evaluable.
    const CT_PARAMS: &[Param<Help>] = concat_params!(
        &[parse_param!("-h, --help          Display this help")],
        &[parse_param!("-c, --config <STR>  Config")],
        &[parse_param!("--define <K=V>...   Define")],
    );
    static CT_TABLE: &ConvertedTable = comptime_table!(CT_PARAMS);
    const CT_HELP_IDX: usize = comptime::find_param_index(CT_TABLE.converted, b"--help");
    const CT_CONFIG_IDX: usize = comptime::find_param_index(CT_TABLE.converted, b"-c");

    #[test]
    fn comptime_table_const_eval() {
        assert_eq!(CT_TABLE.n_flags, 1);
        assert_eq!(CT_TABLE.n_single, 1);
        assert_eq!(CT_TABLE.n_multi, 1);
        assert_eq!(CT_TABLE.converted[CT_HELP_IDX].id, 0);
        assert_eq!(CT_TABLE.converted[CT_CONFIG_IDX].id, 0);
        assert_eq!(CT_TABLE.converted[CT_CONFIG_IDX].takes_value, Values::One);
    }
}
