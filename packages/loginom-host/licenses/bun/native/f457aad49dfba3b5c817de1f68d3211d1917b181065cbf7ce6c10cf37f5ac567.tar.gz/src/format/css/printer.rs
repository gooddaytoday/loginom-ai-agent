//! Prettier's `printer-postcss.js` and `print/sequence.js`.

use super::Parser as Syntax;
use super::media_query::{MediaKind, MediaNode};
use super::memo::Memo;
use super::misc::{
    adjust_numbers, adjust_strings, ends_with_hex_escape, ends_with_unescaped_backslash,
    last_line_has_inline_comment, maybe_to_lower_case, print_css_number, print_string, print_unit,
    quote_attribute_value, to_lower_case,
};
use super::parse::{Context, CssNode, Params, Parsed, Value};
use super::postcss::{Kind, Node, NodeId, Tree};
use super::selector_parser::{Namespace, SelectorId, SelectorKind, Selectors};
use super::sink::Sink;
use super::value_parser::{Before, ValueId, ValueKind, ValueRef, Values};
use crate::FormatError;
use crate::syntax_error::{Message, SyntaxError};
use crate::text::{self, has_newline_backwards, is_next_line_empty};
use std::borrow::Cow;

/// A node and its chain of ancestors.
#[derive(Copy, Clone)]
pub(crate) struct Scope<'s, 'a> {
    pub(crate) node: &'s CssNode<'a>,
    pub(crate) parent: Option<&'s Scope<'s, 'a>>,
    /// The tree that `node` belongs to.
    tree: &'s Tree,
}

/// The node being printed, with its parsed selectors and values.
#[derive(Copy, Clone)]
pub(crate) struct Statement<'s, 'a> {
    pub(crate) scope: &'s Scope<'s, 'a>,
    pub(crate) selectors: &'s Selectors,
    pub(crate) values: &'s Values,
    /// The nearest at-rule, which can be the node itself.
    pub(crate) at_rule: Option<&'s CssNode<'a>>,
}

impl<'s, 'a> Statement<'s, 'a> {
    fn new(scope: &'s Scope<'s, 'a>, selectors: &'s Selectors, values: &'s Values) -> Self {
        let mut statement = Statement {
            scope,
            selectors,
            values,
            at_rule: None,
        };
        statement.at_rule = statement.css_ancestor(Kind::AtRule);
        statement
    }

    pub(crate) fn node(&self) -> &'s CssNode<'a> {
        self.scope.node
    }

    fn parent(&self) -> Option<&'s CssNode<'a>> {
        self.scope.parent.map(|parent| parent.node)
    }

    /// `path.findAncestor((node) => node.type === kind)`, as seen from inside a selector, a value or params. So the
    /// statement's own node counts as an ancestor.
    pub(crate) fn css_ancestor(&self, kind: Kind) -> Option<&'s CssNode<'a>> {
        std::iter::successors(Some(self.scope), |scope| scope.parent)
            .map(|scope| scope.node)
            .find(|node| node.kind == kind)
    }

    /// `insideAtRuleNode`
    pub(crate) fn inside_at_rule(&self, names: &[&[u8]]) -> bool {
        self.at_rule.is_some_and(|node| {
            names
                .iter()
                .any(|name| node.name.eq_ignore_ascii_case(name))
        })
    }

    /// True for a custom property. Scripts read its value exactly as it is, and `style()` queries compare it that
    /// way. So its tokens are printed unchanged, spaces aren't added where there were none, and lines don't break after
    /// a comma that touches the next token. Prettier and oxfmt format it like any other value: `#FFF` becomes `#fff`,
    /// `.50` becomes `0.5`, `'a'` becomes `"a"`, `1,000` becomes `1, 000`, and in Prettier `16:9` becomes `16: 9`.
    pub(crate) fn is_custom_property(&self) -> bool {
        self.node().kind == Kind::Decl && self.node().prop.starts_with(b"--")
    }

    fn is_in_keyframes(&self) -> bool {
        self.at_rule
            .is_some_and(|it| it.name.to_ascii_lowercase().ends_with(b"keyframes"))
    }

    /// `insideIcssRuleNode`, for a declaration.
    fn inside_icss_rule(&self) -> bool {
        std::iter::successors(Some(self.scope), |scope| scope.parent).any(|scope| {
            let node = scope.node;
            node.kind == Kind::Rule
                && (node.raw_selector.starts_with(b":import")
                    || node.raw_selector.starts_with(b":export"))
        })
    }
}

pub(crate) struct Printer<'a, 'o> {
    pub(crate) context: Context<'a>,
    pub(crate) single_quote: bool,
    /// `trailingComma` is `"es5"` or `"all"`.
    pub(crate) trailing_comma: bool,
    /// Part of the memo key, so output cached for one flavor is never reused for the other.
    pub(crate) is_oxfmt: bool,
    /// Prettier's `__isHTMLStyleAttribute`: the declarations go on one line if they fit. It isn't part of the memo key
    /// because it requires `Sink::to_document()`, which never caches.
    pub(crate) is_html_style_attribute: bool,
    /// oxfmt's `sortTailwindcss`, for the classes after `@apply`.
    pub(crate) tailwind: Option<std::sync::Arc<crate::tailwind::Tailwind>>,
    /// The ancestors, within the value, of the value node being printed.
    pub(crate) value_stack: Vec<ValueId>,
    /// If nonzero, the comment that starts the item after a comma and has already been printed right after that comma.
    pub(crate) comment_after_comma: ValueId,
    /// Index of the `value-comma_group` member being printed.
    pub(crate) index_in_comma_group: usize,
    /// A list item, and how many of its leading comments have already been printed above it.
    pub(crate) comments_above_item: (ValueId, usize),
    /// Scratch buffer for building text to print.
    pub(crate) scratch: Vec<u8>,
    /// Set if Prettier would throw on this style sheet.
    pub(crate) failure: Option<SyntaxError>,
    pub(crate) sink: Sink<'o>,
    pub(crate) memo: &'o mut Memo,
    /// True while the current declaration's output depends only on its text and on what `memo_context` covers.
    pub(crate) is_memoizable: bool,
}

/// True if the first selector in the list `selector` contains the placeholder of a JavaScript `${}`.
fn has_placeholder_in_first_selector(selector: &[u8]) -> bool {
    let Some(at) = bun_core::strings::index_of(selector, b"@prettier-placeholder-") else {
        return false;
    };
    let (mut depth, mut quote) = (0u32, 0u8);
    for &byte in &selector[..at] {
        match byte {
            _ if quote != 0 => {
                if byte == quote {
                    quote = 0;
                }
            }
            b'"' | b'\'' => quote = byte,
            b'(' | b'[' => depth += 1,
            b')' | b']' => depth = depth.saturating_sub(1),
            b',' if depth == 0 => return false,
            _ => {}
        }
    }
    true
}

/// True if oxfmt prints a custom property's `value` verbatim because part of it isn't a valid value in the language, as
/// in `--a: [{"b":1}]`, `--a: b:c` and `--a: 1px !b`. Prettier formats it as a value anyway. Only applies to
/// single-line values.
fn has_non_value_syntax(value: &[u8], syntax: Syntax) -> bool {
    let is_name_part =
        |byte: u8| bun_core::strings::is_regexp_word_byte(byte) || byte == b'-' || byte >= 0x80;
    // The number of open `(`.
    let mut depth = 0u32;
    let mut at = 0;
    while let Some(&byte) = value.get(at) {
        let next = value.get(at + 1).copied();
        match byte {
            b'\n' => return false,
            b'"' | b'\'' => {
                at += 1;
                while value.get(at).is_some_and(|it| *it != byte) {
                    at += 1 + usize::from(value[at] == b'\\');
                }
            }
            b'#' if syntax == Syntax::Scss && next == Some(b'{') => {
                at += bun_core::strings::index_of_char_usize(&value[at..], b'}').unwrap_or(0);
            }
            b':' | b'{' | b'}' | b'!' => break,
            b'<' | b'>' if syntax == Syntax::Css => break,
            // The placeholder of a JavaScript `${}` counts as a value.
            b'@' if value[at..].starts_with(b"@prettier-placeholder-") => {}
            b'@' if syntax != Syntax::Less || next == Some(b'{') => break,
            b'(' if at >= 3 && value[at - 3..at].eq_ignore_ascii_case(b"url") => {
                at += bun_core::strings::index_of_char_usize(&value[at..], b')').unwrap_or(0);
            }
            // Bare parentheses are only fine inside a function's parentheses.
            b'(' if syntax != Syntax::Scss
                && depth == 0
                && !at.checked_sub(1).is_some_and(|it| is_name_part(value[it])) =>
            {
                break;
            }
            b'(' => depth += 1,
            b')' => depth = depth.saturating_sub(1),
            _ => {}
        }
        at += 1;
    }
    at < value.len() && !bun_core::strings::contains_char(&value[at..], b'\n')
}

/// True if the parenthesized `text` is more than a name and a value: `(width>=1px)`, `((color) or (hover))`. False if
/// it starts with a variable or an interpolation, which oxfmt doesn't parse either. A function call's `(` doesn't
/// count.
fn is_range_or_condition(text: &[u8]) -> bool {
    let inner = text.get(1..).unwrap_or_default();
    if matches!(
        bun_core::strings::trim_js_whitespace_start(inner).first(),
        Some(b'$' | b'@' | b'#')
    ) {
        return false;
    }
    let mut from = 0;
    while let Some(found) = bun_core::strings::index_of_any(&inner[from..], b"<>=(") {
        let at = from + found;
        let is_call = inner[at] == b'('
            && at
                .checked_sub(1)
                .is_some_and(|it| !inner[it].is_ascii_whitespace() && inner[it] != b'(');
        if !is_call {
            return true;
        }
        from = at + 1;
    }
    false
}

/// In a media query, oxfmt puts a space on both sides of `<`, `>`, `=`, `<=` and `>=`, one after a `:`, and none after
/// a `(` or before a `)`. Prettier only understands a name, a `:` and a value, and leaves everything else alone.
fn with_spaces_in_media_feature(text: &[u8]) -> Vec<u8> {
    let mut result: Vec<u8> = Vec::with_capacity(text.len() + 8);
    let mut at = 0;
    while let Some(&byte) = text.get(at) {
        let mut len = 1;
        match byte {
            b'"' | b'\'' => {
                while text.get(at + len).is_some_and(|it| *it != byte) {
                    len += 1 + usize::from(text[at + len] == b'\\');
                }
                len = (len + 1).min(text.len() - at);
                result.extend_from_slice(&text[at..at + len]);
            }
            _ if byte.is_ascii_whitespace() => {
                if !matches!(result.last(), None | Some(b'(' | b' ')) {
                    result.push(b' ');
                }
            }
            b')' => {
                if result.last() == Some(&b' ') {
                    result.pop();
                }
                result.push(byte);
            }
            b'<' | b'>' | b'=' => {
                len = text[at..]
                    .iter()
                    .take_while(|&&it| matches!(it, b'<' | b'>' | b'='))
                    .count();
                if !matches!(result.last(), None | Some(b'(' | b' ')) {
                    result.push(b' ');
                }
                result.extend_from_slice(&text[at..at + len]);
                result.push(b' ');
            }
            b':' => {
                if result.last() == Some(&b' ') {
                    result.pop();
                }
                result.extend_from_slice(b": ");
            }
            _ => result.push(byte),
        }
        at += len;
    }
    result
}

/// oxfmt prints `f($a)-1` in an SCSS media query as `f($a) - 1`, as it does in a value. Prettier leaves it alone.
///
/// - `*` always gets spaces around it.
/// - `+` and `-` get them if there's no space before them and a variable, a name or a function is next to them, so not
///   in `1+2`. A `-` after anything but a `)` is part of a name, and so is one before a letter.
fn with_spaces_around_operators(value: &[u8]) -> Cow<'_, [u8]> {
    if bun_core::strings::index_of_any(value, b"+-*").is_none() {
        return Cow::Borrowed(value);
    }
    let is_blank = |byte: Option<u8>| byte.is_some_and(|it| it.is_ascii_whitespace());
    let starts_name = |byte: u8| byte == b'$' || byte.is_ascii_alphabetic();
    let mut result = Vec::with_capacity(value.len() + 4);
    let mut quote = 0u8;
    for (at, &byte) in value.iter().enumerate() {
        if quote != 0 || matches!(byte, b'"' | b'\'') {
            quote = match quote {
                0 => byte,
                _ if byte == quote => 0,
                _ => quote,
            };
            result.push(byte);
            continue;
        }
        let previous = at.checked_sub(1).map(|it| value[it]);
        let next = value.get(at + 1).copied();
        let is_operator = match (byte, previous, next) {
            (b'*', Some(_), Some(_)) | (b'+', Some(b')'), Some(_)) => true,
            (b'-', Some(b')'), Some(next)) => {
                next.is_ascii_digit() || matches!(next, b'$' | b'(' | b'.' | b' ')
            }
            (b'+', Some(previous), Some(next)) if !previous.is_ascii_whitespace() => {
                let word_len = value[..at]
                    .iter()
                    .rev()
                    .take_while(|&&it| {
                        it.is_ascii_alphanumeric() || matches!(it, b'$' | b'_' | b'-' | b'.' | b'%')
                    })
                    .count();
                starts_name(next) || (word_len > 0 && starts_name(value[at - word_len]))
            }
            _ => false,
        };
        if is_operator && !is_blank(previous) {
            result.push(b' ');
        }
        result.push(byte);
        if is_operator && !is_blank(next) {
            result.push(b' ');
        }
    }
    Cow::Owned(result)
}

/// `text.replace(/\s*!\s*important/i, " !important")`, and the same for other words.
fn normalize_bang(text: &[u8], word: &[u8], allows_space: bool) -> Vec<u8> {
    let mut from = 0;
    while let Some(bang) = bun_core::strings::index_of_char_pos(text, b'!', from) {
        let after = &text[bang + 1..];
        let after = if allows_space {
            bun_core::strings::trim_js_whitespace_start(after)
        } else {
            after
        };
        if after.len() >= word.len() && after[..word.len()].eq_ignore_ascii_case(word) {
            let mut out = bun_core::strings::trim_js_whitespace_end(&text[..bang]).to_vec();
            out.extend_from_slice(b" !");
            out.extend_from_slice(word);
            out.extend_from_slice(&after[word.len()..]);
            return out;
        }
        from = bang + 1;
    }
    text.to_vec()
}

impl<'a> Printer<'a, '_> {
    pub(crate) fn syntax(&self) -> Syntax {
        self.context.syntax
    }

    /// `options.originalText`
    pub(crate) fn original_text(&self) -> &'a [u8] {
        self.context.original_text
    }

    // ───────────────────────────── the style sheet ─────────────────────────────

    /// Runs `write` to print a unit: output that isn't inside a group and is followed by a line break. See `Sink`.
    /// `write` may run twice, so any side effects besides writing must be idempotent.
    ///
    /// `is_too_long` is a hint that the unit probably won't fit on the line.
    fn unit(&mut self, is_too_long: bool, mut write: impl FnMut(&mut Self)) {
        let mark = self.sink.start_unit();
        if !(is_too_long && mark.is_some()) {
            write(self);
        }
        if let Some(mark) = mark
            && (is_too_long || !self.sink.end_unit())
        {
            self.sink.start_document(&mark);
            write(self);
            if self.context.stack.ran_out() {
                self.sink.fail(FormatError::NestedTooDeeply);
            }
            self.sink.end_document();
        }
    }

    /// Rejects the style sheet. Only the first error is reported.
    #[cold]
    pub(crate) fn fail(&mut self, error: SyntaxError) {
        self.failure.get_or_insert(error);
    }

    pub(crate) fn print_root(&mut self, tree: &Tree, parsed: &mut Parsed) {
        let root = match self.context.convert(tree, 0, parsed) {
            Ok(root) => root,
            Err(_) => return self.fail(self.context.rejection.reason()),
        };
        let mut after = bun_core::strings::trim_js_whitespace(root.after);
        if let Some(rest) = after.strip_prefix(b";") {
            after = bun_core::strings::trim_js_whitespace(rest);
        }
        let scope = Scope {
            node: &root,
            parent: None,
            tree,
        };
        self.print_sequence(&scope, &tree.nodes[0], after, parsed);
        if tree.nodes[0].first_child != 0 {
            self.sink.hard_line();
        }
    }

    /// True if `raw` is printed without a block.
    fn has_no_block(&self, raw: &Node) -> bool {
        match raw.kind {
            Kind::Root | Kind::Rule => false,
            Kind::Comment => true,
            // A custom property set looks like a declaration.
            Kind::Decl => {
                !raw.has_block
                    && !(self.context.of(raw.prop).starts_with(b"--")
                        && self.context.of(raw.value).starts_with(b"{"))
            }
            Kind::AtRule => {
                !raw.has_block || (self.syntax() == Syntax::Less && (raw.mixin || raw.function))
            }
        }
    }

    /// Returns the `Memo::context` for the declarations in `scope`'s block, or `None` if they can't be cached.
    fn memo_context(&mut self, scope: &Scope<'_, 'a>) -> Option<u32> {
        let parent = scope.node;
        if matches!(parent.value, Value::Rule(_)) || !self.context.is_original_text {
            return None;
        }
        let (selectors, values) = Default::default();
        let statement = Statement::new(scope, &selectors, &values);
        let flags = [
            self.syntax() == Syntax::Less,
            self.syntax() == Syntax::Scss,
            self.single_quote,
            self.trailing_comma,
            self.is_oxfmt,
            statement.inside_icss_rule(),
            parent.kind == Kind::AtRule && parent.variable,
            statement
                .css_ancestor(Kind::Rule)
                .is_some_and(|rule| rule.is_scss_nested_property),
            statement.at_rule.is_some(),
        ];
        let flags = flags
            .iter()
            .fold(0, |flags, &flag| flags << 1 | u32::from(flag));
        Some(
            self.memo
                .context(flags, statement.at_rule.map_or(b"", |it| it.name)),
        )
    }

    /// Returns the source text of the declaration `raw`, if that text determines everything `postcss` recorded about
    /// it.
    fn memo_text(&self, raw: &Node) -> Option<&'a [u8]> {
        let is_plain = raw.kind == Kind::Decl
            && !raw.is_nested
            && raw.clean_value.is_none()
            && self.has_no_block(raw)
            && self
                .context
                .of(raw.before)
                .iter()
                .all(u8::is_ascii_whitespace);
        // All of its parts must be in the text, at or after its start.
        let parts = [
            raw.prop,
            raw.between,
            raw.value,
            raw.raw_important.unwrap_or_default(),
        ];
        let end = parts
            .iter()
            .fold(raw.end.filter(|_| is_plain)?, |end, part| end.max(part.end));
        let is_in_order = parts
            .iter()
            .all(|part| part.is_empty() || part.start >= raw.start);
        self.context
            .text
            .get(raw.start as usize..end as usize)
            .filter(|_| is_in_order)
    }

    /// `printSequence` for the children of `block`, whose scope is `scope`. Then prints a space and `after`, unless
    /// `after` is empty.
    fn print_sequence(
        &mut self,
        scope: &Scope<'_, 'a>,
        block: &Node,
        after: &[u8],
        parsed: &mut Parsed,
    ) {
        let (text, tree) = (self.original_text(), scope.tree);
        let memo_context = self.memo_context(scope);
        let mut previous = None;
        let mut first = block.first_child;
        if first == 0 && !after.is_empty() {
            self.sink.token(" ");
            self.sink.text(after);
        }
        while first != 0 {
            // The nodes from `first` up to, but not including, `end` go on one line.
            let mut last = &tree.nodes[first as usize];
            while let Some(next) = tree
                .nodes
                .get(last.next_sibling as usize)
                .filter(|_| last.next_sibling != 0)
                && ((next.kind == Kind::Comment
                    && !has_newline_backwards(text, (next.start as usize).min(text.len())))
                    || (next.kind == Kind::AtRule
                        && last.kind != Kind::Comment
                        && self.context.name_of_at_rule(next) == b"else"))
            {
                last = next;
            }
            let end = last.next_sibling;

            // Leading comments and nodes with a block are printed directly. A node with a block makes its own unit for
            // the line that ends with its `{`. The rest of the line is one unit.
            let mut id = first;
            while id != end
                && let raw = &tree.nodes[id as usize]
                && (raw.kind == Kind::Comment || !self.has_no_block(raw))
            {
                if id != first {
                    self.sink.token(" ");
                }
                self.print_in_sequence(scope, id, previous, None, parsed, None);
                previous = Some(raw);
                id = raw.next_sibling;
            }
            let write_after = |printer: &mut Self| {
                if end == 0 && !after.is_empty() {
                    printer.sink.token(" ");
                    printer.sink.text(after);
                }
            };
            if id == end {
                write_after(self);
            } else {
                let raw = &tree.nodes[id as usize];
                // If the unit's closure runs twice, the node's parse results can be reused, as long as nothing else on
                // the line overwrites `parsed`.
                let mut node = None;
                let is_only_one_parsed = std::iter::successors(Some(raw.next_sibling), |&id| {
                    Some(tree.nodes[id as usize].next_sibling)
                })
                .take_while(|&id| id != end)
                .all(|id| {
                    matches!(
                        tree.nodes[id as usize],
                        Node {
                            kind: Kind::Comment,
                            inline: false,
                            end: Some(_),
                            ..
                        }
                    )
                });
                let is_too_long = raw.end.is_some_and(|end| {
                    !self.sink.has_room_for((end - raw.start.min(end)) as usize)
                });
                self.unit(is_too_long, |printer| {
                    let (mut id, mut previous) = (id, previous);
                    while id != end {
                        let raw = &tree.nodes[id as usize];
                        // oxfmt ignores a trailing `//` comment when it measures whether the line fits.
                        let is_line_suffix = printer.is_oxfmt
                            && id != first
                            && raw.kind == Kind::Comment
                            && (raw.inline || raw.raw_inline)
                            && raw.next_sibling == end;
                        if is_line_suffix {
                            printer.sink.start_line_suffix();
                        }
                        if id != first {
                            printer.sink.token(" ");
                        }
                        let node = if is_only_one_parsed {
                            Some(&mut node)
                        } else {
                            None
                        };
                        printer.print_in_sequence(scope, id, previous, memo_context, parsed, node);
                        if is_line_suffix {
                            printer.sink.end_line_suffix();
                        }
                        previous = Some(raw);
                        id = raw.next_sibling;
                    }
                    write_after(printer);
                });
            }
            previous = Some(last);
            if end != 0 {
                match self.is_html_style_attribute {
                    true => self.sink.line(),
                    false => self.sink.hard_line(),
                }
                let last_end = match last.end {
                    Some(end) if !last.inline => (end as usize).min(text.len()),
                    _ => {
                        let mut id = first;
                        while tree.nodes[id as usize].next_sibling != end {
                            id = tree.nodes[id as usize].next_sibling;
                        }
                        self.context.end_of(tree, id, parsed)
                    }
                };
                if is_next_line_empty(text, last_end) {
                    self.sink.hard_line();
                }
            }
            first = end;
        }
    }

    /// Prints the node `id`, a child of `parent` that follows `previous`. `converted` caches the converted node, unless
    /// it's a comment, so a second call doesn't convert it again.
    fn print_in_sequence(
        &mut self,
        parent: &Scope<'_, 'a>,
        id: NodeId,
        previous: Option<&Node>,
        memo_context: Option<u32>,
        parsed: &mut Parsed,
        converted: Option<&mut Option<CssNode<'a>>>,
    ) {
        if !self.context.stack.has_room() {
            return;
        }
        let (text, tree) = (self.original_text(), parent.tree);
        let raw = &tree.nodes[id as usize];
        let start = (raw.start as usize).min(text.len());
        if previous.is_some_and(|it| {
            it.kind == Kind::Comment
                && match bun_core::strings::trim_js_whitespace(self.context.of(it.text)) {
                    b"prettier-ignore" => true,
                    b"oxfmt-ignore" => self.is_oxfmt,
                    _ => false,
                }
        }) {
            let end = self.context.end_of(tree, id, parsed);
            return self.sink.text(text.get(start..end).unwrap_or_default());
        }
        if raw.kind == Kind::Comment {
            let comment = text
                .get(start..self.context.end_of(tree, id, parsed))
                .unwrap_or_default();
            return self.sink.text(if raw.inline || raw.raw_inline {
                bun_core::strings::trim_js_whitespace_end(comment)
            } else {
                comment
            });
        }
        let position = memo_context
            .zip(self.memo_text(raw))
            .zip(self.sink.position());
        if let Some(((context, text), _)) = position
            && let Some((output, has_group)) = self.memo.get(context, text)
        {
            return self.sink.replay_output(output, has_group);
        }

        let mut own = None;
        let converted = converted.unwrap_or(&mut own);
        if converted.is_none() {
            *converted = self.context.convert(tree, id, parsed).ok();
        }
        let Some(node) = converted else {
            return self.fail(self.context.rejection.reason());
        };
        let scope = Scope {
            node,
            parent: Some(parent),
            tree,
        };
        self.is_memoizable = true;
        match node.kind {
            Kind::Root | Kind::Comment => {}
            Kind::Rule => self.print_rule(&scope, raw, parsed),
            Kind::Decl => self.print_declaration(&scope, raw, parsed),
            Kind::AtRule => self.print_at_rule(&scope, raw, parsed),
        }
        if let Some(((context, text), position)) = position
            && self.is_memoizable
            && self.failure.is_none()
            && let Some((output, has_group)) = self.sink.written_since(position)
        {
            self.memo.insert(context, text, output, has_group);
        }
    }

    /// Prints `block`'s children, one per line, and the `}`. The `{` is already printed.
    fn print_block(
        &mut self,
        scope: &Scope<'_, 'a>,
        block: &Node,
        is_hard_line: bool,
        parsed: &mut Parsed,
    ) {
        let line = if is_hard_line {
            Sink::hard_line
        } else {
            Sink::soft_line
        };
        if block.first_child != 0 {
            self.sink.start_indent();
            line(&mut self.sink);
            self.print_sequence(scope, block, b"", parsed);
            self.sink.end_indent();
        }
        line(&mut self.sink);
        self.sink.token("}");
    }

    fn print_rule(&mut self, scope: &Scope<'_, 'a>, raw: &Node, parsed: &mut Parsed) {
        let node = scope.node;
        let statement = Statement::new(scope, &parsed.selectors, &parsed.values);
        let unknown_selector = node
            .selector
            .filter(|&it| statement.selectors.node(it).kind == SelectorKind::Unknown);
        // `isDetachedRulesetDeclarationNode`: `/^@.+:.*$/`
        let is_detached_ruleset = unknown_selector.is_some_and(|selector| {
            let value = statement.selectors.value(selector);
            value.starts_with(b"@")
                && bun_core::strings::index_of_any(value, b"\n\r").is_none()
                && bun_core::strings::index_of_char_pos(value, b':', 2).is_some()
        });
        self.unit(false, |printer| {
            if printer.is_oxfmt && has_placeholder_in_first_selector(&node.raw_selector) {
                printer.print_lines_of_selector(&node.raw_selector);
            } else if let Some(selector) = node.selector {
                printer.print_selector(statement, selector, None, None);
            }
            if node.important {
                printer.sink.token(" !important");
            }
            match (node.selector, unknown_selector) {
                (_, Some(selector))
                    if last_line_has_inline_comment(statement.selectors.value(selector)) =>
                {
                    printer.sink.line()
                }
                (Some(_), _) => printer.sink.token(" "),
                (None, _) => {}
            }
            printer.sink.token("{");
        });
        self.print_block(scope, raw, true, parsed);
        if is_detached_ruleset {
            self.sink.token(";");
        }
    }

    /// Prints a selector list in JavaScript whose first selector has a `${}` the way oxfmt does: keeps the line breaks,
    /// collapses the whitespace within each line to one space and doesn't indent any line.
    fn print_lines_of_selector(&mut self, selector: &[u8]) {
        let mut is_first = true;
        for line in bun_core::strings::split(selector, b"\n") {
            let mut words = bun_core::strings::split_any(line, b" \t\r\x0C")
                .filter(|word| !word.is_empty())
                .peekable();
            if words.peek().is_none() {
                continue;
            }
            if !std::mem::take(&mut is_first) {
                self.sink.hard_line();
            }
            for (index, word) in words.enumerate() {
                if index > 0 {
                    self.sink.token(" ");
                }
                self.sink.text(word);
            }
        }
    }

    fn print_declaration(&mut self, scope: &Scope<'_, 'a>, raw: &Node, parsed: &mut Parsed) {
        let node = scope.node;
        if let Value::Rule(tree) = &node.value {
            // This unit spans the whole block. The block's lines still go straight to the output, as nested units.
            return self.unit(false, |printer| {
                let is_on_its_own_line = printer.print_name(scope);
                printer.sink.token("{");
                let scope = Scope { tree, ..*scope };
                printer.print_block(
                    &scope,
                    &tree.nodes[tree.nodes[0].first_child as usize],
                    true,
                    parsed,
                );
                if is_on_its_own_line {
                    printer.sink.end_indent();
                    printer.sink.end_indent();
                }
                printer.print_rest_of_declaration(&scope, raw);
            });
        }
        let statement = Statement::new(scope, &parsed.selectors, &parsed.values);
        let write = |printer: &mut Self| {
            let is_on_its_own_line = printer.print_name_and_extend(statement);
            match &node.value {
                Value::None | Value::Rule(_) => {}
                Value::Text(value) => printer.sink.text(value),
                Value::Parsed(_)
                    if printer.is_oxfmt
                        && node.prop.starts_with(b"--")
                        // The raw text includes `!default` and `!global`, which are also printed after the value.
                        && !(node.scss_default || node.scss_global)
                        && has_non_value_syntax(printer.context.of(raw.value), printer.syntax()) =>
                {
                    printer
                        .sink
                        .text(printer.context.original_text_of(raw.value));
                }
                Value::Parsed(value) => {
                    // `hasComposesNode`
                    let is_without_lines = statement.values.node(*value).kind == ValueKind::Root
                        && node.prop.eq_ignore_ascii_case(b"composes");
                    if is_without_lines {
                        printer.sink.start_without_lines();
                    }
                    printer.print_value(statement, *value, None);
                    if is_without_lines {
                        printer.sink.end_without_lines();
                    }
                    // `$a: 1,` is a one-item list in SCSS, and oxfmt keeps the comma.
                    if printer.is_oxfmt
                        && node.prop.starts_with(b"$")
                        && bun_core::strings::trim_js_whitespace_end(printer.context.of(raw.value))
                            .ends_with(b",")
                        && top_level_group(statement.values, *value).is_none_or(|group| {
                            let it = statement.values.node(group);
                            it.kind != ValueKind::ParenGroup
                                || it.open != 0
                                || statement.values.groups(group).len() == 1
                        })
                    {
                        printer.sink.token(",");
                    }
                }
            }
            if is_on_its_own_line {
                printer.sink.end_indent();
                printer.sink.end_indent();
            }
            // Otherwise the backslash would escape the `;`, as it does in Prettier's output.
            if ends_with_unescaped_backslash(printer.context.of(raw.value).trim_ascii_end()) {
                printer.sink.token(" ");
            }
            printer.print_rest_of_declaration(scope, raw);
        };
        match node.has_block {
            false => write(self),
            true => {
                self.unit(false, write);
                self.print_block(scope, raw, false, parsed);
            }
        }
    }

    /// Prints the name of a declaration whose value is a block. See `print_name_and_extend`.
    fn print_name(&mut self, scope: &Scope<'_, 'a>) -> bool {
        let (selectors, values) = Default::default();
        self.print_name_and_extend(Statement::new(scope, &selectors, &values))
    }

    /// Prints everything before the value. Returns true if it opened an `indent` and a `dedent` inside it for the
    /// value, which the caller must close.
    fn print_name_and_extend(&mut self, statement: Statement<'_, 'a>) -> bool {
        let node = statement.node();
        let trimmed_between = bun_core::strings::trim_js_whitespace(&node.between);
        let is_colon = trimmed_between == b":";
        let is_value_all_space =
            matches!(&node.value, Value::Text(value) if value.iter().all(|&b| b == b' '));

        if node
            .before
            .iter()
            .any(|&b| b != b';' && !text::starts_with_white_space(&[b]))
        {
            let before: Vec<u8> = node
                .before
                .iter()
                .copied()
                .filter(|&b| b != b';' && !text::starts_with_white_space(&[b]))
                .collect();
            self.sink.text(&before);
        }
        let is_in_less_variable = statement
            .parent()
            .is_some_and(|parent| parent.kind == Kind::AtRule && parent.variable);
        // Tailwind `@plugin` options are JavaScript object keys, and the names in `@font-feature-values` blocks are
        // chosen by the author. Both are case-sensitive. Prettier prints `className` as `classname`.
        let is_author_defined_name = statement.inside_at_rule(&[
            b"plugin",
            b"stylistic",
            b"historical-forms",
            b"styleset",
            b"character-variant",
            b"swash",
            b"ornaments",
            b"annotation",
        ]);
        match is_in_less_variable || is_author_defined_name || statement.inside_icss_rule() {
            true => self.sink.text(&node.prop),
            false => self.sink.text(&maybe_to_lower_case(&node.prop)),
        }
        if trimmed_between.starts_with(b"//") {
            self.sink.token(" ");
        }
        self.sink.text(trimmed_between);
        // `a:${b} { .. }` in a JavaScript template.
        let is_placeholder_right_after_colon = node.is_nested
            && !(is_colon && node.between.ends_with(b" "))
            && matches!(node.value, Value::Parsed(value) if top_level_group(statement.values, value).is_some_and(|group| {
                is_at_word_placeholder(statement.values, group)
                    || statement.values.groups(group).first().is_some_and(|&first| is_at_word_placeholder(statement.values, first))
            }));
        if !(node.extend || is_value_all_space || is_placeholder_right_after_colon) {
            self.sink.token(" ");
        }
        if let Some(selector) = node
            .selector
            .filter(|_| self.syntax() == Syntax::Less && node.extend)
        {
            match statement.selectors.node(selector).child_count > 1 {
                true => {
                    self.sink.start_group(false);
                    self.sink.token("extend(");
                    self.sink.start_indent();
                    self.sink.soft_line();
                    self.print_selector(statement, selector, None, None);
                    self.sink.end_indent();
                    self.sink.soft_line();
                    self.sink.token(")");
                    self.sink.end_group();
                }
                false => {
                    self.sink.token("extend(");
                    self.print_selector(statement, selector, None, None);
                    self.sink.token(")");
                }
            }
        }

        // `path.call(() => shouldBreakList(path), "value", "group", "group")`
        let should_break_top_level_list = matches!(node.value, Value::Parsed(value)
            if top_level_group(statement.values, value).is_some_and(|group| is_list_with_comma_group(statement.values, group, self.is_oxfmt)))
            && !node.prop.starts_with(b"--");
        let is_on_its_own_line = !is_colon
            && last_line_has_inline_comment(trimmed_between)
            && !should_break_top_level_list;
        if is_on_its_own_line {
            self.sink.start_indent();
            self.sink.hard_line();
            self.sink.start_dedent();
        }
        is_on_its_own_line
    }

    /// Prints everything after the value, through the `{` if there's a block.
    fn print_rest_of_declaration(&mut self, scope: &Scope<'_, 'a>, raw: &Node) {
        let node = scope.node;
        // `!default /* comment */ ;`: oxfmt trims the whitespace before the `;`. Prettier prints the text from
        // `postcss` as is.
        let is_oxfmt = self.is_oxfmt;
        let mut bang =
            |raw: Option<&[u8]>, is_set: bool, word: &'static str, allows_space: bool| match raw {
                Some(raw) => self.sink.text(&normalize_bang(
                    match is_oxfmt {
                        true => bun_core::strings::trim_js_whitespace_end(raw),
                        false => raw,
                    },
                    word.as_bytes(),
                    allows_space,
                )),
                None if is_set => {
                    self.sink.token(" !");
                    self.sink.token(word);
                }
                None => {}
            };
        bang(node.raw_important, node.important, "important", true);
        bang(node.raw_scss_default, node.scss_default, "default", false);
        bang(node.raw_scss_global, node.scss_global, "global", false);
        match node.has_block {
            true => self.sink.token(" {"),
            // `isTemplatePropNode`
            false
                if node.prop.starts_with(b"@prettier-placeholder")
                    && self.has_no_semicolon(scope) => {}
            false if self.is_html_style_attribute && raw.next_sibling == 0 => {
                self.sink.if_break(";")
            }
            false => self.sink.token(";"),
        }
        self.print_line_comment(node);
    }

    /// True if there's no semicolon after `scope`'s node.
    fn has_no_semicolon(&mut self, scope: &Scope<'_, 'a>) -> bool {
        self.is_memoizable = false;
        let parent = scope.parent.map(|parent| parent.node);
        // Prettier's node for `--a: { .. }` has no `raws`, so it throws when it reads them.
        if parent.is_some_and(|parent| matches!(parent.value, Value::Rule(_))) {
            self.fail(SyntaxError(
                Message::UnreadableValue,
                scope.node.start as u32,
            ));
        }
        // oxfmt always treats it as a separate statement.
        (self.is_oxfmt || parent.is_some_and(|parent| !parent.semicolon))
            && scope
                .node
                .end
                .checked_sub(1)
                .and_then(|at| self.original_text().get(at))
                != Some(&b';')
    }

    fn print_at_rule(&mut self, scope: &Scope<'_, 'a>, raw: &Node, parsed: &mut Parsed) {
        let statement = Statement::new(scope, &parsed.selectors, &parsed.values);
        if self.has_no_block(raw) {
            return self.print_at_rule_up_to_block(statement);
        }
        self.unit(false, |printer| {
            printer.print_at_rule_up_to_block(statement)
        });
        self.print_block(scope, raw, false, parsed);
        if self.syntax() == Syntax::Less && scope.node.variable {
            let semicolon = self.semicolon_of_at_rule(scope);
            self.sink.token(semicolon);
        }
    }

    fn semicolon_of_at_rule(&mut self, scope: &Scope<'_, 'a>) -> &'static str {
        // `isTemplatePlaceholderNode`: an expression in a JavaScript template.
        if scope.node.name.starts_with(b"prettier-placeholder") && self.has_no_semicolon(scope) {
            ""
        } else {
            ";"
        }
    }

    /// Prints a whole at-rule or, if it has a block, everything through the `{`.
    fn print_at_rule_up_to_block(&mut self, statement: Statement<'_, 'a>) {
        let node = statement.node();
        let is_placeholder = node.name.starts_with(b"prettier-placeholder");
        let semicolon = self.semicolon_of_at_rule(statement.scope);
        // `/^\(\s*\)$/`
        let is_detached_ruleset_call = node
            .raw_params
            .strip_prefix(b"(")
            .and_then(|it| it.strip_suffix(b")"))
            .is_some_and(|inner| bun_core::strings::trim_js_whitespace(inner).is_empty());
        if self.syntax() == Syntax::Less {
            if node.mixin {
                if let Some(selector) = node.selector {
                    self.print_selector(statement, selector, None, None);
                }
                if node.important {
                    self.sink.token(" !important");
                }
                self.sink.token(semicolon);
                return self.print_line_comment(node);
            }
            if node.function {
                self.sink.text(node.name);
                if let Params::Text(params) = &node.params {
                    self.sink.text(params);
                }
                return self.sink.token(semicolon);
            }
            if node.variable {
                let between = bun_core::strings::trim_js_whitespace(&node.between);
                self.sink.token("@");
                self.sink.text(node.name);
                self.sink.token(": ");
                if let Value::Parsed(value) = node.value {
                    self.print_value(statement, value, None);
                    self.sink.line_suffix_boundary();
                }
                if !between.is_empty() {
                    self.sink.text(between);
                    self.sink.token(" ");
                }
                return self
                    .sink
                    .token(if node.has_block { "{" } else { semicolon });
            }
        }
        let is_control_directive = self.is_scss_control_directive(node);
        self.sink.token("@");
        match is_detached_ruleset_call || node.name.ends_with(b":") || is_placeholder {
            true => self.sink.text(node.name),
            false => self.sink.text(&maybe_to_lower_case(node.name)),
        }
        if !matches!(&node.params, Params::None)
            && !matches!(&node.params, Params::Text(params) if params.is_empty())
        {
            // Count the line breaks in the leading whitespace of `raws.afterName`.
            let spaces = &node.after_name[..text::leading_white_space_len(node.after_name)];
            match bun_core::strings::count_char(spaces, b'\n') {
                _ if is_detached_ruleset_call => {}
                _ if !is_placeholder => self.sink.token(" "),
                _ if node.after_name.is_empty() => {}
                _ if node.name.ends_with(b":") => self.sink.token(" "),
                0 => self.sink.token(" "),
                1 => self.sink.hard_line(),
                _ => {
                    self.sink.hard_line();
                    self.sink.hard_line();
                }
            }
            match &node.params {
                Params::None => {}
                // oxfmt normalizes the quotes in a `@keyframes` name and in `@error` and `@warn` messages like
                // everywhere else.
                Params::Text(params) | Params::Unknown(params)
                    if self.is_oxfmt
                        && (statement.is_in_keyframes()
                            || matches!(node.name, b"error" | b"warn")) =>
                {
                    self.sink.text(&adjust_strings(params, self.single_quote));
                }
                // `${a}-b > c,⏎ .d {` is a rule whose selectors start with a `${}`.
                Params::Text(params) | Params::Unknown(params)
                    if self.is_oxfmt && is_placeholder && node.has_block =>
                {
                    self.print_lines_of_selector(params);
                }
                // `prettier-plugin-tailwindcss` makes Prettier parse these params like the params of `@import`.
                Params::Text(params) | Params::Unknown(params)
                    if !self.is_oxfmt
                        && self.tailwind.is_some()
                        && matches!(node.name, b"plugin" | b"config" | b"source") =>
                {
                    self.sink.text(&adjust_strings(params, self.single_quote));
                }
                Params::Text(params) | Params::Unknown(params) => {
                    let is_sorted = node.name == b"apply" && !node.has_block;
                    // The plugin sorts the words of a comment as if they were classes. oxfmt doesn't sort a list with a
                    // comment.
                    let has_comment = bun_core::strings::contains(params, b"/*");
                    let sorted = (self.tailwind.as_deref())
                        .filter(|it| is_sorted && (it.follows_plugin || !has_comment))
                        .and_then(|tailwind| tailwind.sorted_apply_params(params));
                    self.sink.text(sorted.as_deref().unwrap_or(params));
                }
                Params::Media(list) => self.print_media(list, true),
                Params::Value(value) => self.print_value(statement, *value, None),
            }
        }
        if let Some(selector) = node.selector {
            self.sink.start_indent();
            self.sink.token(" ");
            self.print_selector(statement, selector, None, None);
            self.sink.end_indent();
        }
        let ends_with_space = match node.value {
            Value::Parsed(_) => is_control_directive,
            _ => node.name == b"else",
        };
        match node.value {
            Value::Parsed(value) => {
                // `hasParensAroundNode`
                let has_parens = top_level_group(statement.values, value).is_some_and(|group| {
                    let group = statement.values.node(group);
                    group.kind == ValueKind::ParenGroup && group.open != 0 && group.close != 0
                });
                self.sink.start_group(false);
                self.sink.token(" ");
                self.print_value(statement, value, None);
                match (is_control_directive, has_parens) {
                    (false, _) => {}
                    (true, true) => self.sink.token(" "),
                    (true, false) => self.sink.line(),
                }
                self.sink.end_group();
            }
            _ if node.name == b"else" => self.sink.token(" "),
            _ => {}
        }
        let is_import_that_ends_with_semicolon = node.name == b"import"
            && matches!(node.params, Params::Value(value)
                if statement.values.node(value).kind == ValueKind::Unknown && statement.values.value(value).is_some_and(|it| it.ends_with(b";")));
        match node.has_block {
            true if !node.line_comment.is_empty() => {
                if !ends_with_space {
                    self.sink.token(" ");
                }
                self.sink.text(node.line_comment);
                self.sink.hard_line();
                self.sink.token("{");
            }
            true => {
                let has_inline_comment = match (node.selector, &node.params) {
                    (Some(selector), _) => {
                        statement.selectors.node(selector).kind == SelectorKind::Unknown
                            && last_line_has_inline_comment(statement.selectors.value(selector))
                    }
                    (None, Params::Text(params)) => last_line_has_inline_comment(params),
                    _ => false,
                };
                match (is_control_directive, has_inline_comment) {
                    (true, _) => {}
                    (false, true) => self.sink.line(),
                    (false, false) => self.sink.token(" "),
                }
                self.sink.token("{");
            }
            false if is_import_that_ends_with_semicolon => {}
            false => {
                // Otherwise the backslash would escape the `;`, as it does in Prettier's output. The value of `@if` is
                // already followed by a space.
                if ends_with_unescaped_backslash(&node.raw_params) && !is_control_directive {
                    self.sink.token(" ");
                }
                self.sink.token(semicolon);
                self.print_line_comment(node);
            }
        }
    }

    /// Prints `CssNode::line_comment` after a `;`.
    fn print_line_comment(&mut self, node: &CssNode<'a>) {
        if !node.line_comment.is_empty() {
            self.sink.token(" ");
            self.sink.text(node.line_comment);
        }
    }

    /// `atRuleAncestorNode`, for a value. In oxfmt only an at-rule's own params count as inside it. The contents of its
    /// block are printed as they would be anywhere else.
    pub(crate) fn enclosing_at_rule<'s>(
        &self,
        statement: Statement<'s, 'a>,
    ) -> Option<&'s CssNode<'a>> {
        statement
            .at_rule
            .filter(|_| !self.is_oxfmt || statement.node().kind == Kind::AtRule)
    }

    /// `isSCSSControlDirectiveNode`
    pub(crate) fn is_scss_control_directive(&self, node: &CssNode<'a>) -> bool {
        self.syntax() == Syntax::Scss
            && node.kind == Kind::AtRule
            && matches!(node.name, b"if" | b"else" | b"for" | b"each" | b"while")
    }

    // ───────────────────────────── media queries ─────────────────────────────

    fn print_media(&mut self, node: &MediaNode<'a>, is_last: bool) {
        let children = node.nodes.as_deref().unwrap_or_default();
        match node.kind {
            MediaKind::QueryList => {
                self.sink.start_group(false);
                self.sink.start_indent();
                let mut is_first = true;
                for (index, child) in children.iter().enumerate() {
                    if child.kind == MediaKind::Query && child.value.is_empty() {
                        continue;
                    }
                    if !std::mem::replace(&mut is_first, false) {
                        self.sink.line();
                    }
                    self.print_media(child, index + 1 == children.len());
                }
                self.sink.end_indent();
                self.sink.end_group();
            }
            MediaKind::Query => {
                for (index, child) in children.iter().enumerate() {
                    if index > 0 {
                        self.sink.token(" ");
                    }
                    self.print_media(child, false);
                }
                if !is_last {
                    self.sink.token(",");
                }
            }
            MediaKind::Type | MediaKind::Value => {
                let is_expression =
                    node.kind == MediaKind::Value && self.is_oxfmt && self.syntax() == Syntax::Scss;
                let value = match is_expression {
                    true => with_spaces_around_operators(node.value),
                    false => Cow::Borrowed(node.value),
                };
                self.sink
                    .text(&adjust_numbers(&adjust_strings(&value, self.single_quote)));
            }
            MediaKind::FeatureExpression => match &node.nodes {
                None => self.sink.text(node.value),
                Some(_) if self.is_oxfmt && is_range_or_condition(node.value) => {
                    let text = with_spaces_in_media_feature(node.value);
                    self.sink
                        .text(&adjust_numbers(&maybe_to_lower_case(&adjust_strings(
                            &text,
                            self.single_quote,
                        ))));
                }
                Some(children) => {
                    self.sink.token("(");
                    for child in children {
                        self.print_media(child, false);
                    }
                    // `(a\ )`, which Prettier prints as `(a\)`.
                    if let Some(inner) = node.value.strip_suffix(b")")
                        && inner.last().is_some_and(u8::is_ascii_whitespace)
                        && ends_with_unescaped_backslash(inner.trim_ascii_end())
                    {
                        self.sink.token(" ");
                    }
                    self.sink.token(")");
                }
            },
            MediaKind::Feature => {
                // `value.replaceAll(/ +/g, " ")`
                let mut value = Vec::with_capacity(node.value.len());
                for &byte in node.value {
                    if byte != b' ' || value.last() != Some(&b' ') {
                        value.push(byte);
                    }
                }
                self.sink.text(&maybe_to_lower_case(&adjust_strings(
                    &value,
                    self.single_quote,
                )));
            }
            MediaKind::Colon => {
                self.sink.text(node.value);
                self.sink.token(" ");
            }
            MediaKind::Keyword => self
                .sink
                .text(&adjust_strings(node.value, self.single_quote)),
            MediaKind::Url => {
                // `.replaceAll(/^url\(\s+/gi, "url(").replaceAll(/\s+\)$/g, ")")`
                let mut value = node.value.to_vec();
                if value.len() >= 4
                    && value[..4].eq_ignore_ascii_case(b"url(")
                    && text::starts_with_white_space(&value[4..])
                {
                    value = [
                        b"url(",
                        bun_core::strings::trim_js_whitespace_start(&value[4..]),
                    ]
                    .concat();
                }
                if let Some(rest) = value.strip_suffix(b")")
                    && bun_core::strings::trim_js_whitespace_end(rest).len() < rest.len()
                {
                    value = [bun_core::strings::trim_js_whitespace_end(rest), b")"].concat();
                }
                self.sink.text(&adjust_strings(&value, self.single_quote));
            }
            MediaKind::Unknown => self.sink.text(node.value),
        }
    }

    // ───────────────────────────── selectors ─────────────────────────────

    fn print_namespace(&mut self, selectors: &Selectors, namespace: Option<Namespace>) {
        match namespace {
            None => {}
            Some(Namespace::Empty) => self.sink.token("|"),
            Some(Namespace::Name(name)) => {
                self.sink
                    .text(bun_core::strings::trim_js_whitespace(selectors.text(name)));
                self.sink.token("|");
            }
        }
    }

    /// `parent` is the selector node that contains `id`, and `previous` is `id`'s previous sibling.
    pub(crate) fn print_selector(
        &mut self,
        statement: Statement<'_, 'a>,
        id: SelectorId,
        parent: Option<SelectorId>,
        previous: Option<SelectorId>,
    ) {
        let selectors = statement.selectors;
        let node = selectors.node(id);
        let value = selectors.text(node.value);
        let single_quote = self.single_quote;
        match node.kind {
            SelectorKind::Root | SelectorKind::Pseudo if !self.context.stack.has_room() => {}
            SelectorKind::Root => {
                let custom_selector = match statement.inside_at_rule(&[b"custom-selector"]) {
                    true => statement
                        .at_rule
                        .and_then(|it| it.custom_selector.as_deref()),
                    false => None,
                };
                let is_on_one_line =
                    statement.inside_at_rule(&[b"extend", b"custom-selector", b"nest"]);
                // One selector per line, and those hard line breaks break the group.
                self.sink
                    .start_group(!is_on_one_line && node.child_count > 1);
                if let Some(name) = custom_selector {
                    self.sink.text(name);
                    self.sink.line();
                }
                let (mut child, mut previous) = (node.first_child, None);
                while child != 0 {
                    if previous.is_some() {
                        self.sink.token(",");
                        match is_on_one_line {
                            true => self.sink.line(),
                            false => self.sink.hard_line(),
                        }
                    }
                    self.print_selector(statement, child, Some(id), previous);
                    previous = Some(child);
                    child = selectors.node(child).next_sibling;
                }
                self.sink.end_group();
            }
            SelectorKind::Selector => {
                self.sink.start_group(false);
                if node.child_count > 2 {
                    self.sink.start_indent();
                }
                let (mut child, mut previous) = (node.first_child, None);
                while child != 0 {
                    self.print_selector(statement, child, Some(id), previous);
                    previous = Some(child);
                    child = selectors.node(child).next_sibling;
                }
                if node.child_count > 2 {
                    self.sink.end_indent();
                }
                self.sink.end_group();
            }
            SelectorKind::Comment | SelectorKind::Nesting => self.sink.text(value),
            SelectorKind::String => self.sink.text(&adjust_strings(value, single_quote)),
            SelectorKind::Tag => {
                self.print_namespace(selectors, node.namespace);
                if previous.is_some_and(|it| selectors.node(it).kind == SelectorKind::Nesting) {
                    return self.sink.text(value);
                }
                // `isKeyframeAtRuleKeywords`
                let is_keyframe_keyword = (value.eq_ignore_ascii_case(b"from")
                    || value.eq_ignore_ascii_case(b"to"))
                    && statement.is_in_keyframes();
                match is_keyframe_keyword {
                    true => self.sink.text(&value.to_ascii_lowercase()),
                    false => self.sink.text(&adjust_numbers(value)),
                }
            }
            // Include the `#` before it.
            SelectorKind::Id => self
                .sink
                .text(selectors.text((node.value.0.saturating_sub(1), node.value.1))),
            // oxfmt treats `.50%` in `@keyframes` as a number.
            SelectorKind::Class
                if self.is_oxfmt
                    && previous.is_none()
                    && value.first().is_some_and(u8::is_ascii_digit)
                    && statement.is_in_keyframes() =>
            {
                let number = selectors.text((node.value.0.saturating_sub(1), node.value.1));
                self.sink.text(&adjust_numbers(number));
            }
            SelectorKind::Class => {
                match (adjust_strings(value, single_quote), adjust_numbers(value)) {
                    // Include the `.` before it.
                    (Cow::Borrowed(_), Cow::Borrowed(_)) => self
                        .sink
                        .text(selectors.text((node.value.0.saturating_sub(1), node.value.1))),
                    (adjusted, _) => {
                        self.sink.token(".");
                        self.sink.text(&adjust_numbers(&adjusted));
                    }
                }
            }
            SelectorKind::Attribute => {
                self.sink.token("[");
                self.print_namespace(selectors, node.namespace);
                self.sink.text(bun_core::strings::trim_js_whitespace(
                    selectors.text(node.attribute),
                ));
                self.sink.text(
                    node.operator
                        .map(|it| selectors.text(it))
                        .unwrap_or_default(),
                );
                if node.has_value {
                    let value = bun_core::strings::trim_js_whitespace_start(value);
                    let mut len = bun_core::strings::trim_js_whitespace_end(value).len();
                    if len < value.len() && ends_with_unescaped_backslash(&value[..len]) {
                        len += 1;
                    }
                    let adjusted = adjust_strings(&value[..len], single_quote);
                    // `replaceEndOfLine(.., literallineWithoutBreakParent)`
                    for (index, line) in bun_core::strings::split(
                        &quote_attribute_value(adjusted, single_quote),
                        b"\n",
                    )
                    .enumerate()
                    {
                        if index > 0 {
                            self.sink.literal_line();
                        }
                        self.sink.text(line);
                    }
                }
                self.sink.token(if node.insensitive { " i]" } else { "]" });
            }
            SelectorKind::Combinator => {
                if matches!(value, b"+" | b">" | b"~" | b">>>") {
                    let is_first = parent.is_some_and(|parent| {
                        let parent = selectors.node(parent);
                        parent.kind == SelectorKind::Selector && parent.first_child == id
                    });
                    if !is_first {
                        self.sink.line();
                    }
                    self.sink.text(value);
                    // `:nth-child(+n+3)` and the keyframe selector `+50%`. Prettier prints a space after the sign,
                    // which makes them invalid.
                    let is_sign = is_first
                        && value == b"+"
                        && (selectors.text((node.value.1, node.value.1 + 1)).first())
                            .is_some_and(|next| !next.is_ascii_whitespace())
                        && parent.is_some_and(|parent| {
                            let container = selectors.node(selectors.node(parent).parent);
                            match container.kind {
                                SelectorKind::Pseudo => (selectors.text(container.value).get(..5))
                                    .is_some_and(|it| it.eq_ignore_ascii_case(b":nth-")),
                                SelectorKind::Root => statement.is_in_keyframes(),
                                _ => false,
                            }
                        });
                    if node.next_sibling != 0 && !is_sign {
                        self.sink.token(" ");
                    }
                    return;
                }
                if value.iter().all(u8::is_ascii_whitespace) {
                    // The first space of `.\31  .b` ends the escape and the second is the combinator. Prettier prints
                    // `.\31 .b`, which is a compound selector.
                    if value.len() > 1
                        && previous.is_some_and(|it| {
                            let name = (selectors.node(it).value.0, node.value.0);
                            ends_with_hex_escape(selectors.text(name))
                        })
                    {
                        self.sink.token(" ");
                    }
                    return self.sink.line();
                }
                if bun_core::strings::trim_js_whitespace_start(value).starts_with(b"(") {
                    self.sink.line();
                }
                let adjusted =
                    adjust_strings(bun_core::strings::trim_js_whitespace(value), single_quote);
                let adjusted = adjust_numbers(&adjusted);
                match adjusted.is_empty() {
                    true => self.sink.line(),
                    false => self.sink.text(&adjusted),
                }
            }
            SelectorKind::Universal => {
                self.print_namespace(selectors, node.namespace);
                self.sink.text(value);
            }
            SelectorKind::Pseudo => {
                self.sink.text(&maybe_to_lower_case(value));
                if node.first_child != 0 {
                    self.sink.start_group(false);
                    self.sink.token("(");
                    self.sink.start_indent();
                    self.sink.soft_line();
                    let (mut child, mut previous) = (node.first_child, None);
                    while child != 0 {
                        if previous.is_some() {
                            self.sink.token(",");
                            self.sink.line();
                        }
                        self.print_selector(statement, child, Some(id), previous);
                        previous = Some(child);
                        child = selectors.node(child).next_sibling;
                    }
                    self.sink.end_indent();
                    self.sink.soft_line();
                    self.sink.token(")");
                    self.sink.end_group();
                }
            }
            SelectorKind::Unknown => self.print_unknown_selector(statement, value),
        }
    }

    fn print_unknown_selector(&mut self, statement: Statement<'_, 'a>, value: &[u8]) {
        self.is_memoizable = false;
        if statement
            .css_ancestor(Kind::Rule)
            .is_some_and(|rule| rule.is_scss_nested_property)
        {
            let value = maybe_to_lower_case(value);
            return self
                .sink
                .text(&adjust_numbers(&adjust_strings(&value, self.single_quote)));
        }
        let values = statement.values;
        // Inside the parentheses of `selector()`.
        if let [.., func, paren_group] = self.value_stack[..]
            && let paren_group = values.node(paren_group)
            && paren_group.kind == ValueKind::ParenGroup
            && paren_group.open != 0
            && paren_group.close != 0
            && values.node(func).kind == ValueKind::Func
            && values.value(func) == Some(b"selector")
        {
            let start = values
                .node(paren_group.open)
                .loc
                .end_offset()
                .map_or(0, |at| at as usize + 1);
            let end = values
                .node(paren_group.close)
                .loc
                .start_offset()
                .map_or(0, |at| at as usize);
            let selector = bun_core::strings::trim_js_whitespace(
                self.original_text().get(start..end).unwrap_or_default(),
            );
            if last_line_has_inline_comment(selector) {
                self.sink.break_parent();
            }
            return self.sink.text(selector);
        }
        // Use the original text, because the parsed copy of a Less file has some characters blanked out.
        let parent = statement.node();
        if self.value_stack.is_empty() && !parent.raw_selector.is_empty() {
            let end = parent.start + parent.raw_selector.len();
            return self.sink.text(bun_core::strings::trim_js_whitespace(
                self.original_text()
                    .get(parent.start..end)
                    .unwrap_or_default(),
            ));
        }
        self.sink.text(value);
    }

    // ───────────────────────────── values ─────────────────────────────

    /// Returns the name of the innermost function around the value node being printed.
    pub(crate) fn value_function<'v>(&self, values: &'v Values) -> Option<&'v [u8]> {
        let function = self
            .value_stack
            .iter()
            .rev()
            .find(|&&id| values.node(id).kind == ValueKind::Func);
        function.and_then(|&id| values.value(id))
    }

    /// `insideValueFunctionNode`
    pub(crate) fn inside_value_function(&self, values: &Values, name: &[u8]) -> bool {
        self.value_function(values)
            .is_some_and(|value| value.eq_ignore_ascii_case(name))
    }

    /// `previous` is the node before `id` in its group.
    pub(crate) fn print_value(
        &mut self,
        statement: Statement<'_, 'a>,
        id: ValueId,
        previous: Option<ValueId>,
    ) {
        let values = statement.values;
        let node = values.node(id);
        let value = values.value(id).unwrap_or_default();
        match node.kind {
            ValueKind::Root
            | ValueKind::Value
            | ValueKind::CommaGroup
            | ValueKind::ParenGroup
            | ValueKind::Func
            | ValueKind::Selector
                if !self.context.stack.has_room() => {}
            ValueKind::Root | ValueKind::Value => self.print_child_value(statement, id, node.group),
            ValueKind::Comment => {
                self.is_memoizable = false;
                let (start, end) = (
                    node.loc.start_offset().unwrap_or(0) as usize,
                    node.loc.end_offset().unwrap_or(0) as usize,
                );
                let text = self.original_text().get(start..end).unwrap_or_default();
                match node.inline {
                    true => {
                        self.sink.start_line_suffix();
                        self.sink
                            .text(bun_core::strings::trim_js_whitespace_end(text));
                        self.sink.end_line_suffix();
                    }
                    false => self.sink.text(text),
                }
            }
            ValueKind::CommaGroup => self.print_comma_separated_value_group(statement, id),
            ValueKind::ParenGroup => self.print_parenthesized_value_group(statement, id),
            ValueKind::Func => {
                let is_keyword = ["not", "and", "or"]
                    .iter()
                    .any(|it| value.eq_ignore_ascii_case(it.as_bytes()));
                self.sink.text(value);
                if is_keyword && statement.inside_at_rule(&[b"supports"]) {
                    self.sink.token(" ");
                }
                self.print_child_value(statement, id, node.group);
            }
            ValueKind::Number => {
                let source_text = match statement.is_custom_property() {
                    true => (ValueRef { values, id }).number_source_text(),
                    false => None,
                };
                match source_text {
                    Some(number) => self.sink.text(number),
                    None => {
                        self.scratch.clear();
                        print_css_number(value, &mut self.scratch);
                        self.sink.text(&self.scratch);
                        self.sink.text(print_unit(values.text(node.unit)));
                    }
                }
            }
            ValueKind::Paren
            | ValueKind::Operator
            | ValueKind::UnicodeRange
            | ValueKind::Unknown
            | ValueKind::Comma => {
                self.sink.text(value);
            }
            ValueKind::Text => self.sink.text(values.text_of(id)),
            ValueKind::Word => {
                let is_wide_keyword = ["initial", "inherit", "unset", "revert"]
                    .iter()
                    .any(|it| value.eq_ignore_ascii_case(it.as_bytes()));
                match ((node.is_color && node.is_hex) || is_wide_keyword)
                    && !statement.is_custom_property()
                {
                    true => self.sink.text(&to_lower_case(value)),
                    false => self.sink.text(value),
                }
            }
            ValueKind::Colon => {
                let is_escaped = previous
                    .and_then(|it| values.value(it))
                    .is_some_and(|it| it.ends_with(b"\\"));
                self.sink.start_group(false);
                self.sink.token(":");
                let is_verbatim = statement.is_custom_property()
                    && (ValueRef { values, id }).whitespace_after() == 0;
                if !(is_escaped || is_verbatim || self.inside_value_function(values, b"url")) {
                    self.sink.line();
                }
                self.sink.end_group();
            }
            // `@import "a" source('b')`: oxfmt only normalizes quotes inside `url()`. A string in any other function
            // keeps its quotes.
            ValueKind::String
                if self.is_oxfmt
                    && statement.inside_at_rule(&[b"import"])
                    && self
                        .value_function(values)
                        .is_some_and(|name| !name.eq_ignore_ascii_case(b"url")) =>
            {
                self.sink.text(values.raw_string(id));
            }
            ValueKind::String if statement.is_custom_property() => {
                self.sink.text(values.raw_string(id));
            }
            ValueKind::String => {
                self.scratch.clear();
                print_string(values.raw_string(id), self.single_quote, &mut self.scratch);
                self.sink.text(&self.scratch);
            }
            ValueKind::AtWord => {
                self.sink.token("@");
                // oxfmt prints `@a!important` as `@a !important`.
                match value.len().checked_sub(b"!important".len()).filter(|&at| {
                    self.is_oxfmt && at > 0 && value[at..].eq_ignore_ascii_case(b"!important")
                }) {
                    Some(at) => {
                        self.sink.text(&value[..at]);
                        self.sink.token(" !important");
                    }
                    None => self.sink.text(value),
                }
            }
            ValueKind::Selector => self.print_selector(statement, node.selector, None, None),
        }
    }

    pub(crate) fn print_child_value(
        &mut self,
        statement: Statement<'_, 'a>,
        parent: ValueId,
        child: ValueId,
    ) {
        self.value_stack.push(parent);
        self.print_value(statement, child, None);
        self.value_stack.pop();
    }
}

/// `isAtWordPlaceholderNode`
pub(crate) fn is_at_word_placeholder(values: &Values, id: ValueId) -> bool {
    values.node(id).kind == ValueKind::AtWord
        && values
            .value(id)
            .is_some_and(|value| value.starts_with(b"prettier-placeholder-"))
}

/// `node.value.group.group`
pub(crate) fn top_level_group(values: &Values, root: ValueId) -> Option<ValueId> {
    let root = values.node(root);
    let value = Some(values.node(root.group))
        .filter(|value| root.kind == ValueKind::Root && value.kind == ValueKind::Value)?;
    Some(value.group)
}

/// `-apple-system`, `+3em`: postcss-value-parser treats a sign that isn't at the start of a value as an operator, so
/// Prettier sees two nodes.
fn is_signed_word(values: &Values, id: ValueId) -> bool {
    matches!(*values.groups(id), [sign, word]
        if values.node(sign).kind == ValueKind::Operator
            && matches!(values.node(sign).first_byte, b'-' | b'+')
            && values.node(word).before == Before::Empty)
}

/// The first condition of `shouldBreakList`. `signed_word_is_one` is oxfmt's behavior, which keeps
/// `font-family: a, -apple-system` on one line.
pub(crate) fn is_list_with_comma_group(
    values: &Values,
    id: ValueId,
    signed_word_is_one: bool,
) -> bool {
    let node = values.node(id);
    node.kind == ValueKind::ParenGroup
        && node.open == 0
        && values.groups(id).iter().any(|&it| {
            values.node(it).kind == ValueKind::CommaGroup
                && !(signed_word_is_one && is_signed_word(values, it))
        })
}
