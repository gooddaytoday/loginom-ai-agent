use crate::js::format::identifier;
use crate::prelude::*;
use crate::write;

/// `[A, B]`
pub(crate) fn write_ts_tuple_type<'a>(
    ty: TypeNode<'a>,
    elements: List<'a, TupleElem<'a>>,
    f: &mut Formatter<'a>,
) {
    if f.file().is_flow() && super::flow::write_tuple_of_unknown_elements(ty, elements, f) {
        return;
    }
    let needs_parentheses = f.file().is_flow() && super::flow::needs_parentheses(ty);
    write!(f, [needs_parentheses.then_some("("), "["]);
    if elements.is_empty() {
        write!(
            f,
            dangling_comments(AstNodes::TSTupleType(ty)).with_soft_block_indent()
        );
    } else {
        let element_types = format_with(|f| {
            let trailing_separator =
                match f.file().is_flow() && super::flow::is_inexact_tuple(elements) {
                    true => TrailingSeparator::Disallowed,
                    false => FormatTrailingCommas::ES5.trailing_separator(f.options()),
                };
            f.join_nodes_with_soft_line()
                .entries_with_trailing_separator(
                    elements.iter().map(FormatTupleElement),
                    ",",
                    trailing_separator,
                );
        });
        write!(f, group(&soft_block_indent(&element_types)));
    }
    write!(f, ["]", needs_parentheses.then_some(")")]);
}

/// An element and the comments around it form a group, as in Prettier's `printArrayElements`: a comment that ends its
/// line in the source stays before the element if both fit on one line.
struct FormatTupleElement<'a>(TupleElem<'a>);

impl Spanned for FormatTupleElement<'_> {
    fn span(&self) -> Span {
        self.0.span()
    }
}

impl<'a> Format<'a> for FormatTupleElement<'a> {
    fn fmt(&self, f: &mut Formatter<'a>) {
        match f.is_quiet() {
            true => write!(f, self.0),
            false => write!(f, group(&self.0)),
        }
    }
}

/// `a: T`, `a?: T`, `T?`, `...T`, `...a: T`
pub(crate) fn write_ts_tuple_element<'a>(element: TupleElem<'a>, f: &mut Formatter<'a>) {
    if f.file().is_flow() {
        return super::flow::write_tuple_element(element, f);
    }
    write!(f, element.is_rest().then_some("..."));
    match element.name() {
        Some(label) => write!(
            f,
            [
                identifier(label),
                element.is_optional().then_some("?"),
                ":",
                space(),
                element.ty()
            ]
        ),
        None => write!(f, [element.ty(), element.is_optional().then_some("?")]),
    }
}
