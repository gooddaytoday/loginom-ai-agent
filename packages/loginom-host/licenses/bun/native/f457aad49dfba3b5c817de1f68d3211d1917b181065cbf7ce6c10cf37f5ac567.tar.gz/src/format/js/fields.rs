//! ESTree node fields, as methods on the handles.
//!
//! Use `match e.kind()` to destructure a node. These methods are for checking one field of a node whose kind is known,
//! usually a parent: `parent.object() == Some(e)`. Each returns `None`, or an empty list, for a node without that
//! field.

use bun_lint::ast::{Call, Expr, ExprKind, Func, Stmt, StmtKind, TypeNode};
use bun_sema::hir::ExprTag;

pub(crate) trait ExprFields<'a>: Copy {
    /// `TaggedTemplateExpression.tag`
    fn tag_expression(self) -> Option<Expr<'a>>;
    /// `ConditionalExpression.test`
    fn test(self) -> Option<Expr<'a>>;
    /// `ConditionalExpression.alternate`
    fn alternate(self) -> Option<Expr<'a>>;
    /// `.argument` of a `UnaryExpression`, an `UpdateExpression`, an `AwaitExpression`, a
    /// `YieldExpression` or a `SpreadElement`.
    fn argument(self) -> Option<Expr<'a>>;
    /// `.expression` of a `TSAsExpression`, a `TSSatisfiesExpression`, a `TSTypeAssertion`, a
    /// `TSNonNullExpression` or a `TSInstantiationExpression`, and the index of a
    /// `ComputedMemberExpression`.
    fn expression(self) -> Option<Expr<'a>>;
    /// `.typeAnnotation` of a `TSAsExpression`, a `TSSatisfiesExpression` or a `TSTypeAssertion`.
    /// `None` for `as const`.
    fn type_annotation(self) -> Option<TypeNode<'a>>;
    /// The function of an `ArrowFunctionExpression`.
    fn arrow_function(self) -> Option<Func<'a>>;
}

impl<'a> ExprFields<'a> for Expr<'a> {
    #[inline]
    fn tag_expression(self) -> Option<Expr<'a>> {
        match self.tag() {
            ExprTag::TaggedTemplate => self.as_call_like().map(Call::callee),
            _ => None,
        }
    }

    #[inline]
    fn test(self) -> Option<Expr<'a>> {
        match self.tag() {
            ExprTag::Cond => match self.kind() {
                ExprKind::Cond { test, .. } => Some(test),
                _ => None,
            },
            _ => None,
        }
    }

    #[inline]
    fn alternate(self) -> Option<Expr<'a>> {
        match self.tag() {
            ExprTag::Cond => match self.kind() {
                ExprKind::Cond { no, .. } => Some(no),
                _ => None,
            },
            _ => None,
        }
    }

    #[inline]
    fn argument(self) -> Option<Expr<'a>> {
        match self.tag() {
            ExprTag::Unary | ExprTag::Await | ExprTag::Spread => self.operand(),
            ExprTag::Yield => match self.kind() {
                ExprKind::Yield { value, .. } => value,
                _ => None,
            },
            _ => None,
        }
    }

    #[inline]
    fn expression(self) -> Option<Expr<'a>> {
        match self.tag() {
            ExprTag::As
            | ExprTag::Satisfies
            | ExprTag::AsConst
            | ExprTag::NonNull
            | ExprTag::Instantiation => self.operand(),
            ExprTag::Index => self.index(),
            _ => None,
        }
    }

    #[inline]
    fn type_annotation(self) -> Option<TypeNode<'a>> {
        match self.tag() {
            ExprTag::As | ExprTag::Satisfies => match self.kind() {
                ExprKind::As { ty, .. } | ExprKind::Satisfies { ty, .. } => Some(ty),
                _ => None,
            },
            _ => None,
        }
    }

    #[inline]
    fn arrow_function(self) -> Option<Func<'a>> {
        self.as_fn().filter(|func| func.is_arrow())
    }
}

pub(crate) trait StmtFields<'a>: Copy {
    /// `ForInStatement.left`, `ForOfStatement.left`: a `Var` statement, or the statement that wraps an expression.
    fn for_left(self) -> Option<Stmt<'a>>;
    /// `ForStatement.init`
    fn for_init(self) -> Option<Stmt<'a>>;
    /// `TryStatement.finalizer`
    fn finalizer(self) -> Option<Stmt<'a>>;
    /// `for await`
    fn is_for_await(self) -> bool;
}

impl<'a> StmtFields<'a> for Stmt<'a> {
    fn for_left(self) -> Option<Stmt<'a>> {
        match self.kind() {
            StmtKind::ForIn { left, .. } | StmtKind::ForOf { left, .. } => Some(left),
            _ => None,
        }
    }

    fn for_init(self) -> Option<Stmt<'a>> {
        match self.kind() {
            StmtKind::For { init, .. } => init,
            _ => None,
        }
    }

    fn finalizer(self) -> Option<Stmt<'a>> {
        match self.kind() {
            StmtKind::Try { finalizer, .. } => finalizer,
            _ => None,
        }
    }

    fn is_for_await(self) -> bool {
        matches!(self.kind(), StmtKind::ForOf { is_await: true, .. })
    }
}
