//! `angular-html-parser` 10.12: `ml_parser/parser.ts`.

use super::ast::{Attribute, Id, Kind, Node, Span, StartTagComment, Tree};
use super::data::{self, TagDefinition};
use super::error::{ErrorKind, SyntaxError};
use super::lexer::{self, ContentType, GetTagContentType, LexedAttribute, Parts, Token, TokenType};
use rustc_hash::FxHashMap;
use std::borrow::Cow;

#[derive(Copy, Clone)]
pub(crate) struct Options<'f> {
    pub(crate) lexer: lexer::Options,
    pub(crate) is_tag_name_case_sensitive: bool,
    /// Prettier's `shouldParseAsRawText(tagName, prefix, hasParent, attrs)`
    pub(crate) should_parse_as_raw_text:
        Option<&'f dyn Fn(&[u8], bool, &[LexedAttribute<'_>]) -> bool>,
}

pub(crate) struct ParseResult<'a> {
    /// Its children are the `rootNodes`.
    pub(crate) root: Id,
    pub(crate) errors: Vec<SyntaxError<'a>>,
    pub(crate) is_nested_too_deeply: bool,
}

struct TreeBuilder<'a, 't, 'k> {
    text: &'a [u8],
    tree: &'t mut Tree<'a>,
    tokens: &'k [Token],
    index: usize,
    /// The index where this builder's tokens end, and the token it sees there instead.
    end: usize,
    eof: Token,
    container_stack: Vec<Id>,
    /// The parent of nodes that aren't in any container.
    root: Id,
    errors: Vec<SyntaxError<'a>>,
    can_self_close: bool,
    allow_htm_component_closing_tags: bool,
    is_tag_name_case_sensitive: bool,
    is_nested_too_deeply: bool,
    stack_check: bun_core::StackCheck,
    /// Ends of the nested ICU cases that were passed while scanning for the end of an outer one: maps the index of a
    /// case's first token to the index of the token that ends it.
    case_ends: FxHashMap<usize, usize>,
}

/// A name with its namespace: `:namespace:name`.
#[derive(Copy, Clone, PartialEq, Eq)]
struct FullName<'a> {
    prefix: &'a [u8],
    name: &'a [u8],
}

pub(crate) fn definition_of(name: &[u8], is_case_sensitive: bool) -> &'static TagDefinition {
    match is_case_sensitive || !name.iter().any(u8::is_ascii_uppercase) {
        true => data::tag_definition(name),
        false => data::tag_definition(&name.to_ascii_lowercase()),
    }
}

impl<'a> TreeBuilder<'a, '_, '_> {
    fn peek(&self) -> Token {
        match self.index < self.end {
            true => self.tokens.get(self.index).copied().unwrap_or(self.eof),
            false => self.eof,
        }
    }

    fn advance(&mut self) -> Token {
        let token = self.peek();
        if self.index < self.end {
            self.index += 1;
        }
        token
    }

    fn advance_if(&mut self, kind: TokenType) -> Option<Token> {
        (self.peek().kind == kind).then(|| self.advance())
    }

    /// `_getTagDefinition(node)`
    fn definition_of_node(&self, id: Id) -> Option<&'static TagDefinition> {
        let node = &self.tree[id];
        (node.kind == Kind::Element).then_some(node.tag_definition)
    }

    /// While the tree is being built, an element's name and namespace are substrings of the text.
    fn full_name_of(&self, id: Id) -> FullName<'a> {
        let node = &self.tree[id];
        FullName {
            prefix: node.namespace,
            name: match &node.name {
                Cow::Borrowed(name) => name,
                Cow::Owned(_) => b"",
            },
        }
    }

    /// `this.errors.push(TreeError.create(..))`
    fn error(&mut self, at: u32, kind: ErrorKind, name: &'a [u8]) {
        self.errors.push(SyntaxError::new(at, kind, name));
    }

    /// The same, for a message that includes an element's name.
    fn error_about(&mut self, at: u32, kind: ErrorKind, name: FullName<'a>) {
        self.errors.push(SyntaxError {
            prefix: name.prefix,
            ..SyntaxError::new(at, kind, name.name)
        });
    }

    fn build(&mut self) {
        use TokenType::*;
        while self.peek().kind != Eof && !self.is_nested_too_deeply {
            let kind = self.peek().kind;
            if matches!(
                kind,
                TagClose
                    | CdataStart
                    | CommentStart
                    | Text
                    | RawText
                    | EscapableRawText
                    | BlockOpenStart
                    | BlockClose
                    | IncompleteBlockOpen
                    | LetStart
                    | IncompleteLet
            ) {
                self.close_void_element();
            }
            let token = self.advance();
            match kind {
                TagOpenStart | IncompleteTagOpen => self.consume_element_start_tag(token),
                TagClose => self.consume_element_end_tag(token),
                CdataStart => self.consume_cdata(token),
                CommentStart => self.consume_comment(token),
                Text | RawText | EscapableRawText => self.consume_text(token),
                ExpansionFormStart => self.consume_expansion(token),
                BlockOpenStart => self.consume_block_open(token),
                BlockClose => self.consume_block_close(token),
                IncompleteBlockOpen => self.consume_incomplete_block(token),
                LetStart => self.consume_let(token),
                DocTypeStart => self.consume_doc_type(token),
                IncompleteLet => {
                    let name = match token.parts {
                        Parts::Value(name) => name.of(self.text),
                        _ => b"",
                    };
                    self.error(token.span.start, ErrorKind::IncompleteLet, name);
                }
                _ => {}
            }
        }
        for index in 0..self.container_stack.len() {
            let container = self.container_stack[index];
            if self.tree[container].kind == Kind::AngularControlFlowBlock {
                let name = self.full_name_of(container).name;
                self.error(
                    self.tree[container].span.start,
                    ErrorKind::UnclosedBlock,
                    name,
                );
            }
        }
    }

    fn container(&self) -> Option<Id> {
        self.container_stack.last().copied()
    }

    fn closest_element_like_parent(&self) -> Option<Id> {
        self.container_stack
            .iter()
            .rev()
            .copied()
            .find(|&id| self.tree[id].kind == Kind::Element)
    }

    fn add_to_parent(&mut self, node: Node<'a>) -> Id {
        let id = self.tree.add(node);
        self.tree
            .append_child(self.container().unwrap_or(self.root), id);
        id
    }

    /// True if a line feed at the start of a text in `parent` is ignored.
    fn ignores_first_lf(&self, parent: Option<Id>) -> bool {
        parent.is_some_and(|parent| {
            !self.tree.has_children(parent)
                && self
                    .definition_of_node(parent)
                    .is_some_and(|it| it.ignore_first_lf)
        })
    }

    fn consume_cdata(&mut self, start_token: Token) {
        let text = self.advance();
        let mut value = text.span.of(self.text);
        if value.first() == Some(&b'\n')
            && self.ignores_first_lf(self.closest_element_like_parent())
        {
            value = &value[1..];
        }
        let end_token = self.advance_if(TokenType::CdataEnd);
        let mut node = Node::new(
            Kind::Cdata,
            Span::new(start_token.span.start, end_token.unwrap_or(text).span.end),
        );
        node.value = Cow::Borrowed(value);
        self.add_to_parent(node);
    }

    fn consume_comment(&mut self, token: Token) {
        self.advance_if(TokenType::RawText);
        let end_token = self.advance_if(TokenType::CommentEnd);
        let span = Span::new(token.span.start, end_token.unwrap_or(token).span.end);
        self.add_to_parent(Node::new(Kind::Comment, span));
    }

    fn consume_doc_type(&mut self, start_token: Token) {
        let text = self.advance_if(TokenType::RawText);
        let end_token = self.advance_if(TokenType::DocTypeEnd);
        let end = end_token.or(text).unwrap_or(start_token).span.end;
        let mut node = Node::new(Kind::DocType, Span::new(start_token.span.start, end));
        node.value = Cow::Borrowed(text.map_or(&b""[..], |text| {
            bun_core::strings::trim_js_whitespace(text.span.of(self.text))
        }));
        self.add_to_parent(node);
    }

    fn value_of(&self, token: Token) -> &'a [u8] {
        match token.parts {
            Parts::Value(span) => span.of(self.text),
            Parts::ElseIf => b"else if",
            Parts::DefaultNever => b"default never",
            _ => token.span.of(self.text),
        }
    }

    fn consume_expansion(&mut self, token: Token) {
        let switch_value = self.advance();
        let kind = self.advance();
        let expansion = self
            .tree
            .add(Node::new(Kind::AngularIcuExpression, token.span));
        while self.peek().kind == TokenType::ExpansionCaseValue {
            match self.parse_expansion_case() {
                Some(case) => self.tree.append_child(expansion, case),
                None => return,
            }
        }
        if self.peek().kind != TokenType::ExpansionFormEnd {
            self.error(
                self.peek().span.start,
                ErrorKind::IcuWithoutClosingBrace,
                b"",
            );
            return;
        }
        let end = self.advance().span.end;
        let node = &mut self.tree[expansion];
        node.span.end = end;
        node.value = Cow::Borrowed(switch_value.span.of(self.text));
        node.name = Cow::Borrowed(kind.span.of(self.text));
        self.tree
            .append_child(self.container().unwrap_or(self.root), expansion);
    }

    fn parse_expansion_case(&mut self) -> Option<Id> {
        let value = self.advance();
        if self.peek().kind != TokenType::ExpansionCaseExpStart {
            self.error(
                self.peek().span.start,
                ErrorKind::IcuWithoutOpeningBrace,
                b"",
            );
            return None;
        }
        let start = self.advance();
        let first = self.index;
        self.skip_expansion_exp_tokens(start)?;
        let last = self.index;
        let end = self.advance();
        if !self.stack_check.is_safe_to_recurse() {
            self.is_nested_too_deeply = true;
            return None;
        }
        let mut node = Node::new(
            Kind::AngularIcuCase,
            Span::new(value.span.start, end.span.end),
        );
        node.value = Cow::Borrowed(self.value_of(value));
        let case = self.tree.add(node);
        let mut builder = TreeBuilder {
            text: self.text,
            tree: &mut *self.tree,
            tokens: self.tokens,
            index: first,
            end: last,
            eof: Token {
                kind: TokenType::Eof,
                span: end.span,
                parts: Parts::None,
            },
            container_stack: Vec::new(),
            root: case,
            errors: Vec::new(),
            can_self_close: self.can_self_close,
            allow_htm_component_closing_tags: self.allow_htm_component_closing_tags,
            is_tag_name_case_sensitive: self.is_tag_name_case_sensitive,
            is_nested_too_deeply: false,
            stack_check: self.stack_check,
            case_ends: std::mem::take(&mut self.case_ends),
        };
        builder.build();
        let (errors, is_nested_too_deeply) = (builder.errors, builder.is_nested_too_deeply);
        self.case_ends = builder.case_ends;
        self.is_nested_too_deeply |= is_nested_too_deeply;
        if !errors.is_empty() {
            self.errors.extend(errors);
            return None;
        }
        Some(case)
    }

    /// `_collectExpansionExpTokens`: skips to the token that ends the case.
    fn skip_expansion_exp_tokens(&mut self, start: Token) -> Option<()> {
        use TokenType::{
            Eof, ExpansionCaseExpEnd, ExpansionCaseExpStart, ExpansionFormEnd, ExpansionFormStart,
        };
        // This case is nested in one that was already scanned without errors.
        if let Some(&end) = self.case_ends.get(&self.index) {
            self.index = end;
            return Some(());
        }
        // The open forms and cases, each with the index of its first token.
        let mut stack = vec![(ExpansionCaseExpStart, self.index)];
        loop {
            let kind = self.peek().kind;
            if matches!(kind, ExpansionFormStart | ExpansionCaseExpStart) {
                stack.push((kind, self.index + 1));
            }
            if kind == ExpansionCaseExpEnd {
                let Some(&(ExpansionCaseExpStart, first)) = stack.last() else {
                    self.error(start.span.start, ErrorKind::IcuWithoutClosingBrace, b"");
                    return None;
                };
                self.case_ends.insert(first, self.index);
                stack.pop();
                if stack.is_empty() {
                    return Some(());
                }
            }
            if kind == ExpansionFormEnd {
                if !matches!(stack.last(), Some((ExpansionFormStart, _))) {
                    self.error(start.span.start, ErrorKind::IcuWithoutClosingBrace, b"");
                    return None;
                }
                stack.pop();
            }
            if kind == Eof {
                self.error(start.span.start, ErrorKind::IcuWithoutClosingBrace, b"");
                return None;
            }
            self.advance();
        }
    }

    fn consume_text(&mut self, token: Token) {
        let start = token.span.start;
        let mut end = token.span.end;
        let mut len = token.span.len();
        if token.span.of(self.text).first() == Some(&b'\n')
            && self.ignores_first_lf(self.container())
        {
            len -= 1;
        }
        while matches!(
            self.peek().kind,
            TokenType::Interpolation | TokenType::Text | TokenType::EncodedEntity
        ) {
            let token = self.advance();
            len += token.span.len();
            end = token.span.end;
        }
        if len > 0 {
            self.add_to_parent(Node::new(Kind::Text, Span::new(start, end)));
        }
    }

    fn close_void_element(&mut self) {
        if self
            .container()
            .and_then(|it| self.definition_of_node(it))
            .is_some_and(|it| it.is_void)
        {
            self.container_stack.pop();
        }
    }

    /// `_getElementFullName`, plus the definition for that name. With a namespace, the parser looks up `:prefix:name`.
    /// No definition has a colon in its name, so that's the default definition.
    fn full_name(
        &self,
        token: Token,
        parent: Option<Id>,
    ) -> (FullName<'a>, &'static TagDefinition) {
        let Parts::Name(prefix, name) = token.parts else {
            let (prefix, name) = (&b""[..], &b""[..]);
            return (FullName { prefix, name }, &data::DEFAULT_TAG_DEFINITION);
        };
        let (prefix, name) = (prefix.of(self.text), name.of(self.text));
        if !prefix.is_empty() {
            return (FullName { prefix, name }, &data::DEFAULT_TAG_DEFINITION);
        }
        let definition = definition_of(name, self.is_tag_name_case_sensitive);
        let mut prefix = definition.implicit_namespace_prefix.unwrap_or_default();
        if prefix.is_empty()
            && let Some(parent) = parent.map(|parent| self.full_name_of(parent))
            && !parent.prefix.is_empty()
            && !definition_of(parent.name, self.is_tag_name_case_sensitive)
                .prevent_namespace_inheritance
        {
            prefix = parent.prefix;
        }
        match prefix {
            b"" => (FullName { prefix, name }, definition),
            _ => (FullName { prefix, name }, &data::DEFAULT_TAG_DEFINITION),
        }
    }

    fn consume_element_start_tag(&mut self, start_tag_token: Token) {
        let first_attr = self.tree.attrs.len() as u32;
        let first_comment = self.tree.start_tag_comments.len() as u32;
        loop {
            match self.peek().kind {
                TokenType::AttrName => {
                    let name = self.advance();
                    let attr = self.consume_attr(name);
                    self.tree.attrs.push(attr);
                }
                TokenType::InElementComment => {
                    let token = self.advance();
                    if let Parts::Comment(content, is_single_line) = token.parts {
                        self.tree.start_tag_comments.push(StartTagComment {
                            span: token.span,
                            value: content.of(self.text),
                            is_single_line,
                        });
                    }
                }
                _ => break,
            }
        }
        let (full_name, definition) =
            self.full_name(start_tag_token, self.closest_element_like_parent());
        let mut is_self_closing = false;
        if self.peek().kind == TokenType::TagOpenEndVoid {
            self.advance();
            is_self_closing = true;
            if !(self.can_self_close
                || definition.can_self_close
                || !full_name.prefix.is_empty()
                || definition.is_void)
            {
                self.error(
                    start_tag_token.span.start,
                    ErrorKind::SelfClosed,
                    full_name.name,
                );
            }
        } else if self.peek().kind == TokenType::TagOpenEnd {
            self.advance();
        }
        let span = Span::new(start_tag_token.span.start, self.peek().span.start);
        let mut node = Node::new(Kind::Element, span);
        node.set_start_span(span);
        node.name_span = Span::new(start_tag_token.span.start + 1, start_tag_token.span.end);
        node.name = Cow::Borrowed(full_name.name);
        node.namespace = full_name.prefix;
        node.tag_definition = definition;
        node.attrs = (first_attr, self.tree.attrs.len() as u32);
        node.start_tag_comments = (first_comment, self.tree.start_tag_comments.len() as u32);
        let is_closed_by_child = self
            .container()
            .and_then(|it| self.definition_of_node(it))
            .is_some_and(|it| {
                // The lookup uses the child's full name, and no list has a name with a namespace.
                it.is_void || (full_name.prefix.is_empty() && it.is_closed_by_child(full_name.name))
            });
        self.push_container(node, is_closed_by_child);
        if is_self_closing {
            self.pop_container(Some(full_name), Kind::Element, Some(span));
        } else if start_tag_token.kind == TokenType::IncompleteTagOpen {
            self.pop_container(Some(full_name), Kind::Element, None);
            self.error_about(span.start, ErrorKind::OpeningTagNotTerminated, full_name);
        }
    }

    fn push_container(&mut self, node: Node<'a>, is_closed_by_child: bool) {
        if is_closed_by_child {
            self.container_stack.pop();
        }
        let id = self.add_to_parent(node);
        self.container_stack.push(id);
    }

    fn consume_element_end_tag(&mut self, end_tag_token: Token) {
        let full_name =
            match self.allow_htm_component_closing_tags && end_tag_token.parts == Parts::None {
                true => None,
                false => Some(self.full_name(end_tag_token, self.closest_element_like_parent())),
            };
        let at = end_tag_token.span.start;
        let name = full_name.map(|(name, _)| name);
        if let Some((name, _)) = full_name.filter(|(_, definition)| definition.is_void) {
            self.error(at, ErrorKind::EndTagOfVoidElement, name.name);
        } else if !self.pop_container(name, Kind::Element, Some(end_tag_token.span)) {
            let (prefix, name) = (&b""[..], &b"null"[..]);
            let name = full_name.map_or(FullName { prefix, name }, |(name, _)| name);
            self.error_about(at, ErrorKind::UnexpectedClosingTag, name);
        }
    }

    /// `_popContainer`
    fn pop_container(
        &mut self,
        expected_name: Option<FullName<'a>>,
        expected_kind: Kind,
        end_span: Option<Span>,
    ) -> bool {
        let mut unexpected_close_tag_detected = false;
        for stack_index in (0..self.container_stack.len()).rev() {
            let id = self.container_stack[stack_index];
            let kind = self.tree[id].kind;
            // A block's name has no namespace and is never compared.
            let name = self.full_name_of(id);
            let is_expected = match kind == Kind::Element && !name.prefix.is_empty() {
                true => Some(name) == expected_name,
                false => {
                    expected_name.is_none_or(|expected| kind == Kind::Element && expected == name)
                        && kind == expected_kind
                }
            };
            if is_expected {
                let node = &mut self.tree[id];
                node.set_end_span(end_span);
                if let Some(end_span) = end_span {
                    node.span.end = end_span.end;
                }
                self.container_stack.truncate(stack_index);
                return !unexpected_close_tag_detected;
            }
            if kind == Kind::AngularControlFlowBlock
                || !self
                    .definition_of_node(id)
                    .is_some_and(|it| it.closed_by_parent)
            {
                unexpected_close_tag_detected = true;
            }
        }
        false
    }

    fn consume_attr(&mut self, attr_name: Token) -> Attribute<'a> {
        let mut attr_end = attr_name.span.end;
        let start_quote = self.advance_if(TokenType::AttrQuote);
        let mut value_start = None;
        let mut value_end = None;
        if self.peek().kind == TokenType::AttrValueText {
            value_start = Some(self.peek().span.start);
            value_end = Some(self.peek().span.end);
            while matches!(
                self.peek().kind,
                TokenType::AttrValueText
                    | TokenType::AttrValueInterpolation
                    | TokenType::EncodedEntity
            ) {
                attr_end = self.advance().span.end;
                value_end = Some(attr_end);
            }
        }
        if let Some(quote) = self.advance_if(TokenType::AttrQuote) {
            attr_end = quote.span.end;
            value_end = Some(attr_end);
        }
        let (prefix, name) = match attr_name.parts {
            Parts::Name(prefix, name) => (prefix.of(self.text), name.of(self.text)),
            _ => (&b""[..], &b""[..]),
        };
        Attribute {
            span: Span::new(attr_name.span.start, attr_end),
            name_span: attr_name.span,
            value_span: value_start
                .zip(value_end)
                .map(|(start, end)| Span::new(start_quote.map_or(start, |it| it.span.start), end)),
            name: Cow::Borrowed(name),
            namespace: prefix,
            has_explicit_namespace: false,
            value: None,
        }
    }

    /// Makes a block, with its parameters, whose start span ends where the next token starts.
    fn block(&mut self, token: Token, has_end: bool) -> (Node<'a>, Option<Id>) {
        // Prettier's `normalizeAngularControlFlowBlock`.
        let mut parameters = None;
        while let Some(token) = self.advance_if(TokenType::BlockParameter) {
            let mut node = Node::new(Kind::AngularControlFlowBlockParameter, token.span);
            node.value = Cow::Borrowed(token.span.of(self.text));
            let parameter = self.tree.add(node);
            let list = *parameters.get_or_insert_with(|| {
                self.tree.add(Node::new(
                    Kind::AngularControlFlowBlockParameters,
                    token.span,
                ))
            });
            self.tree[list].span.end = token.span.end;
            self.tree.append_child(list, parameter);
        }
        if has_end {
            self.advance_if(TokenType::BlockOpenEnd);
        }
        let span = Span::new(token.span.start, self.peek().span.start);
        let mut node = Node::new(Kind::AngularControlFlowBlock, span);
        node.set_start_span(span);
        node.name_span = token.span;
        node.name = Cow::Borrowed(self.value_of(token));
        (node, parameters)
    }

    fn push_block(&mut self, (block, parameters): (Node<'a>, Option<Id>)) {
        self.push_container(block, false);
        if let (Some(block), Some(parameters)) = (self.container(), parameters) {
            self.tree.set_parameters(block, parameters);
        }
    }

    fn consume_block_open(&mut self, token: Token) {
        let block = self.block(token, true);
        self.push_block(block);
    }

    fn consume_block_close(&mut self, token: Token) {
        let (depth, top) = (self.container_stack.len(), self.container());
        if !self.pop_container(None, Kind::AngularControlFlowBlock, Some(token.span)) {
            // An open element was closed along the way.
            let (prefix, name) = (&b""[..], &b""[..]);
            let name = (top.filter(|_| self.container_stack.len() < depth))
                .map_or(FullName { prefix, name }, |top| self.full_name_of(top));
            self.error_about(token.span.start, ErrorKind::UnexpectedClosingBlock, name);
        }
    }

    fn consume_incomplete_block(&mut self, token: Token) {
        let block = self.block(token, false);
        let start = block.0.span.start;
        self.push_block(block);
        self.pop_container(None, Kind::AngularControlFlowBlock, None);
        self.error(start, ErrorKind::IncompleteBlock, self.value_of(token));
    }

    fn consume_let(&mut self, start_token: Token) {
        let (at, name) = (start_token.span.start, self.value_of(start_token));
        let Some(value_token) = self.advance_if(TokenType::LetValue) else {
            self.error(at, ErrorKind::LetWithoutValue, name);
            return;
        };
        let Some(end_token) = self.advance_if(TokenType::LetEnd) else {
            self.error(at, ErrorKind::LetNotTerminated, name);
            return;
        };
        // Prettier's `normalizeAngularLetDeclaration`.
        let mut node = Node::new(
            Kind::AngularLetDeclaration,
            Span::new(start_token.span.start, end_token.span.end),
        );
        node.name = Cow::Borrowed(self.value_of(start_token));
        node.name_span = value_token.span;
        node.value = Cow::Borrowed(value_token.span.of(self.text));
        self.add_to_parent(node);
    }
}

/// `new HtmlParser().parse(..)`, for the part of `text` from `start` on.
pub(crate) fn parse<'a>(
    tree: &mut Tree<'a>,
    text: &'a [u8],
    start: usize,
    options: Options<'_>,
) -> ParseResult<'a> {
    let is_case_sensitive = options.is_tag_name_case_sensitive;
    let get_tag_content_type = |name: &[u8], has_parent: bool, attrs: &[LexedAttribute<'_>]| {
        let is_raw =
            options
                .should_parse_as_raw_text
                .is_some_and(|should| match is_case_sensitive {
                    true => should(name, has_parent, attrs),
                    false => should(&name.to_ascii_lowercase(), has_parent, attrs),
                });
        if is_raw {
            ContentType::RawText
        } else {
            definition_of(name, is_case_sensitive).content_type
        }
    };
    let get_tag_content_type: GetTagContentType<'_> = &get_tag_content_type;
    let (tokens, mut errors) = lexer::tokenize(text, start, get_tag_content_type, options.lexer);
    // A node is typically three or four tokens.
    tree.nodes.reserve(tokens.len() / 3);
    let root = tree.add(Node::new(Kind::Root, Span::new(0, text.len() as u32)));
    let end = tokens.len().saturating_sub(1);
    let mut builder = TreeBuilder {
        text,
        tree,
        tokens: &tokens,
        index: 0,
        end,
        eof: tokens.last().copied().unwrap_or_else(|| Token {
            kind: TokenType::Eof,
            span: Span::new(text.len() as u32, text.len() as u32),
            parts: Parts::None,
        }),
        container_stack: Vec::new(),
        root,
        errors: Vec::new(),
        can_self_close: options.lexer.can_self_close,
        allow_htm_component_closing_tags: options.lexer.allow_htm_component_closing_tags,
        is_tag_name_case_sensitive: is_case_sensitive,
        is_nested_too_deeply: false,
        stack_check: crate::stack::check_for_tree(),
        case_ends: FxHashMap::default(),
    };
    builder.build();
    errors.append(&mut builder.errors);
    let ended = builder.eof.span.start;
    if (ended as usize) < text.len() {
        errors.push(SyntaxError::new(ended, ErrorKind::TextAfterNul, b""));
    }
    ParseResult {
        root,
        errors,
        is_nested_too_deeply: builder.is_nested_too_deeply,
    }
}
