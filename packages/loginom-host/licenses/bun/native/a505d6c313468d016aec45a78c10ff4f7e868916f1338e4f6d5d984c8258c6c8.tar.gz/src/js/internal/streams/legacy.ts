"use strict";

const EE = require("node:events");
const { isArrayBufferView, isUint8Array } = require("node:util/types");

const ReflectOwnKeys = Reflect.ownKeys;
const ArrayIsArray = Array.isArray;

function Stream(opts) {
  EE.$call(this, opts);
}
$toClass(Stream, "Stream", EE);

Stream.prototype.pipe = function (dest, options) {
  const source = this;

  function ondata(chunk) {
    if (dest.writable && dest.write(chunk) === false && source.pause) {
      source.pause();
    }
  }

  source.on("data", ondata);

  function ondrain() {
    if (source.readable && source.resume) {
      source.resume();
    }
  }

  dest.on("drain", ondrain);

  // If the 'end' option is not supplied, dest.end() will be called when
  // source gets the 'end' or 'close' events.  Only dest.end() once.
  if (!dest._isStdio && (!options || options.end !== false)) {
    source.on("end", onend);
    source.on("close", onclose);
  }

  let didOnEnd = false;
  function onend() {
    if (didOnEnd) return;
    didOnEnd = true;

    dest.end();
  }

  function onclose() {
    if (didOnEnd) return;
    didOnEnd = true;

    if (typeof dest.destroy === "function") dest.destroy();
  }

  // Don't leave dangling pipes when there are errors.
  function onerror(er) {
    cleanup();
    if (this.listenerCount?.("error") === 0) {
      this.emit("error", er);
    }
  }

  prependListener(source, "error", onerror);
  prependListener(dest, "error", onerror);

  // Remove all the event listeners that were added.
  function cleanup() {
    source.removeListener("data", ondata);
    dest.removeListener("drain", ondrain);

    source.removeListener("end", onend);
    source.removeListener("close", onclose);

    source.removeListener("error", onerror);
    dest.removeListener("error", onerror);

    source.removeListener("end", cleanup);
    source.removeListener("close", cleanup);

    dest.removeListener("close", cleanup);
  }

  source.on("end", cleanup);
  source.on("close", cleanup);

  dest.on("close", cleanup);
  dest.emit("pipe", source);

  // Allow for unix-like usage: A.pipe(B).pipe(C)
  return dest;
};

Stream.prototype.eventNames = function eventNames() {
  const names: PropertyKey[] = [];
  for (const key of ReflectOwnKeys(this._events)) {
    if (typeof this._events[key] === "function" || (ArrayIsArray(this._events[key]) && this._events[key].length > 0)) {
      names.push(key);
    }
  }
  return names;
};

function prependListener(emitter, event, fn) {
  // Sadly this is not cacheable as some libraries bundle their own
  // event emitter implementation with them.
  if (typeof emitter.prependListener === "function") return emitter.prependListener(event, fn);

  // This is a hack to make sure that our error handler is attached before any
  // userland ones.  NEVER DO THIS. This is here only because this code needs
  // to continue to work with older versions of Node.js that do not include
  // the prependListener() method. The goal is to eventually remove this hack.
  let events, existing;
  if (!(events = emitter._events) || !(existing = events[event])) emitter.on(event, fn);
  // A fresh array, not unshift(): node:events iterates stored arrays without
  // cloning, so a stored `_events` array must never be mutated in place.
  else if (ArrayIsArray(existing)) events[event] = [fn, ...existing];
  else events[event] = [fn, existing];
}

// Add helper methods to Stream
Stream._isArrayBufferView = isArrayBufferView;
Stream._isUint8Array = isUint8Array;
Stream._uint8ArrayToBuffer = function _uint8ArrayToBuffer(chunk) {
  return new $Buffer(chunk.buffer, chunk.byteOffset, chunk.byteLength);
};

type NodeStream = typeof import("node:stream").Stream;

interface StreamConstructor extends Omit<NodeStream, "Stream" | "pipeline" | "finished"> {
  new (opts?: ConstructorParameters<NodeStream>[0]): import("node:stream").Stream;
  Stream: StreamConstructor;
  pipeline: typeof import("internal/streams/pipeline").default.pipeline;
  finished: typeof import("internal/streams/end-of-stream").default;
  eos?: typeof import("internal/streams/end-of-stream").default;
  destroy: typeof import("internal/streams/destroy").default.destroyer;
  isDestroyed: typeof import("internal/streams/utils").default.isDestroyed;
  isDisturbed: typeof import("internal/streams/utils").default.isDisturbed;
  _isArrayBufferView: typeof Stream._isArrayBufferView;
  _isUint8Array: typeof Stream._isUint8Array;
  _uint8ArrayToBuffer: typeof Stream._uint8ArrayToBuffer;
}

export default { Stream, prependListener } as unknown as {
  Stream: StreamConstructor;
  prependListener: typeof prependListener;
};
