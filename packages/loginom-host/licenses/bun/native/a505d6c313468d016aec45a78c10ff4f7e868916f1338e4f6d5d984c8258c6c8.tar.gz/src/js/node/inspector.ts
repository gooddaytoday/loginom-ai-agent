// Hardcoded module "node:inspector" and "node:inspector/promises"
// Implemented: the in-process Session (Profiler CPU profiles and precise
// coverage, Runtime console notifications, forwarded Debugger.* configuration),
// and open()/url()/close()/waitForDebugger() backed by a Chrome DevTools
// Protocol WebSocket server with breakpoint pausing.
const { hideFromStack } = require("internal/shared");
const { validateString, validateFunction } = require("internal/validators");
const { SafeSet } = require("internal/primordials");
const EventEmitter = require("node:events");
const { pathToFileURL } = require("node:url");
const { isAbsolute } = require("node:path");
const DateNow = Date.now;

// #handleMethod return marker for inspector-protocol errors: the callback
// receives the plain `{ code, message }` object (Node delivers protocol
// errors as plain objects, not Error instances).
const kProtocolError = Symbol("kProtocolError");

// Native profiler functions exposed via $newCppFunction
const startCPUProfiler = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_startCPUProfiler", 0);
const stopCPUProfiler = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_stopCPUProfiler", 0);
const setCPUSamplingInterval = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_setCPUSamplingInterval", 1);
const isCPUProfilerRunning = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_isCPUProfilerRunning", 0);
const startPreciseCoverage = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_startPreciseCoverage", 0);
const stopPreciseCoverage = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_stopPreciseCoverage", 0);
const collectPreciseCoverage = $newCppFunction("JSInspectorProfiler.cpp", "jsFunction_collectPreciseCoverage", 0);

// Native bindings for inspector.open(): they start Bun's debugger thread with a
// WebSocket server that speaks the V8 Chrome DevTools Protocol (see
// internal/debugger.ts and internal/inspector/cdp.ts).
const openNodeInspector = $newCppFunction("BunDebugger.cpp", "jsFunction_openNodeInspector", 2);
const waitForNodeInspectorConnection = $newCppFunction(
  "BunDebugger.cpp",
  "jsFunction_waitForNodeInspectorConnection",
  0,
);
const postNodeInspectorControl = $newCppFunction("BunDebugger.cpp", "jsFunction_postNodeInspectorControl", 1);
const closeNodeInspector = $newCppFunction("BunDebugger.cpp", "jsFunction_closeNodeInspector", 0);

let activeInspectorUrl: string | undefined;

function open(port?: number, host?: string, wait?: boolean) {
  if (activeInspectorUrl !== undefined) {
    throw $ERR_INSPECTOR_ALREADY_ACTIVATED();
  }
  if (!Bun.isMainThread) {
    // Node supports per-worker inspectors; Bun does not yet.
    throw $ERR_WORKER_UNSUPPORTED_OPERATION("inspector.open() is not supported in workers");
  }

  if (port !== undefined && port !== null) {
    if (typeof port !== "number" || !Number.isInteger(port) || port < 0 || port > 65535) {
      throw $ERR_OUT_OF_RANGE("port", ">= 0 && <= 65535", port);
    }
  }
  const portNumber = port === undefined || port === null ? process.debugPort : port;
  const hostname = typeof host === "string" && host.length > 0 ? host : "127.0.0.1";
  // Bracket bare IPv6 hosts so they survive URL parsing.
  const hostPart = hostname.includes(":") && !hostname.startsWith("[") ? `[${hostname}]` : hostname;
  const requestedUrl = `ws://${hostPart}:${portNumber}/${globalThis.crypto.randomUUID()}`;

  const disposable = {
    __proto__: null,
    [Symbol.dispose]() {
      close();
    },
  };

  let resolvedUrl: string | null | EvalError;
  try {
    resolvedUrl = openNodeInspector(requestedUrl, !!wait);
  } catch (e) {
    // Node prints one diagnostic line and returns instead of throwing when the
    // socket cannot be bound, so a caller can retry with a different port.
    const raw = (e as Error)?.message ?? String(e);
    const prefix = "Failed to start inspector: ";
    const detail = raw.startsWith(prefix) ? raw.slice(prefix.length) : raw;
    process.stderr.write(`Starting inspector on ${hostname}:${portNumber} failed: ${detail}\n`);
    return disposable;
  }
  if (typeof resolvedUrl === "object" && resolvedUrl !== null) {
    // --disallow-code-generation-from-strings=strict
    throw resolvedUrl;
  }
  if (resolvedUrl === null) {
    // A prior inspector.open() success is caught by the top guard above, so
    // null here means the debugger thread was started outside node:inspector
    // (CLI --inspect / BUN_INSPECT). That server speaks the JSC protocol and
    // never registered a controlCallback, so inspector.close() cannot shut it
    // down; the default ERR_INSPECTOR_ALREADY_ACTIVATED message would send the
    // user to a no-op close().
    throw $ERR_INSPECTOR_ALREADY_ACTIVATED(
      "An inspector was already started via --inspect and cannot be reopened from node:inspector",
    );
  }

  activeInspectorUrl = resolvedUrl;
  // Node writes the resolved port back so process.debugPort reflects it after
  // open(0) picks an ephemeral port.
  try {
    process.debugPort = Number(new URL(resolvedUrl).port);
  } catch {}
  process.stderr.write(`Debugger listening on ${resolvedUrl}\n`);

  if (wait) {
    waitForNodeInspectorConnection();
  }

  return disposable;
}

function close() {
  if (activeInspectorUrl === undefined) {
    return;
  }
  // Sends the "close" control message and blocks until the debugger thread has
  // stopped the server, so the port is already refused when close() returns.
  closeNodeInspector();
  activeInspectorUrl = undefined;
}

function url() {
  // https://nodejs.org/api/inspector.html#inspectorurl
  return activeInspectorUrl;
}

function waitForDebugger() {
  if (activeInspectorUrl === undefined) {
    throw $ERR_INSPECTOR_NOT_ACTIVE();
  }
  waitForNodeInspectorConnection();
}

// Sessions with Runtime enabled receive Runtime.consoleAPICalled for console
// calls. This monkey-patches globalThis.console (not JSC's ConsoleClient as
// cdp.ts does), so pre-captured refs bypass it and no stackTrace is emitted.
// SafeSet iteration is tamper-proof (own frozen Symbol.iterator), so a hostile
// Set.prototype[Symbol.iterator] cannot make console.log itself throw from
// inside the hook's for-of loop head.
const runtimeEnabledSessions: Set<Session> = new SafeSet();
const hookedConsoleMethods: Array<[string, Function, Function]> = [];

const CONSOLE_API_TYPES = {
  __proto__: null,
  log: "log",
  info: "info",
  warn: "warning",
  error: "error",
  debug: "debug",
  trace: "trace",
  dir: "dir",
  table: "table",
  group: "startGroup",
  groupCollapsed: "startGroupCollapsed",
  groupEnd: "endGroup",
};

function toRemoteObject(arg: unknown): object {
  switch (typeof arg) {
    case "string":
      return { type: "string", value: arg };
    case "number":
      if (Object.is(arg, -0)) return { type: "number", unserializableValue: "-0", description: "-0" };
      return Number.isFinite(arg)
        ? { type: "number", value: arg, description: String(arg) }
        : {
            type: "number",
            unserializableValue: String(arg),
            description: String(arg),
          };
    case "boolean":
      return { type: "boolean", value: arg };
    case "undefined":
      return { type: "undefined" };
    case "bigint":
      return {
        type: "bigint",
        unserializableValue: `${arg}n`,
        description: `${arg}n`,
      };
    case "symbol":
      return { type: "symbol", description: String(arg) };
    case "function":
      return {
        type: "function",
        description: Function.prototype.toString.$call(arg),
      };
    default:
      if (arg === null) return { type: "object", subtype: "null", value: null };
      return {
        type: "object",
        description: Object.prototype.toString.$call(arg),
      };
  }
}

// Node delivers consoleAPICalled through V8's message pump, so a listener
// that logs cannot re-enter the console hook. We emit synchronously, so a
// guard is needed: console calls made from inside a listener run the
// original method but are not re-emitted.
let emittingConsoleAPI = false;

function emitConsoleAPICalled(type: string, args: unknown[]) {
  if (emittingConsoleAPI) return;
  emittingConsoleAPI = true;
  try {
    const timestamp = DateNow();
    for (const session of runtimeEnabledSessions) {
      // Neither a throwing listener nor a throwing argument serialization
      // (toRemoteObject reads user-controlled toString) may make the console
      // call itself throw, suppress the underlying output, or starve later
      // sessions; Node surfaces listener exceptions as process warnings.
      try {
        // A fresh message per session: a listener that mutates its payload
        // must not contaminate what the next session receives.
        const message = {
          method: "Runtime.consoleAPICalled",
          params: {
            type,
            args: args.map(toRemoteObject),
            executionContextId: 1,
            timestamp,
          },
        };
        // Node's Session#onMessage emits the method-specific event first,
        // then the generic "inspectorNotification".
        session.emit("Runtime.consoleAPICalled", message);
        session.emit("inspectorNotification", message);
      } catch (e) {
        let warning: Error;
        // Both `instanceof` (prototype walk) and String(e) can themselves
        // throw on hostile values like a thrown revoked Proxy, which would
        // defeat this guard.
        try {
          warning = e instanceof Error ? e : new Error(String(e));
        } catch {
          warning = new Error("Runtime.consoleAPICalled handler threw a value that could not be stringified");
        }
        process.emitWarning(warning);
      }
    }
  } finally {
    emittingConsoleAPI = false;
  }
}

function makeConsoleHook(type: string, original: Function): Function {
  return function (this: unknown, ...args: unknown[]) {
    emitConsoleAPICalled(type, args);
    return original.$apply(this, args);
  };
}

function installConsoleHooks() {
  if (hookedConsoleMethods.length > 0) return;
  const consoleObject = globalThis.console;
  for (const method in CONSOLE_API_TYPES) {
    const original = consoleObject[method];
    if (typeof original !== "function") continue;
    const hook = makeConsoleHook(CONSOLE_API_TYPES[method], original);
    hookedConsoleMethods.push([method, original, hook]);
    consoleObject[method] = hook;
  }
}

function removeConsoleHooks() {
  const consoleObject = globalThis.console;
  for (let i = 0; i < hookedConsoleMethods.length; i++) {
    const entry = hookedConsoleMethods[i];
    // Only restore slots that still hold our hook — user code may have
    // reassigned the method since the Runtime domain was enabled.
    if (consoleObject[entry[0]] === entry[2]) {
      consoleObject[entry[0]] = entry[1];
    }
  }
  hookedConsoleMethods.length = 0;
}

// Reshapes the raw control-flow-profiler data from jsFunction_collectPreciseCoverage
// ([{ url, scriptId, sourceLength, blocks: [[start, end, count]], functions: [[start, end, executed]] }])
// into the V8 ScriptCoverage list returned by Profiler.takePreciseCoverage:
// each function gets an entry whose first range spans the whole function with its
// call count, followed by the basic-block ranges inside it; blocks outside any
// function go on a synthetic whole-script entry.
function buildScriptCoverageList(
  rawScripts: Array<{
    url: string;
    scriptId: number;
    sourceLength: number;
    blocks: Array<[number, number, number]>;
    functions: Array<[number, number, boolean]>;
  }>,
  callCount: boolean,
  detailed: boolean,
): object[] {
  const result: object[] = [];

  for (const script of rawScripts) {
    const { scriptId, sourceLength } = script;
    // V8 does not report empty scripts (the whole-script range would be zero-width).
    if (sourceLength === 0) continue;
    let { url } = script;
    // V8 coverage reports file-backed scripts with file:// URLs even when the
    // script name is a plain filesystem path (e.g. a vm script filename or a
    // require()d module), so convert absolute paths the same way.
    if (url && isAbsolute(url)) {
      url = pathToFileURL(url).href;
    }

    // Outer ranges before nested ones, so a stack-based sweep below sees
    // enclosing ranges first.
    const functions = script.functions.sort((a, b) => a[0] - b[0] || b[1] - a[1]);
    const blocks = script.blocks.sort((a, b) => a[0] - b[0] || b[1] - a[1]);

    // Assign each basic block to the innermost function range containing it.
    const blocksPerFunction: Array<Array<[number, number, number]>> = functions.map(() => []);
    const topLevelBlocks: Array<[number, number, number]> = [];
    const stack: number[] = [];
    let nextFunction = 0;
    for (const block of blocks) {
      // The script's own, which is not in a function that is the whole script.
      if (block[0] === 0 && block[1] === sourceLength) {
        topLevelBlocks.push(block);
        continue;
      }
      while (nextFunction < functions.length && functions[nextFunction][0] <= block[0]) {
        stack.push(nextFunction);
        nextFunction++;
      }
      // Functions that ended before this block started can no longer contain
      // this block or any later one (blocks are sorted by start).
      while (stack.length > 0 && functions[stack[stack.length - 1]][1] <= block[0]) {
        stack.pop();
      }
      // The stack is a nesting chain (siblings get popped above), so ends
      // decrease towards the top; the first entry from the top that still
      // covers the block's end is the innermost containing function.
      let owner = -1;
      for (let i = stack.length - 1; i >= 0; i--) {
        if (functions[stack[i]][1] >= block[1]) {
          owner = stack[i];
          break;
        }
      }
      if (owner === -1) {
        topLevelBlocks.push(block);
      } else {
        blocksPerFunction[owner].push(block);
      }
    }

    // Derived from the (delta-subtracted) block counts only: the function
    // `executed` flag is cumulative and would make a second takePreciseCoverage
    // report 1 even when nothing ran since the first.
    const scriptExecuted = blocks.some(([, , count]) => count > 0) ? 1 : 0;
    const entries: object[] = [];

    // As in V8, a range is listed only where its count is not that of the range it is in.
    const toRanges = (outer: [number, number, number], inner: Array<[number, number, number]>) => {
      const ranges: Array<{ startOffset: number; endOffset: number; count: number }> = [];
      const enclosing: typeof ranges = [];
      for (const [startOffset, endOffset, blockCount] of detailed ? [outer, ...inner] : [outer]) {
        while (enclosing.length > 0 && enclosing[enclosing.length - 1].endOffset <= startOffset) enclosing.pop();
        const count = callCount ? blockCount : blockCount > 0 ? 1 : 0;
        if (enclosing.length > 0 && enclosing[enclosing.length - 1].count === count) continue;
        const range = { startOffset, endOffset, count };
        ranges.push(range);
        enclosing.push(range);
      }
      return ranges;
    };

    // Whole-script entry. V8 always reports one covering the entire source.
    entries.push({
      functionName: "",
      ranges: toRanges([0, sourceLength, scriptExecuted], topLevelBlocks),
      isBlockCoverage: detailed,
    });

    for (let i = 0; i < functions.length; i++) {
      const [startOffset, endOffset, executed] = functions[i];
      if (!executed) {
        entries.push({
          functionName: "",
          ranges: [{ startOffset, endOffset, count: 0 }],
          isBlockCoverage: false,
        });
        continue;
      }

      const ownBlocks = blocksPerFunction[i];
      // Approximate the call count from the entry block (the one with the
      // smallest start offset). Diverges from V8 for generators/async
      // functions, which JSC compiles as two nested CodeBlocks whose body
      // entry counts state-0 resumes rather than user-visible calls.
      let count = 1;
      if (ownBlocks.length > 0) {
        let entryBlock = ownBlocks[0];
        for (const block of ownBlocks) {
          if (block[0] < entryBlock[0]) entryBlock = block;
        }
        count = entryBlock[2];
      }
      entries.push({
        functionName: "",
        ranges: toRanges([startOffset, endOffset, count], ownBlocks),
        isBlockCoverage: detailed,
      });
    }

    result.push({ scriptId: String(scriptId), url, functions: entries });
  }

  return result;
}

function collectCoverageScripts(): any[] | Error {
  const raw = collectPreciseCoverage();
  if (raw === null) return [];
  try {
    return JSON.parse(raw);
  } catch (e) {
    return $ERR_INSPECTOR_COMMAND(`-32000: Failed to parse coverage JSON: ${e}`);
  }
}

class Session extends EventEmitter {
  #connected = false;
  #profilerEnabled = false;
  #preciseCoverageEnabled = false;
  #preciseCoverageCallCount = false;
  #preciseCoverageDetailed = false;
  #forwardedDebugger = false;
  // Baseline for delta semantics: takePreciseCoverage must reset counters, but
  // JSC has no counter-reset API, so subtract the previous take instead.
  #coverageBaseline: Map<string, number> = new Map();

  // Report each block's count relative to the baseline, and make the raw
  // counts the new baseline.
  #rebaseCoverage(scripts: any[]) {
    const baseline = this.#coverageBaseline;
    for (const script of scripts) {
      for (const block of script.blocks) {
        const key = `${script.scriptId}:${block[0]}:${block[1]}`;
        const raw = block[2];
        block[2] = Math.max(0, raw - (baseline.$get(key) ?? 0));
        baseline.$set(key, raw);
      }
    }
  }

  #snapshotCoverageBaseline() {
    const scripts = collectCoverageScripts();
    if (!(scripts instanceof Error)) this.#rebaseCoverage(scripts);
  }

  connect() {
    if (this.#connected) {
      throw $ERR_INSPECTOR_ALREADY_CONNECTED();
    }
    this.#connected = true;
  }

  connectToMainThread() {
    if (Bun.isMainThread) {
      throw $ERR_INSPECTOR_NOT_WORKER();
    }
    this.connect();
  }

  disconnect() {
    if (!this.#connected) return;
    if (isCPUProfilerRunning()) stopCPUProfiler();
    if (this.#preciseCoverageEnabled) {
      stopPreciseCoverage();
      this.#preciseCoverageEnabled = false;
    }
    this.#profilerEnabled = false;
    this.#connected = false;
    this.#coverageBaseline.$clear();
    runtimeEnabledSessions.delete(this);
    if (runtimeEnabledSessions.size === 0) removeConsoleHooks();
    // Forwarded Debugger.* state (breakpoints etc.) lives on a shared backend
    // on the debugger thread; release it so a disconnected session cannot keep
    // pausing the process, matching Node's disconnect() contract.
    if (this.#forwardedDebugger && activeInspectorUrl !== undefined) {
      postNodeInspectorControl(JSON.stringify({ type: "session-disconnect" }));
    }
    this.#forwardedDebugger = false;
  }

  post(
    method: string,
    params?: Record<string, unknown> | ((err: Error | null, result?: any) => void),
    callback?: (err: Error | null, result?: any) => void,
  ) {
    validateString(method, "method");
    // Handle overloaded signature: post(method, callback)
    if (callback === undefined && typeof params === "function") {
      callback = params;
      params = undefined;
    }
    if (params !== undefined && params !== null && typeof params !== "object") {
      throw $ERR_INVALID_ARG_TYPE("params", "Object", params);
    }
    if (callback !== undefined) validateFunction(callback, "callback");

    if (!this.#connected) {
      const error = $ERR_INSPECTOR_NOT_CONNECTED();
      if (callback) {
        queueMicrotask(() => callback(error));
        return;
      }
      throw error;
    }

    const result = this.#handleMethod(method, params as object | undefined);

    if (callback) {
      // Callback API - async
      queueMicrotask(() => {
        if (result instanceof Error) {
          callback(result, undefined);
        } else if (result !== null && typeof result === "object" && kProtocolError in result) {
          callback(result[kProtocolError], undefined);
        } else {
          callback(null, result);
        }
      });
    } else {
      // Sync throw for errors when no callback
      if (result instanceof Error) {
        throw result;
      }
      if (result !== null && typeof result === "object" && kProtocolError in result) {
        const protocolError = result[kProtocolError];
        const error = new Error(protocolError.message);
        error.code = protocolError.code;
        throw error;
      }
      return result;
    }
  }

  #handleMethod(method: string, params?: object): any {
    switch (method) {
      case "Runtime.enable":
        runtimeEnabledSessions.add(this);
        installConsoleHooks();
        return {};

      case "Runtime.disable":
        runtimeEnabledSessions.delete(this);
        if (runtimeEnabledSessions.size === 0) removeConsoleHooks();
        return {};

      case "Profiler.enable":
        this.#profilerEnabled = true;
        return {};

      case "Profiler.disable":
        if (isCPUProfilerRunning()) {
          stopCPUProfiler();
        }
        // V8's Profiler agent stops precise coverage on disable; without this
        // the control-flow profiler keeps instrumenting newly-compiled code.
        if (this.#preciseCoverageEnabled) {
          stopPreciseCoverage();
          this.#preciseCoverageEnabled = false;
        }
        this.#profilerEnabled = false;
        return {};

      case "Profiler.start":
        if (!this.#profilerEnabled) return $ERR_INSPECTOR_COMMAND("-32000: Profiler is not enabled");
        if (!isCPUProfilerRunning()) startCPUProfiler();
        return {};

      case "Profiler.stop":
        if (!isCPUProfilerRunning()) return $ERR_INSPECTOR_COMMAND("-32000: Profiler is not started");
        try {
          return { profile: JSON.parse(stopCPUProfiler()) };
        } catch (e) {
          return $ERR_INSPECTOR_COMMAND(`-32000: Failed to parse profile JSON: ${e}`);
        }

      case "Profiler.setSamplingInterval": {
        if (isCPUProfilerRunning())
          return $ERR_INSPECTOR_COMMAND("-32000: Cannot change sampling interval while profiler is running");
        const interval = (params as any)?.interval;
        if (typeof interval !== "number" || interval <= 0)
          return $ERR_INSPECTOR_COMMAND("-32602: interval must be a positive number");
        setCPUSamplingInterval(interval);
        return {};
      }

      case "Profiler.startPreciseCoverage": {
        if (!this.#profilerEnabled) return $ERR_INSPECTOR_COMMAND("-32000: Profiler is not enabled");
        if (!this.#preciseCoverageEnabled) {
          startPreciseCoverage();
          this.#preciseCoverageEnabled = true;
        }
        this.#preciseCoverageCallCount = !!(params as any)?.callCount;
        this.#preciseCoverageDetailed = !!(params as any)?.detailed;
        // Counts start from zero here: the VM's profiler is never torn down once
        // enabled (see JSInspectorProfiler.cpp), so whatever it accumulated
        // before this start — an earlier session, or the window since a
        // stopPreciseCoverage — becomes the baseline the next take subtracts.
        this.#coverageBaseline.$clear();
        this.#snapshotCoverageBaseline();
        // CDP: monotonic seconds since an arbitrary origin (V8 uses TimeTicks).
        return { timestamp: performance.now() / 1000 };
      }

      case "Profiler.stopPreciseCoverage": {
        if (!this.#profilerEnabled) return $ERR_INSPECTOR_COMMAND("-32000: Profiler is not enabled");
        if (this.#preciseCoverageEnabled) {
          stopPreciseCoverage();
          this.#preciseCoverageEnabled = false;
        }
        this.#coverageBaseline.$clear();
        return {};
      }

      case "Profiler.takePreciseCoverage": {
        if (!this.#preciseCoverageEnabled)
          return $ERR_INSPECTOR_COMMAND("-32000: Precise coverage has not been started.");
        const scripts = collectCoverageScripts();
        if (scripts instanceof Error) return scripts;
        // CDP contract: takePreciseCoverage resets execution counters, so a
        // second take reports the delta. JSC has no counter reset, so subtract
        // the previous take's raw block counts (function-level call counts are
        // derived from the entry block, so they follow automatically).
        this.#rebaseCoverage(scripts);
        return {
          result: buildScriptCoverageList(scripts, this.#preciseCoverageCallCount, this.#preciseCoverageDetailed),
          timestamp: performance.now() / 1000,
        };
      }

      case "Profiler.getBestEffortCoverage": {
        // JSC has no always-on invocation counters, so unlike V8 this returns
        // [] unless startPreciseCoverage has run in this VM.
        const scripts = collectCoverageScripts();
        if (scripts instanceof Error) return scripts;
        return { result: buildScriptCoverageList(scripts, false, false) };
      }

      // Configuration-only Debugger commands are forwarded to the inspector
      // server started by inspector.open() (vitest --inspect-brk uses
      // Debugger.enable + Debugger.setBreakpointByUrl to stop at the first
      // test file). The forwarding is fire-and-forget: results such as
      // breakpointId are not available in-process.
      case "Debugger.enable":
      case "Debugger.disable":
      case "Debugger.setBreakpointByUrl":
      case "Debugger.removeBreakpoint":
      case "Debugger.setBreakpointsActive":
      case "Debugger.setPauseOnExceptions":
      case "Debugger.setSkipAllPauses":
      case "Debugger.setAsyncCallStackDepth":
      case "Debugger.setBlackboxPatterns": {
        if (activeInspectorUrl === undefined) {
          return $ERR_INSPECTOR_COMMAND(
            `-32000: Inspector method "${method}" requires an active inspector (call inspector.open() first)`,
          );
        }
        if (!this.#forwardedDebugger) {
          this.#forwardedDebugger = true;
          postNodeInspectorControl(JSON.stringify({ type: "session-connect" }));
        }
        postNodeInspectorControl(JSON.stringify({ type: "command", method, params }));
        return {};
      }

      case "NodeWorker.enable": {
        // Minimal NodeWorker domain stub for test-worker-name only: a session
        // connected from inside a worker reports itself. Main-thread child
        // enumeration is NOT implemented — return an error there instead of
        // silent success so callers know.
        const wt = require("node:worker_threads");
        if (wt.isMainThread) {
          return new Error("Inspector method NodeWorker.enable is not supported on the main thread yet");
        }
        const title = `[worker ${wt.threadId}] ${wt.threadName}`;
        const workerInfo = { workerId: String(wt.threadId), type: "worker", title };
        queueMicrotask(() => {
          this.emit("NodeWorker.attachedToWorker", {
            params: { sessionId: `worker:${wt.threadId}`, workerInfo },
          });
        });
        return {};
      }

      case "NodeWorker.disable":
      case "NodeWorker.detach":
        return {};

      case "NodeTracing.start": {
        if (!Bun.isMainThread) {
          return {
            [kProtocolError]: {
              code: -32000,
              message: "Tracing properties can only be changed through main thread sessions",
            },
          };
        }
        const includedCategories = (params as any)?.traceConfig?.includedCategories;
        const categories = $isArray(includedCategories) ? includedCategories : [];
        const started = require("internal/trace_events").inspectorStart(categories);
        if (!started) {
          return { [kProtocolError]: { code: -32000, message: "Tracing is already started" } };
        }
        return {};
      }

      case "NodeTracing.stop": {
        if (!Bun.isMainThread) {
          return {
            [kProtocolError]: {
              code: -32000,
              message: "Tracing properties can only be changed through main thread sessions",
            },
          };
        }
        const { collected, metadata } = require("internal/trace_events").inspectorStop();
        // Node streams the collected events back over the session in chunks
        // (trace events, then metadata) before signalling completion. Emit
        // synchronously: listeners observe everything before the post()
        // callback (queued as a microtask above) runs.
        this.emit("NodeTracing.dataCollected", {
          method: "NodeTracing.dataCollected",
          params: { value: collected },
        });
        this.emit("NodeTracing.dataCollected", {
          method: "NodeTracing.dataCollected",
          params: { value: metadata },
        });
        this.emit("NodeTracing.tracingComplete", { method: "NodeTracing.tracingComplete", params: {} });
        return {};
      }

      default:
        return $ERR_INSPECTOR_COMMAND(`-32601: '${method}' wasn't found`);
    }
  }
}

const console = {
  ...globalThis.console,
  context: {
    console: globalThis.console,
  },
};

export default {
  console,
  open,
  close,
  url,
  waitForDebugger,
  Session,
};

hideFromStack(open, close, url, waitForDebugger, Session.prototype.constructor);
