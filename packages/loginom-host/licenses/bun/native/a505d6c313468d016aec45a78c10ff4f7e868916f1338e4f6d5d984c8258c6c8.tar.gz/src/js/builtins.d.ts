/// <reference types="../../build/types/generated.d.ts" />
/// <reference types="../../build/types/ErrorCode.d.ts" />
/// <reference types="../../build/types/ZigGeneratedClasses.d.ts" />
/// <reference types="../../build/types/WebCoreJSBuiltins.d.ts" />
/// <reference types="../../build/types/Bindgen.d.ts" />

// Typedefs for JSC intrinsics. Instead of @, we use $
type TODO = any;

declare module "bun" {
  interface Socket {
    $write(data: string | BufferSource, encoding?: string): boolean | number;
    $end(data?: string | BufferSource, encoding?: string): boolean;
  }
}

/** $debug is a preprocessor macro that works like a templated console.log, and only runs in debug mode if you pass
 * BUN_DEBUG_JS=<module>
 *
 * So to get node stream to log, you pass BUN_DEBUG_JS=stream or BUN_DEBUG_JS=node:stream
 *
 * This only works in debug builds, the log fn is completely removed in release builds.
 */
declare function $debug(...args: any[]): void;
/**
 * Assert that a condition holds in debug builds.
 *
 * $assert is a preprocessor macro that only runs in debug mode. it throws an
 * error if the first argument is falsy.  The source code passed to `check` is
 * inlined in the message, but in addition you can pass additional messages.
 *
 * @note gets removed in release builds. Do not put code with side effects in the `check`.
 */
declare function $assert(check: any, ...message: any[]): asserts check;

/** Asserts the input is a promise. Returns `true` if the promise is resolved */
declare function $isPromiseFulfilled(promise: Promise<any>): boolean;
/** Asserts the input is a promise. Returns `true` if the promise is rejected */
declare function $isPromiseRejected(promise: Promise<any>): boolean;
/** Asserts the input is a promise. Returns `true` if the promise is pending */
declare function $isPromisePending(promise: Promise<any>): boolean;

declare const IS_BUN_DEVELOPMENT: boolean;

/** Place this directly above a function declaration (like a decorator) to make it a getter. */
declare const $getter: never;
/** Assign to this directly above a function declaration (like a decorator) to override the function's display name. */
declare var $overriddenName: string;
/** ??? */
declare var $linkTimeConstant: never;
/** Assign to this directly above a function declaration (like a decorator) to set visibility */
declare var $visibility: "Public" | "Private" | "PrivateRecursive";
/** Assign to this directly above a function declaration (like a decorator) to make it a constructor. */
declare var $constructor;
/** Place this directly above a function declaration (like a decorator) to always inline the function */
declare var $alwaysInline;

/**
 * Overrides **
 */

interface ReadableStream<R = any> extends _ReadableStream<R> {
  /** The native source behind a Bun-created stream: `undefined` when there is none, `-1` once it is detached. */
  $bunNativePtr: TODO | undefined;
}

declare var ReadableStream: {
  prototype: ReadableStream;
  new (
    underlyingSource: import("node:stream/web").UnderlyingByteSource,
    strategy?: { highWaterMark?: number },
  ): ReadableStream<Uint8Array>;
  new <R = any>(
    underlyingSource?: Omit<Bun.UnderlyingSource<R>, "type"> & { type?: "bytes" | undefined },
    strategy?: QueuingStrategy<R>,
  ): ReadableStream<R>;
  new <R = any>(underlyingSource?: Bun.DirectUnderlyingSource<R>, strategy?: QueuingStrategy<R>): ReadableStream<R>;
};

// The public constructor only accepts a known `Bun.Encoding`; builtins pass arbitrary labels and catch the throw.
declare var TextDecoder: {
  prototype: TextDecoder;
  new (label?: string, options?: { __proto__?: null; fatal?: boolean; ignoreBOM?: boolean }): TextDecoder;
};

interface Console {
  $writer: ReturnType<typeof Bun.stdout.writer>;
}

// JSC defines their intrinsics in a nice list here:
// https://github.com/WebKit/WebKit/blob/main/Source/JavaScriptCore/bytecode/BytecodeIntrinsicRegistry.h
//
// And implemented here: (search for "emit_intrinsic_<name>", like "emit_intrinsic_arrayPush")
// https://github.com/WebKit/WebKit/blob/main/Source/JavaScriptCore/bytecompiler/NodesCodegen.cpp

/** returns `arguments[index]` */
declare function $argument<T = any>(index: number): any | undefined;
/** returns number of arguments */
declare function $argumentCount(): number;
/** array.push(item) */
declare function $arrayPush(array: T[], item: T): void;

/**
 * Returns the internal Promise state as a small integer:
 * `0` = pending, `1` = fulfilled, `2` = rejected.
 */
declare function $peekPromiseStatus(promise: Promise<any>): number;
/**
 * Returns the settlement value of a settled Promise (the fulfillment value
 * or the rejection reason). Returns `undefined` for a pending promise.
 */
declare function $peekPromiseSettledValue<V>(promise: Promise<V>): V | undefined;
/**
 * Marks a promise as handled so it doesn't fire the unhandled-rejection
 * tracker. Equivalent to JSC's `JSPromise::markAsHandled()`.
 */
declare function $pokePromiseAsHandled(promise: Promise<any>): void;
/**
 * A promise that settles when a WHATWG ReadableStream/WritableStream reaches a terminal state.
 * Does not lock the stream. Throws when given anything else.
 */
declare function $webStreamClosedPromise(stream: ReadableStream | WritableStream): Promise<void>;

/**
 * Error a WHATWG ReadableStream/WritableStream as `controller.error(e)` would, including its
 * no-op once the stream is no longer readable/writable. Throws for any other value.
 */
declare function $webStreamControllerError(stream: ReadableStream | WritableStream, error: unknown): void;
declare function $getInternalField<Fields extends any[], N extends keyof Fields>(
  base: InternalFieldObject<Fields>,
  number: N,
): Fields[N];
/**
 * Use {@link $resolvePromise} when:
 * - The value might be a promise or thenable
 * - You need the full resolution algorithm (self-check, thenable unwrapping)
 * - You're implementing user-facing APIs where the resolution value is unknown
 */
declare function $resolvePromise<T>(promise: Promise<T>, value: NoInfer<T>): void;
/**
 * Reject a promise with a value
 */
declare function $rejectPromise(promise: Promise<unknown>, value: unknown): void;
/** A new pending promise. `$resolvePromise` / `$rejectPromise` require it to still be pending. */
declare function $newPromise<T = unknown>(): Promise<T>;
/** Like the resolving functions of a Promise executor: calls after the first one are ignored. */
declare function $resolvePromiseWithFirstResolvingFunctionCallCheck<T>(promise: Promise<T>, value: NoInfer<T>): void;
declare function $rejectPromiseWithFirstResolvingFunctionCallCheck(promise: Promise<unknown>, value: unknown): void;

declare function $loadEsmIntoCjs(...args: any[]): TODO;
declare function $getProxyInternalField(): TODO;
// Helper types for the `$isObject` / `$isCallable` / `$isArray` guards. Each guard has two overloads: a
// generic one that narrows the argument's own type and rejects `any`, and a plain one for `any`. A single generic
// predicate evaluates to `any` for an `any` argument, which TypeScript narrows to `never` in the false branch.
type $NotAny<T> = 0 extends 1 & T ? never : unknown;
/** Keeps the members of `T` that can be a `U`. */
type $GuardNarrow<T, U> = T extends U ? T : U extends T ? U : never;
type $AnyObject = Record<PropertyKey, any>;
type $AnyCallable = ((...args: any[]) => any) & $AnyObject;
/**
 * True for object-like `JSCell`s. That is, this is roughly equivalent to this
 * JS code:
 * ```js
 * typeof obj === "object" && obj !== null
 * ```
 *
 * @param obj The object to check
 * @returns `true` if `obj` is an object-like `JSCell`
 *
 * @see [JSCell.h](https://github.com/oven-sh/WebKit/blob/main/Source/JavaScriptCore/runtime/JSCell.h)
 * @see [JIT implementation](https://github.com/oven-sh/WebKit/blob/433f7598bf3537a295d0af5ffd83b9a307abec4e/Source/JavaScriptCore/jit/JITOpcodes.cpp#L311)
 */
declare function $isObject<T>(obj: T & $NotAny<T>): obj is $GuardNarrow<T, object> & $NotAny<T>;
declare function $isObject(obj: any): obj is $AnyObject;
declare function $isArray<T>(
  obj: T & $NotAny<T>,
): obj is ([Extract<T, readonly any[]>] extends [never] ? T & any[] : Extract<T, readonly any[]>) & $NotAny<T>;
declare function $isArray(obj: any): obj is any[];
declare function $isCallable<T>(fn: T & $NotAny<T>): fn is $GuardNarrow<T, CallableFunction> & $NotAny<T>;
declare function $isCallable(fn: any): fn is $AnyCallable;
declare function $isJSArray(obj: unknown): obj is any[];
declare function $isProxyObject(obj: unknown): obj is Proxy;
declare function $isRegExpObject(obj: unknown): obj is RegExp;
declare function $isMap<K, V>(obj: unknown): obj is Map<K, V>;
declare function $isSet<V>(obj: unknown): obj is Set<V>;
declare function $isUndefinedOrNull(obj: unknown): obj is null | undefined;
declare function $tailCallForwardArguments(fn: CallableFunction, thisValue: ThisType): any;
/**
 * **NOTE** - use `throw new TypeError()` instead. it compiles to the same builtin
 * @deprecated
 */
declare function $throwTypeError(message: string): never;
/**
 * **NOTE** - use `throw new RangeError()` instead. it compiles to the same builtin
 * @deprecated
 */
declare function $throwRangeError(message: string): never;
declare function $putByIdDirect(obj: any, key: PropertyKey, value: any): void;

/**
 * Sets a private property on an object.
 * Translates to the `op_put_by_id_direct` bytecode.
 *
 * @param obj The object to set the private property on
 * @param key The key of the private property (without the "$" prefix)
 * @param value The value to set the private property to
 */
declare function $putByIdDirectPrivate<T extends Record<`$${K}`, unknown>, K extends string>(
  obj: T,
  key: K,
  value: T[`$${K}`],
): void;

declare function $putByValDirect(obj: any, key: PropertyKey, value: any): void;
declare function $putInternalField<Fields extends any[], N extends keyof Fields>(
  base: InternalFieldObject<Fields>,
  number: N,
  value: Fields[N],
): void;
/**
 * ## References
 * - [WebKit - `emit_intrinsic_newArrayWithSize`](https://github.com/oven-sh/WebKit/blob/e1a802a2287edfe7f4046a9dd8307c8b59f5d816/Source/JavaScriptCore/bytecompiler/NodesCodegen.cpp#L2317)
 */
declare function $newArrayWithSize<T>(size: number): T[];
declare const $ModuleFetch: number;
declare const $ModuleLink: number;
declare const $proxyFieldTarget: TODO;
declare const $proxyFieldHandler: TODO;
declare const $processBindingConstants: {
  os: typeof import("os").constants;
  fs: typeof import("fs").constants;
  crypto: typeof import("crypto").constants;
  zlib: typeof import("zlib").constants;
};
declare const $asyncContext: InternalFieldObject<[import("./node/async_hooks").Frame | undefined]>;

// We define our intrinsics in ./BunBuiltinNames.h. Some of those are globals.

declare var $_events: TODO;
declare function $addAbortAlgorithmToSignal(signal: AbortSignal, algorithm: () => void): TODO;
declare function $autoAllocateChunkSize(): TODO;
declare function $basename(): TODO;
declare function $body(): TODO;
declare function $bunNativePtr(): TODO;
declare function $cancel(): TODO;
declare function $close(): TODO;
declare function $code(): TODO;
declare function $createFIFO(): TODO;
declare function $createUninitializedArrayBuffer(size: number): ArrayBuffer;
declare function $data(): TODO;
declare function $decode(): TODO;
declare function $dirname(): TODO;
declare function $encoding(): TODO;
declare function $end(): TODO;
declare function $errno(): TODO;
declare function $extname(): TODO;
declare function $fatal(): TODO;
declare function $format(): TODO;
// `requirer`: a CommonJS module; the registry is its Bun.ModuleGraph's loader's. Omitted: the global object's.
declare function $esmNamespaceForCjs(key: string, requirer?: JSCommonJSModule): any | undefined;
declare function $esmRegistryDelete(key: string, requirer?: JSCommonJSModule): boolean;
declare function $esmRegistryEvaluatedKeys(requirer?: JSCommonJSModule): string[];
declare function $esmRegistryHasEvaluated(key: string, requirer?: JSCommonJSModule): boolean;
declare function $esmLoadSync(key: string, requirer?: JSCommonJSModule): any;
declare function $get(): TODO;
declare function $handleEvent(): TODO;
declare function $headers(): TODO;
declare function $highWaterMark(): TODO;
declare function $host(): TODO;
declare function $hostname(): TODO;
declare function $ignoreBOM(): TODO;
declare function $importer(): TODO;
declare function $internalRequire(id: string, parent: JSCommonJSModule, requireMap: RequireMap): TODO;
declare function $isAbortSignal(signal: unknown): signal is AbortSignal;
declare function $isAbsolute(): TODO;
declare function $join(): TODO;
declare function $main(): TODO;
declare function $makeDOMException(): TODO;
declare function $makeGetterTypeError(className: string, prop: string): Error;
declare function $method(): TODO;
declare function $normalize(): TODO;
declare function $parse(): TODO;
declare function $path(): TODO;
declare function $port(): TODO;
declare function $pull(): TODO;
declare function $read(): TODO;
declare function $readable(): TODO;
declare function $removeAbortAlgorithmFromSignal(signal: AbortSignal, algorithmIdentifier: number): TODO;
declare function $redirect(): TODO;
declare function $relative(): TODO;
declare function $require(): TODO;
/** Loads `id` into `mod`. Returns -1 when the module is ESM and must be loaded from the ESM registry. */
declare function $requireCommonJS(
  id: string,
  mod: JSCommonJSModule,
  parentFilename: unknown,
  userArgumentCount: number,
  userOptions: unknown,
): JSCommonJSModule | -1;
declare function $requireESM(path: string, requirer?: JSCommonJSModule): any;
declare function $requireNativeModule(id: string): any;
declare const $requireMap: Map<string, JSCommonJSModule>;
declare const $internalModuleRegistry: InternalFieldObject<any[]>;
declare function $resolve(name: string, from: string): Promise<string>;
declare function $resolveSync(
  name: string,
  from: string,
  isESM?: boolean,
  isUserRequireResolve?: boolean,
  paths?: string[],
  parentModule?: JSCommonJSModule,
  resolveFilenameOptions?: unknown,
): string;
declare function $self(): TODO;
declare function $size(): TODO;
declare function $start(): TODO;
declare function $status(): TODO;
declare function $stream(): TODO;
declare function $syscall(): TODO;
declare function $toNamespacedPath(): TODO;
declare function $url(): TODO;
declare function $writable(): TODO;
declare function $write(): TODO;
declare function $writer(): TODO;
declare function $written(): TODO;

declare function $createCommonJSModule(
  id: string,
  exports: any,
  hasEvaluated: boolean,
  parent: JSCommonJSModule | undefined,
): JSCommonJSModule;
declare function $evaluateCommonJSModule(
  moduleToEvaluate: JSCommonJSModule,
  sourceModule: JSCommonJSModule,
): JSCommonJSModule[];
declare function $evictIsolationSourceProviderCache(key?: string): void;

declare function $overridableRequire(this: JSCommonJSModule, id: string): any;

// The following I cannot find any definitions of, but they are functional.
declare function $toLength(length: number): number;
declare function $isTypedArrayView(obj: unknown): obj is ArrayBufferView | DataView | Uint8Array;
declare function $setStateToMax(target: any, state: number): void;
/** @deprecated, use new TypeError instead */
declare function $makeTypeError(message: string): TypeError;

declare const __internal: unique symbol;
interface InternalFieldObject<T extends any[]> {
  [__internal]: T;
}

// You can also `@` on any method on a classes to avoid prototype pollution and secret internals
type ClassWithIntrinsics<T> = { [K in keyof T as T[K] extends Function ? `$${K}` : never]: T[K] };

declare interface Map<K, V> extends ClassWithIntrinsics<Map<K, V>> {}
declare interface CallableFunction extends ClassWithIntrinsics<CallableFunction> {}
declare interface Promise<T> extends ClassWithIntrinsics<Promise<T>> {}
declare interface ArrayBufferConstructor extends ClassWithIntrinsics<ArrayBufferConstructor> {}
declare interface PromiseConstructor extends ClassWithIntrinsics<PromiseConstructor> {}

declare interface UnderlyingSource {
  $lazy?: boolean;
  $bunNativePtr?: undefined | TODO;
  autoAllocateChunkSize?: number;
  $stream?: ReadableStream;
}

declare interface AddEventListenerOptions {
  /**
   * Private symbol read by the native EventTarget. A listener registered with it still
   * runs after another listener called `stopImmediatePropagation()`. Mirrors Node.js's
   * internal `kResistStopPropagation`.
   */
  $kResistStopPropagation?: boolean;
}

// Provided by the C++ Web Streams implementation.
declare class ReadableByteStreamController {
  private constructor();
}
declare class ReadableStreamBYOBRequest {
  private constructor();
}
declare class ReadableStreamBYOBReader {
  constructor(stream: ReadableStream);
}

// Inlining our enum types
declare const $ImportKindIdToLabel: Array<import("bun").ImportKind>;
declare const $ImportKindLabelToId: Record<import("bun").ImportKind, number>;
declare const $LoaderIdToLabel: Array<import("bun").Loader>;
declare const $LoaderLabelToId: Record<import("bun").Loader, number>;

// not a builtin, but a build-time macro of our own
/** Returns a not implemented error that points to a github issue. */
declare function notImplementedIssue(issueNumber: number, description: string): Error;
/** Return a function that throws a not implemented error that points to a github issue */
declare function notImplementedIssueFn(issueNumber: number, description: string): (...args: any[]) => never;

declare type JSCSourceCodeObject = unique symbol;

declare interface Function {
  path: string;
}

interface String {
  $charCodeAt: String["charCodeAt"];
  // add others as needed
}

interface Set {
  $add: Set["add"];
  $clear: Set["clear"];
  $delete: Set["delete"];
  $has: Set["has"];
}

interface Map {
  $clear: Map["clear"];
  $delete: Map["delete"];
  $has: Map["has"];
  $set: Map["set"];
  $get: Map["get"];
}

declare var $Array: ArrayConstructor;
declare var $Buffer: {
  byteLength: typeof Buffer.byteLength;
  new (array: Array): Buffer;
  new (arrayBuffer: ArrayBuffer, byteOffset?: number, length?: number): Buffer;
  new (view: ArrayBufferView, byteOffset?: number, length?: number): Buffer;
  new (buffer: Buffer): Buffer;
  new (size: number): Buffer;
  new (string: string, encoding?: BufferEncoding): Buffer;
};

declare interface Error {
  code?: string;
}

declare function $makeAbortError(message?: string, options?: ErrorOptions): Error;

/**
 * -- Error Codes with manual messages
 */
declare function $ERR_INVALID_ARG_TYPE(argName: string, expectedType: string, actualValue: any): TypeError;
declare function $ERR_INVALID_ARG_TYPE(argName: string, expectedTypes: string[], actualValue: any): TypeError;
declare function $ERR_INVALID_ARG_VALUE(name: string, value: any, reason?: string): TypeError;
declare function $ERR_INVALID_ARG_VALUE_RangeError(name: string, value: any, reason?: string): RangeError;
declare function $ERR_UNKNOWN_ENCODING(enc: string): TypeError;
declare function $ERR_STREAM_DESTROYED(method: string): Error;
declare function $ERR_METHOD_NOT_IMPLEMENTED(method: string): Error;
declare function $ERR_STREAM_ALREADY_FINISHED(method: string): Error;
declare function $ERR_MISSING_ARGS(...args: [string, ...string[]]): TypeError;
/**
 * `The "foo" or "bar" or "baz" argument must be specified`
 *
 * Panics if `oneOf` is empty.
 */
declare function $ERR_MISSING_ARGS(oneOf: string[]): TypeError;
declare function $ERR_INVALID_RETURN_VALUE(expected_type: string, name: string, actual_value: any): TypeError;
declare function $ERR_TLS_INVALID_PROTOCOL_VERSION(a: string, b: string): TypeError;
declare function $ERR_TLS_PROTOCOL_VERSION_CONFLICT(version: string, secureProtocol: string): TypeError;
declare function $ERR_INVALID_IP_ADDRESS(ip: any): TypeError;
declare function $ERR_INVALID_ADDRESS_FAMILY(addressType, host, port): RangeError;
declare function $ERR_OUT_OF_RANGE(name: string, reason: string, value): RangeError;
declare function $ERR_BUFFER_TOO_LARGE(len: number): RangeError;
declare function $ERR_BROTLI_INVALID_PARAM(p: number): RangeError;
declare function $ERR_TLS_CERT_ALTNAME_INVALID(reason: string, host: string, cert): Error;
declare function $ERR_USE_AFTER_CLOSE(name: string): Error;
declare function $ERR_HTTP2_INVALID_HEADER_VALUE(value: string, name: string): TypeError;
declare function $ERR_INVALID_HANDLE_TYPE(): TypeError;
declare function $ERR_INVALID_HTTP_TOKEN(name: string, value: string): TypeError;
declare function $ERR_HTTP2_STATUS_INVALID(code: number): RangeError;
declare function $ERR_HTTP2_INVALID_PSEUDOHEADER(name: string): TypeError;
declare function $ERR_HTTP2_STREAM_ERROR(code): Error;
declare function $ERR_HTTP2_SESSION_ERROR(code): Error;
declare function $ERR_HTTP2_PAYLOAD_FORBIDDEN(status): Error;
declare function $ERR_HTTP2_INVALID_INFO_STATUS(code): RangeError;
declare function $ERR_INVALID_URL(input, base?): TypeError;
declare function $ERR_INVALID_CHAR(name, field?): TypeError;
declare function $ERR_HTTP_INVALID_HEADER_VALUE(value: string, name: string): TypeError;
declare function $ERR_HTTP_HEADERS_SENT(action: string): Error;
declare function $ERR_INVALID_PROTOCOL(proto, expected): TypeError;
declare function $ERR_INVALID_URL_SCHEME(expected: string): TypeError;
declare function $ERR_INVALID_STATE(message: string): Error;
declare function $ERR_INVALID_STATE_TypeError(message: string): TypeError;
declare function $ERR_INVALID_STATE_RangeError(message: string): RangeError;
declare function $ERR_UNESCAPED_CHARACTERS(arg): TypeError;
declare function $ERR_HTTP_INVALID_STATUS_CODE(code): RangeError;
declare function $ERR_HTTP_CONTENT_LENGTH_MISMATCH(actual: number, expected: number): Error;
declare function $ERR_UNHANDLED_ERROR(err?): Error;
declare function $ERR_BUFFER_OUT_OF_BOUNDS(name?: string): RangeError;
declare function $ERR_CHILD_PROCESS_IPC_REQUIRED(where): Error;
declare function $ERR_CHILD_PROCESS_STDIO_MAXBUFFER(message): Error;
declare function $ERR_INVALID_ASYNC_ID(name, value): RangeError;
declare function $ERR_ASYNC_TYPE(name): TypeError;
declare function $ERR_ASYNC_CALLBACK(name): TypeError;
declare function $ERR_AMBIGUOUS_ARGUMENT(arg, message): TypeError;
declare function $ERR_INVALID_FD_TYPE(type): TypeError;
declare function $ERR_IP_BLOCKED(ip): Error;

declare function $ERR_IPC_CHANNEL_CLOSED(): Error;
declare function $ERR_IPC_DISCONNECTED(): Error;
declare function $ERR_INSPECTOR_ALREADY_ACTIVATED(message?: string): Error;
declare function $ERR_INSPECTOR_NOT_ACTIVE(): Error;
declare function $ERR_INSPECTOR_ALREADY_CONNECTED(): Error;
declare function $ERR_INSPECTOR_NOT_CONNECTED(): Error;
declare function $ERR_INSPECTOR_NOT_WORKER(): Error;
declare function $ERR_INSPECTOR_COMMAND(message: string): Error;
declare function $ERR_WORKER_UNSUPPORTED_OPERATION(message: string): TypeError;
declare function $ERR_SERVER_NOT_RUNNING(): Error;
declare function $ERR_SOCKET_BAD_TYPE(): Error;
declare function $ERR_ZLIB_INITIALIZATION_FAILED(): Error;
declare function $ERR_IPC_ONE_PIPE(): Error;
declare function $ERR_SOCKET_ALREADY_BOUND(): Error;
declare function $ERR_SOCKET_BAD_BUFFER_SIZE(): Error;
declare function $ERR_SOCKET_DGRAM_IS_CONNECTED(): Error;
declare function $ERR_SOCKET_DGRAM_NOT_CONNECTED(): Error;
declare function $ERR_SOCKET_DGRAM_NOT_RUNNING(): Error;
declare function $ERR_INVALID_CURSOR_POS(): Error;
declare function $ERR_SCRIPT_EXECUTION_INTERRUPTED(): Error;
declare function $ERR_MULTIPLE_CALLBACK(): Error;
declare function $ERR_STREAM_PREMATURE_CLOSE(): Error;
declare function $ERR_STREAM_NULL_VALUES(): TypeError;
declare function $ERR_STREAM_ITER_MISSING_FLAG(): TypeError;
declare function $ERR_STREAM_CANNOT_PIPE(): Error;
declare function $ERR_STREAM_WRITE_AFTER_END(): Error;
declare function $ERR_STREAM_UNSHIFT_AFTER_END_EVENT(): Error;
declare function $ERR_STREAM_PUSH_AFTER_EOF(): Error;
declare function $ERR_STREAM_UNABLE_TO_PIPE(): Error;
declare function $ERR_ILLEGAL_CONSTRUCTOR(): TypeError;
declare function $ERR_SERVER_ALREADY_LISTEN(): Error;
declare function $ERR_SOCKET_CLOSED(): Error;
declare function $ERR_SOCKET_CLOSED_BEFORE_CONNECTION(): Error;
declare function $ERR_TLS_RENEGOTIATION_DISABLED(): Error;
declare function $ERR_TLS_RENEGOTIATION_UNSUPPORTED(): Error;
declare function $ERR_TLS_INVALID_STATE(): Error;
declare function $ERR_UNAVAILABLE_DURING_EXIT(): Error;
declare function $ERR_TLS_CERT_ALTNAME_FORMAT(): SyntaxError;
declare function $ERR_TLS_REQUIRED_SERVER_NAME(): Error;
declare function $ERR_TLS_SNI_FROM_SERVER(): Error;
declare function $ERR_SSL_NO_CIPHER_MATCH(): Error;
declare function $ERR_INVALID_URI(): URIError;
declare function $ERR_HTTP2_PSEUDOHEADER_NOT_ALLOWED(): TypeError;
declare function $ERR_HTTP2_INFO_STATUS_NOT_ALLOWED(): RangeError;
declare function $ERR_HTTP2_HEADERS_SENT(): Error;
declare function $ERR_HTTP2_INVALID_STREAM(): Error;
declare function $ERR_HTTP2_NO_SOCKET_MANIPULATION(): Error;
declare function $ERR_HTTP2_SOCKET_UNBOUND(): Error;
declare function $ERR_HTTP2_MAX_PENDING_SETTINGS_ACK(): Error;
declare function $ERR_HTTP2_INVALID_SESSION(): Error;
declare function $ERR_HTTP2_TRAILERS_ALREADY_SENT(): Error;
declare function $ERR_HTTP2_TRAILERS_NOT_READY(): Error;
declare function $ERR_HTTP2_SEND_FILE(): Error;
declare function $ERR_HTTP2_SEND_FILE_NOSEEK(): Error;
declare function $ERR_HTTP2_PUSH_DISABLED(): Error;
declare function $ERR_HTTP2_HEADERS_AFTER_RESPOND(): Error;
declare function $ERR_HTTP2_STATUS_101(): Error;
declare function $ERR_HTTP2_ALTSVC_INVALID_ORIGIN(): TypeError;
declare function $ERR_HTTP2_INVALID_ORIGIN(): TypeError;
declare function $ERR_HTTP2_ALTSVC_LENGTH(): TypeError;
declare function $ERR_HTTP2_PING_LENGTH(): RangeError;
declare function $ERR_HTTP2_OUT_OF_STREAMS(): Error;
declare function $ERR_HTTP_BODY_NOT_ALLOWED(): Error;
declare function $ERR_HTTP_TRAILER_INVALID(): Error;
declare function $ERR_HTTP_SOCKET_ASSIGNED(): Error;
declare function $ERR_DIR_CLOSED(): Error;
declare function $ERR_SOCKET_CONNECTION_TIMEOUT(): Error;
declare function $ERR_TLS_HANDSHAKE_TIMEOUT(): Error;
declare function $ERR_VM_MODULE_STATUS(reason: string): Error;
declare function $ERR_VM_MODULE_ALREADY_LINKED(): Error;
declare function $ERR_VM_MODULE_CANNOT_CREATE_CACHED_DATA(): Error;
declare function $ERR_VM_MODULE_NOT_MODULE(): Error;
declare function $ERR_VM_MODULE_DIFFERENT_CONTEXT(): Error;
declare function $ERR_VM_MODULE_LINK_FAILURE(message: string, cause: Error): Error;
declare function $ERR_TLS_ALPN_CALLBACK_WITH_PROTOCOLS(): TypeError;
declare function $ERR_TLS_ALPN_CALLBACK_INVALID_RESULT(message: string): TypeError;
declare function $ERR_HTTP2_TOO_MANY_CUSTOM_SETTINGS(): Error;
declare function $ERR_HTTP2_CONNECT_AUTHORITY(): Error;
declare function $ERR_HTTP2_CONNECT_SCHEME(): Error;
declare function $ERR_HTTP2_CONNECT_PATH(): Error;
declare function $ERR_HTTP2_TOO_MANY_INVALID_FRAMES(): Error;
declare function $ERR_HTTP2_PING_CANCEL(): Error;

/**
 * Convert a function to a class-like object.
 *
 * This does:
 * - Sets the name of the function to the given name
 * - Sets .prototype to Object.create(base?.prototype, { constructor: { value: fn } })
 * - Calls Object.setPrototypeOf(fn, base ?? Function.prototype)
 *
 * @param fn - The function to convert to a class
 * @param name - The name of the class
 * @param base - The base class to inherit from
 */
declare function $toClass(fn: Function, name: string, base?: Function | undefined | null);

declare function $min(a: number, b: number): number;

interface Map<K, V> {
  $get: typeof Map.prototype.get;
  $set: typeof Map.prototype.set;
}

interface Set<T> {
  $forEach: Set<T>["forEach"];
}

interface ObjectConstructor {
  $defineProperty: typeof Object.defineProperty;
  $defineProperties: typeof Object.defineProperties;
}

/** gets a property on an object */
declare function $getByIdDirect<T, K extends keyof T>(obj: T, key: K): T[K];

/**
 * Gets a private property on an object.
 * Translates to the `op_get_by_id_direct` bytecode.
 *
 * @param obj The object to get the private property from
 * @param key The key of the private property (without the "$" prefix)
 * @returns The value of the private property
 */
declare function $getByIdDirectPrivate<T = any, K extends string = string>(
  obj: T,
  key: K,
): K extends keyof T ? T[`$${K}`] : T extends { [P in `$${K}`]: infer V } ? V : never;

declare var $Promise: PromiseConstructor;

declare function $isPromise<T>(value: unknown): value is Promise<T>;
