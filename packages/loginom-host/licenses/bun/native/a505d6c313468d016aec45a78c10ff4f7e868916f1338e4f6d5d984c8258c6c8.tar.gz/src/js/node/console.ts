export default console;
