"use strict";

const Duplex = require("internal/streams/duplex");

const kCallback = Symbol("Callback");
const kInitOtherSide = Symbol("InitOtherSide");

class DuplexSide extends Duplex {
  #otherSide: DuplexSide | null = null;
  [kCallback]: (() => void) | null = null;

  constructor(options) {
    super(options);
    this.#otherSide = null;
  }

  [kInitOtherSide](otherSide) {
    // Ensure this can only be set once, to enforce encapsulation.
    if (this.#otherSide === null) {
      this.#otherSide = otherSide;
    } else {
      $assert(this.#otherSide === null);
    }
  }

  _read() {
    const callback = this[kCallback];
    if (callback) {
      this[kCallback] = null;
      callback();
    }
  }

  _write(chunk, encoding, callback) {
    $assert(this.#otherSide !== null);
    $assert(this.#otherSide[kCallback] === null);
    if (chunk.length === 0) {
      process.nextTick(callback);
    } else {
      this.#otherSide.push(chunk);
      this.#otherSide[kCallback] = callback;
    }
  }

  _final(callback) {
    this.#otherSide!.on("end", callback);
    this.#otherSide!.push(null);
  }

  _destroy(err, callback) {
    const otherSide = this.#otherSide;

    if (otherSide !== null && !otherSide.destroyed) {
      // nextTick so the current execution stack (an HTTP parser, say) is not
      // torn down underneath itself.
      process.nextTick(() => {
        if (otherSide.destroyed) return;

        // Destroy without the error: closes the peer so it cannot hang, while
        // avoiding an "Unhandled error" crash on that side.
        if (err) otherSide.destroy();
        else otherSide.push(null);
      });
    }

    callback(err);
  }
}

function duplexPair(options?): [DuplexSide, DuplexSide] {
  const side0 = new DuplexSide(options);
  const side1 = new DuplexSide(options);
  side0[kInitOtherSide](side1);
  side1[kInitOtherSide](side0);
  return [side0, side1];
}

export default duplexPair;
