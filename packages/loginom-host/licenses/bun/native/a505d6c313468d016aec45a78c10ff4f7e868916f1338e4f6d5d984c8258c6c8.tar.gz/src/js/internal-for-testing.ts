// Hardcoded module "bun:internal-for-testing"

// If you want to test an internal API, add a binding into this file.
//
// Then at test time: import ... from "bun:internal-for-testing"
//
// In a debug build, the import is always allowed.
// It is disallowed in release builds unless run in Bun's CI.

const fmtBinding = $bindgen("fmt_jsc.bind.ts", "fmtString");

export const highlightJavaScript = (code: string) => fmtBinding(code, "highlight-javascript");
export const highlightJavaScriptRedacted = (code: string) => fmtBinding(code, "highlight-javascript-redacted");
export const escapePowershell = (code: string) => fmtBinding(code, "escape-powershell");

export const canonicalizeIP = $newCppFunction("NodeTLS.cpp", "Bun__canonicalizeIP", 1);

// Process-wide additions to the public keys no certificate chain may hold (blocked_spkis.cpp). `hash` is the SHA-256 of
// a DER SubjectPublicKeyInfo.
export const addBlockedSPKIForTesting: (hash: ArrayBufferView) => void = $newCppFunction(
  "NodeTLS.cpp",
  "addBlockedSPKIForTesting",
  1,
);
export const clearBlockedSPKIsForTesting: () => void = $newCppFunction("NodeTLS.cpp", "clearBlockedSPKIsForTesting", 0);

// Runtime-dispatched SIMD xxHash3 kernel (src/jsc/bindings/xxhash3.cpp), driven
// directly so tests can exercise the Highway path independent of Bun.hash.
export const xxHash3ForTesting: (view: ArrayBufferView, seed?: number | bigint) => bigint = $newCppFunction(
  "xxhash3_testing.cpp",
  "Bun__xxhash3_64_forTesting",
  2,
);

// Runtime-dispatched SIMD byte-search kernels (src/jsc/bindings/highway_strings.cpp)
// behind `bun_core::strings`, driven directly so tests can sweep lengths and
// alignments. Returns the kernel's raw result: an index (`haystack.length` =
// not found), a count, or for memmem/memrmem the offset with -1 = not found.
// scannerRunStops fills `arg` with its three bitmaps and returns 0. lineStarts
// fills `arg` with uint32 offsets and returns how many. oddBlocks fills `arg`
// with uint64 words and returns 0.
export const highwayStringsForTesting: (
  op:
    | "indexOfChar"
    | "lastIndexOfChar"
    | "indexOfNotChar"
    | "countChar"
    | "indexOfAny"
    | "lastIndexOfAny"
    | "memmem"
    | "memrmem"
    | "memmem16"
    | "memrmem16"
    | "scannerRunStops"
    | "lineStarts"
    | "oddBlocks",
  haystack: Uint8Array,
  arg: number | Uint8Array,
) => number = $newCppFunction("highway_strings_testing.cpp", "Bun__highwayStringsForTesting", 3);

export const SQL = $cpp("JSSQLStatement.cpp", "createJSSQLStatementConstructor");
export const setSQLiteColumnNameTransform = (
  statement: import("bun:sqlite").Statement,
  transform: ((name: string) => string) | null | undefined,
) => statement.native.$setColumnNameTransform(transform);

export const patchInternals = {
  parse: $newRustFunction("patch.rs", "TestingAPIs.parse", 1),
  apply: $newRustFunction("patch.rs", "TestingAPIs.apply", 2),
  makeDiff: $newRustFunction("patch.rs", "TestingAPIs.makeDiff", 2),
};

export const internalSourceMap = {
  fromVLQ: $newRustFunction("sourcemap/InternalSourceMap.rs", "TestingAPIs.fromVLQ", 1) as (vlq: string) => Uint8Array,
  toVLQ: $newRustFunction("sourcemap/InternalSourceMap.rs", "TestingAPIs.toVLQ", 1) as (blob: Uint8Array) => string,
  find: $newRustFunction("sourcemap/InternalSourceMap.rs", "TestingAPIs.find", 3) as (
    blob: Uint8Array,
    line: number,
    col: number,
  ) => {
    generatedLine: number;
    generatedColumn: number;
    originalLine: number;
    originalColumn: number;
    sourceIndex: number;
  } | null,
};

const shellLex = $newRustFunction("shell.rs", "TestingAPIs.shellLex", 2);
const shellParse = $newRustFunction("shell.rs", "TestingAPIs.shellParse", 2);

export const sslCtxLiveCount = $newRustFunction("SecureContext.rs", "jsLiveCount", 0);

export const napiThreadsafeFunctionLiveCount = $newRustFunction("napi_body.rs", "jsThreadsafeFunctionLiveCount", 0);

export const bundlerWorkerLiveCount: () => number = $newRustFunction("JSBundler.rs", "jsWorkerLiveCount", 0);

export const semverIntersects = $newRustFunction("SemverObject.rs", "intersectsForTesting", 2) as (
  left: string,
  right: string,
) => boolean;

/** What a bytecode order file calls the code of `text`: `M <name>` and `<start> <kind> <name>` lines, or null. */
export const bytecodeOrderNames = $newRustFunction("BytecodeOrderRecorder.rs", "namesForTesting", 3) as (
  text: string,
  kind: "module" | "script" | "builtin" | "internal",
  chunkPaths?: string,
) => string | null | undefined;

export const escapeRegExp = $newRustFunction("escapeRegExp.rs", "jsEscapeRegExp", 1);
export const escapeRegExpForPackageNameMatching = $newRustFunction(
  "escapeRegExp.rs",
  "jsEscapeRegExpForPackageNameMatching",
  1,
);

export const shellInternals = {
  lex: (a, ...b) => shellLex(a.raw, b),
  parse: (a, ...b) => shellParse(a.raw, b),
  /**
   * Checks if the given builtin is disabled on the current platform
   *
   * @example
   * ```typescript
   * const isDisabled = builtinDisabled("cp")
   * ```
   */
  builtinDisabled: $newRustFunction("shell.rs", "TestingAPIs.disabledOnThisPlatform", 1),
};

export const subprocessInternals = {
  injectStdioReadError: $newRustFunction("subprocess.rs", "TestingAPIs.injectStdioReadError", 2) as (
    subprocess: import("bun").Subprocess,
    kind: "stdout" | "stderr",
  ) => boolean,
  closeStdinWriter: $newRustFunction("subprocess.rs", "TestingAPIs.closeStdinWriter", 1) as (
    subprocess: import("bun").Subprocess,
  ) => boolean,
};

export const iniInternals = {
  parse: $newRustFunction("ini.rs", "IniTestingAPIs.parse", 1),
  loadNpmrc: $newRustFunction("ini.rs", "IniTestingAPIs.loadNpmrcFromJS", 2),
};

export const cssInternals = {
  minifyTestWithOptions: $newRustFunction("css_internals.rs", "minifyTestWithOptions", 3),
  minifyErrorTestWithOptions: $newRustFunction("css_internals.rs", "minifyErrorTestWithOptions", 3),
  testWithOptions: $newRustFunction("css_internals.rs", "testWithOptions", 3),
  prefixTestWithOptions: $newRustFunction("css_internals.rs", "prefixTestWithOptions", 3),
  minifyTest: $newRustFunction("css_internals.rs", "minifyTest", 3),
  prefixTest: $newRustFunction("css_internals.rs", "prefixTest", 3),
  _test: $newRustFunction("css_internals.rs", "_test", 3),
  attrTest: $newRustFunction("css_internals.rs", "attrTest", 3),
};

export const crash_handler = $rust("crash_handler.rs", "js_bindings.generate") as {
  getMachOImageZeroOffset: () => number;
  segfault: () => void;
  panic: () => void;
  rootError: () => void;
  outOfMemory: () => void;
  operatorNew: (nothrow?: boolean) => boolean | undefined;
  abort: () => void;
  fastfail: () => void;
  trap: () => void;
  raiseIgnoringPanicHandler: () => void;
};

export const upgrade_test_helpers = $rust("upgrade_command.rs", "upgrade_js_bindings.generate") as {
  openTempDirWithoutSharingDelete: () => void;
  closeTempDirHandle: () => void;
};

export const install_test_helpers = $rust("install_binding.rs", "bun_install_js_bindings.generate") as {
  /**
   * Returns the lockfile at the given path as an object.
   */
  parseLockfile: (cwd: string) => any;
};

export const jscInternals = $cpp("JSCTestingHelpers.cpp", "createJSCTestingHelpers");

export const nativeFrameForTesting: (callback: () => void) => void = $cpp(
  "CallSite.cpp",
  "createNativeFrameForTesting",
);

// Linux-only. Create an in-memory file descriptor with a preset size.
// You should call fs.closeSync(fd) when you're done with it.
export const memfd_create: (size: number) => number = $newRustFunction(
  "node_fs_binding.rs",
  "createMemfdForTesting",
  1,
);

export const createStatsForIno: (ino: bigint, big: boolean) => any = $newRustFunction(
  "Stat.rs",
  "createStatsForIno",
  2,
);

export const setSyntheticAllocationLimitForTesting: (limit: number) => number = $newRustFunction(
  "virtual_machine_exports.rs",
  "Bun__setSyntheticAllocationLimitForTesting",
  1,
);

// Shrink the markdown parser's block-metadata cap (in bytes) so its
// `TooManyBlocks` error is reachable without 4 GiB of input. The cap can only
// be lowered, never raised past the real limit. Returns the previous value so
// a test can restore it.
export const setMaxMarkdownBlockBytesForTesting: (limit: number) => number = $newRustFunction(
  "MarkdownObject.rs",
  "setMaxMarkdownBlockBytesForTesting",
  1,
);

export const npm_manifest_test_helpers = $rust("npm.rs", "PackageManifest.bindings.generate") as {
  /**
   * Returns the parsed manifest file. Currently only returns an array of available versions.
   */
  parseManifest: (manifestFileName: string, registryUrl: string) => any;
};

export const readTarball: (tarball: string) => any = $newRustFunction("pack_command.rs", "bindings.jsReadTarball", 1);

export const isArchitectureMatch: (architecture: string[]) => boolean = $newRustFunction(
  "npm.rs",
  "Architecture.jsFunctionArchitectureIsMatch",
  1,
);

export const isOperatingSystemMatch: (operatingSystem: string[]) => boolean = $newRustFunction(
  "npm.rs",
  "OperatingSystem.jsFunctionOperatingSystemIsMatch",
  1,
);

export const createSocketPair: () => [number, number] = $newRustFunction(
  "runtime/socket/socket.rs",
  "jsCreateSocketPair",
  0,
);

export const isModuleResolveFilenameSlowPathEnabled: () => boolean = $newCppFunction(
  "NodeModuleModule.cpp",
  "jsFunctionIsModuleResolveFilenameSlowPathEnabled",
  0,
);

export const frameworkRouterInternals = $rust("FrameworkRouter.rs", "JSFrameworkRouter.getBindings") as {
  parseRoutePattern: (style: string, pattern: string) => null | { kind: string; pattern: string };
  FrameworkRouter: {
    new (opts: any): any;
  };
};

// Only in a build with assertions: `isCompiled` in scripts/build/codegen.ts.
export const bindgen = $bindgen("bindgen_test.bind.ts", "add") && {
  add: $bindgen("bindgen_test.bind.ts", "add"),
  requiredAndOptionalArg: $bindgen("bindgen_test.bind.ts", "requiredAndOptionalArg"),
  utf8Echo: $bindgen("bindgen_test.bind.ts", "utf8Echo"),
  utf8EchoLoose: $bindgen("bindgen_test.bind.ts", "utf8EchoLoose"),
  utf8Optional: $bindgen("bindgen_test.bind.ts", "utf8Optional"),
  utf8Owned: $bindgen("bindgen_test.bind.ts", "utf8Owned"),
  stringEcho: $bindgen("bindgen_test.bind.ts", "stringEcho"),
  stringLength: $bindgen("bindgen_test.bind.ts", "stringLength"),
  expectedByNode: $bindgen("bindgen_test.bind.ts", "expectedByNode"),
  expectedMessage: $bindgen("bindgen_test.bind.ts", "expectedMessage"),
  nextColor: $bindgen("bindgen_test.bind.ts", "nextColor"),
  optionsEcho: $bindgen("bindgen_test.bind.ts", "optionsEcho"),
  describeValue: $bindgen("bindgen_test.bind.ts", "describeValue"),
  describeAnything: $bindgen("bindgen_test.bind.ts", "describeAnything"),
  overloaded: $bindgen("bindgen_test.bind.ts", "overloaded"),
  describeDefaults: $bindgen("bindgen_test.bind.ts", "describeDefaults"),
  names: $bindgen("bindgen_test.bind.ts", "names"),
  bare: $bindgen("bindgen_test.bind.ts", "bare"),
  dateOf: $bindgen("bindgen_test.bind.ts", "dateOf"),
  latin1: $bindgen("bindgen_test.bind.ts", "latin1"),
  textOrBytes: $bindgen("bindgen_test.bind.ts", "textOrBytes"),
  positions: $bindgen("bindgen_test.bind.ts", "positions"),
  sumArray: $bindgen("bindgen_test.bind.ts", "sumArray"),
  range: $bindgen("bindgen_test.bind.ts", "range"),
  words: $bindgen("bindgen_test.bind.ts", "words"),
  sumBytes: $bindgen("bindgen_test.bind.ts", "sumBytes"),
  sumBytesThenText: $bindgen("bindgen_test.bind.ts", "sumBytesThenText"),
  sumBytesIfAny: $bindgen("bindgen_test.bind.ts", "sumBytesIfAny"),
  fillBuffer: $bindgen("bindgen_test.bind.ts", "fillBuffer"),
  stringOrObjectEcho: $bindgen("bindgen_test.bind.ts", "stringOrObjectEcho"),
  sumBeforeAndAfterCallback: $bindgen("bindgen_test.bind.ts", "sumBeforeAndAfterCallback"),
  callOr: $bindgen("bindgen_test.bind.ts", "callOr"),
  stringAsIsOrBytesIfAny: $bindgen("bindgen_test.bind.ts", "stringAsIsOrBytesIfAny"),
  presentUnlessEmptyString: $bindgen("bindgen_test.bind.ts", "presentUnlessEmptyString"),
  fail: $bindgen("bindgen_test.bind.ts", "fail"),
  TestCounter: $bindgen("bindgen_test.bind.ts", "TestCounter"),
  TestHolder: $bindgen("bindgen_test.bind.ts", "TestHolder"),
  TestRefCounted: $bindgen("bindgen_test.bind.ts", "TestRefCounted"),
  makeToken: $bindgen("bindgen_test.bind.ts", "makeToken"),
  bytesOf: $bindgen("bindgen_test.bind.ts", "bytesOf"),
  bytesOfOrToString: $bindgen("bindgen_test.bind.ts", "bytesOfOrToString"),
  bytesOfString: $bindgen("bindgen_test.bind.ts", "bytesOfString"),
  bytesOfRefusingStringObject: $bindgen("bindgen_test.bind.ts", "bytesOfRefusingStringObject"),
  bytesOfBufferOrBlob: $bindgen("bindgen_test.bind.ts", "bytesOfBufferOrBlob"),
  bytesOfRefusingUndefined: $bindgen("bindgen_test.bind.ts", "bytesOfRefusingUndefined"),
  bytesOfThen: $bindgen("bindgen_test.bind.ts", "bytesOfThen"),
  bytesOfThenCopyingShared: $bindgen("bindgen_test.bind.ts", "bytesOfThenCopyingShared"),
  bytesOfThenCopied: $bindgen("bindgen_test.bind.ts", "bytesOfThenCopied"),
  bytesOfAreSameMemory: $bindgen("bindgen_test.bind.ts", "bytesOfAreSameMemory"),
  bytesOfAreSameMemoryCopyingShared: $bindgen("bindgen_test.bind.ts", "bytesOfAreSameMemoryCopyingShared"),
  bytesBeforeAndAfterCallback: $bindgen("bindgen_test.bind.ts", "bytesBeforeAndAfterCallback"),
  bytesBeforeAndAfterCallbackCopyingShared: $bindgen(
    "bindgen_test.bind.ts",
    "bytesBeforeAndAfterCallbackCopyingShared",
  ),
  pinnedBytesAfterCallback: $bindgen("bindgen_test.bind.ts", "pinnedBytesAfterCallback"),
  stringAsIsOrBytes: $bindgen("bindgen_test.bind.ts", "stringAsIsOrBytes"),
  asBigInt: $bindgen("bindgen_test.bind.ts", "asBigInt"),
  integerOrBigInt: $bindgen("bindgen_test.bind.ts", "integerOrBigInt"),
  looseInteger: $bindgen("bindgen_test.bind.ts", "looseInteger"),
  looseIntegerOrBigInt: $bindgen("bindgen_test.bind.ts", "looseIntegerOrBigInt"),
  looseDoubleOrBigInt: $bindgen("bindgen_test.bind.ts", "looseDoubleOrBigInt"),
  wideIntegerOrBigInt: $bindgen("bindgen_test.bind.ts", "wideIntegerOrBigInt"),
  portOf: $bindgen("class_ref_test.bind.ts", "portOf"),
  portOfOrNull: $bindgen("class_ref_test.bind.ts", "portOfOrNull"),
  portAfterCallback: $bindgen("class_ref_test.bind.ts", "portAfterCallback"),
  describeAddressOrList: $bindgen("class_ref_test.bind.ts", "describeAddressOrList"),
  isAddress: $bindgen("class_ref_test.bind.ts", "isAddress"),
  portPlus: $bindgen("class_ref_test.bind.ts", "portPlus"),
};

export const noOpForTesting = $cpp("NoOpForTesting.cpp", "createNoOpForTesting");

/**
 * `bun test --isolate` SourceProvider cache introspection: returns the cached
 * provider's JSC sourceType name ("Module", "BunTranspiledModule", ...) for a
 * resolved specifier, or null when the specifier isn't cached.
 */
export const isolatedModuleCacheSourceType: (specifier: string) => string | null = $cpp(
  "IsolatedModuleCache.cpp",
  "createIsolatedModuleCacheSourceTypeForTesting",
);
export const Dequeue = require("internal/fifo");

// node lib/internal/util.js normalizeEncoding: nullish and '' mean utf8, and
// non-strings are undefined; Bun's Rust binding does not fold 'utf-16le',
// so the node edge cases are handled here.
const rustNormalizeEncoding = $bindgen("node_util_binding.bind.ts", "normalizeEncoding");
const nodeKEmptyObject = require("internal/shared").kEmptyObject;
function nodeNormalizeEncoding(enc) {
  if (enc == null) return "utf8";
  if (typeof enc !== "string") return undefined;
  const lower = enc.toLowerCase();
  if (lower === "utf-16le") return "utf16le";
  // The Rust map also accepts Buffer-only names node's normalizeEncoding rejects.
  if (lower === "buffer" || lower === "utf16-le") return undefined;
  return rustNormalizeEncoding(enc);
}

// Verbatim from node lib/internal/util.js (countBinaryOnes/getCIDR).
function countBinaryOnes(n) {
  // Count the number of bits set in parallel, which is faster than looping
  n = n - ((n >>> 1) & 0x55555555);
  n = (n & 0x33333333) + ((n >>> 2) & 0x33333333);
  return (((n + (n >>> 4)) & 0xf0f0f0f) * 0x1010101) >>> 24;
}

function getCIDR(address, netmask, family) {
  let ones = 0;
  let split = ".";
  let range = 10;
  let groupLength = 8;
  let hasZeros = false;
  let lastPos = 0;

  if (family === "IPv6") {
    split = ":";
    range = 16;
    groupLength = 16;
  }

  for (let i = 0; i < netmask.length; i++) {
    if (netmask[i] !== split) {
      if (i + 1 < netmask.length) {
        continue;
      }
      i++;
    }
    const part = netmask.slice(lastPos, i);
    lastPos = i + 1;
    if (part !== "") {
      if (hasZeros) {
        if (part !== "0") {
          return null;
        }
      } else {
        const binary = parseInt(part, range);
        const binaryOnes = countBinaryOnes(binary);
        ones += binaryOnes;
        if (binaryOnes !== groupLength) {
          if (binary.toString(2).includes("01")) {
            return null;
          }
          hasZeros = true;
        }
      }
    }
  }

  return `${address}/${ones}`;
}

// Verbatim from node lib/internal/util.js assignFunctionName (assert -> throw).
function assignFunctionName(name, fn, descriptor = nodeKEmptyObject) {
  if (typeof name !== "string") {
    const symbolDescription = name.description;
    if (symbolDescription === undefined) throw new Error("Attempted to name function after descriptionless Symbol");
    name = `[${symbolDescription}]`;
  }
  return Object.defineProperty(fn, "name", {
    __proto__: null,
    writable: false,
    enumerable: false,
    configurable: true,
    ...Object.getOwnPropertyDescriptor(fn, "name"),
    ...descriptor,
    value: name,
  });
}

function nodeIsError(e) {
  return require("node:util/types").isNativeError(e) || e instanceof Error;
}

// node's internal WeakReference: a WeakRef that pins the target strongly
// while its refcount is above zero.
class WeakReference {
  #ref;
  #strong = null;
  #refCount = 0;
  constructor(object) {
    this.#ref = new WeakRef(object);
  }
  get() {
    // Serving from the pinned ref (when held) is equivalent to deref() and
    // keeps the keepalive member read, not write-only.
    return this.#strong ?? this.#ref.deref();
  }
  incRef() {
    if (++this.#refCount === 1) this.#strong = this.#ref.deref();
  }
  decRef() {
    if (--this.#refCount === 0) this.#strong = null;
  }
}

// node's internal/child_process.getValidStdio, ported verbatim except that
// bun has no Pipe/TTY/TCP handle wraps: pipe entries get a closeable stand-in
// handle and wrap detection is omitted (throws ERR_INVALID_ARG_VALUE instead).
function stdioStringToArray(stdio, channel?) {
  const options: (string | number)[] = [];
  switch (stdio) {
    case "ignore":
    case "overlapped":
    case "pipe":
      options.push(stdio, stdio, stdio);
      break;
    case "inherit":
      options.push(0, 1, 2);
      break;
    default:
      throw $ERR_INVALID_ARG_VALUE("stdio", stdio);
  }
  if (channel) options.push(channel);
  return options;
}

function makeCodedError(Base: ErrorConstructor, code: string, message: string) {
  const err = new Base(message) as Error & { code: string };
  err.code = code;
  return err;
}

function nodeGetValidStdio(stdio, sync?) {
  const { isArrayBufferView } = require("node:util/types");
  let ipc;
  let ipcFd;

  if (typeof stdio === "string") {
    stdio = stdioStringToArray(stdio);
  } else if (!Array.isArray(stdio)) {
    throw $ERR_INVALID_ARG_VALUE("stdio", stdio);
  }

  while (stdio.length < 3) stdio.push(undefined);

  stdio = stdio.reduce(function reduceStdioEntry(acc, stdio, i) {
    function cleanup() {
      for (let i = 0; i < acc.length; i++) {
        if ((acc[i].type === "pipe" || acc[i].type === "ipc") && acc[i].handle) acc[i].handle.close();
      }
    }

    stdio ??= i < 3 ? "pipe" : "ignore";

    if (stdio === "ignore") {
      acc.push({ type: "ignore" });
    } else if (stdio === "pipe" || stdio === "overlapped" || (typeof stdio === "number" && stdio < 0)) {
      const a: Record<string, unknown> = {
        type: stdio === "overlapped" ? "overlapped" : "pipe",
        readable: i === 0,
        writable: i !== 0,
      };
      // node: `a.handle = new Pipe(PipeConstants.SOCKET)`; bun has no Pipe wrap.
      if (!sync) a.handle = { close() {} };
      acc.push(a);
    } else if (stdio === "ipc") {
      if (sync || ipc !== undefined) {
        cleanup();
        if (!sync) throw $ERR_IPC_ONE_PIPE();
        else throw makeCodedError(Error, "ERR_IPC_SYNC_FORK", "IPC cannot be used with synchronous forks");
      }
      ipc = { close() {} };
      ipcFd = i;
      acc.push({ type: "pipe", handle: ipc, ipc: true });
    } else if (stdio === "inherit") {
      acc.push({ type: "inherit", fd: i });
    } else if (typeof stdio === "number") {
      acc.push({ type: "fd", fd: stdio });
    } else if (typeof stdio.fd === "number") {
      const { fd } = stdio;
      acc.push({ type: "fd", fd });
    } else if (isArrayBufferView(stdio) || typeof stdio === "string") {
      if (!sync) {
        cleanup();
        const inspected = require("node:util").inspect(stdio);
        throw makeCodedError(
          TypeError,
          "ERR_INVALID_SYNC_FORK_INPUT",
          `Asynchronous forks do not support Buffer, TypedArray, DataView or string input: ${inspected}`,
        );
      }
    } else {
      cleanup();
      throw $ERR_INVALID_ARG_VALUE("stdio", stdio);
    }

    return acc;
  }, []);

  return { stdio, ipc, ipcFd };
}

let cachedInternalChildProcess;

// Userland access to node-internal modules for vendored node tests that
// declare `// Flags: --expose-internals` (served via the require interceptor
// in test/js/node/test/common/index.js). Static requires only — the builtin
// bundler cannot rewrite variable-path requires. Extend the map as more
// vendored tests need more internals.
export const exposedInternals = {
  "internal/streams/add-abort-signal": require("internal/streams/add-abort-signal"),
  "internal/util/debuglog": require("internal/util/debuglog"),
  "internal/async_context_frame": require("internal/async_context_frame"),
  "internal/async_hooks": require("internal/async_hooks"),
  "internal/webstreams/adapters": require("internal/webstreams_adapters"),
  "internal/dgram": require("internal/dgram"),
  // Bun's real implementations, under the names node's tests import them by.
  "internal/validators": require("internal/validators"),
  "internal/util/inspect": require("internal/util/inspect"),
  "internal/freelist": require("internal/freelist"),
  // Node's internal/fixed_queue module IS the FixedQueue class.
  "internal/fixed_queue": require("internal/fixed_queue").FixedQueue,
  "internal/assert/myers_diff": require("internal/assert/myers_diff"),
  // Bun's internal/errors only carries aggregateTwoErrors; the ERR_* hierarchy
  // is native, not a JS `codes` table, so nothing else is exposed here.
  "internal/errors": require("internal/errors"),
  // normalizeEncoding wraps the same Rust binding node:crypto and the
  // webstream adapters call; the rest are node's own JS helpers, ported
  // verbatim from lib/internal/util.js where Bun has no native equivalent.
  "internal/util": {
    normalizeEncoding: nodeNormalizeEncoding,
    // Bun always has crypto support compiled in.
    assertCrypto() {},
    getCIDR,
    isError: nodeIsError,
    assignFunctionName,
    kEnumerableProperty: Object.freeze({ __proto__: null, enumerable: true }),
    kEmptyObject: nodeKEmptyObject,
    WeakReference,
  },
  // Bun's EventTarget/Event/CustomEvent are the native (global) ones; node
  // keeps them in internal/event_target. kWeakHandler is Bun's real weak
  // listener symbol from internal/shared. Bun has no NodeEventTarget.
  "internal/event_target": {
    Event: globalThis.Event,
    CustomEvent: globalThis.CustomEvent,
    EventTarget: globalThis.EventTarget,
    kWeakHandler: require("internal/shared").kWeakHandler,
  },
  // ChildProcess is the real class exec()/spawn() instantiate, so vendored
  // tests can monkeypatch its prototype; getValidStdio is ported from node.
  // A getter so loading this module does not eagerly pull in child_process.
  get "internal/child_process"() {
    return (cachedInternalChildProcess ??= {
      ChildProcess: require("node:child_process").ChildProcess,
      getValidStdio: nodeGetValidStdio,
    });
  },
  "internal/fs/utils": {
    // Both are the REAL parsers the fs entry points use (FileSystemFlags::from_js
    // and args::Rm::from_js), not JS reimplementations -- vendored tests assert
    // the production behavior through these.
    stringToFlags: $newRustFunction("node_fs_binding.rs", "string_to_flags_for_testing", 1),
    validateRmOptionsSync: $newRustFunction("node_fs_binding.rs", "rm_options_for_testing", 2),
  },
  // internalBinding() is served by the registered "internal/test/binding"
  // module (src/js/internal/test/binding.ts), not from here.
};

// State of a web ReadableStream/WritableStream for vendored node tests that
// read Node's `stream[kState].state` / `.storedError` (served through the
// internal/webstreams/util shim in test/js/node/test/common/index.js).
// The stream's closed promise is settled from every terminal transition, so its
// status is the state. A WritableStream mid-`erroring` still reports "writable":
// erroring is not terminal, and nothing observable distinguishes the two here.
export function getWebStreamState(stream: ReadableStream | WritableStream): {
  state: string;
  storedError: unknown;
} {
  const closed = $webStreamClosedPromise(stream);
  switch (Bun.peek.status(closed)) {
    case "fulfilled":
      return { state: "closed", storedError: undefined };
    case "rejected":
      return { state: "errored", storedError: Bun.peek(closed) };
    default:
      return { state: $inheritsWritableStream(stream) ? "writable" : "readable", storedError: undefined };
  }
}

export const arrayBufferViewHasBuffer = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_arrayBufferViewHasBuffer",
  1,
);

export const timerInternals = {
  timerClockMs: $newRustFunction("runtime/timer/Timer.rs", "internal_bindings.timerClockMs", 0),
  monotonicNowMs: $bindgen("Timer.bind.ts", "monotonicNowMs"),
  // Sets the id of this thread's next timer. The counter can only move forward.
  setNextTimerId: $newRustFunction("runtime/timer/Timer.rs", "internal_bindings.setNextTimerId", 1) as (
    id: number,
  ) => void,
};

// Raw datagram descriptor helpers for tests that need an unbound fd (which
// the internal/dgram UDP wrap does not expose — it binds on create).
export const dgramInternals = {
  newRawSocketFd: $bindgen("udp_socket.bind.ts", "dgramNewSocketFd"),
  closeRawFd: $bindgen("udp_socket.bind.ts", "dgramCloseFd"),
};

export const decodeURIComponentSIMD = $newCppFunction(
  "decodeURIComponentSIMD.cpp",
  "jsFunctionDecodeURIComponentSIMD",
  1,
);

export const getDevServerDeinitCount = $bindgen("DevServer.bind.ts", "getDeinitCountForTesting");
export const getCounters = $newRustFunction("Counters.rs", "createCountersObject", 0);
export const linearFifoOrderedRemoveProbe = $newRustFunction(
  "collections/linear_fifo.rs",
  "TestingAPIs.orderedRemoveProbe",
  1,
) as (scenario: number) => number[];
export const hasNonReifiedStatic = $newCppFunction("InternalForTesting.cpp", "jsFunction_hasReifiedStatic", 1);

const setNativeSocketOptions: (socket: unknown, option: 1 | 2, size: number) => void = $newRustFunction(
  "runtime/socket/socket.rs",
  "jsSetSocketOptions",
  3,
);

/**
 * `setsockopt()` with `SO_SNDBUF` (`option` 1) or `SO_RCVBUF` (`option` 2) on the connection behind `socket`.
 *
 * To get backpressure without sending megabytes, shrink the send buffer of the side that sends. On loopback the kernel
 * grows the sender's buffer to its maximum (4 MiB on Linux) at once, so shrinking the receiver's buffer changes little.
 *
 * @param socket A `Bun.Socket`, a `ServerWebSocket`, a `WebSocket`, a `node:net` socket, the socket of a `node:http`
 * server's request, or a WebSocket of the `ws` package (built-in or from npm). It has to be connected.
 */
export function setSocketOptions(socket: any, option: 1 | 2, size: number): void {
  // `ws`: the stream the WebSocket runs on, or what the built-in has in its place on a native client.
  socket = socket._socket ?? socket;
  setNativeSocketOptions(
    socket[require("internal/http").kHandle] ?? socket._handle ?? socket[Symbol.for("::bunternal::")] ?? socket,
    option,
    size,
  );
}

/**
 * The syscalls instrumented in bsd.c, plus non-syscall hooks whose failure
 * paths are otherwise unreachable without injection ("ssl_loop_buffer",
 * "poll_start", "session_buffer", "ssl_write"; see fault_inject.h for the per-hook
 * description). Arming anything else is rejected.
 */
export type SocketFaultSyscall =
  | "recv"
  | "send"
  | "writev"
  | "sendmsg"
  | "recvmsg"
  | "connect"
  | "accept"
  | "ssl_loop_buffer"
  | "poll_start"
  | "session_buffer"
  | "ssl_write";

export type SocketFaultRule = {
  syscall: SocketFaultSyscall;
  action: "errno" | "short" | "zero" | "excess" | "none";
  /** errno name or numeric value (only used when action === "errno") */
  errno?:
    | "ECONNRESET"
    | "EPIPE"
    | "ETIMEDOUT"
    | "ECONNREFUSED"
    | "EAGAIN"
    | "EWOULDBLOCK"
    | "EINTR"
    | "ENOBUFS"
    | "ENOMEM"
    | "EBADF"
    | "EINVAL"
    | "ENETUNREACH"
    | "EHOSTUNREACH"
    | number;
  /** clamp recv/send length to this many bytes; required and > 0 when action === "short" */
  bytes?: number;
  /** skip the first N matching calls before triggering. Default 0. */
  after?: number;
  /** fire this many times then disarm; -1 = forever. Default 1. */
  repeat?: number;
  /** match only this fd; -1 (default) = any. Rejected for "ssl_loop_buffer" and "session_buffer", which have no fd. */
  fd?: number;
};

export const socketFaultInjection = {
  /** True when the current binary was built with `--socket-fault-injection=on` (defaults to on for ASan builds). */
  available: $newRustFunction(
    "runtime/socket/socket.rs",
    "TestingAPIs.jsSocketFaultInjectionAvailable",
    0,
  ) as () => boolean,
  /** Arm a process-wide fault rule for one usockets bsd_* syscall. */
  set: $newRustFunction("runtime/socket/socket.rs", "TestingAPIs.jsSetSocketFault", 1) as (
    rule: SocketFaultRule,
  ) => boolean,
  /** Disarm all fault rules. */
  clear: $newRustFunction("runtime/socket/socket.rs", "TestingAPIs.jsClearSocketFaults", 0) as () => void,
};

export const namedPipeInternals = {
  /**
   * Live native contexts behind sockets over Windows named pipes: one per
   * connecting or connected `Bun.connect({ unix: "\\\\.\\pipe\\..." })` socket and
   * one per accepted pipe client. Always 0 on other platforms.
   */
  liveCount: $newRustFunction("runtime/socket/socket.rs", "TestingAPIs.jsNamedPipeContextLiveCount", 0) as () => number,
};

export const duplexTLSInternals = {
  /**
   * Live native contexts behind TLS sockets that run over a JS stream
   * (`tls.connect({ socket: duplex })`, `new tls.TLSSocket(duplex)`): one per
   * socket, until the task that frees it after the close has run.
   */
  liveCount: $newRustFunction(
    "runtime/socket/socket.rs",
    "TestingAPIs.jsDuplexUpgradeContextLiveCount",
    0,
  ) as () => number,
};
type SerializationContext = "worker" | "window" | "postMessage" | "default";
export const structuredCloneAdvanced: (
  value: any,
  transferList: any[],
  forTransfer: boolean,
  forStorage: boolean,
  serializationContext: SerializationContext,
) => any = $newCppFunction("StructuredClone.cpp", "jsFunctionStructuredCloneAdvanced", 5);

export const isASANEnabled: () => boolean = $newCppFunction("InternalForTesting.cpp", "jsFunction_isASANEnabled", 0);

export const BunString_threadIsolatedCopyRefCountDelta: () => number = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_BunString_threadIsolatedCopyRefCountDelta",
  0,
);

export const BunString_makeThreadShareableRefCountDelta: () => number = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_BunString_makeThreadShareableRefCountDelta",
  0,
);

export const lowercaseHeaderNameSIMD: (name: string) => string = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_lowercaseHeaderNameSIMD",
  1,
);

export const emitMemoryPressure: (level: "warning" | "critical") => void = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_emitMemoryPressure",
  1,
);

export const isMemoryPressureWatcherInstalled: () => boolean = $newCppFunction(
  "InternalForTesting.cpp",
  "jsFunction_isMemoryPressureWatcherInstalled",
  0,
);

// `parallelism` threads each spawn `iterations` no-op threads through bun's own pthread_create,
// writing every failure to `fd`. Returns the first failing errno, or with `detach` 0 as soon as
// every loop runs; a detached loop also writes to `fd` when it runs out of iterations.
export const spawnThreadsForTesting: (iterations: number, fd: number, parallelism: number, detach?: boolean) => number =
  $newCppFunction("InternalForTesting.cpp", "jsFunction_spawnThreadsForTesting", 4);

// True when the installed watcher registered a real OS source (a PSI trigger
// on Linux). The watcher installs silently without one when the kernel
// refuses the trigger, so isMemoryPressureWatcherInstalled() cannot tell.
export const memoryPressureWatcherHasOsBackend: () => boolean = $newRustFunction(
  "memory_pressure.rs",
  "jsWatcherHasOsBackend",
  0,
);

// The exact bytes Bun writes to /proc/pressure/memory to arm its trigger.
// null where there is no PSI backend (everything except Linux).
export const memoryPressurePsiTrigger: () => Buffer | null = $newRustFunction("memory_pressure.rs", "jsPsiTrigger", 0);

// The PSI event filter: `armed` is the file at arm time, `polls` one read per POLLPRI. null off Linux.
export const memoryPressurePsiFilter: (armed: string, ...polls: string[]) => boolean[] | null = $newRustFunction(
  "memory_pressure.rs",
  "jsPsiFilter",
  1,
);

export const getEventLoopStats: () => {
  activeTasks: number;
  tasks: number;
  immediateTasks: number;
  concurrentTasksEmpty: boolean;
  concurrentRef: number;
  numPolls: number;
  loopActive: boolean;
  eventLoopAlive: boolean;
  /** usockets/libuv loop iterations so far (us_internal_loop_pre count). */
  iteration: number;
} = $newRustFunction("event_loop.rs", "getActiveTasks", 0);

export const hostedGitInfo = {
  parseUrl: $newRustFunction("hosted_git_info.rs", "TestingAPIs.jsParseUrl", 1),
  fromUrl: $newRustFunction("hosted_git_info.rs", "TestingAPIs.jsFromUrl", 1),
};

export const translateUVErrorToE: (code: number) => string | undefined = $newRustFunction(
  "sys.rs",
  "TestingAPIs.translateUVErrorToE",
  1,
);

export const translateNtStatusToE: (status: number) => string | undefined = $newRustFunction(
  "sys.rs",
  "TestingAPIs.translateNtStatusToE",
  1,
);

export const sigactionLayout: () =>
  | undefined
  | {
      installed: { handler: number; flags: number };
      readback: { handler: number; flags: number };
      sizeof: number;
    } = $newRustFunction("sys.rs", "TestingAPIs.sigactionLayout", 0);

export const stringsInternals = {
  /**
   * Calls `bun.strings.toUTF16AllocForReal(allocator, bytes, false, true)` and
   * returns the resulting UTF-16 data as a JS string. The `sentinel = true`
   * path is otherwise only reachable from Windows `bun build --compile`
   * metadata, so this binding lets us exercise it on all platforms.
   */
  toUTF16AllocSentinel: $newRustFunction("string/immutable/unicode.rs", "TestingAPIs.toUTF16AllocSentinel", 1) as (
    bytes: Uint8Array,
  ) => string,
};

/** Seed the connect-path DNS cache for `hostname` via the real `process_results` interleave; returns family order. */
export const dnsCacheSeed = $newRustFunction("runtime/dns_jsc/dns.rs", "internal.seedCacheForTesting", 2) as (
  hostname: string,
  addresses: string[],
) => number[];

/** Whether the connect-path resolver answers `hostname` with the loopback addresses itself instead of asking getaddrinfo. */
export const dnsIsLocalhostName = $newRustFunction(
  "runtime/dns_jsc/dns.rs",
  "internal.isLocalhostNameForTesting",
  1,
) as (hostname: string) => boolean;

/** Whether a getaddrinfo() answer made of `addresses` makes the connect-path resolver retry without AI_ADDRCONFIG. */
export const dnsIsAllLoopbackOfOneFamily = $newRustFunction(
  "runtime/dns_jsc/dns.rs",
  "internal.isAllLoopbackOfOneFamilyForTesting",
  1,
) as (addresses: string[]) => boolean;

/** The error a getaddrinfo lookup of `hostname` reports when getaddrinfo(3) returns the `EAI_*` status named `code` (`"EAI_AGAIN"`, `"EAI_FAIL"`, `"EAI_NONAME"`). */
export const dnsGetaddrinfoError = $newRustFunction(
  "runtime/dns_jsc/dns.rs",
  "internal.getaddrinfoErrorForTesting",
  2,
) as (code: string, hostname: string) => Error & { code: string; errno: number; syscall: string; hostname: string };

export const fetchH2Internals = {
  liveCounts: $newRustFunction("http/H2Client.rs", "TestingAPIs.liveCounts", 0) as () => {
    sessions: number;
    streams: number;
  },
};

export const fetchH3Internals = {
  liveCounts: $newRustFunction("http/H3Client.rs", "TestingAPIs.quicLiveCounts", 0) as () => {
    sessions: number;
    streams: number;
  },
};

const proxyFor = $newRustFunction("runtime/webcore/fetch.rs", "TestingAPIs.proxyFor", 2) as (
  entries: string[],
  url: string,
) => string | null;

export const proxyInternals = {
  /** Whether the `NO_PROXY` value `list` exempts `hostname` on `port`. */
  noProxyMatches: $newRustFunction("runtime/webcore/fetch.rs", "TestingAPIs.noProxyMatches", 3) as (
    list: string,
    hostname: string,
    port: number,
  ) => boolean,
  /** The proxy an environment of exactly `env` selects for `url`, or null. */
  proxyFor: (env: Record<string, string>, url: string) => proxyFor(Object.entries(env).flat(), url),
  /** What the HTTP client's URL parser makes of `href`. */
  parseURL: $newRustFunction("runtime/webcore/fetch.rs", "TestingAPIs.parseURL", 1) as (href: string) => {
    username: string;
    password: string;
    hostname: string;
    port: string;
    pathname: string;
  },
};

export const fileSinkInternals = {
  liveCount: $newRustFunction("runtime/webcore/FileSink.rs", "TestingAPIs.fileSinkLiveCount", 0) as () => number,
};

export const byteStreamInternals = {
  // Swap a ByteStream-backed stream's producer for one whose drain signal
  // re-enters on_cancel, making consumed-during-signal_drained re-entrancy
  // deterministic in tests.
  cancelOnDrain: $newRustFunction("runtime/webcore/ByteStream.rs", "TestingAPIs.byteStreamCancelOnDrain", 1) as (
    stream: ReadableStream,
  ) => void,
};

// How many internal modules (node:fs etc.) this process created from bytecode embedded by `bun build --compile
// --bytecode` instead of parsing their source.
export const internalModulesLoadedFromBytecode: () => number = $newCppFunction(
  "InternalModuleRegistry.cpp",
  "jsInternalModulesLoadedFromBytecode",
  0,
);

// Whether the source of `fn` knows where its lines start. Before anything asked for a position in it, that means they
// came with its code: from the parse, or out of the bytecode.
export const sourceHasLineStarts: (fn: Function) => boolean = $newCppFunction(
  "ZigSourceProvider.cpp",
  "jsSourceHasLineStarts",
  1,
);

// The bytecode `bun build --compile --bytecode` embeds for a builtin module, plus the external string table it embeds
// beside it: internal module number `index` (null past the last), or `source` written in builtin syntax (@-intrinsics,
// a function expression) compiled under `name`.
export const internalModuleBytecode: {
  (index: number): { name: string; bytecode: Uint8Array; strings: Uint8Array } | null;
  (source: string, name: string): { name: string; bytecode: Uint8Array; strings: Uint8Array };
} = $newCppFunction("InternalModuleRegistry.cpp", "jsInternalModuleBytecode", 2);
