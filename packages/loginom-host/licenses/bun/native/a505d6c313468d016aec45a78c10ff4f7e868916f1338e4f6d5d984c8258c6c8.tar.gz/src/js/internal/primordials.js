// TODO: Use native code and JSC intrinsics for everything in this file.
// Do not use this file for new code, many things here will be slow especailly when intrinsics for these operations is available.
// It is primarily used for `internal/util`

const ObjectSetPrototypeOf = Object.setPrototypeOf;
const ObjectFreeze = Object.freeze;

const createSafeIterator = (factory, next_) => {
  class SafeIterator {
    constructor(iterable) {
      this._iterator = factory(iterable);
    }
    next() {
      return next_(this._iterator);
    }
    [Symbol.iterator]() {
      return this;
    }
  }
  ObjectSetPrototypeOf(SafeIterator.prototype, null);
  ObjectFreeze(SafeIterator.prototype);
  ObjectFreeze(SafeIterator);
  return SafeIterator;
};

// Intrinsics do not have `call` as a valid identifier, so this cannot be `Function.prototype.call.bind`.
const FunctionPrototypeCall = $getByIdDirect(Function.prototype, "call");
const ObjectPrototypeHasOwnProperty = FunctionPrototypeCall.bind(Object.prototype.hasOwnProperty);

function getGetter(cls, getter) {
  // TODO: __lookupGetter__ is deprecated, but Object.getOwnPropertyDescriptor doesn't work on built-ins like Typed Arrays.
  return FunctionPrototypeCall.bind(cls.prototype.__lookupGetter__(getter));
}

function uncurryThis(func) {
  // Intrinsics do not have `call` as a valid identifier, so this cannot be `Function.prototype.call.bind`.
  return FunctionPrototypeCall.bind(func);
}

const copyProps = (src, dest) => {
  const keys = Reflect.ownKeys(src);
  for (let i = 0; i < keys.length; i++) {
    const key = keys[i];
    if (!ObjectPrototypeHasOwnProperty(dest, key)) {
      Reflect.defineProperty(dest, key, Reflect.getOwnPropertyDescriptor(src, key));
    }
  }
};

const SymbolIterator = Symbol.iterator;
/**
 * @template T
 * @param {Function} unsafe
 * @param {T} safe
 * @returns {T}
 */
const makeSafe = (unsafe, safe) => {
  const unsafePrototype = unsafe.prototype;
  const safePrototype = safe.prototype;
  if (SymbolIterator in unsafePrototype) {
    const dummy = new unsafe();
    let next; // We can reuse the same `next` method.

    const keys = Reflect.ownKeys(unsafePrototype);
    for (let i = 0; i < keys.length; i++) {
      const key = keys[i];
      if (ObjectPrototypeHasOwnProperty(safePrototype, key)) continue;
      const desc = Reflect.getOwnPropertyDescriptor(unsafePrototype, key);
      if (typeof desc.value === "function" && desc.value.length === 0) {
        const called = desc.value.$call(dummy) || {};
        if (SymbolIterator in (typeof called === "object" ? called : {})) {
          const createIterator = uncurryThis(desc.value);
          next ??= uncurryThis(createIterator(dummy).next);
          const SafeIterator = createSafeIterator(createIterator, next);
          desc.value = function () {
            return new SafeIterator(this);
          };
        }
      }
      Reflect.defineProperty(safePrototype, key, desc);
    }
  } else copyProps(unsafePrototype, safePrototype);
  copyProps(unsafe, safe);

  Object.setPrototypeOf(safePrototype, null);
  Object.freeze(safePrototype);
  Object.freeze(safe);
  return safe;
};

const StringIterator = uncurryThis(String.prototype[Symbol.iterator]);
const StringIteratorPrototype = Reflect.getPrototypeOf(StringIterator(""));
const ArrayPrototypeSymbolIterator = uncurryThis(Array.prototype[Symbol.iterator]);
const ArrayIteratorPrototypeNext = uncurryThis(Array.prototype[Symbol.iterator]().next);
const SafeArrayIterator = createSafeIterator(ArrayPrototypeSymbolIterator, ArrayIteratorPrototypeNext);

const PromisePrototypeThen = $Promise.prototype.$then;
const PromiseResolve = Promise.$resolve.bind(Promise);
// Shared scheduler for SafePromiseAllReturnVoid/ReturnArrayLike: `returnVal`
// is null for the void variant (no result bookkeeping, resolves with nothing).
const safePromiseAllCollect = (promises, mapFn, returnVal) =>
  new Promise((resolve, reject) => {
    const { length } = promises;

    if (length === 0) resolve(returnVal ?? undefined);

    let pendingPromises = length;
    for (let i = 0; i < length; i++) {
      const promise = mapFn != null ? mapFn(promises[i], i) : promises[i];
      PromisePrototypeThen.$call(
        PromiseResolve(promise),
        result => {
          if (returnVal !== null) returnVal[i] = result;
          if (--pendingPromises === 0) resolve(returnVal ?? undefined);
        },
        reject,
      );
    }
  });
const SafePromiseAllReturnVoid = (promises, mapFn) => safePromiseAllCollect(promises, mapFn, null);
const SafePromiseAllReturnArrayLike = (promises, mapFn) => {
  const returnVal = Array(promises.length);
  ObjectSetPrototypeOf(returnVal, null);
  return safePromiseAllCollect(promises, mapFn, returnVal);
};

export default {
  SafeArrayIterator,
  MapPrototypeGetSize: getGetter(Map, "size"),
  SafeStringIterator: createSafeIterator(StringIterator, uncurryThis(StringIteratorPrototype.next)),
  SafeMap: makeSafe(
    Map,
    class SafeMap extends Map {
      constructor(i) {
        super(i);
      }
    },
  ),
  SafePromiseAllReturnArrayLike,
  SafePromiseAllReturnVoid,
  SafeSet: makeSafe(
    Set,
    class SafeSet extends Set {
      constructor(i) {
        super(i);
      }
    },
  ),
  SafeWeakMap: makeSafe(
    WeakMap,
    class SafeWeakMap extends WeakMap {
      constructor(i) {
        super(i);
      }
    },
  ),
  SetPrototypeGetSize: getGetter(Set, "size"),
  TypedArrayPrototypeGetBuffer: getGetter(Uint8Array, "buffer"),
  TypedArrayPrototypeGetByteLength: getGetter(Uint8Array, "byteLength"),
  TypedArrayPrototypeGetByteOffset: getGetter(Uint8Array, "byteOffset"),
  TypedArrayPrototypeGetLength: getGetter(Uint8Array, "length"),
  TypedArrayPrototypeGetSymbolToStringTag: getGetter(Uint8Array, Symbol.toStringTag),
  Uint8ClampedArray,
  Uint8Array,
  Uint16Array,
  Uint32Array,
  Int8Array,
  Int16Array,
  Int32Array,
  Float16Array,
  Float32Array,
  Float64Array,
  BigUint64Array,
  BigInt64Array,
  uncurryThis,
};
